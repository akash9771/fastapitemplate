from importlib import util
import subprocess


def import_non_local(name, custom_name=None):
    import imp, sys
    custom_name = custom_name or name
    f, pathname, desc = imp.find_module(name, sys.path[1:])  # openai python module excludes first element i.e cwd
    print(f, pathname, desc)
    module = imp.load_module(custom_name, f, pathname, desc)
    return module


openai = import_non_local('openai', 'openai')
