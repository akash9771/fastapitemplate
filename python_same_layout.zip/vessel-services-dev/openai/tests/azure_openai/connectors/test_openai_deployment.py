from unittest import TestCase

from app.azure_openai.utils.connectors.openai.deployment import openai_deployment


class TestOpenAIDeployment(TestCase):

    async def test_list_deployment(self):
        response = await openai_deployment.list()
        assert len(response)