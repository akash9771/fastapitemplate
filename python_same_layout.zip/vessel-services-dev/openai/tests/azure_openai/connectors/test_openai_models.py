from unittest import TestCase

from app.azure_openai.utils.connectors.openai.model import openai_model


class TestOpenAIModels(TestCase):

    async def test_list(self):

        models = await openai_model.list()
        assert len(models) > 0