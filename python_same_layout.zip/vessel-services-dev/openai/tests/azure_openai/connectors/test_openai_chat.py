from unittest import TestCase
import pytest


from app.azure_openai.utils.connectors.openai.chat import openai_chat



class TestOpenAIChat(TestCase):

    @pytest.mark.asyncio
    async def test_chat(self):
        messages = [
            {
                "role": "system",
                "content": "You are a digital assistant for Pfizer Inc",
            },
            {"role": "user", "content": "what is virus ? ? ?"},
        ]

        response = await openai_chat.chat(model="gpt-35-turbo", messages=messages, temperature=0, tokens=1000)
        assert response.status == "success"