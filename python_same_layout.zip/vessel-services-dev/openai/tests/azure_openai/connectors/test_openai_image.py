from unittest import TestCase

from app.azure_openai.utils.connectors.openai.image import openai_image


class TestOpenAIImage(TestCase):

    async def test_generate_image(self):
        response = await openai_image.image_generation(prompt="A cat and a dog", size="1024x1024", n=5, format="b64_json")
        assert len(response) > 0