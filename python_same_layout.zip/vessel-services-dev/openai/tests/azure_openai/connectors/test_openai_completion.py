from unittest import TestCase

from app.azure_openai.utils.connectors.openai.completion import openai_completion


class TestOpenAICompletion(TestCase):

    async def test_completion(self):
        response = await openai_completion.completion(model="gpt-35-turbo",
                                                prompt="what is the capital of India?",
                                                tokens=5,
                                                temperature=0)
        assert response.status == "success"

    async def test_summarize(self):
        response = await openai_completion.summarize(model="gpt-35-turbo",
                                               prompt="what is the capital of India?",
                                               temperature=0,
                                               tokens=5)

        assert response.status == "success"

    async def test_press_release(self):
        response = await openai_completion.press_release(model="gpt-35-turbo",
                                                   prompt="what is the capital of India?",
                                                   temperature=0,
                                                   tokens=5)
        assert response.status == "success"
