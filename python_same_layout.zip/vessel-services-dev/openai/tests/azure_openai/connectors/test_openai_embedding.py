from unittest import TestCase

from app.azure_openai.utils.connectors.openai.embedding import openai_embedding


class TestOpenAIEmbedding(TestCase):

    async def test_embedding(self):

        response = await openai_embedding.embeddings(deployment_id="text-embedding-ada-002", input="hello there")
        assert response.status == "success"