import unittest

from app.azure_openai.v1.api import *
from app.azure_openai.v1.models import Response


class TestResponse(unittest.TestCase):
    def setUp(self):
        self.response = Response(status="success", result="Sample Response", totalTokens=30)

    def test_getitem(self):
        self.assertEqual(self.response['status'], 'success')
        self.assertEqual(self.response['result'], 'Sample Response')
        self.assertEqual(self.response['totalTokens'], 30)
