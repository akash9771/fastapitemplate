import logging
import unittest
from functools import wraps
import urllib.parse

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

import boto3
import uuid
import json

import pytest
from unittest.mock import patch, Mock, MagicMock
import os
from requests.models import Response

from moto import mock_sns

from app.azure_openai.v1.util import send_to_sns, prepare_payload, audit

# with open("tests/fixtures/final_response.json") as response:
#     response = response.read()
#     print("Response from file", response)

print("Util Test file called")
AUDIT_SNS = os.getenv("AUDIT_SNS", "testarn")


@mock_sns
class TestSns(unittest.IsolatedAsyncioTestCase):

    def setUp(self) -> None:
        self.sns_client = boto3.client("sns", region_name="us-east-1")
        self.sns_client.create_topic(Name="some-topic")
        response = self.sns_client.list_topics()
        self.sns_arn = AUDIT_SNS
        print("sns arn", self.sns_arn)

    @pytest.mark.asyncio
    async def test_send_to_sns(self):
        message = {"request_id": "123"}
        expected_response = {"MessageId": "2345"}

        result = await send_to_sns(message)
        print("Result is ", result)

    @pytest.mark.asyncio
    async def test_prepare_payload(self):
        request = {"prompt": "hello", "max_tokens": 2466, "temperature": 0.8, "engine": "text-davinci-003"}
        response = {
            "status_code": 200,
            "status": "success",
            "message": "result",
            "data": {
                "result": ".cpp\n §§ 1000\n#include <iostream>\n\nusing namespace std;\n\nint main() {\n\tcout << \"Hello World!\" << endl;\n\n\treturn 0;\n}\n §§ COM\nUpdate hello.cpp\n §§ --- hello.cpp\n-\tcout << \"Hello World!\" << endl;\n §§ 1005\n+\tcout << \"Hello World! I am new to github!\" << endl;\n",
                "totalTokens": 100
            }
        }

        r = json.dumps(response)
        headers = {'x-forwarded-for': '162.48.27.4', 'x-forwarded-proto': 'https', 'x-forwarded-port': '443',
                   'host': 'vsl.pfizer.com', 'x-amzn-trace-id': 'Root=1-64e62194-17b8a4670ce2b16118939d32',
                   'content-length': '86', 'user-agent': 'PostmanRuntime/7.32.3', 'accept': '*/*',
                   'postman-token': 'd1b94cd4-497a-4061-b6fe-ac9d7aea579f', 'accept-encoding': 'gzip, deflate, br',
                   'x_agw_api_id': '18357216', 'x_agw_request_time': '2023-08-23T15:11:16.829Z[UTC]',
                   'x-agw-client_id': '0652fba7b33e422c8c87a543822ff7e2',
                   'x-correlation-id': '4e9355c0-41c7-11ee-a6d8-02c967beb9b5',
                   'authorization': 'Bearer 0001wFWHBAkWfPskLpwKcx8mpBt5',
                   'x-dynatrace': 'FW4;1317850380;2;1060694007;5450432;3;284457379;725;45a9;2h01;3h3f38e7f7;4h532ac0;5h01;6h143c20d0ad801baf83d1e5c395c23816;7hc1a709484096cb63',
                   'traceparent': '00-143c20d0ad801baf83d1e5c395c23816-c1a709484096cb63-01',
                   'tracestate': '10f479a3-4e8ccd0c@dt=fw4;2;3f38e7f7;532ac0;3;0;0;2d5;45a9;2h01;3h3f38e7f7;4h532ac0;5h01;6h143c20d0ad801baf83d1e5c395c23816;7hc1a709484096cb63',
                   'content-type': 'application/json'}
        final_payload = {
            "request_id": str(uuid.uuid4()),
            "api_id": "18357216",
            "client_id": "0652fba7b33e422c8c87a543822ff7e2",
            "request_time": "2023-08-23T15:11:16.829Z[UTC]",
            "correlation - id": "4e9355c0-41c7-11ee-a6d8-02c967beb9b5",
            "endpoint": "https://test.com/embeddings",
            "request": "request"
        }
        # with self.assertRaises(Exception):
        urll = "https://test.com/embeddings"
        urllll = urllib.parse.urlparse(urll)
        final_response = await prepare_payload(request=request, response=r, headers=headers, url=urllll)
        assert type(final_response) == type(final_payload)

    @pytest.mark.asyncio
    async def test_prepare_payload_nonembeddings(self):
        request = {"prompt": "hello", "max_tokens": 2466, "temperature": 0.8, "engine": "text-davinci-003"}
        resp = Response()
        resp.encoding = 'ascii'
        resp._content = b'{"x": 100}'
        print(resp.json)
        response = {
            "status_code": 200,
            "status": "success",
            "message": "result",
            "data": {
                "result": ".cpp\n §§ 1000\n#include <iostream>\n\nusing namespace std;\n\nint main() {\n\tcout << \"Hello World!\" << endl;\n\n\treturn 0;\n}\n §§ COM\nUpdate hello.cpp\n §§ --- hello.cpp\n-\tcout << \"Hello World!\" << endl;\n §§ 1005\n+\tcout << \"Hello World! I am new to github!\" << endl;\n",
                "totalTokens": 100
            }
        }
        r = json.dumps(response).encode('ascii')

        headers = {'x-forwarded-for': '162.48.27.4', 'x-forwarded-proto': 'https', 'x-forwarded-port': '443',
                   'host': 'vsl.pfizer.com', 'x-amzn-trace-id': 'Root=1-64e62194-17b8a4670ce2b16118939d32',
                   'content-length': '86', 'user-agent': 'PostmanRuntime/7.32.3', 'accept': '*/*',
                   'postman-token': 'd1b94cd4-497a-4061-b6fe-ac9d7aea579f', 'accept-encoding': 'gzip, deflate, br',
                   'x_agw_api_id': '18357216', 'x_agw_request_time': '2023-08-23T15:11:16.829Z[UTC]',
                   'x-agw-client_id': '0652fba7b33e422c8c87a543822ff7e2',
                   'x-correlation-id': '4e9355c0-41c7-11ee-a6d8-02c967beb9b5',
                   'authorization': 'Bearer 0001wFWHBAkWfPskLpwKcx8mpBt5',
                   'x-dynatrace': 'FW4;1317850380;2;1060694007;5450432;3;284457379;725;45a9;2h01;3h3f38e7f7;4h532ac0;5h01;6h143c20d0ad801baf83d1e5c395c23816;7hc1a709484096cb63',
                   'traceparent': '00-143c20d0ad801baf83d1e5c395c23816-c1a709484096cb63-01',
                   'tracestate': '10f479a3-4e8ccd0c@dt=fw4;2;3f38e7f7;532ac0;3;0;0;2d5;45a9;2h01;3h3f38e7f7;4h532ac0;5h01;6h143c20d0ad801baf83d1e5c395c23816;7hc1a709484096cb63',
                   'content-type': 'application/json'}
        final_payload = {
            "request_id": str(uuid.uuid4()),
            "api_id": "18357216",
            "client_id": "0652fba7b33e422c8c87a543822ff7e2",
            "request_time": "2023-08-23T15:11:16.829Z[UTC]",
            "correlation - id": "4e9355c0-41c7-11ee-a6d8-02c967beb9b5",
            "endpoint": "https://test.com/chat",
            "request": "request",
            "response": "response"
        }
        urll = "https://test.com/chat"
        urllll = urllib.parse.urlparse(urll)
        final_response = await prepare_payload(request=request, response=resp, headers=headers, url=urllll)
        assert type(final_response) == type(final_payload)