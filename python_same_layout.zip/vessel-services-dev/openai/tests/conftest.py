import os


def pytest_configure():
    os.environ["REDIS_HOST_PORT"] = "rediss://localhost:6379"
    os.environ["REDIS_PASSWORD"] = ""
    os.environ["TEST_MODE"] = "True"
