# Vessel OpenAI Service

Vessel Service for communicating with Azure OpenAI resources

## Models

## Deployments

### Completion

### Chat

### Embeddings

### Completion

### Chat

## Completion

## Chat

### Install libzip

pip install ../utils/libzip/
