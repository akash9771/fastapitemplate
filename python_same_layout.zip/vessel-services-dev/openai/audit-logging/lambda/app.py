import json
import os
import datetime
import boto3

AUDIT_BUCKET = os.getenv("AUDIT_BUCKET", "")


def push_to_s3(payload):
    try:
        # Pushing payload to S3 bucket
        s3 = boto3.resource("s3")
        file_name = payload['request_id']
        client_id = payload['client_id']
        log_date = datetime.date.today()
        log_year = log_date.year
        # preparing path of file
        file_path = f"{client_id}/{log_year}/{file_name}.json"

        payload_string = json.dumps(payload)
        s3response = s3.Bucket(AUDIT_BUCKET).put_object(
            Key=file_path,
            Body=payload_string
        )
        print("S3 response ", s3response)
    except Exception as e:
        print(f"Error while uploading file to S3:{str(e)}")
        raise e


def handler(event, context):
    try:
        # Lopping over event. In some case event may have multiple message.
        for ev in event["Records"]:
            body = ev["body"]
            json_body = json.loads(body)
            push_to_s3(json_body)

    except Exception as e:
        print(f"Error while in lambda {str(e)}")
        return {
            "status": "error",
            "data": e,
            "message": e.orig.args if hasattr(e, "orig") else f"{e}",
        }
