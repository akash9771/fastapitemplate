from fastapi import FastAPI
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.cors import CORSMiddleware
import logging
from app.azure_openai.v1.api import router as openai_v1
from fastapi.openapi.utils import get_openapi
import json
from contextlib import asynccontextmanager
import os

# OpenTelemetry Configuration
# Basic packages for your application
# Add imports for OTel components into the application
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource, get_aggregated_resources
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.sdk.extension.aws.resource import AwsEcsResourceDetector
from opentelemetry.semconv.resource import ResourceAttributes

# Import the AWS X-Ray for OTel Python IDs Generator into the application.
from opentelemetry.sdk.extension.aws.trace import AwsXRayIdGenerator

# Import the AWS X-Ray for OTel Python IDs Generator into the application.
from opentelemetry.sdk.extension.aws.trace import AwsXRayIdGenerator

# Import the httx, requests, boto3 instrumentors
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor

# Import the AWS X-Ray propagator into the application
from opentelemetry.propagate import set_global_textmap
from opentelemetry.propagators.aws.aws_xray_propagator import AwsXRayPropagator




SERVER_ENV = os.environ.get("SERVER_ENV", "dev")
SERVER_REGION = os.environ.get("SERVER_REGION", "us-east-1")

PREFIX_V1 = "/openai"
TAGS_METADATA = [
    {
        "name": "Deployments",
        "description": """Get models supported by each usecase type.""",
    },
    {
        "name": "Models",
        "description": """Get details of each model - their modality.""",
    },
    {
        "name": "Featured Endpoints",
        "description": """list of services actively supported by vessel.""",
    },
    {
        "name": "Preview",
        "description": """List of services in active deployment from vsl or openai""",
    },
    {
        "name": "Health Check",
        "description": """Use this to know the availability of the vessel's openai service availablity.""",
    },
]

@asynccontextmanager
async def lifespan(app: FastAPI):
    with open("mule_openapi.json", "w") as f:
        openapi_data = get_openapi(
            title=app.title,
            version=app.version,
            openapi_version=app.openapi_version,
            description=app.description,
            routes=app.routes,
            tags=app.openapi_tags,
            contact=app.contact,
            summary=app.summary,
        )

        # Replace all occurrences of "/openapi/" with "/vessel-openai-api-v1/"
        openapi_data_str = json.dumps(openapi_data)
        openapi_data_str = openapi_data_str.replace(
            "/openai/", "/vessel-openai-api-v1/"
        )

        # Save the modified data to the file
        f.write(openapi_data_str)
    yield
    os.remove("mule_openapi.json")


app = FastAPI(
    lifespan=lifespan,
    title=f"Vessel | Azure OpenAI Services | {SERVER_ENV} | {SERVER_REGION}",
    openapi_tags=TAGS_METADATA,
    swagger_ui_parameters={
        "defaultModelsExpandDepth": -1,
        "syntaxHighlight.theme": "tomorrow-night",
        "persistAuthorization": True,
    },
    version="1.1",
    contact={
        "name": "VOX Team",
        "email": "DL-IAS-Platform-Operations@pfizer.com; dl-vox-dev@pfizer.com",
    },
    summary="Access to the Azure's secure OpenAI endpoints.",
    # description="#### Access to the Azure's secure OpenAI endpoints.",
    openapi_url=PREFIX_V1 + "/openapi.json",
    docs_url=PREFIX_V1 + "/vsl-docs",
)

TRACING_ENABLED = os.environ.get("TRACING_ENABLED")

if TRACING_ENABLED =='ENABLED':
    # Sends generated traces in the OTLP format to an ADOT Collector running on port 4317
    otlp_exporter = OTLPSpanExporter(endpoint="127.0.0.1:4317", insecure=True)
    # Processes traces in batches as opposed to immediately one after the other
    span_processor = BatchSpanProcessor(otlp_exporter)
    # Configures the Global Tracer Provider
    trace.set_tracer_provider(
        TracerProvider(
            active_span_processor=span_processor,
            id_generator=AwsXRayIdGenerator(),
            resource=get_aggregated_resources(
                initial_resource=Resource(
                    attributes={"service.name": f"{SERVER_ENV}-xray-openai"}
                ),
                detectors=[AwsEcsResourceDetector()],
            ),
        )
    )

    # Set the global propagator to AwsXRayPropagator
    set_global_textmap(AwsXRayPropagator())

    # Instrument httpx
    HTTPXClientInstrumentor().instrument()

    # Instrument requests
    RequestsInstrumentor().instrument()

    FastAPIInstrumentor.instrument_app(app)

app.include_router(openai_v1, prefix=PREFIX_V1)
# app.add_middleware(GZipMiddleware, minimum_size=500)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    logging.getLogger().warning("Start up !")
    # taskUrl = "{0}/task".format(os.environ.get('ECS_CONTAINER_METADATA_URI_V4'))
    # res = requests.get(taskUrl)
    # availabilityZone = json.loads(res.content)['AvailabilityZone']
    # logging.getLogger().warning(availabilityZone)
    # regions = json.loads(os.environ.get('OPENAI_REGIONS'))
    # openai.api_key = regions[availabilityZone]['api_key']
    # openai.api_base = regions[availabilityZone]['api_base']
    # logging.getLogger().warning(regions)
    # logging.getLogger().warning(openai.api_base)
    # logging.getLogger().warning(openai.api_key)
