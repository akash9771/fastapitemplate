import os

from app.azure_openai.utils.connectors.openai.openai_connector import azure_deployment_client

file_name = os.path.expanduser("~") +"/extract_models_deprecated.csv"
if os.path.exists(file_name):
    os.remove(file_name)

clients = azure_deployment_client.accounts.list()

with open(file_name,"w") as f:
    f.write('resource_group_name, account_name, region, deployment_name, model_name, kind, model_format, version, max_capacity, deprecation_fina_tune, deprecation_inference\n')
    for client in clients:
        resource_group_name = client.id.split('/')[4]
        deployments = azure_deployment_client.deployments.list(resource_group_name=resource_group_name, account_name=client.name)
        deployments = list(deployments)
        models = azure_deployment_client.models.list(client.location)
        models = list(models)
        for deployment in deployments:
            items = list(filter(lambda x: x.model.name == deployment.properties.model.name and x.kind == deployment.properties.model.format and x.model.version == deployment.properties.model.version, models))
            for item in items:
                f.write(
                f"{resource_group_name}, {client.name}, {client.location}, "
                f"{deployment.name},  {item.model.name}, "
                f"{item.kind}, {item.model.format}, {item.model.version}, {item.model.max_capacity}, "
                f"{item.model.deprecation.fine_tune}, {item.model.deprecation.inference}\n")
