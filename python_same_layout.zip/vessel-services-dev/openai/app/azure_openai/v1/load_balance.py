import random
import httpx
import json
from app.azure_openai.utils import (
    SERVER_ENV,
    REDIS_HOST_PORT,
    REDIS_PASSWORD,
    logger,
    VISION_API_VERSION_PREVIEW,
)
import redis
from redis.cluster import RedisCluster
from redis.exceptions import RedisClusterException
from dotenv import load_dotenv
from fastapi.responses import JSONResponse
from fastapi.exceptions import HTTPException

load_dotenv()

http_client = httpx.AsyncClient(timeout=220)
config_key = f"{SERVER_ENV.lower()}-vsl-failover-lb:openai:default"


class RedisClient:
    def __init__(
        self,
        host_port=REDIS_HOST_PORT,
        password=REDIS_PASSWORD,
        encoding="utf8",
        decode_responses=True,
    ):
        self.host_port = host_port
        self.password = password
        self.encoding = encoding
        self.decode_responses = decode_responses
        self.redis = None

    def connect(self):
        try:
            self.redis = RedisCluster.from_url(
                f"{self.host_port}",
                password=self.password,
                encoding=self.encoding,
                decode_responses=self.decode_responses,
            )
            pong = self.redis.ping()
            logger.info(f"Connected to Redis: {pong}")
        except RedisClusterException as e:
            logger.error(
                "Cluster mode is not enabled on this redis - trying standard mode"
            )
            self.redis = redis.from_url(
                f"{self.host_port}",
                password=self.password,
                encoding=self.encoding,
                decode_responses=self.decode_responses,
            )
            pong = self.redis.ping()
            logger.info(f"Connected to Redis: {pong}")
        except Exception as e:
            logger.error(f"Failed connecting to Redis: {str(e)}")
            raise

    def close(self):
        if self.redis:
            self.redis.close()
            self.redis = None


def fetch_deployment_config(deployment_name):
    redis_client = RedisClient()
    redis_client.connect()
    print(f"deployment_name::::::::::: {deployment_name} - config_key: {config_key}")
    config_data = redis_client.redis.get(config_key)
    # print(config_data)
    if config_data:
        config_data = json.loads(config_data)

        deployment_config = config_data["default"]["openai"].get(
            str(deployment_name), None
        )
        if deployment_name:
            return deployment_config
    return None


async def make_lb_request(
    deployment_name: str,
    json_body,
):
    deployment_config = fetch_deployment_config(deployment_name)
    # print(f"deployment_config::::::::::: {deployment_config} {type(deployment_config)}")
    error = ""
    if deployment_config:
        used_configs = []
        for region_config in deployment_config:
            if region_config in used_configs:
                continue
            used_configs.append(region_config)
            # print(region_config)
            region_endpoint = region_config[
                "resource_endpoint"
            ]  # https://pfe-openai-dev-weu.openai.azure.com/
            api_key = region_config["api-keys"]["key2"]
            try:
                endpoint_url = f"{region_endpoint}openai/deployments/{deployment_name}/chat/completions?api-version={VISION_API_VERSION_PREVIEW}"
                headers = {
                    "Content-Type": "application/json",
                    "api-key": api_key,
                }
                response = await http_client.post(
                    endpoint_url, headers=headers, json=json_body
                )
                print(
                    f"LB request for deployment {deployment_name} served from {region_endpoint}"
                )

                if response.status_code in [408, 409, 429, 500, 503]:
                    print(
                        f"Error status code from Azure - {region_endpoint} - {str(response.status_code)} {str(response.text)}- Retrying..."
                    )
                    continue
                elif response.status_code == 200:
                    return response.json()
                else:
                    raise ValueError(f"{str(response.text)}")
            except Exception as e:
                print(f"Error occurred: {str(e)}")
                error = e
                raise ValueError(
                    f"{str(e)}"
                )  # Continue to the next config in case of error
        raise ValueError(
            f"OOPS! ran out of valid LB-configs! | Retry - {len(deployment_config)} | {str(error)}"
        )
    raise ValueError("No cached LB configurations")
