import os, base64

import json
from typing import List

import fastapi
import httpx
import tiktoken
from fastapi import APIRouter, HTTPException, Depends, Body
from fastapi import Request as fastapi_request
from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.responses import StreamingResponse, FileResponse
from fastapi.security.api_key import APIKeyHeader
from validator.decorators import async_token_validation_and_metering
from app.azure_openai.v1.load_balance import make_lb_request
from app.azure_openai.utils.mgmt_export import get_mgmt_export_data
from fastapi.background import BackgroundTasks

from app.azure_openai.utils import (
    logger,
    MULESOFT_CHAT_ENDPOINT,
    API_VERSION_STABLE,
    SERVER_ENV,
    SERVER_REGION,
    MULESOFT_COMPLETION_ENDPOINT,
    MULESOFT_EMBEDDINGS_ENDPOINT,
    GPT4_VISION_KEY,
    VISION_ENDPOINT,
    TEMP_VISION_MODEL_NAME,
    API_VERSION_PREVIEW,
    VISION_API_VERSION_PREVIEW,
    API_VERSION_EMBEDDINGS,
)
from app.azure_openai.utils.connectors.metering.metering_connector import push_metrics
from app.azure_openai.utils.connectors.openai.chat import openai_chat
from app.azure_openai.utils.connectors.openai.completion import openai_completion
from app.azure_openai.utils.connectors.openai.deployment import openai_deployment
from app.azure_openai.utils.connectors.openai.embedding import openai_embedding
from app.azure_openai.utils.connectors.openai.image import openai_image
from app.azure_openai.utils.connectors.openai.model import openai_model
from app.azure_openai.utils.connectors.sns.sns_connector import push_audit_log
from app.azure_openai.v1.examples import (
    ImageRequestExample,
    completionRequestExample,
    chatCompletionRequestExample,
    embeddingsRequestExample,
)
from app.azure_openai.v1.models import (
    Model,
    Deploy,
    Response,
    Request,
    CompletionRequest,
    Status,
    HealthCheckResponse,
    ChatRequest,
    EmbeddingsRequest,
    ImageRequest,
)
from app.azure_openai.v1.util import audit

access_token_header = APIKeyHeader(
    name="Authorization",
    description="access_token generated from your client-id and client secret. Prefix 'Bearer ' before the token eg: Bearer 123567",
)

router = APIRouter()


client = httpx.AsyncClient(timeout=220)


@router.get(
    "/health_check", status_code=200, tags=["Health Check"], summary="server up/down"
)
async def health_check():
    print("health check -- ")
    return HealthCheckResponse(
        status=Status.success, message="health_check completed successfully"
    )


@router.get("/mule_openapi.json", include_in_schema=False)
async def openapijson():
    with open("mule_openapi.json", "r") as openapifile:
        data = json.loads(openapifile.read())
    return data


@router.get("/docs", include_in_schema=False)
async def documentation():
    server_env = SERVER_ENV
    server_region = SERVER_REGION

    region_mapping = {
        "eu-central-1": "emea",
        "us-east-1": "amer",
    }

    env_mapping = {
        "test": "-stg",
        "prod": "",
    }

    server_region = region_mapping.get(server_region, "amer")
    server_env = env_mapping.get(server_env, "-dev")

    openapi_url = f"https://mule4api-comm-{server_region}{server_env}.pfizer.com/vessel-openai-api-v1/mule_openapi.json"

    return get_swagger_ui_html(
        # openapi_url="http://localhost:8000/openai/openapi.json",
        openapi_url=openapi_url,
        title="IAS - Vessel",
    )


# Vessel Completion endpoint
@router.post(
    "/vessel_completion",
    status_code=200,
    tags=["Completion"],
    response_model=Response,
    include_in_schema=False,
)
async def vessel_completion(request: fastapi_request, req: Request):
    try:

        return await openai_completion.completion(
            model=req.engine,
            prompt=req.prompt,
            temperature=req.temperature,
            tokens=req.max_tokens,
        )
    except Exception as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.post(
    "/completion",
    status_code=200,
    tags=["Featured Endpoints"],
    response_model=Response,
    summary="Given a prompt, the model will generate new texts. Will be deprecated soon - Use chatCompletion endpoint which supports newer models.",
)
@audit()
@async_token_validation_and_metering(uom=6)
async def completion(
    request: fastapi_request,
    req: CompletionRequest = Body(openapi_examples=completionRequestExample),
    access_key=Depends(access_token_header),
):
    try:
        headers = prepare_header(request)

        payload = {
            "prompt": req.prompt,
            "max_tokens": req.max_tokens,
            "temperature": req.temperature,
            # Optional Parameters
            "top_p": req.top_p,
            "n": req.n,
            # "stream": req.stream,
            "frequency_penalty": req.frequency_penalty,
            "presence_penalty": req.presence_penalty,
        }
        if req.logit_bias:
            payload["logit_bias"] = req.logit_bias
        if req.suffix:
            payload["suffix"] = req.suffix
        if req.stop:
            payload["stop"] = req.stop
        # below params are not supported in latest gpt models
        # if req.logprobs:
        #     payload["logprobs"] = req.logprobs
        if req.echo:
            payload["echo"] = req.echo
        if req.best_of:
            payload["best_of"] = req.best_of
        url = MULESOFT_COMPLETION_ENDPOINT.format(req.engine, API_VERSION_STABLE)
        # logger.warning("{0}\n{1}\n{2}".format(url, payload, headers))
        response = await client.post(
            url=url, json=payload, headers=headers, timeout=220
        )
        response.raise_for_status()
        result = response.json()

        return Response(
            status=Status.success,
            result=(
                result["choices"][0]["text"]
                if req.n == 1
                else json.dumps([i["text"] for i in result["choices"]])
            ),
            totalTokens=result["usage"]["total_tokens"],
        )
    except httpx.TimeoutException as e:
        logger.error(f"MuleSoft Completion Timeout: {e}")
        raise HTTPException(
            status_code=408, detail=f"Error: MuleSoft Completion Timeout"
        )
    except Exception as e:
        logger.error(f"ERROR completion: {str(e)}")
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(
            status_code=error_code, detail=f"Error completion: {error_text}"
        )


def prepare_header(request):
    headers = {
        key: value
        for key, value in {
            "Authorization": request.headers.get("Authorization"),
            "x-agw-client_id": request.headers.get("x-agw-client_id"),
            "x-vsl-client_id": request.headers.get("x-vsl-client_id"),
        }.items()
        if value is not None
    }
    return headers


@router.post(
    "/vessel_chatCompletion",
    status_code=200,
    tags=["chatCompletion"],
    response_model=Response,
    include_in_schema=False,
    summary="Given a list of messages comprising a conversation, the model will return a response.",
)
async def vessel_chatcompletion(request: fastapi_request, req: ChatRequest):
    try:

        return await openai_chat.chat(
            model=req.engine,
            messages=req.messages,
            temperature=req.temperature,
            tokens=req.max_tokens,
        )

    except HTTPException as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.post(
    "/chatCompletion",
    status_code=200,
    tags=["Featured Endpoints"],
    response_model=Response,
)
@audit()
# decorator for metering
@async_token_validation_and_metering(uom=6)
async def chatcompletion(
    request: fastapi_request,
    req: ChatRequest = Body(openapi_examples=chatCompletionRequestExample),
    access_key=Depends(access_token_header),
):
    try:
        headers = prepare_header(request)
        logger.warning(f"chatCompletion headers: {headers}")
        req_msg = [msg.dict(exclude_none=True) for msg in req.messages]
        payload = {
            "messages": req_msg,
            "max_tokens": req.max_tokens,
            "temperature": req.temperature,
            "n": req.n,
            "frequency_penalty": req.frequency_penalty,
            "presence_penalty": req.presence_penalty,
        }
        # Optional Parameters
        if req.logit_bias:
            payload["logit_bias"] = req.logit_bias
        if req.stop:
            payload["stop"] = req.stop
        if req.enhancements:
            payload["enhancements"] = req.enhancements
        if req.dataSources:
            payload["dataSources"] = req.dataSources

        url = MULESOFT_CHAT_ENDPOINT.format(
            req.engine, API_VERSION_PREVIEW if req.tools else API_VERSION_STABLE
        )

        if req.tools:
            payload["tools"] = [tool.dict(exclude_none=True) for tool in req.tools]
        if req.tool_choice:
            payload["tool_choice"] = req.tool_choice

        if req.engine in ["gpt-4-vision-preview", "gpt-4-vision"]:
            logger.info(f"USING {req.engine} MODEL")
            result = await make_lb_request(req.engine, payload)
            # print(f"result:::::::::::::::::: {result}")
        else:

            # logger.warning("{0}\n{1}\n{2}".format(url, payload, headers))
            logger.info(f"URL: {url}")
            response = await client.post(
                url=url, json=payload, headers=headers, timeout=220
            )
            response.raise_for_status()

            result = response.json()

        # logger.warning(f"Result : {result}")

        total_tokens = 0
        if "usage" in result and "total_tokens" in result["usage"]:
            total_tokens = result["usage"]["total_tokens"]

        total_tokens = 0
        if "usage" in result and "total_tokens" in result["usage"]:
            total_tokens = result["usage"]["total_tokens"]

        return Response(
            status=Status.success,
            result=json.dumps(
                result["choices"][0]["message"]
                if req.n == 1
                else [i["message"] for i in result["choices"]]
            ),
            totalTokens=total_tokens,
        )
    except httpx.TimeoutException as e:
        logger.error(f"MuleSoft chatCompletion Timeout: {e}")
        raise HTTPException(
            status_code=408, detail=f"Error: MuleSoft chatCompletion Timeout"
        )
    except Exception as e:
        logger.error(f"ERROR chatCompletion: {str(e)}")
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(
            status_code=error_code, detail=f"Error chatCompletion: {error_text}"
        )


@router.post(
    "/summarize",
    status_code=200,
    tags=["Summarization"],
    response_model=Response,
    include_in_schema=False,
)
@audit()
@async_token_validation_and_metering(uom=6)
# @backoff.on_exception(backoff.expo, openai.error.RateLimitError)
async def summarize(request: fastapi_request, req: Request):
    try:

        return await openai_completion.summarize(
            model=req.engine,
            prompt=req.prompt,
            temperature=req.temperature,
            tokens=req.max_tokens,
        )

    except Exception as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.post(
    "/press_release",
    status_code=200,
    tags=["Completion"],
    response_model=Response,
    include_in_schema=False,
)
@audit()
@async_token_validation_and_metering(uom=6)
async def press_release(request: fastapi_request, req: Request):
    try:
        return await openai_completion.press_release(
            model=req.engine,
            prompt=req.prompt,
            temperature=req.temperature,
            tokens=req.max_tokens,
        )
    except Exception as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.get(
    "/models",
    status_code=200,
    tags=["Models"],
    response_model=List[Model],
    summary="get details of each model.",
)
async def models(access_key=Depends(access_token_header)):
    try:
        models = await openai_model.list()
        return models
    except Exception as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.get(
    "/deployments",
    status_code=200,
    tags=["Deployments"],
    response_model=List[Deploy],
    summary="Get list of models available.",
)
async def deployments(access_key=Depends(access_token_header)):
    try:
        deployments = await openai_deployment.list()
        return deployments
    except Exception as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.get(
    "/deployments/completion",
    status_code=200,
    tags=["Deployments"],
    response_model=List[Deploy],
    summary="Get list of models supporting text completion.",
)
async def completion_deployments(access_key=Depends(access_token_header)):
    try:
        deployments = await openai_deployment.completion_deployments()
        return deployments

    except Exception as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.get(
    "/deployments/chat",
    status_code=200,
    tags=["Deployments"],
    response_model=List[Deploy],
)
async def chat_deployments(access_key=Depends(access_token_header)):
    try:
        deployments = await openai_deployment.chats()
        return deployments
    except Exception as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.get(
    "/deployments/embeddings",
    status_code=200,
    tags=["Deployments"],
    response_model=List[Deploy],
)
async def embeddings_deployments(access_key=Depends(access_token_header)):
    try:
        deployments = await openai_deployment.embeddings_deployments()
        return deployments
    except Exception as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.get(
    "/deployments/export",
    status_code=200,
    tags=["Deployments"],
    response_model=List[Deploy],
)
async def deployments_exports(access_key=Depends(access_token_header)):
    try:
        csv = openai_deployment.deprecated_models()
        response = fastapi.Response(content=csv, status_code=200)
        response.headers["Content-Disposition"] = (
            "attachment; filename=extract_models_deprecated.csv"
        )
        response.headers["Content-Type"] = "text/csv"
        return response
    except Exception as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.get(
    "/deployment",
    status_code=200,
    tags=["Deployments"],
    response_model=Deploy,
    include_in_schema=False,
)
async def deployment(deployment_id: str, access_key=Depends(access_token_header)):
    try:
        return await openai_deployment.deployment(deployment_id=deployment_id)
    except Exception as e:
        logger.error(e)
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


@router.get("/rate_limit", status_code=429, include_in_schema=False)
def rate_limit():
    return HTTPException(
        status_code=429,
        detail="You exceeded your current quota, please check your plan and billing details",
    )


@router.post(
    "/vessel_embeddings",
    status_code=200,
    tags=["Embeddings"],
    response_model=Response,
    include_in_schema=False,
)
@audit()
@async_token_validation_and_metering(uom=6)
async def vessel_embeddings(request: fastapi_request, req: EmbeddingsRequest):
    try:
        return await openai_embedding.embeddings(
            deployment_id=req.engine, input=req.input
        )
    except Exception as e:
        logger.error(f"ERROR embeddings: {str(e)}")
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(
            status_code=error_code, detail=f"Error embeddings: {error_text}"
        )


@router.post(
    "/embeddings",
    status_code=200,
    tags=["Featured Endpoints"],
    response_model=Response,
    summary="Get a vector representation of a given input that can be easily consumed by machine learning models and algorithms.",
)
@audit()
@async_token_validation_and_metering(uom=6)
async def embeddings(
    request: fastapi_request,
    req: EmbeddingsRequest = Body(openapi_examples=embeddingsRequestExample),
    access_key=Depends(access_token_header),
):
    try:
        headers = prepare_header(request)
        logger.warning(f"embeddings headers: {headers}")

        payload = {"input": req.input}
        url = MULESOFT_EMBEDDINGS_ENDPOINT.format(req.engine, API_VERSION_EMBEDDINGS)
        # logger.warning("{0}\n{1}\n{2}".format(url, payload, headers))
        response = await client.post(
            url=url, json=payload, headers=headers, timeout=220
        )
        response.raise_for_status()
        result = response.json()

        return Response(
            status=Status.success,
            result=json.dumps(result["data"]),
            totalTokens=result["usage"]["total_tokens"],
        )
    except httpx.TimeoutException as e:
        logger.error(f"MuleSoft Embeddings Timeout: {e}")
        raise HTTPException(
            status_code=408, detail=f"Error: MuleSoft embeddings Timeout"
        )
    except Exception as e:
        logger.error(f"ERROR embeddings: {str(e)}")
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(
            status_code=error_code, detail=f"Error embeddings: {error_text}"
        )


@router.post(
    "/streaming/completion",
    tags=["Completion"],
    status_code=200,
    include_in_schema=False,
)
@async_token_validation_and_metering()
async def stream_completion(request: fastapi_request, req: Request):
    tokens = 0

    def get_streaming_completion(req: Request):
        nonlocal tokens
        try:

            response = openai_completion.completion_stream(
                model=req.engine,
                prompt=req.prompt,
                temperature=req.temperature,
                tokens=req.max_tokens,
            )

            encoding = tiktoken.encoding_for_model(req.engine)
            total_tokens = len(encoding.encode(req.prompt))
            total_content = ""
            for chunk in response:
                # logging.getLogger().warning(chunk)
                choice = chunk.choices[0]
                current_content = choice.text if not choice.text is None else ""

                total_tokens += len(encoding.encode(current_content))
                total_content += current_content
                res = Response(
                    status=Status.success,
                    result=(
                        current_content
                        if choice.finish_reason is None
                        else total_content
                    ),
                    totalTokens=(0 if choice.finish_reason is None else total_tokens),
                )
                # logging.getLogger().warning(res)
                tokens = res.totalTokens
                if tokens > 0:

                    push_metrics(
                        req_arrival_time=request.headers["x_agw_request_time"],
                        client_id=request.headers["x-agw-client_id"],
                        api_id=request.headers["x_agw_api_id"],
                        url=str(request.url),
                        tokens=res.totalTokens,
                        engine=req.engine,
                    )

                    push_audit_log(
                        api_id=request.headers.get("x_agw_api_id"),
                        client_id=request.headers.get("x-agw-client_id"),
                        request_time=request.headers.get("x_agw_request_time"),
                        correlation_id=request.headers.get("x-correlation-id"),
                        endpoint=request.url.path,
                        request=req,
                        response=res,
                    )

                yield f"{res.model_dump_json()}\n"

        except Exception as e:
            logger.error(e)

            error_code = (
                e.response.status_code
                if hasattr(e, "response") and hasattr(e.response, "status_code")
                else 500
            )
            error_text = (
                str(e.response.text)
                if hasattr(e, "response") and hasattr(e.response, "text")
                else str(e)
            )
            raise HTTPException(status_code=error_code, detail=f"Error: {error_text}")

    data = get_streaming_completion(req)

    headers = {"totalTokens": (str)(tokens)}
    logger.warning(headers)
    return StreamingResponse(data, media_type="application/x-ndjson", headers=headers)


@router.post(
    "/streaming/chatCompletion",
    tags=["chatCompletion"],
    status_code=200,
    include_in_schema=False,
)
@async_token_validation_and_metering()
async def stream_chatcompletion(request: fastapi_request, req: ChatRequest):
    def get_streaming_chatcompletion(req: ChatRequest):
        try:
            total_tokens = 0

            # Use acreate for async
            response = openai_chat.chat_stream(
                model=req.engine,
                messages=[msg.dict(exclude_none=True) for msg in req.messages],
                temperature=req.temperature,
                tokens=req.max_tokens,
            )

            encoding = tiktoken.encoding_for_model(req.engine)
            total_tokens = sum(
                len(encoding.encode(message.content)) for message in req.messages
            )
            for message in [msg.dict(exclude_none=True) for msg in req.messages]:
                for key, value in message.items():
                    total_tokens += len(encoding.encode(value))

            total_content = ""
            for chunk in response:

                choice = chunk.choices[0]
                current_content = (
                    choice.delta.content if not choice.delta.content is None else ""
                )

                total_tokens += len(encoding.encode(current_content))
                total_content += current_content
                res = Response(
                    status=Status.success,
                    result=(
                        current_content
                        if choice.finish_reason is None
                        else total_content
                    ),
                    totalTokens=(0 if choice.finish_reason is None else total_tokens),
                )

                if res.totalTokens > 0:

                    push_metrics(
                        req_arrival_time=request.headers["x_agw_request_time"],
                        client_id=request.headers["x-agw-client_id"],
                        api_id=request.headers["x_agw_api_id"],
                        url=str(request.url),
                        tokens=res.totalTokens,
                        engine=req.engine,
                    )

                    push_audit_log(
                        api_id=request.headers.get("x_agw_api_id"),
                        client_id=request.headers.get("x-agw-client_id"),
                        request_time=request.headers.get("x_agw_request_time"),
                        correlation_id=request.headers.get("x-correlation-id"),
                        endpoint=request.url.path,
                        request=req,
                        response=res,
                    )
                yield f"{res.model_dump_json()}\n"

        except Exception as e:
            logger.error(e)
            error_code = (
                e.response.status_code
                if hasattr(e, "response") and hasattr(e.response, "status_code")
                else 500
            )
            error_text = (
                str(e.response.text)
                if hasattr(e, "response") and hasattr(e.response, "text")
                else str(e)
            )
            raise HTTPException(status_code=error_code, detail=f"Error: {error_text}")

    data = get_streaming_chatcompletion(req)
    return StreamingResponse(data, media_type="application/x-ndjson")


@router.post(
    "/image",
    status_code=200,
    tags=["Preview"],
    response_model=Response,
    summary="Given a prompt, the model will generate a new image.",
)
@audit()
@async_token_validation_and_metering(uom=8)
async def image_generation(
    request: fastapi_request,
    req: ImageRequest = Body(openapi_examples=ImageRequestExample),
    access_key=Depends(access_token_header),
):
    """generate images using DALLE 3"""
    try:
        print("enter into dalle3 image generation function()")
        # images = await openai_image.image_generation(req.prompt, size=req.size, n=req.n, format=req.response_format , style=req.style , quality=req.quality)

        api_version_preview = os.environ.get("API_VERSION_PREVIEW", "")
        headers = prepare_header(request)

        url = os.environ.get("MULESOFT_IMAGE_ENDPOINT").format(
            req.engine, api_version_preview
        )

        payload = {
            "prompt": req.prompt,
            "size": req.size,
            "n": req.n,
            "style": req.style,
            "quality": req.quality,
            "response_format": req.response_format,
        }
        response = await client.post(url=url, json=payload, headers=headers)
        response.raise_for_status()
        response = response.json()
        if req.response_format == "b64_json":
            result = [
                {"b64_json": (img_item["b64_json"])} for img_item in response["data"]
            ]
        else:
            result = [{"image_url": img_item["url"]} for img_item in response["data"]]

        return Response(
            status=Status.success,
            result=json.dumps(result),
            totalTokens=0,
        )
    except Exception as e:
        logger.error(f"ERROR Image: {str(e)}")
        error_code = (
            e.response.status_code
            if hasattr(e, "response") and hasattr(e.response, "status_code")
            else 500
        )
        error_text = (
            str(e.response.text)
            if hasattr(e, "response") and hasattr(e.response, "text")
            else str(e)
        )
        raise HTTPException(status_code=error_code, detail=f"Error image: {error_text}")


# @router.post("/deployment",
#             status_code=201,
#             tags=["Deployments"],
#             response_model=Deploy
#             )
# @async_token_validation_and_metering()
# async def deployment(request: fastapi_request , model:Model):
#     try:
#         item  = openai.Deployment.create( model=model.id, scale_settings={"scale_type":"standard"} )
#         return (Deploy(id= item.id,
#                                 model=item.model,
#                                 status=item.status,
#                                 owner=item.owner))
#     except Exception as e:
#         raise HTTPException(status_code=©00, detail=f"Error: {str(e)}")

# @router.delete("/deployment",
#             status_code=200,
#             tags=["Deployments"]
#             )
# @async_token_validation_and_metering()
# async def deployment(request: fastapi_request ,item :Deploy):
#     try:
#         openai.Deployment.delete(sid=item.id)
#         return "Deployment {0} has been  deleted.".format(item.id)
#     except Exception as e:
#         raise HTTPException(status_code=400, detail=f"Error: {str(e)}")


def delete_file(path: str):
    os.remove(path)


@router.get("/management/export")
async def mgmt_export(background_tasks: BackgroundTasks):
    print("\*\*\*\*\*\*\*\*\*\* MGMT EXPORT \*\*\*\*\*\*\*\*\*\*")
    file_path = get_mgmt_export_data()

    # Add a background task to delete the file after sending the response
    background_tasks.add_task(delete_file, file_path)

    headers = {
        # By adding this, browsers can download this file.
        "Content-Disposition": f'attachment; filename="{os.path.basename(file_path)}"',
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "*",
        "Access-Control_Allow-Methods": "POST, GET, OPTIONS",
    }
    media_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    return FileResponse(path=file_path, headers=headers, media_type=media_type)
