import datetime
from functools import wraps
import json
import boto3
import os
import logging
import uuid

import pytest

from app.azure_openai.utils import AUDIT_SNS, logger, AUDIT_BUCKET, AUDIT_EXCLUSION
from app.azure_openai.v1.config import settings


s3 = boto3.resource("s3")


async def send_to_sns(message):
    """
    Send message to SNS.
    """
    # Try to publish message to the SNS queue
    try:
        # serialize the msg dict to json string
        message_string = json.dumps(message)

        sns_client = boto3.client("sns", region_name="us-east-1")
        # publish the message
        response = sns_client.publish(
            TopicArn=AUDIT_SNS,
            Message=message_string,
            MessageStructure="string",
            MessageDeduplicationId=message["request_id"],
            MessageGroupId="openai",
        )
        print("audit request id: ", message["request_id"])
        print("Response is: ", response)
    # Log any errors that occur while trying to send the message
    except Exception as e:
        logger.error(f"Error while sending message to SNS {AUDIT_SNS}: {str(e)}")


async def send_to_audit_s3(message):
    """
    Send the payload to s3 - if the endpoint is /image and also if the resp format is base64
    """
    # Try to push
    try:
        # Pushing payload to S3 bucket
        file_name = message["request_id"]
        client_id = message["client_id"]
        log_date = datetime.date.today()
        log_year = log_date.year
        log_month = log_date.month
        # preparing path of file
        file_path = f"{client_id}/{log_year}/{log_month}/{file_name}.json"
        print("filepath", file_path)

        payload_string = json.dumps(message)
        s3response = s3.Bucket(AUDIT_BUCKET).put_object(
            Key=file_path, Body=payload_string
        )
        print("S3 response ", s3response)
    except Exception as e:
        print(f"Error while uploading file to S3:{str(e)}")
        # raise e


async def prepare_payload(request, response, headers, url):
    # try:
    # checking if api call is for embedding then exclude the response from payload
    print("Splittttt : ", url.path.split("/")[-1])
    if url.path.split("/")[-1] == "embeddings":
        final_payload = {
            "request_id": str(uuid.uuid4()),
            "api_id": headers.get("x_agw_api_id"),
            "client_id": headers.get("x-agw-client_id"),
            "request_time": headers.get("x_agw_request_time"),
            "correlation - id": headers.get("x-correlation-id"),
            "endpoint": url.path.split("/")[-1],
            "request": request,
        }
        print("FInal payload from Util---- ", final_payload)
        return final_payload
    else:
        final_payload = {
            "request_id": str(uuid.uuid4()),
            "api_id": headers.get("x_agw_api_id"),
            "client_id": headers.get("x-agw-client_id"),
            "request_time": headers.get("x_agw_request_time"),
            "correlation - id": headers.get("x-correlation-id"),
            "endpoint": url.path.split("/")[-1],
            "request": request,
            "response": response.json(),
        }
        # print("FInal payload from Util other---- ", final_payload)
        return final_payload
    # except Exception as e:
    #     logger.error(f"Error preparing final payload: {str(e)}")

    # return final_payload


def audit():
    def decorator(func):
        @wraps(func)
        async def wrapper(request=None, *args, **kwargs):
            if os.environ.get("TEST_MODE", "") == "True":
                return await func(request, *args, **kwargs)

            header = request.headers
            if request:
                res = await func(request, *args, **kwargs)

            else:
                res = await func(*args, **kwargs)
            json_body = await request.json()
            AUDIT_EXCLUSION_LIST = AUDIT_EXCLUSION.strip("[]")
            AUDIT_EXCLUSION_LIST = AUDIT_EXCLUSION_LIST.split(", ")

            # Here checking client id is present in AUDIT_EXCLUSION_LIST or not
            if header.get("x-agw-client_id") in AUDIT_EXCLUSION_LIST:
                pass
            elif (
                "x_agw_api_id" not in header
                or "x-agw-client_id" not in header
                or "x-correlation-id" not in header
            ):
                pass
            else:
                # Prepare the payload for the SNS message
                final_payload = await prepare_payload(
                    json_body, res, request.headers, request.url
                )

                # check payload size and decide whether to push to S3 directly or the normal path sqs->lambda->s3
                # FYI this decorator is not running as a background job!!!
                final_payload_json_string = json.dumps(final_payload)
                byte_ = final_payload_json_string.encode("utf-8")
                size_in_bytes = len(byte_)
                print("payload size_in_bytes", size_in_bytes)

                if (
                    "response_format" in json_body
                    and json_body["response_format"] == "b64_json"
                ):
                    await send_to_audit_s3(final_payload)
                elif size_in_bytes > 200000:  # 256000 bytes is the SQS payload limit
                    print(
                        "Based on payload size - upload audit payload to S3 directly."
                    )
                    await send_to_audit_s3(final_payload)
                else:
                    # Send prepared payload to SNS
                    await send_to_sns(final_payload)

            return res

        return wrapper

    return decorator
