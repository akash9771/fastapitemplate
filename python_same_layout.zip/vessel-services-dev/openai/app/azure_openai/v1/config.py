import json
import logging
from os import environ
from base64 import b64decode

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    log_level: int = logging.WARNING


settings = Settings()
