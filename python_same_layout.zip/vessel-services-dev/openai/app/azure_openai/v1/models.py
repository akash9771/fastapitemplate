from enum import Enum
from typing import List, Optional, Union, Dict, Literal, Tuple

from pydantic import BaseModel, Field


class Status(str, Enum):
    failure = "failure"
    success = "success"


class HealthCheckResponse(BaseModel):
    status: Status
    message: str


class Request(BaseModel):
    prompt: str
    max_tokens: int = Field(default=2048)
    temperature: float = Field(0, ge=0, le=1)
    engine: str


class CompletionRequest(Request):
    top_p: float = Field(default=0, ge=0, le=1)
    logit_bias: Optional[Dict[str, int]] = None
    n: Optional[int] = Field(default=1, ge=1)
    # stream: Optional[bool] = False
    suffix: Optional[str] = None
    stop: Optional[Union[str, list[str]]] = None
    frequency_penalty: Optional[float] = Field(default=0, ge=-2.0, le=2.0)
    presence_penalty: Optional[float] = Field(default=0, ge=-2.0, le=2.0)
    # below params are not supported in latest gpt models
    echo: Optional[bool] = None
    # logprobs: Optional[int] = None
    best_of: Optional[int] = None


class EmbeddingsRequest(BaseModel):
    input: Union[str, List[str]]
    engine: str


class Response(BaseModel):
    status: Status
    result: str
    totalTokens: int

    def __getitem__(self, item):
        return getattr(self, item)


class Model(BaseModel):
    id: str
    lifecycle_status: str
    fine_tune: bool
    inference: bool
    completion: bool
    embeddings: bool
    max_tokens: Optional[int] = None
    description: Optional[str] = None
    training_data: Optional[str] = None
    use_cases: Optional[str] = None
    chatCompletion: Optional[bool] = None
    family: Optional[str] = None


class Deploy(BaseModel):
    id: str
    model: str
    status: str
    owner: str


class ImageUrl(BaseModel):
    url: str
    detail: Optional[Literal["high", "low", "auto"]] = "auto"
    # detail: Optional[str]


class ContentItem(BaseModel):
    type: Literal["text", "image_url"]
    text: Optional[str] = None
    image_url: Optional[Union[ImageUrl, str]] = None


class ChatMessage(BaseModel):
    role: Literal["system", "user", "assistant", "tool"]
    content: Union[str, List[ContentItem]]
    tool_call_id: Optional[str] = None
    name: Optional[str] = None
    tool_calls: Optional[list] = None


class Enabled(BaseModel):
    enabled: bool


class Enhancements(BaseModel):
    ocr: Enabled
    grounding: Enabled


class DataSource(BaseModel):
    class Parameters(BaseModel):
        endpoint: str
        key: str

    type: str
    parameters: Parameters


class FunctionDefinition(BaseModel):
    name: str
    description: Optional[str] = None
    parameters: Optional[Dict[str, object]] = None


class ChatCompletionToolParam(BaseModel):
    type: Literal["function"]
    function: FunctionDefinition


class ChatRequest(BaseModel):
    engine: str
    messages: List[ChatMessage]
    temperature: float = Field(0, ge=0, le=1)
    max_tokens: int
    n: Optional[int] = Field(default=1, ge=1)
    stop: Optional[Union[str, list[str]]] = None
    logit_bias: Optional[Dict[str, int]] = None
    frequency_penalty: Optional[float] = Field(default=0, ge=-2.0, le=2.0)
    presence_penalty: Optional[float] = Field(default=0, ge=-2.0, le=2.0)
    tools: Optional[List[ChatCompletionToolParam]] = None
    tool_choice: Optional[str] = None
    enhancements: Optional[Enhancements] = None
    dataSources: Optional[List[DataSource]] = None


class ImageRequest(BaseModel):
    prompt: str
    size: Optional[Literal["1792x1024", "1024x1024", "1024x1792"]] = "1024x1024"
    n: Optional[int] = 1
    # response_format: str = "b64_json"
    response_format: Optional[Literal["b64_json", "url"]] = "b64_json"
    quality: Optional[Literal["standard", "hd"]] = "standard"
    style: Optional[Literal["vivid", "natural"]] = "natural"
    engine: Optional[str] = "dall-e-3"
