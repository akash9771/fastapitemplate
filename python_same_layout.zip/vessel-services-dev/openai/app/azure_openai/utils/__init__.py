import logging
import sys
from os import environ
from logging import getLogger
from dotenv import load_dotenv

load_dotenv()


SERVER_ENV = environ.get("SERVER_ENV", "dev")
SERVER_REGION = environ.get("SERVER_REGION", "us-east-1")

OPENAI_API_BASE = environ.get("OPENAI_API_BASE", "")
OPENAI_API_KEY = environ.get("OPENAI_API_KEY", "")
API_VERSION_STABLE = environ.get("API_VERSION_STABLE", "")
API_VERSION_PREVIEW = environ.get("API_VERSION_PREVIEW", "")
API_VERSION_EMBEDDINGS = environ.get("API_VERSION_EMBEDDINGS", "")

MULSESOFT_USERNAME = environ.get("MULESOFT_USERNAME", "")
MULESOFT_PASSWORD = environ.get("MULESOFT_PASSWORD", "")
MULESOFT_COMPLETION_ENDPOINT = environ.get("MULESOFT_COMPLETION_ENDPOINT", "")
MULESOFT_CHAT_ENDPOINT = environ.get("MULESOFT_CHAT_ENDPOINT")
MULESOFT_EMBEDDINGS_ENDPOINT = environ.get("MULESOFT_EMBEDDINGS_ENDPOINT", "")


METERING_SQS_QUEUE = environ.get("METERING_SQS_QUEUE", "")


AZURE_CLIENT_ID = environ.get("AZURE_CLIENT_ID", "")
AZURE_TENANT_ID = environ.get("AZURE_TENANT_ID", "")
AZURE_CLIENT_SECRET = environ.get("AZURE_CLIENT_SECRET", "")
AZURE_SUBSCRIPTION_ID = environ.get("AZURE_OPENAI_SUBSCRIPTION_ID", "")

RESOURCE_GROUP_NAME = environ.get("RESOURCE_GROUP_NAME", "")
ACCOUNT_NAME = environ.get("ACCOUNT_NAME", "")

GPT4_VISION_KEY = environ.get("OPENAI_API_KEY_SWEC", "")

VISION_ENDPOINT = environ.get("VISION_ENDPOINT")
TEMP_VISION_MODEL_NAME = environ.get("TEMP_VISION_MODEL_NAME")
VISION_API_VERSION_PREVIEW = environ.get("VISION_API_VERSION_PREVIEW")

AUDIT_SNS = environ.get("AUDIT_SNS", "")
AUDIT_EXCLUSION = environ.get("AUDIT_EXCLUSION_LIST", "")
AUDIT_BUCKET = environ.get("AUDIT_BUCKET", "")

REDIS_HOST_PORT = environ.get("REDIS_HOST_PORT", "rediss://localhost:6379")
REDIS_PASSWORD = environ.get("REDIS_PASSWORD")


logger = getLogger()
logger.setLevel(logging.INFO)
logger.addHandler(logging.StreamHandler(sys.stdout))
