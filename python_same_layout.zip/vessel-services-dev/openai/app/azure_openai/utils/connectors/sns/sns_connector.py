import json
from uuid import uuid4

import boto3

from app.azure_openai.utils import AUDIT_SNS, logger


def push_audit_log(api_id , client_id, request_time, correlation_id, endpoint, request, response):

    payload = {
        "request_id": str(uuid4()),
        "api_id": api_id,
        "client_id": client_id,
        "request_time": request_time,
        "correlation - id": correlation_id,
        "endpoint": endpoint.split("/")[-1],
        "request": request.model_dump_json(),
        "response": response.model_dump_json(),
    }

    logger.debug(f"push audit message {payload}")

    sns_client = boto3.client("sns", region_name="us-east-1")
    # publish the message
    sns_client.publish(
        TopicArn=AUDIT_SNS,
        Message=json.dumps(payload),
        MessageStructure="string",
        MessageDeduplicationId=payload["request_id"],
        MessageGroupId="openai",
    )

    logger.debug("message pushed successfully")