import base64

import httpx

from app.azure_openai.utils import logger, API_VERSION_PREVIEW
from app.azure_openai.utils.connectors.openai.openai_connector import azure_openai_connector


class OpenAIImage():

    async def image_generation(self, prompt, size, n, format , style , quality):

        try:
            images = await azure_openai_connector(api_version=API_VERSION_PREVIEW).images.generate(prompt=prompt,size=size, n=n , model="dall-e-3" , quality=quality , style=style,
                                                                                                  response_format=format)
            if format == "b64_json":
                # return [
                #     {"b64_json": base64.b64encode(httpx.get(url=img_item.url).content).decode("utf-8")}
                #     for img_item in images.data
                # ]
                return [
                    {"b64_json": (img_item.b64_json)}
                    for img_item in images.data
                ]

            else:
                return [{"image_url":img_item.url}
                    for img_item in images.data

                ]


        except Exception as e:
            logger.error(f"failed to create the image as prompt={prompt}, "
                         f"size={size}, n={n} and format={format}: {str(e)}", e)
            raise e

openai_image = OpenAIImage()