import asyncio

from app.azure_openai.utils import logger, RESOURCE_GROUP_NAME, ACCOUNT_NAME
from app.azure_openai.utils.connectors import models_metadata
from app.azure_openai.utils.connectors.openai.model import openai_model
from app.azure_openai.utils.connectors.openai.openai_connector import azure_deployment_client
from app.azure_openai.v1.models import Deploy

regions = ['global', 'australiaeast', 'brazilsouth', 'westus', 'westus2', 'westeurope', 'northeurope', 'southeastasia',
            'eastasia', 'westcentralus', 'southcentralus', 'eastus', 'eastus2', 'canadacentral', 'japaneast',
            'centralindia', 'uksouth', 'japanwest', 'koreacentral', 'francecentral', 'northcentralus', 'centralus',
            'southafricanorth', 'uaenorth', 'swedencentral', 'switzerlandnorth', 'switzerlandwest', 'germanywestcentral',
            'norwayeast', 'westus3', 'jioindiawest', 'qatarcentral', 'canadaeast', 'polandcentral', 'southindia']


class OpenAIDeployment():
    async def list(self):
        try:
            deployments = azure_deployment_client.deployments.list(resource_group_name=RESOURCE_GROUP_NAME, account_name=ACCOUNT_NAME)
            return [Deploy(id=self.__format_model_name(item.id), model=item.properties.model.name, status=item.properties.provisioning_state.lower(), owner=item.system_data.created_by) for item in deployments]
        except Exception as e:
            logger.error(f"failed to list deployment {str(e)}", e)
            raise e

    def deployment(self, deployment_id: str):
        try:
            item = azure_deployment_client.deployments.get(resource_group_name=RESOURCE_GROUP_NAME, account_name=ACCOUNT_NAME, deployment_name=deployment_id)
            return Deploy(id=self.__format_model_name(item.id), model=item.properties.model.name, status=item.properties.provisioning_state.lower(), owner=item.system_data.created_by)
        except Exception as e:
            logger.error(f"failed to get a deploymento by deployment_id={deployment_id}, {str(e)}", e)
            raise e

    def deprecated_models(self):
        csv_file = ""
        csv_file  += 'resource_group_name, account_name, region, deployment_name, model_name, kind, model_format, version, max_capacity, deprecation_fina_tune, deprecation_inference\n'

        clients = azure_deployment_client.accounts.list()
        for client in clients:
            resource_group_name = client.id.split('/')[4]

            deployments = azure_deployment_client.deployments.list(resource_group_name=resource_group_name, account_name=client.name)
            deployments = list(deployments)
            models = azure_deployment_client.models.list(client.location)
            models = list(models)
            for deployment in deployments:
                items = list(filter(lambda x: x.model.name == deployment.properties.model.name and
                                              x.kind == deployment.properties.model.format and
                                              x.model.version == deployment.properties.model.version, models))
                for item in items:
                    csv_file += f"{resource_group_name}, {client.name}, {client.location}, "
                    csv_file += f"{deployment.name},  {item.model.name}, "
                    csv_file += f"{item.kind}, {item.model.format}, {item.model.version}, {item.model.max_capacity}, "
                    csv_file += f"{item.model.deprecation.fine_tune}, {item.model.deprecation.inference}\n"

        return csv_file



    def models(self, region):
        models = {}

        logger.info(f"get models from region {region}")

        for m in azure_deployment_client.models.list(location=region):
            try:
                model = self.__create_model(m)
                if region in models:
                    models[region].append(model)
                else:
                    models.update({region: [model]})
            except Exception as e:
                logger.error(f"failed to get model from region {region}. {str(e)}", e)
                raise e

        return models


    def __create_model(self, m):
        model = vars(m.model)
        model = {key: model[key] for key in sorted(set(model.keys()).difference(['deprecation', 'system_data', 'skus']))}
        model['deprecation'] = vars(m.model.deprecation)
        return model

    async def chats(self):
        try:
            deployments = await self.list()
            data = []

            for item in deployments:
                metadata = next((x for x in models_metadata if x["id"] == item.id), None)

                if metadata and metadata["chatCompletion"]:
                    data.append(item)
            return data
        except Exception as e:
            logger.error(f"failed to list all chats deployed. {str(e)}", e)
            raise e

    async def completion_deployments(self):
        try:

            deployments = await self.list()
            models = await openai_model.list()
            return await self.__define_completion_models(deployments, models)

        except Exception as e:
            logger.error(f"failed to list all completion deployed. {str(e)}", e)
            raise e

    async def embeddings_deployments(self):
        try:
            deployments = await self.list()
            models = await openai_model.list()
            return await self.__define_embeddings_models(deployments, models)
        except Exception as e:
            logger.error(f"failed to list all embeddings deployed. {str(e)}", e)
            raise e

    async def __find_deployed_models(self, deployments, all_models):

        return [Deploy(id=item.id,
                       model=item.model,
                       status=item.status,
                       owner=item.owner) for item in deployments for model in all_models if model.id == item.id]

    async def __define_completion_models(self, deployments, models):
        # Find all available completion models
        all_completion_models = [
            model
            for model in models
            if model.completion
               and model.inference
               and not model.embeddings
        ]
        # Find which of the deployed models support completion
        return await self.__find_deployed_models(deployments, all_completion_models)


    async def __define_embeddings_models(self, deployments, models):
        # Find all available embeddings models

        all_embeddings_models = [
            model for model in models if model.embeddings
        ]
        # Find which of the deployed models support embeddings
        deployments = await self.__find_deployed_models(deployments, all_embeddings_models)

        return deployments

    def __format_model_name(self, deployment):
        return deployment.split("/")[10]

openai_deployment = OpenAIDeployment()