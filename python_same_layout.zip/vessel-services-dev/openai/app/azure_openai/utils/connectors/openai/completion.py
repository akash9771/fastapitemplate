from app.azure_openai.utils import logger
from app.azure_openai.utils.connectors import PRESS_RELEASE_TEMPLATE
from app.azure_openai.utils.connectors.openai.openai_connector import openai_connector, stream_connector
from app.azure_openai.v1.models import Response, Status


class OpenAICompletion():


    def completion_stream(self,model, prompt, tokens, temperature):
        try:

            logger.info(
                f"starting completion method using model={model}, prompt={prompt}, max_tokens={tokens}, temperature={temperature}")

            return stream_connector.completions.create(model=model,
                                                                   prompt=prompt,
                                                                   max_tokens=tokens,
                                                                   temperature=temperature,
                                                                   stream=True )


        except Exception as e:
            logger.error(f"failed to run the completions on openai. {str(e)}", e)
            raise e
    async def completion(self, model, prompt, tokens, temperature, stream=False):
        try:

            logger.info(
                f"starting completion method using model={model}, prompt={prompt}, max_tokens={tokens}, temperature={temperature}")

            completion = await openai_connector.completions.create(model=model,
                                                             prompt=prompt,
                                                             max_tokens=tokens,
                                                             temperature=temperature,
                                                             stream=stream)

            logger.debug(f"response found result={completion.choices}, tokens={completion.usage.total_tokens}")
            return Response(
                status=Status.success,
                result=completion.choices[0].text,
                totalTokens=completion.usage.total_tokens,
            )
        except Exception as e:
            logger.error(f"failed to run the completions on openai. {str(e)}", e)
            raise e

    async def summarize(self, model, prompt, tokens, temperature):
        return await self.completion(model=model,
                               prompt=f"Provide a summary of the text below that captures its main idea.{prompt}",
                               tokens=tokens, temperature=temperature)

    async def press_release(self, model, prompt, tokens, temperature):

        return await self.completion(model=model,
                               prompt=f"Create a press release for the following product : {PRESS_RELEASE_TEMPLATE}. Use professional tone and be as detailed as possible.An example of press release for a product is the following {prompt} ",
                               tokens=tokens,
                               temperature=temperature)


openai_completion = OpenAICompletion()
