import json

from app.azure_openai.utils import logger
from app.azure_openai.utils.connectors.openai.openai_connector import openai_connector
from app.azure_openai.v1.models import Response, Status


class OpenAIEmbedding():

    async def embeddings(self, deployment_id, input):
        try:
            response = await openai_connector.embeddings.create(model=deployment_id, input=input)

            return Response(
                status=Status.success,
                result=response.data[0].embedding,
                totalTokens=response.usage.total_tokens,
            )
        except Exception as e:
            logger.error(f"faield to list embeddings by deployment_id {deployment_id} and input {input}: {str(e)}", e)
            raise e

openai_embedding = OpenAIEmbedding()