from app.azure_openai.utils import logger
from app.azure_openai.utils.connectors import models_metadata
from app.azure_openai.utils.connectors.openai.openai_connector import openai_connector
from app.azure_openai.v1.models import Model


class OpenAIModel():
    async def list(self):
        try:
            returned = []
            model_id_list=[]#list is for storing the model id
            models = await openai_connector.models.list()
            for item in models.data:
                metadata = next((x for x in models_metadata if x["id"] == item.id), None)
                if item.id not in model_id_list:#removing duplicate models
                    model_id_list.append(item.id)
                    model = Model(
                        id=item.id,
                        lifecycle_status=item.lifecycle_status,
                        fine_tune=item.capabilities['fine_tune'],
                        inference=item.capabilities['inference'],
                        completion=item.capabilities['completion'],
                        embeddings=item.capabilities['embeddings'],
                    )

                    if metadata:
                        model.max_tokens = metadata["max_tokens"]
                        model.description = metadata["description"]
                        model.training_data = metadata["training_data"]
                        model.chatCompletion = metadata["chatCompletion"]
                        model.use_cases = metadata["use_cases"]
                        model.family = metadata["family"]
                        returned.append(model)
            return returned
        except Exception as e:
            logger.error(f"failed to list models {str(e)}", e)
            raise e

openai_model = OpenAIModel()