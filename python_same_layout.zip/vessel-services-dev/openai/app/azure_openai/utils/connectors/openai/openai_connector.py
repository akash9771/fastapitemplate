import httpx
from azure.identity import DefaultAzureCredential
from azure.mgmt.cognitiveservices import CognitiveServicesManagementClient
from openai import AsyncAzureOpenAI, AzureOpenAI

from app.azure_openai.utils import OPENAI_API_KEY, API_VERSION_STABLE, OPENAI_API_BASE, AZURE_SUBSCRIPTION_ID

from app.azure_openai.utils.connectors.openai.custom_http_connection import AsyncCustomHTTPTransport, \
    CustomHTTPTransport



def azure_openai_connector(api_key=OPENAI_API_KEY,api_version=API_VERSION_STABLE, azure_endpoint=OPENAI_API_BASE):

    return AsyncAzureOpenAI(api_key=api_key, azure_endpoint=azure_endpoint, api_version=api_version,
                        http_client=httpx.AsyncClient(transport=AsyncCustomHTTPTransport(),), )


def azure_deployment_client(subscription_id=AZURE_SUBSCRIPTION_ID):
    return CognitiveServicesManagementClient(credential=DefaultAzureCredential(logging_enable=True),
                                             subscription_id=subscription_id)


def stream_openai_connector(api_key=OPENAI_API_KEY,api_version=API_VERSION_STABLE, azure_endpoint=OPENAI_API_BASE):
    return AzureOpenAI(api_key=api_key, azure_endpoint=azure_endpoint, api_version=api_version,
                            http_client=httpx.Client(transport=CustomHTTPTransport(),), )


stream_connector = stream_openai_connector(api_key=OPENAI_API_KEY,api_version=API_VERSION_STABLE, azure_endpoint=OPENAI_API_BASE)
openai_connector = azure_openai_connector(api_key=OPENAI_API_KEY,api_version=API_VERSION_STABLE, azure_endpoint=OPENAI_API_BASE)
azure_deployment_client = azure_deployment_client(subscription_id=AZURE_SUBSCRIPTION_ID)
