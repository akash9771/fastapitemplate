import openai
from fastapi import HTTPException

from app.azure_openai.utils import logger
from app.azure_openai.utils.connectors.openai.openai_connector import openai_connector, stream_connector
from app.azure_openai.v1.models import Response, Status


class OpenAIChat:
    async def chat(self, model, messages, tokens, temperature, stream=False):
        try:

            logger.info(
                f"starting chat completions method using model={model}, messages={messages}, max_tokens={tokens}, temperature={temperature}")

            # Use acreate for async
            completion = await openai_connector.chat.completions.create(model=model,
                                                                     messages=messages,
                                                                     max_tokens=tokens,
                                                                     temperature=temperature,
                                                                     stream=stream)

            logger.debug(f"response found result={completion.choices}, tokens={completion.usage.total_tokens}")
            # response = OpenAIObject(response.id)
            return Response(
                status=Status.success,
                result=str(completion.choices[0].message.content),
                totalTokens=completion.usage.total_tokens,
            )

        except openai.NotFoundError as e:
            logger.error(f"failed to found the resource to run the chat completions on openai. {str(e)}")
            raise HTTPException(status_code=e.status_code, detail=f"Error: {str(e)}")
        except Exception as e:
            logger.error(f"failed to run the chat completions on openai. {str(e)}", e)
            raise e

    def chat_stream(self, model, messages, tokens, temperature):
        try:

            logger.info(
                f"starting chat completions method using model={model}, messages={messages}, max_tokens={tokens}, temperature={temperature}")

            # Use acreate for async
            return stream_connector.chat.completions.create(model=model,
                                                                  messages=messages,
                                                                  max_tokens=tokens,
                                                                  temperature=temperature, stream=True)


        except openai.NotFoundError as e:
            logger.error(f"failed to found the resource to run the chat completions on openai. {str(e)}")
            raise HTTPException(status_code=e.status_code, detail=f"Error: {str(e)}")
        except Exception as e:
            logger.error(f"failed to run the chat completions on openai. {str(e)}", e)
            raise e

openai_chat = OpenAIChat()