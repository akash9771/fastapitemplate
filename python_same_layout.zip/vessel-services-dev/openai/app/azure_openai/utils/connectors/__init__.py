import json


def template(filename):
    with open(filename) as f:
        return f.readlines()


PRESS_RELEASE_TEMPLATE_FILE = "CLEAR_eHLT_PressRelease.txt"

# PRESS_RELEASE_TEMPLATE = template(PRESS_RELEASE_TEMPLATE_FILE)
PRESS_RELEASE_TEMPLATE = ""

models_metadata = json.load(open("models-metadata.json"))
