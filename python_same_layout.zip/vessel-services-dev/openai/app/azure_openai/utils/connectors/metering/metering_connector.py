import json
import uuid
from datetime import datetime
from validator.generic_topic_msg_producer import TopicMsgPublisher

from app.azure_openai.utils import METERING_SQS_QUEUE, logger



def push_metrics(req_arrival_time, client_id, api_id, url, tokens, engine):

    metering_req = {}

    req_arrival_time_utc = datetime.strptime(

        req_arrival_time[:-6], "%Y-%m-%dT%H:%M:%S.%f"
    )

    client_id = str(
        uuid.UUID(hex=client_id)
    )  # for r_su_id

    client_id_split = client_id.split("-")[4]

    access_token = client_id.replace(
        client_id_split, api_id
    )  # for api_key

    process_end_time = datetime.utcnow()

    metering_req["r_tt"] = (
            process_end_time - req_arrival_time_utc
    ).total_seconds()


    metering_req["r_yr"] = req_arrival_time_utc.year
    metering_req["r_m"] = req_arrival_time_utc.month
    metering_req["r_d"] = req_arrival_time_utc.day
    metering_req["rec_id"] = str(uuid.uuid4())
    metering_req["api_key"] = access_token
    metering_req["pk_id"] = (
            api_id
            + "#"
            + str(metering_req["r_yr"])
            + "#"
            + str(metering_req["r_m"])
            + "#"
            + str(metering_req["r_d"])
    )
    metering_req["r_su_id"] = client_id
    # str(uuid.UUID(hex="6f90ab7409494cdfb67e09de2de63334"))
    # metering_req["r_sv_id"] = headers['x-correlation-id']
    metering_req["r_sv_id"] = api_id  # this will go into Lambda (picks the value from Cache)
    metering_req["r_arr_t"] = str(req_arrival_time_utc)
    metering_req["vendor_id"] = 0
    metering_req["r_param_1"] = "NA"
    metering_req["r_param_2"] = "NA"
    metering_req["raw_url"] = url
    metering_req["svc_op_type"] = url.split("/")[-1]
    metering_req["r_ret_t"] = str(process_end_time)
    metering_req["r_chnl_type_id"] = "NA"
    metering_req["r_chnl_id"] = "NA"
    metering_req["r_user_id"] = "NA"
    metering_req["r_parent_wf_req_id"] = "NA"
    metering_req["r_id"] = str(uuid.uuid4())

    metering_req["r_uom_val"] = tokens  # OpenAI response
    metering_req["r_param_1"] = engine
    metering_req["vendor_id"] = (
        3  # vendor_serial['azure']  # Vendor ID Azure
    )
    metering_req["unit_of_measurement"] = "total_tokens"


    logger.debug(f"push metrics {metering_req}")

    TopicMsgPublisher.send_msg_to_topic(
        METERING_SQS_QUEUE,
        json.dumps(metering_req),
    )

    logger.debug("message pushed successfully")

