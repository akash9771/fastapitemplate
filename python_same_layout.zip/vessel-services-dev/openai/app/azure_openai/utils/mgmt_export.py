import os
import openpyxl
from dotenv import load_dotenv
from azure.mgmt.cognitiveservices import CognitiveServicesManagementClient
from azure.identity import DefaultAzureCredential
from datetime import datetime

now = datetime.now()


def get_management_client(subscription_id):
    return CognitiveServicesManagementClient(
        credential=DefaultAzureCredential(),
        subscription_id=subscription_id,
    )


def get_deployments_with_models(mgmt_client, subscription_id):
    deployments_with_models = []
    clients = mgmt_client.accounts.list()

    for client in clients:
        resource_group_name = client.id.split("/")[4]
        resource_name = client.name
        resource_kind = client.kind
        resource_location = client.location

        if resource_kind == "OpenAI":
            deployments = (
                deployment
                for deployment in mgmt_client.deployments.list(
                    resource_group_name, resource_name
                )
            )
            for deployment in deployments:
                # print(f"\n\n\n\n\n deployment.name - {deployment.name}")
                deployment_name = deployment.name
                model_name = deployment.properties.model.name
                model_version = deployment.properties.model.version
                capacity = deployment.sku.capacity
                # print(deployment.sku)
                # print(deployment.system_data)
                # print(deployment.properties.model)
                # print(deployment.properties)
                created_by = deployment.system_data.created_by
                created_by_type = deployment.system_data.created_by_type
                created_at = deployment.system_data.created_at
                last_modified_by = deployment.system_data.last_modified_by
                last_modified_by_type = deployment.system_data.last_modified_by_type
                last_modified_at = deployment.system_data.last_modified_at
                provisioning_state = deployment.properties.provisioning_state
                rate_limits = deployment.properties.rate_limits
                version_upgrade_option = deployment.properties.version_upgrade_option

                # print(deployment.properties.rate_limits)

                request_rate_limits = (
                    deployment.properties.rate_limits[0]
                    if len(deployment.properties.rate_limits) > 0
                    else " "
                )

                token_rate_limits = (
                    deployment.properties.rate_limits[1]
                    if len(deployment.properties.rate_limits) > 1
                    else " "
                )

                request_renewal_period = getattr(
                    request_rate_limits, "renewal_period", None
                )
                request_count = getattr(request_rate_limits, "count", None)
                request_dynamic_throttling_enabled = getattr(
                    request_rate_limits, "dynamic_throttling_enabled", None
                )
                request_match_patterns = getattr(
                    request_rate_limits, "match_patterns", None
                )
                request_min_counts = getattr(request_rate_limits, "min_count", None)

                token_renewal_period = getattr(
                    token_rate_limits, "renewal_period", None
                )
                token_count = getattr(token_rate_limits, "count", None)
                # print(f"token_count: {token_count}: {type(token_count)}")
                if not isinstance(token_count, (float, int, str, list, dict, tuple)):
                    token_count = None
                token_dynamic_throttling_enabled = getattr(
                    token_rate_limits, "dynamic_throttling_enabled", None
                )
                token_match_patterns = getattr(
                    token_rate_limits, "match_patterns", None
                )
                token_min_counts = getattr(token_rate_limits, "min_count", None)

                # Get OpenAI models
                models_paged = mgmt_client.models.list(resource_location)
                model_seen = set()
                for models in models_paged:
                    if (
                        models.model.name == model_name
                        and models.model.version == model_version
                    ):
                        deprecation_inference = models.model.deprecation.inference
                        model_lifecycle_status = models.model.lifecycle_status
                        model_capabilities = models.model.capabilities
                        __model_capabilities = [
                            key
                            for key, value in model_capabilities.items()
                            if value.lower() == "true"
                        ]

                        if (model_name, model_version) in model_seen:
                            continue  # sometimes there are duplicate model details
                        deployments_with_models.append(
                            {
                                "subscription_id": subscription_id,
                                "deployment_name": deployment_name,
                                "resource_name": resource_name,
                                "resource_location": resource_location,
                                "model_name": model_name,
                                "model_version": model_version,
                                "capacity": capacity,
                                "deprecation_date": deprecation_inference,
                                "lifecycle_status": model_lifecycle_status,
                                "capabilities": __model_capabilities,
                                "created_by": created_by,
                                "created_by_type": created_by_type,
                                "created_at": str(created_at),
                                "last_modified_by": last_modified_by,
                                "last_modified_by_type": last_modified_by_type,
                                "last_modified_at": str(last_modified_at),
                                "provisioning_state": provisioning_state,
                                "request_renewal_period": request_renewal_period,
                                "request_count": request_count,
                                "request_dynamic_throttling_enabled": request_dynamic_throttling_enabled,
                                "request_match_patterns": request_match_patterns,
                                "request_min_counts": request_min_counts,
                                "token_renewal_period": token_renewal_period,
                                "token_count": token_count,
                                "token_dynamic_throttling_enabled": token_dynamic_throttling_enabled,
                                "token_match_patterns": token_match_patterns,
                                "token_min_counts": token_min_counts,
                                "version_upgrade_option": version_upgrade_option,
                            }
                        )
                        model_seen.add((model_name, model_version))

    return deployments_with_models


def get_quotas(mgmt_client, subscription_id):
    quotas = []
    clients = mgmt_client.accounts.list()

    for client in clients:
        resource_group_name = client.id.split("/")[4]
        resource_name = client.name
        resource_kind = client.kind
        resource_location = client.location

        if resource_kind == "OpenAI":
            for items in mgmt_client.usages.list(resource_location):
                quotas.append(
                    {
                        "subscription_id": subscription_id,
                        "resource_location": resource_location,
                        "resource_name": resource_name,
                        "localized_value": items.name.localized_value,
                        "limit": items.limit,
                        "current_value": items.current_value,
                    }
                )
    return quotas


def get_excel_workbook(data1, data2):
    workbook = openpyxl.Workbook()

    sheet1 = workbook.active
    sheet1.title = "Deployments"
    header1 = list(data1[0].keys())
    sheet1.append(header1)
    for obj in data1:
        row = []
        for value in obj.values():
            if isinstance(value, list):
                value = ", ".join(value)  # Convert list to comma-separated string
            row.append(value)
        sheet1.append(row)  # Write the data rows

    sheet2 = workbook.create_sheet("Quotas")
    header2 = list(data2[0].keys())
    sheet2.append(header2)
    for obj in data2:
        row = []
        for value in obj.values():
            if isinstance(value, list):
                value = ", ".join(value)  # Convert list to comma-separated string
            row.append(value)
        sheet2.append(row)  # Write the data rows

    return workbook


load_dotenv()


def get_mgmt_export_data():
    date_time = now.strftime("%Y%m%d-%H%M%S")

    subscription_id = os.getenv("AZURE_SUBSCRIPTION_ID")
    subscription_ids = subscription_id.split(",")
    subscription_ids = [sub_id.strip() for sub_id in subscription_ids]
    all_deployments = []
    all_quotas = []
    for subscription_id in subscription_ids:
        mgmt_client = get_management_client(subscription_id)
        deployments = get_deployments_with_models(mgmt_client, subscription_id)
        quotas = get_quotas(mgmt_client, subscription_id)
        all_deployments.extend(deployments)
        all_quotas.extend(quotas)

    workbook = get_excel_workbook(all_deployments, all_quotas)

    # save workbook to a file
    file_path = f"azure-openai-mgmt-export-{date_time}.xlsx"
    workbook.save(file_path)

    return file_path
