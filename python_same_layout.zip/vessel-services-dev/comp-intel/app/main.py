import logging

from fastapi import FastAPI
from validator.decorators import async_token_validation_and_metering

DEMO_SUMMARIZE_RESPONSE = {
    "status": "success",
    "trackingId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
}

DEMO_STATUS_RESPONSE = {
    "status": "success",
    "process_status": "Pending",
    "data": [
        {
            "id": 1,
            "relevancy_score": 1,
            "article_data": {
                "metadata": {
                    "title": "Article title",
                    "publisher": "Article publisher",
                    "author": "Article author",
                    "publish_date": "Feb 16, 2024",
                    "source_url": "https://xyz.com",
                },
                "content": "Content goes here",
            },
        }
    ],
}


app = FastAPI()

logger = logging.getLogger()
logger.setLevel(logging.WARNING)


@app.get("/comp-intel/health", status_code=200)
async def get_health():
    return {"status": "success"}


@app.post("/comp-intel/eventsummarize", status_code=200)
@async_token_validation_and_metering()
async def summarize_event():
    return DEMO_SUMMARIZE_RESPONSE


@app.post("/comp-intel/eventsummarize/mock", status_code=200)
@async_token_validation_and_metering()
async def summarize_event_mock():
    return DEMO_SUMMARIZE_RESPONSE


@app.get("/comp-intel/eventsummarize/status/{tracking_id}", status_code=200)
@async_token_validation_and_metering()
async def get_status(tracking_id):
    return DEMO_STATUS_RESPONSE


@app.get("/comp-intel/eventsummarize/status/{tracking_id}", status_code=200)
@async_token_validation_and_metering()
async def get_status_mock(tracking_id):
    return DEMO_STATUS_RESPONSE
