<p align="center">
    <img src="static/coverage.svg" alt="Coverage score">
</p>

# Ethicara API

- [Ethicara API](#ethicara-api)
  - [Setup](#setup)
  - [Coding best practices](#coding-best-practices)
  - [Run the application](#run-the-application)
  - [Call the `health` endpoint](#call-the-health-endpoint)
  - [Test the application](#test-the-application)
  - [Generate coverage report](#generate-coverage-report)
  - [Deploy in Vessel](#deploy-in-vessel)

## Setup

Clone the repository with ssh:

```bash
git clone git@github.com:pfizer-analytics/ethicara-api.git
```

This project is currently using python3.11.5. This API does not need to work with different python versions, so lets stick to this version. If you have another python version already installed, you can install multiple version of python using [pyenv](https://github.com/pyenv-win/pyenv-win). After that:

```bash
pyenv install 3.11.5
```

Then, create a virtual environment:

```bash
pyenv local 3.11.5
pyenv exec python -m pip install virtualenv
pyenv exec python -m virtualenv .venv
```

Enable the virtual environment and install the required dependencies:

```bash
source .venv/Scripts/activate
pip install -r requirements.txt
```

We need to do some exploration and pin down the exact versions of the dependencies. For now, we will use the latest versions of the dependencies.

Also, install the following extensions for VSCode:

- [black](https://marketplace.visualstudio.com/items?itemName=ms-python.black-formatter)

Add the following configuration to the `settings.json` file. To open your settings file, press `Ctrl + Shift + P` and then write `Open User Settings (JSON)` in the input on the top textbox. Then, add the following configuration to the file and save it. This will format the code using black when you save the file:

```json
 "[python]": {
    "editor.defaultFormatter": "ms-python.black-formatter",
    "editor.formatOnSave": true
  }
  ```

- [isort](https://marketplace.visualstudio.com/items?itemName=ms-python.isort)

or install the requirements for development.

```bash
pip install -r requirements_dev.txt
```

## Coding best practices

Refer to this link for more information about [pre-commits](https://confluence.pfizer.com/display/AICV/Coding+Best+Practices)

```bash
pip install pre-commit
pre-commit install

git add .
git commit -S -m <your message commit>
```

Note: Only the first time you do this process it will take a while.

To get your commit through without running that pre-commit hook, use the --no-verify option.

```bash
git commit -S -m <your message commit> --no-verify
```

## Run the application

You can run the application using the following command:

```bash
uvicorn app.main:app --reload --port 8000 --host 0.0.0.0
```

or using the `run.py` script:

```bash
python scripts/run.py
```

This is only for development purpose. For production, you should use a proper web server like [gunicorn](https://gunicorn.org/). Also, the `-reload` option should not be used in production.

## Call the `health` endpoint

```python
import requests

req = requests.get("http://127.0.0.1:8000/ethicara/health")
print(req.json())

{'status': 'OK'}
```

## Test the application

```bash
pip install pytest httpx pyarrow pytest-asyncio
./test.sh
```

or

```bash
py -m pytest -v --disable-warnings
```

## Generate coverage report

```bash
pip install coverage coverage-badge
./scripts/coverage.sh
```

If you cannot run the tests, plase exit the virtual environment and re-enter it.

## Deploy in Vessel

Create a new file `scripts/update.sh`

```bash
rm -rf ethicara
git clone git@github.com:pfizer-analytics/ethicara-api.git ethicara

rm -rf ethicara/.git
rm -rf ethicara/.github
rm -rf ethicara/.gitignore
rm -rf ethicara/.pfizer.yaml
rm -rf ethicara/sonar-project.properties
rm -rf ethicara/validator
rm -rf ethicara/.pre-commit-config.yaml
rm -rf ethicara/requirements_dev.txt

git restore ethicara/Dockerfile

```
