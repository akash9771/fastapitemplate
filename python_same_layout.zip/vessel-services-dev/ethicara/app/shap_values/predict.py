import shap
import pandas as pd


def predict_shap_values(clf, train_preprocessed, test_preprocessed):
    """
    This function takes as an input the predictor object and returns the train/test sets and shap values.
    Args:
        clf: The classifier object
        train_preprocessed: The preprocessed train dataset
        test_preprocessed: The preprocessed test dataset
    Returns:
        shap_values: Computed shap values
    """

    train_preprocessed = pd.DataFrame(train_preprocessed)
    test_preprocessed = pd.DataFrame(test_preprocessed)

    try:
        explainer = shap.TreeExplainer(clf, train_preprocessed)
        shap_values = explainer.shap_values(test_preprocessed, check_additivity=False)
        shap_values = shap_values[:, :, 1]
    except:
        try:
            explainer = shap.TreeExplainer(clf.base_estimator, train_preprocessed)
            shap_values = explainer.shap_values(
                test_preprocessed, check_additivity=False
            )
            shap_values = shap_values[:, :, 1]
        except:
            try:
                explainer = shap.LinearExplainer(clf, train_preprocessed)
                shap_values = explainer.shap_values(test_preprocessed)
            except:
                raise Exception("The model is not supported")

    return shap_values.tolist()
