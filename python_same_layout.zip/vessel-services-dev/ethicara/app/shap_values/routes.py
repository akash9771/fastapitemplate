from fastapi import APIRouter, File, Request, UploadFile
import pickle as pkl

from app.shap_values.predict import predict_shap_values
from app.shap_values.schema import ShapExplainer
from app.logger import logger
from app.utils import load_model

from validator.decorators import async_token_validation_and_metering


logger = logger.getChild(__name__)

router = APIRouter(
    prefix="/explainability/shap-values",
    tags=["Shap Explainer"],
)


@router.get("/")
@async_token_validation_and_metering()
async def shap_info(request: Request):
    return {
        "description": "This is the shap values endpoint.",
        "information": "Please use the /predict endpoint to make a prediction.",
    }


@router.post("/predict")
@async_token_validation_and_metering()
async def shap_values_predict(request: Request, data: ShapExplainer):

    """

    ### Args:
        - clf: The classifier object
        - train_preprocessed: The preprocessed train dataset
        - test_preprocessed: The preprocessed test dataset

    ### Returns:
        - JSON: A JSON object with the model bias metrics.
    """
    clf = await load_model(**data.model_dump(include={"clf"}))
    return predict_shap_values(**data.model_dump(exclude={"clf"}), clf=clf)
