import os
import warnings
from functools import lru_cache
from typing import List

from pydantic import BaseModel
from pydantic_settings import BaseSettings, SettingsConfigDict

from app.constants import COMMON


class EthicaraModelOutput(BaseModel):
    name: str
    endpoint: str
    description: str


os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
warnings.filterwarnings(
    "ignore", category=UserWarning, module="torch._functorch.deprecated"
)
warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", message="is_sparse is deprecated")
warnings.filterwarnings("always", message="No module named")


class Settings(BaseSettings):
    api_name: str = "Awesome API"
    api_description: str = "Description of the API"
    ci_number: str = "CI_number"
    support_mail: str = "email-id_of_the_support_team"
    api_version: str = "1.0"
    api_console_url: str = "URL_link"
    keywords: str = "keyword,keywords"
    business_line: str = "Commercial"
    api_style: str = "REST"
    api_type: str = "Experience"
    github_repo: str = "https://github.com/pfizer-analytics/ethicara-api"
    confluence_id: str = "confluence_id_of_api"
    analytics_id: str = "analytics_id"
    info: List[EthicaraModelOutput] = COMMON.get("methods")
    model_config = SettingsConfigDict(env_file=".env")


@lru_cache()
def get_settings():
    return Settings()
