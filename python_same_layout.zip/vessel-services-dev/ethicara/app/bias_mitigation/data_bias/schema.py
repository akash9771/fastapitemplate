from typing import Dict, List, Optional, Union

from pydantic import BaseModel, Field, model_validator

from app.bias_mitigation.data_bias.examples import EXAMPLES


class BiasMitigationDataBiasInput(BaseModel):

    input: Dict = Field(None, description="Input for the model")
    target: str = Field(..., description="Target attribute")
    favorable_label: Union[str, int] = Field(..., description="Favorable label")

    protected_attributes: List[str] = Field(..., description="Protected attributes")
    preferred_attribute: str = Field(..., description="Preferred attribute")
    privileged_classes: List[List[str]] = Field(..., description="Privileged classes")
    # TODO: consolidate logic with ModelBias since it is common
    models: List[str] = Field(..., description="List of models")

    lfr_params: Optional[Dict] = Field(None, description="Parameters for the model")

    model_config = {"json_schema_extra": {"examples": EXAMPLES}}

    @model_validator(mode="after")
    def validate_models(self):
        models = self.models

        # TODO: is the not models redundant, since is it not optional?
        if not models:
            raise ValueError("models cannot be empty")

        for model in models:
            if model not in ["Reweighing", "Learning Fair Representations"]:
                raise ValueError(
                    "models contains invalid models. Available models are: ['Reweighing', 'Learning Fair Representation']"
                )

        return self

    @model_validator(mode="after")
    def validate_target(self):
        target = self.target
        values = self.input

        if target not in values.keys():
            raise ValueError(
                f"target {target} not found in input keys. Available keys are: {list(values.keys())}"
            )
        return self

    @model_validator(mode="after")
    def validate_favorable_label(self):
        favorable_label = self.favorable_label
        target_dict = self.input[self.target]

        if str(favorable_label) not in [str(x) for x in target_dict.values()]:

            raise ValueError(
                f"favorable_label {favorable_label} not found in input values. Available values are: {list(target_dict.values())}"
            )
        return self
