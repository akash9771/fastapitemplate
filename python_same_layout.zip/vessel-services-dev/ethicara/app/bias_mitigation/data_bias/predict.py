from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from aif360.sklearn.datasets.utils import standardize_dataset
from aif360.sklearn.metrics import (
    average_odds_difference,
    disparate_impact_ratio,
    equal_opportunity_difference,
    statistical_parity_difference,
)
from aif360.sklearn.preprocessing.learning_fair_representations import (
    LearnedFairRepresentations,
)
from aif360.sklearn.preprocessing.reweighing import Reweighing
from dask import compute, delayed
from sklearn import metrics as skm
from sklearn.base import BaseEstimator
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.preprocessing import StandardScaler

from app.bias_mitigation.AIF360_util import StandardDataset
from app.bias_mitigation.utils.scoring_strategies import scoring_func


def create_models_dict(models_list: List, lfr_params: Dict, pref_attr: str) -> List:
    """
    Create a list with all the selected models names, the model object, their hyperparameters and the scoring function.

    Args:
        models_list(List): A list with all the selected models.
        parameters(Dict): The dictionary with all the information from the UI.
        pref_attr(str): The prefered protected attribute to be used on metrics and on models with only one protective attribute option.

    Returns:
    models(List): A list with all the selected models names, the model object, their hyperparameters and the scoring function

    """
    models = []
    lr = LogisticRegression()
    lr_params = {"C": [0.1, 1.0, 10.0]}
    scorer_lr = "balanced_accuracy"
    models.insert(0, ("Logistic Regression", lr, lr_params, scorer_lr))
    for model in models_list:
        if model == "Learning Fair Representations":
            lfr = LearnedFairRepresentations(
                pref_attr, n_prototypes=25, max_iter=1000, random_state=0
            )
            lfr_scorer = skm.make_scorer(
                scoring_func, scoring="Delta", pref_attr=pref_attr
            )
            models.append(
                ("Learning Fair Representations", lfr, lfr_params, lfr_scorer)
            )

        elif model == "Reweighing":
            lr = LogisticRegression()
            lr_params = {"C": [0.1, 1.0, 10.0]}
            rwg_scorer = skm.make_scorer(
                scoring_func,
                scoring="StatisticalParity",
                greater_is_better=False,
                pref_attr=pref_attr,
            )
            models.append(("Reweighing", lr, lr_params, rwg_scorer))

    return models


def create_predictions(
    name: str,
    model: BaseEstimator,
    params: Dict,
    scorer,
    X_train: pd.DataFrame,
    y_train: pd.DataFrame,
    X_test: pd.DataFrame,
    prot_attr: List,
) -> Dict:
    """
    This function implements GridSerachCV, fit the model to the training set and gives the predictions.

    Args:
        name(str): The name of the algorithm.
        model(BaseEstimator): The AI Fairness 360 scikit-learn model object.
        params(Dict): A dictionaty with all the hyperparameters to be tuned during GridSearchCV.
        scorer(function): The scoring function.
        X_train(pd.DataFrame): The training set with columns of protected and non attributes attributes.
        y_train(pd.DataFrame): The training set with columns the target variable.
        X_test(pd.DataFrame): The test set with columns of protected and non attributes attributes.
        prot_attr(List): All the protective attributes.

    Returns:
        preds_dict(Dict): A dictionary with keys the names of the models and values the predictions of every model.
    """
    preds_dict = {}
    if name == "Reweighing":
        rwg_instance_weights = Reweighing(prot_attr).fit_transform(X_train, y_train)[1]
        grid = GridSearchCV(model, params, scoring=scorer, cv=5, n_jobs=4).fit(
            X_train, y_train, sample_weight=rwg_instance_weights
        )
        y_pred = grid.predict(X_test)
        y_proba = grid.predict_proba(X_test)
        preds_dict[name] = [y_pred, y_proba, rwg_instance_weights]

    elif name in ("Reject Option Classifier CV", "Calibrated Equalized Odds"):
        grid = model.fit(X_train, y_train)
        y_pred = grid.predict(X_test)
        y_proba = grid.predict_proba(X_test)
        preds_dict[name] = [y_pred, y_proba]
    elif name == "Learning Fair Representations":
        grid = GridSearchCV(model, params, scoring=scorer, cv=5, n_jobs=4).fit(
            X_train, y_train
        )
        y_pred = grid.predict(X_test)
        y_proba = grid.predict_proba(X_test)
        cv_results = grid.cv_results_
        best_params = grid.best_params_
        X_train_transformed = grid.transform(X_train)
        preds_dict[name] = [
            y_pred,
            y_proba,
            cv_results,
            best_params,
            X_train_transformed,
        ]
    elif name == "Adversarial Debiasing":
        grid = GridSearchCV(model, params, scoring=scorer, cv=5, n_jobs=None).fit(
            X_train, y_train
        )
        y_pred = grid.predict(X_test)
        y_proba = grid.predict_proba(X_test)
        cv_results = grid.cv_results_
        best_params = grid.best_params_
        preds_dict[name] = [y_pred, y_proba, cv_results, best_params]
    elif name in (
        "Exponentiated Gradient Reduction",
        "Grid Search Reduction",
        "Logistic Regression",
    ):
        grid = GridSearchCV(model, params, scoring=scorer, cv=5, n_jobs=4).fit(
            X_train, y_train
        )
        y_pred = grid.predict(X_test)
        y_proba = grid.predict_proba(X_test)
        cv_results = grid.cv_results_
        best_params = grid.best_params_
        preds_dict[name] = [y_pred, y_proba, cv_results, best_params]
    else:
        y_pred = model.predict(X_test)
        y_proba = model.predict_proba(X_test)
        preds_dict[name] = [y_pred, y_proba]

    return preds_dict


def fairness_metrics_calc(
    y_test: pd.DataFrame, prot_attr: List, preds_dict: Dict
) -> pd.DataFrame:
    """
    Create a dataframe that contains information about evaluation and fairness metrics results on every model.

    Args:
        y_test(pd.DataFrame): The test set with columns the target variable.
        prot_attr(List): All the protective attributes.
        preds_dict(Dict): A dictionary with keys the names of the models and values the predictions of every model.

    Returns:
        final_report(pd.DataFrame): A dataframe that contains information about evaluation
                                    and fairness metrics results on every model.

    """

    fairness_metrics = {}
    for name, values in preds_dict.items():
        y_pred = values[0]
        y_proba = values[1][:, 1]
        alg_scores = {}
        alg_scores["Algorithm"] = name
        alg_scores["Balanced Accuracy"] = round(
            balanced_accuracy_score(y_test, y_pred), 4
        )
        alg_scores["f1-score"] = round(f1_score(y_test, y_pred), 4)
        alg_scores["ROC-AUC"] = round(roc_auc_score(y_test, y_proba), 4)

        for attr in prot_attr:
            alg_scores[f"Statistical Parity Difference ({attr})"] = round(
                statistical_parity_difference(y_test, y_pred, prot_attr=attr), 4
            )
            alg_scores[f"Disparate Impact Ratio ({attr})"] = round(
                disparate_impact_ratio(y_test, y_pred, prot_attr=attr), 4
            )
            alg_scores[f"Equal Opportunity Difference ({attr})"] = round(
                equal_opportunity_difference(y_test, y_pred, prot_attr=attr), 4
            )
            alg_scores[f"Average Odds Difference ({attr})"] = round(
                average_odds_difference(y_test, y_pred, prot_attr=attr), 4
            )

        fairness_metrics[name] = alg_scores
    final_report = pd.DataFrame(fairness_metrics).T

    return final_report


def params_calc(preds_dict: Dict) -> pd.DataFrame:
    """
    Create a dataframe that contains information about the selected hyperparameters on every selected model.

    Args:
        preds_dict(Dict): A dictionary with keys the names of the models and values the predictions of every model.

    Returns:
        params_df(pd.DataFrame): A dataframe that contains information about
                                 the selected hyperparameters on every selected model.
    """

    params_df = pd.DataFrame()
    for name, params in preds_dict.items():
        if name in (
            "Learning Fair Representations",
            "Exponentiated Gradient Reduction",
            "Grid Search Reduction",
            "Adversarial Debiasing",
        ):
            # Convert numpy arrays in params[2] and params[3] to lists
            params[2] = {
                k: v.tolist() if isinstance(v, np.ndarray) else v
                for k, v in params[2].items()
            }
            params[3] = {
                k: v.tolist() if isinstance(v, np.ndarray) else v
                for k, v in params[3].items()
            }
            lfr_params = {"Algorithm": name, "best_params": params[3]}
            lfr_params.update(params[2])

            params_df = pd.concat(
                [params_df, pd.DataFrame([lfr_params])], ignore_index=True
            )
            params_df = params_df[
                [
                    "Algorithm",
                    "best_params",
                    "mean_fit_time",
                    "std_fit_time",
                    "mean_test_score",
                    "std_test_score",
                ]
            ]

    if params_df.shape == (0, 0):
        params_df["Algorithm"] = "No hyperparameter tuning"

    # Replace non-compliant float values
    params_df.replace([np.inf, -np.inf], np.finfo(np.float64).max, inplace=True)
    params_df.replace(np.nan, None, inplace=True)

    return params_df


def data_bias_output(
    data: pd.DataFrame,
    preds_dict: Dict,
    categorical_features: List,
    X_train: pd.DataFrame,
    y_train: pd.DataFrame,
    indices_train: np.ndarray,
    indices_test: np.ndarray,
    X_test: pd.DataFrame,
    y_test: pd.DataFrame,
) -> pd.DataFrame:
    """
    Create a dataframe with the transformed data from the data bias models.

    Args:
        data(pd.DataFrame): The preprocessed dataframe.
        preds_dict(Dict): A dictionary with keys the names of the models and values the predictions of every model.
        categical_features(List): A list with all the categorical features from the initial dataframe.
        X_train(pd.DataFrame): The training set with columns of protected and non attributes attributes.
        y_train(pd.DataFrame): The training set with columns the target variable.
        indices_train(ndarray): The indices of training set.
        indices_test(ndarray): The indices of test set.
        X_test(pd.DataFrame): The test set with columns of protected and non attributes attributes.
        y_test(pd.DataFrame): The test set with columns the target variable.
    Returns:
        output_data(pd.DataFrame): A dataframe with the transformed data from the data bias models.

    """

    data_output = []
    for name, values in preds_dict.items():
        if name != "Logistic Regression":
            if name == "Reweighing":
                weights = pd.DataFrame(
                    values[2], index=X_train.index, columns=["weights"]
                )
                X_train_transformed = pd.concat([X_train, weights], axis=1)
                X_test_transformed = X_test.copy()
                X_test_transformed["weights"] = 1
            else:
                X_train_transformed = values[-1]
                X_test_transformed = X_test.copy()

            train = pd.concat([X_train_transformed, y_train], axis=1)
            train["source"] = "train"
            test = pd.concat([X_test_transformed, y_test], axis=1)
            test["source"] = "test"
            transformed_data = pd.concat(
                [train.reset_index(drop=True), test.reset_index(drop=True)], axis=0
            )
            transformed_data["model"] = name

            indices_train = [str(i) for i in indices_train]
            indices_test = [str(i) for i in indices_test]

            categorical_init_categories = pd.concat(
                [
                    data[categorical_features].loc[indices_train],
                    data[categorical_features].loc[indices_test],
                ]
            ).reset_index(drop=True)
            transformed_data = pd.concat(
                [categorical_init_categories, transformed_data.reset_index(drop=True)],
                axis=1,
            )
            data_output.append(transformed_data)
            output_data = pd.concat(data_output)
    return output_data


def standardized_dataset(data: pd.DataFrame, prot_attr: List, target: str) -> Tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    np.ndarray,
    np.ndarray,
]:
    """
    Τurn data to a multindex to faciliatate calculations, split data into train/test and implement data scaling.

    Args:
       data(pd.DataFrame): The initial dataset.
       prot_attr(List): All the protective attributes.
       target(str): The target variable.
    Returns:
        X(pd.DataFrame): A dataframe with columns of protected and non attributes attributes.
        y(pd.DataFrame): A dataframe with column the target variable.
        X_train(pd.DataFrame): The training set with columns of protected and non attributes attributes.
        y_train(pd.DataFrame): The training set with columns the target variable.
        y_test(pd.DataFrame): The test set with columns the target variable.
        indices_train(np.ndarray): The indices of training set.
        indices_test(np.ndarray): The indices of the test set.

    """
    standard_dataset = standardize_dataset(df=data, prot_attr=prot_attr, target=target)

    X = standard_dataset[0]
    y = standard_dataset[1]

    X.index = y.index = pd.MultiIndex.from_arrays(X.index.codes, names=X.index.names)
    y = pd.Series(y.factorize(sort=True)[0], index=y.index, name=y.name)

    (
        X_train,
        X_test,
        y_train,
        y_test,
        indices_train,
        indices_test,
    ) = train_test_split(X, y, range(len(data)), train_size=0.7, random_state=0)
    sc = StandardScaler()
    X_train_scaled = sc.fit_transform(X_train)
    X_test_scaled = sc.transform(X_test)
    X_train = pd.DataFrame(X_train_scaled, index=X_train.index, columns=X_train.columns)
    X_test = pd.DataFrame(X_test_scaled, index=X_test.index, columns=X_test.columns)

    return X_train, X_test, y_train, y_test, indices_train, indices_test


def scoring_converter(parameters: Dict) -> Dict:
    """
    Convert the UI parameteres related to the metrics selection in order to have the correct format.

    Args:
        parameters(dict): The dictionary with all the information from the UI.

    Returns:
        parameters(dict): The dictionary with all the information from the UI.

    """

    parameters["calMetrics"] = (
        parameters["calMetrics"]
        .replace("False Positive Rate", "fpr")
        .replace("False Negative Rate", "fnr")
        .replace("Weighted", "weighted")
    )

    parameters["expMetrics"] = (
        parameters["expMetrics"]
        .replace("Demographic Parity", "DemographicParity")
        .replace("Equalized Odds", "EqualizedOdds")
        .replace("True Positive Rate Parity", "TruePositiveRateParity")
        .replace("False Positive Rate Parity", "FalsePositiveRateParity")
        .replace("Error Rate Parity", "ErrorRateParity")
    )

    parameters["gridMetrics"] = (
        parameters["gridMetrics"]
        .replace("Demographic Parity", "DemographicParity")
        .replace("Equalized Odds", "EqualizedOdds")
        .replace("True Positive Rate Parity", "TruePositiveRateParity")
    )

    parameters["rejMetrics"] = (
        parameters["rejMetrics"]
        .replace("Demographic Parity", "StatisticalParity")
        .replace("Equalized Odds", "AverageOdds")
        .replace("True Positive Rate Parity", "EqualOpportunity")
        .replace("Disparate Impact", "disparate_impact")
    )

    return parameters


def hyperparameters_converter(parameters: Dict) -> Dict:
    """
    Convert the UI parameteres related to the hyperparameters selection in order to have the correct format.

    Args:
        parameters(Dict): The dictionary with all the information from the UI.

    Returns:
        parameters(Dict): The dictionary with all the information from the UI.

    """

    for param in parameters["advGroup"]:
        param["value"] = [
            (
                float(val)
                if param["hyperparameter"] == "adversary_loss_weight"
                else int(val) if val != "" else val
            )
            for val in param["value"].split(", ")
        ]

    for param in parameters["expGroup"]:
        param["value"] = [
            float(val) if val != "" else val for val in param["value"].split(", ")
        ]

    for param in parameters["fairGroup"]:
        param["value"] = [
            float(val) if val != "" else val for val in param["value"].split(", ")
        ]

    for param in parameters["gridGroup"]:
        param["value"] = [
            float(val) if val != "" else val for val in param["value"].split(", ")
        ]

    return parameters


def hyperparameters_boolean(parameters: Dict) -> Dict:
    """
    Convert the UI parameteres related to the hyperparameters selection in order to insert the default hyperparameters,
    in case the user doesn't select to modify their own hyperparameters.

    Args:
        parameters(Dict): The dictionary with all the information from the UI.

    Returns:
        parameters(Dict): The dictionary with all the information from the UI.

    """

    if not parameters["hyperparamBoolean"]:
        parameters["fairGroup"] = [
            {"hyperparameter": "reconstruct_weight", "value": "0.0001, 0.001, 0.01"},
            {"hyperparameter": "target_weight", "value": "1, 10"},
            {"hyperparameter": "fairness_weight", "value": "10, 100"},
        ]
        parameters["advGroup"] = [
            {"hyperparameter": "adversary_loss_weight", "value": "0.1, 0.5"},
            {"hyperparameter": "num_epochs", "value": "50, 100"},
            {"hyperparameter": "classifier_num_hidden_units", "value": "100, 200"},
        ]
        parameters["expGroup"] = [
            {"hyperparameter": "eta0", "value": "0.01, 0.1, 2.0"},
            {"hyperparameter": "eps", "value": "0.01, 0.05, 0.1"},
        ]
        parameters["gridGroup"] = [
            {"hyperparameter": "constraint_weight", "value": "0.1, 0.5, 0.7"}
        ]

    return parameters


def metrics_boolean(parameters: Dict) -> Dict:
    """
    Convert the UI parameteres related to the metrics selection in order to insert the default metrics,
    in case the user doesn't select to modify their own hyperparameters.

    Args:
        parameters(Dict): The dictionary with all the information from the UI.

    Returns:
        parameters(Dict): The dictionary with all the information from the UI.

    """

    if not parameters["metricsBoolean"]:
        parameters["expMetrics"] = "EqualizedOdds"
        parameters["gridMetrics"] = "EqualizedOdds"
        parameters["rejMetrics"] = "AverageOdds"
        parameters["calMetrics"] = "fnr"

    return parameters


def custom_preprocessing(df: pd.DataFrame) -> pd.DataFrame:
    """
    A custom preprocessing function that fills in NA values of numerical variables
    with the mean value and of categorical values with a dinstict Other category

    Args:
        df(pd.DataFrame): The initial dataframe.

    Returns:
        df(pd.DataFrame): The preprocessed dataframe.
    """

    numerical_cols = df.select_dtypes(include=np.number).columns
    df[numerical_cols] = df[numerical_cols].fillna(df[numerical_cols].mean())
    categorical_cols = df.select_dtypes(include="object").columns
    df[categorical_cols] = df[categorical_cols].fillna("Other")

    return df


def replace_non_compliant_floats(obj):
    """Replace non-compliant floats in the given object.

    This function recursively traverses the given object and replaces any non-compliant floats with appropriate values.

    Args:
        obj (object): The object to be processed.

    Returns:
        object: The processed object with non-compliant floats replaced.

    Examples:
        >>> replace_non_compliant_floats(3.14)
        3.14

        >>> replace_non_compliant_floats(np.nan)
        None

        >>> replace_non_compliant_floats(np.inf)
        1.7976931348623157e+308

        >>> replace_non_compliant_floats(-np.inf)
        -1.7976931348623157e+308

        >>> replace_non_compliant_floats({'a': 3.14, 'b': np.nan})
        {'a': 3.14, 'b': None}

        >>> replace_non_compliant_floats([3.14, np.nan])
        [3.14, None]
    """
    if isinstance(obj, float):
        if np.isnan(obj):
            return None
        if obj == np.inf:
            return np.finfo(np.float64).max
        if obj == -np.inf:
            return -np.finfo(np.float64).max
    elif isinstance(obj, dict):
        return {k: replace_non_compliant_floats(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [replace_non_compliant_floats(x) for x in obj]
    return obj


def predict_data_bias(
    protected_attributes: List,
    preferred_attribute: str,
    privileged_classes: List,
    target: str,
    models: List,
    favorable_label: str,
    lfr_params: Dict,
    input=None,
) -> Tuple[Dict, Dict, Dict]:
    """
    Create the final pipeline for the computation of data or model bias.

    Args:
        protected_attributes(List): All the protective attributes.
        preferred_attribute(str): The prefered protected attribute to be used on metrics
                        and on models with only one protective attribute option.
        privileged_classes(List): The privilege class for ecery protective attribute.
        target(str): The target variable.
        models(List): A list with all the selected models.
        favorable_label(str): The favorable label of the target variable.
        lfr_params(Dict): It contains the hyperparameters.
        input (dict): The initial dataset in dict format.

    Returns:
        Dict[dict, dict, dict]: A dictionary that contains three dictionaries:
                                1) final_report: information about evaluation and fairness metrics results on every model.
                                2) preds_output: The transformed data from the data bias models or the predictions from the model bias models.
                                3) params_df: A dict that contains information about the selected hyperparameters on every selected model.
    """
    if input and isinstance(input, dict):
        input = pd.DataFrame(input)

    models_dict = create_models_dict(models, lfr_params, preferred_attribute)

    categorical_features = list(
        set(input.select_dtypes(include="object").columns) - set([target])
    )

    df = (
        StandardDataset(
            df=input,
            label_name=target,
            favorable_classes=[favorable_label],
            protected_attribute_names=protected_attributes,
            privileged_classes=privileged_classes,
            categorical_features=categorical_features,
            custom_preprocessing=custom_preprocessing,
            bias="Data Bias",
        )
        .convert_to_dataframe()[0]
        .reset_index(drop=True)
    )
    combined_prot_attr = "_".join(attr for attr in protected_attributes)
    df[combined_prot_attr] = np.where(
        np.all(df[protected_attributes] == 1, axis=1), 1, 0
    )

    protected_attributes.append(combined_prot_attr)

    (
        X_train,
        X_test,
        y_train,
        y_test,
        indices_train,
        indices_test,
    ) = standardized_dataset(df, protected_attributes, target)
    X_train = X_train.drop(protected_attributes, axis=1)
    X_test = X_test.drop(protected_attributes, axis=1)

    computations = [
        delayed(create_predictions)(
            name,
            model,
            lfr_params,
            scorer,
            X_train,
            y_train,
            X_test,
            protected_attributes,
        )
        for name, model, lfr_params, scorer in models_dict
    ]
    results = compute(*computations)

    preds_dict = {}
    for result in results:
        preds_dict.update(result)

    final_report = fairness_metrics_calc(y_test, protected_attributes, preds_dict)
    params_df = params_calc(preds_dict)

    preds_output = data_bias_output(
        input,
        preds_dict,
        categorical_features,
        X_train,
        y_train,
        indices_train,
        indices_test,
        X_test,
        y_test,
    )

    final_report_dict = replace_non_compliant_floats(final_report.to_dict())
    preds_output_dict = replace_non_compliant_floats(preds_output.to_dict())
    params_df_dict = replace_non_compliant_floats(params_df.to_dict())

    return {
        "final_report": final_report_dict,
        "preds_output": preds_output_dict,
        "params_df": params_df_dict,
    }
