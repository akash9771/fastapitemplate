from fastapi import APIRouter, Request

from app.bias_mitigation.data_bias.predict import predict_data_bias
from app.bias_mitigation.data_bias.schema import BiasMitigationDataBiasInput
from app.logger import logger
from validator.decorators import async_token_validation_and_metering

# from app.v1.odds_ratio import compute_odds_ratio


logger = logger.getChild(__name__)

router = APIRouter(
    prefix="/bias-mitigation/data-bias",
    tags=["Bias Mitigation"],
)


@router.get("/")
@async_token_validation_and_metering()
async def data_bias_info(request: Request):
    return {
        "description": "This is the data_bias endpoint.",
        "information": "Please use the /predict endpoint to make a prediction.",
    }


@router.post("/predict")
@async_token_validation_and_metering()
async def data_bias_predict(request: Request, model: BiasMitigationDataBiasInput):
    """
    ## Data Bias Prediction

    Returns:
        JSON: A JSON object with the prediction.
    """
    return predict_data_bias(**model.model_dump())
