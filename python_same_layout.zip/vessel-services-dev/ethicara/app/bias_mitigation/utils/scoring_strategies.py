from abc import ABC, abstractmethod

import pandas as pd
from aif360.sklearn.metrics import (
    average_odds_error,
    equal_opportunity_difference,
    statistical_parity_difference,
)
from sklearn.metrics import balanced_accuracy_score

from app.bias_mitigation.AIF360_util import false_positive_rate_difference


class ScoringStrategy(ABC):
    @abstractmethod
    def score(self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str):
        pass


class DeltaScoring(ScoringStrategy):
    def score(self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str):
        return balanced_accuracy_score(y_true, y_pred) - abs(
            statistical_parity_difference(y_true, y_pred, prot_attr=pref_attr)
        )


class StatisticalParityScoring(ScoringStrategy):
    def score(self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str):
        return abs(statistical_parity_difference(y_true, y_pred, prot_attr=pref_attr))


class DemographicParityScoring(ScoringStrategy):
    def score(self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str):
        return abs(statistical_parity_difference(y_true, y_pred, prot_attr=pref_attr))


class AverageOddsScoring(ScoringStrategy):
    def score(self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str):
        return abs(average_odds_error(y_true, y_pred, prot_attr=pref_attr))


class EquilizedOddsScoring(ScoringStrategy):
    def score(self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str):
        return abs(average_odds_error(y_true, y_pred, prot_attr=pref_attr))


class ErrorRateParityScoring(ScoringStrategy):
    def score(self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str):
        return abs(average_odds_error(y_true, y_pred, prot_attr=pref_attr))


class EqualOpportunityScoring(ScoringStrategy):
    def score(self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str):
        return abs(equal_opportunity_difference(y_true, y_pred, prot_attr=pref_attr))


class TruePositiveRateParityScoring(ScoringStrategy):
    def score(self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str):
        return abs(equal_opportunity_difference(y_true, y_pred, prot_attr=pref_attr))


class FalsePositiveRateParityScoring(ScoringStrategy):
    def score(self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str):
        return abs(false_positive_rate_difference(y_true, y_pred, prot_attr=pref_attr))


# Define other scoring strategies...


class ScoringContext:
    def __init__(self, strategy: ScoringStrategy):
        self._strategy = strategy

    @property
    def strategy(self):
        return self._strategy

    @strategy.setter
    def strategy(self, strategy: ScoringStrategy):
        self._strategy = strategy

    def execute_strategy(
        self, y_true: pd.DataFrame, y_pred: pd.DataFrame, pref_attr: str
    ):
        return self._strategy.score(y_true, y_pred, pref_attr)


def scoring_func(
    y_true: pd.DataFrame, y_pred: pd.DataFrame, scoring: str, pref_attr: str
):
    strategies = {
        "Delta": DeltaScoring(),
        "StatisticalParity": StatisticalParityScoring(),
        "DemographicParity": DemographicParityScoring(),
        "AverageOdds": AverageOddsScoring(),
        "EqualizedOdds": EquilizedOddsScoring(),
        "ErrorRateParity": ErrorRateParityScoring(),
        "EqualOpportunity": EqualOpportunityScoring(),
        "TruePositiveRateParity": TruePositiveRateParityScoring(),
        "FalsePositiveRateParity": FalsePositiveRateParityScoring(),
        # Add other strategies...
    }

    if scoring in strategies:
        context = ScoringContext(strategies[scoring])
        return context.execute_strategy(y_true, y_pred, pref_attr)
    else:
        raise ValueError(f"Invalid scoring method: {scoring}")
