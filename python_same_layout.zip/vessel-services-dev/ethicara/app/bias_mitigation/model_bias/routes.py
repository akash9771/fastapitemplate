import warnings

from fastapi import APIRouter, Body, Request

from app.bias_mitigation.model_bias.predict import predict_model_bias
from app.bias_mitigation.model_bias.schema import BiasMitigationModelBiasInput
from app.logger import logger
from app.utils import load_model

logger = logger.getChild(__name__)

router = APIRouter(
    prefix="/bias-mitigation/model-bias",
    tags=["Bias Mitigation"],
)


@router.get("/")
async def model_bias_info():
    return {
        "description": "This is the model_bias endpoint.",
        "information": "Please use the /predict endpoint to make a prediction.",
    }


@router.post("/predict")
async def model_bias_predict(
    request: Request, data: BiasMitigationModelBiasInput = Body()
):
    """
    ## Data Bias Prediction

    Returns:
        JSON: A JSON object with the prediction.
    """
    with warnings.catch_warnings():
        warnings.simplefilter("always")
        clf = await load_model(**data.model_dump(include={"clf"}))
        return predict_model_bias(clf, **data.model_dump(exclude={"clf"}))
