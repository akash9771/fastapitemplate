from typing import Dict, List, Tuple

import dask
import numpy as np
import pandas as pd
from aif360.sklearn.datasets.utils import standardize_dataset
from aif360.sklearn.inprocessing import (
    AdversarialDebiasing,
    ExponentiatedGradientReduction,
    GridSearchReduction,
)
from aif360.sklearn.metrics import (
    average_odds_difference,
    disparate_impact_ratio,
    equal_opportunity_difference,
    statistical_parity_difference,
)
from aif360.sklearn.postprocessing import (
    CalibratedEqualizedOdds,
    PostProcessingMeta,
    RejectOptionClassifierCV,
)
from aif360.sklearn.preprocessing import Reweighing
from dask import delayed
from sklearn import metrics as skm
from sklearn.base import BaseEstimator
from sklearn.metrics import balanced_accuracy_score, f1_score, roc_auc_score
from sklearn.model_selection import GridSearchCV

from app.bias_mitigation.AIF360_util import StandardDataset
from app.bias_mitigation.utils.scoring_strategies import scoring_func


def create_models_dict(
    models_params: List,
    prot_attr: List,
    pref_attr: str,
    prot_attr_cols=None,
    my_clf=None,
) -> List:
    """
    Create a list with all the selected models names, the model object, their hyperparameters and the scoring function.

    Args:
        models_list(List): A list with all the selected models.
        parameters(Dict): The dictionary with all the information from the UI.
        bias(str): The type of bias, model or data bias.
        prot_attr(List): All the protective attributes.
        pref_attr(str): The prefered protected attribute to be used on metrics and on models with only one protective attribute option.
        prot_attr_cols(List): The encoding protected attributes to be used for in-processing models.
        my_clf(BaseEstimator): The input scikit-learn model object that be insterted by the user.

    Returns:
    models(List): A list with all the selected models names, the model object, their hyperparameters and the scoring function

    """
    models = []
    models.insert(0, ("Classifier", my_clf, "", ""))
    for model in models_params:
        params_dict = {}
        if model["name"] == "Exponentiated Gradient Reduction":
            np.random.seed(0)
            egr = ExponentiatedGradientReduction(
                prot_attr_cols,
                estimator=my_clf,
                constraints=model["metric"],
            )
            egr_scorer = skm.make_scorer(
                scoring_func,
                scoring=model["metric"],
                greater_is_better=False,
                pref_attr=pref_attr,
            )
            models.append(
                (
                    "Exponentiated Gradient Reduction",
                    egr,
                    model["params"],
                    egr_scorer,
                )
            )
        elif model["name"] == "Grid Search Reduction":
            np.random.seed(0)
            gsr = GridSearchReduction(
                prot_attr_cols,
                estimator=my_clf,
                constraints=model["metric"],
            )
            gsr_params = params_dict
            gsr_scorer = skm.make_scorer(
                scoring_func,
                scoring=model["metric"],
                greater_is_better=False,
                pref_attr=pref_attr,
            )
            models.append(("Grid Search Reduction", gsr, gsr_params, gsr_scorer))
        elif model["name"] == "Calibrated Equalized Odds Postprocessing":
            ceo = PostProcessingMeta(
                my_clf,
                CalibratedEqualizedOdds(
                    pref_attr,
                    cost_constraint=model["metric"],
                    random_state=0,
                ),
                random_state=0,
            )
            models.append(("Calibrated Equalized Odds", ceo, None, None))
        elif model["name"] == "Adversarial Debiasing":
            ad = AdversarialDebiasing(
                prot_attr[:-1], scope_name="adversary", debias=True, random_state=0
            )
            ad_params = params_dict
            ad_scorer = skm.make_scorer(
                scoring_func,
                scoring="average_odds",
                greater_is_better=False,
                pref_attr=pref_attr,
            )
            models.append(("Adversarial Debiasing", ad, ad_params, ad_scorer))
        elif model["name"] == "Reject Option Based Classification":
            roc = PostProcessingMeta(
                my_clf,
                RejectOptionClassifierCV(pref_attr, scoring=model["metric"], n_jobs=-1),
                random_state=0,
            )
            models.append(("Reject Option Classifier CV", roc, None, None))

    return models


def standardized_dataset(data: pd.DataFrame, prot_attr: List, target: str) -> Tuple[
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    pd.DataFrame,
    np.ndarray,
    np.ndarray,
]:
    """
    Τurn data to a multindex to faciliatate calculations, split data into train/test and implement data scaling.

    Args:
       data(pd.DataFrame): The initial dataset.
       prot_attr(List): All the protective attributes.
       target(str): The target variable.
       bias(str): The type of bias, model or data bias.
    Returns:
        X(pd.DataFrame): A dataframe with columns of protected and non attributes attributes.
        y(pd.DataFrame): A dataframe with column the target variable.
        X_train(pd.DataFrame): The training set with columns of protected and non attributes attributes.
        y_train(pd.DataFrame): The training set with columns the target variable.
        y_test(pd.DataFrame): The test set with columns the target variable.
        indices_train(np.ndarray): The indices of training set.
        indices_test(np.ndarray): The indices of the test set.

    """

    standard_dataset = standardize_dataset(df=data, prot_attr=prot_attr, target=target)

    X = standard_dataset[0]
    y = standard_dataset[1]

    X.index = y.index = pd.MultiIndex.from_arrays(X.index.codes, names=X.index.names)
    y = pd.Series(y.factorize(sort=True)[0], index=y.index, name=y.name)

    return X, y


def create_predictions(
    name: str,
    model: BaseEstimator,
    params: Dict,
    scorer,
    X_train: pd.DataFrame,
    y_train: pd.DataFrame,
    X_test: pd.DataFrame,
    prot_attr: List,
) -> Dict:
    """
    This function implements GridSerachCV, fit the model to the training set and gives the predictions.

    Args:
        name(str): The name of the algorithm.
        model(BaseEstimator): The AI Fairness 360 scikit-learn model object.
        params(Dict): A dictionaty with all the hyperparameters to be tuned during GridSearchCV.
        scorer(function): The scoring function.
        X_train(pd.DataFrame): The training set with columns of protected and non attributes attributes.
        y_train(pd.DataFrame): The training set with columns the target variable.
        X_test(pd.DataFrame): The test set with columns of protected and non attributes attributes.
        prot_attr(List): All the protective attributes.

    Returns:
        preds_dict(Dict): A dictionary with keys the names of the models and values the predictions of every model.
    """
    preds_dict = {}
    if name == "Reweighing":
        rwg_instance_weights = Reweighing(prot_attr).fit_transform(X_train, y_train)[1]
        grid = GridSearchCV(model, params, scoring=scorer, cv=5, n_jobs=4).fit(
            X_train, y_train, sample_weight=rwg_instance_weights
        )
        y_pred = grid.predict(X_test)
        y_proba = grid.predict_proba(X_test)
        preds_dict[name] = [y_pred, y_proba, rwg_instance_weights]

    elif name in ("Reject Option Classifier CV", "Calibrated Equalized Odds"):
        grid = model.fit(X_train, y_train)
        y_pred = grid.predict(X_test)
        y_proba = grid.predict_proba(X_test)
        preds_dict[name] = [y_pred, y_proba]
    elif name == "Learning Fair Representations":
        grid = GridSearchCV(model, params, scoring=scorer, cv=5, n_jobs=4).fit(
            X_train, y_train
        )
        y_pred = grid.predict(X_test)
        y_proba = grid.predict_proba(X_test)
        cv_results = grid.cv_results_
        best_params = grid.best_params_
        X_train_transformed = grid.transform(X_train)
        preds_dict[name] = [
            y_pred,
            y_proba,
            cv_results,
            best_params,
            X_train_transformed,
        ]
    elif name == "Adversarial Debiasing":
        grid = GridSearchCV(model, params, scoring=scorer, cv=5, n_jobs=None).fit(
            X_train, y_train
        )
        y_pred = grid.predict(X_test)
        y_proba = grid.predict_proba(X_test)
        cv_results = grid.cv_results_
        best_params = grid.best_params_
        preds_dict[name] = [y_pred, y_proba, cv_results, best_params]
    elif name in (
        "Exponentiated Gradient Reduction",
        "Grid Search Reduction",
        "Logistic Regression",
    ):
        grid = GridSearchCV(model, params, scoring=scorer, cv=5, n_jobs=4).fit(
            X_train, y_train
        )
        y_pred = grid.predict(X_test)
        y_proba = grid.predict_proba(X_test)
        cv_results = grid.cv_results_
        best_params = grid.best_params_
        preds_dict[name] = [y_pred, y_proba, cv_results, best_params]
    else:
        y_pred = model.predict(X_test)
        y_proba = model.predict_proba(X_test)
        preds_dict[name] = [y_pred, y_proba]

    return preds_dict


def params_calc(preds_dict: Dict) -> pd.DataFrame:
    """
    Create a dataframe that contains information about the selected hyperparameters on every selected model.

    Args:
        preds_dict(Dict): A dictionary with keys the names of the models and values the predictions of every model.

    Returns:
        params_df(pd.DataFrame): A dataframe that contains information about
                                 the selected hyperparameters on every selected model.
    """

    params_df = pd.DataFrame()
    for name, params in preds_dict.items():
        if name in (
            "Learning Fair Representations",
            "Exponentiated Gradient Reduction",
            "Grid Search Reduction",
            "Adversarial Debiasing",
        ):
            params_dict = {"Algorithm": name, "best_params": params[3]}
            params_dict.update(params[2])

            params_df = pd.concat(
                [params_df, pd.DataFrame([params_dict])], ignore_index=True
            )
            params_df = params_df[
                [
                    "Algorithm",
                    "best_params",
                    "mean_fit_time",
                    "std_fit_time",
                    "mean_test_score",
                    "std_test_score",
                ]
            ]

    if params_df.shape == (0, 0):
        params_df["Algorithm"] = "No hyperparameter tuning"

    if params_df.empty:
        params_df = pd.DataFrame({"Algorithm": ["No hyperparameter tuning"]})

    return params_df


def fairness_metrics_calc(
    y_test: pd.DataFrame, prot_attr: List, preds_dict: Dict
) -> pd.DataFrame:
    """
    Create a dataframe that contains information about evaluation and fairness metrics results on every model.

    Args:
        y_test(pd.DataFrame): The test set with columns the target variable.
        prot_attr(List): All the protective attributes.
        preds_dict(Dict): A dictionary with keys the names of the models and values the predictions of every model.

    Returns:
        final_report(pd.DataFrame): A dataframe that contains information about evaluation
                                    and fairness metrics results on every model.

    """

    fairness_metrics = {}
    for name, values in preds_dict.items():
        y_pred = values[0]
        y_proba = values[1][:, 1]
        alg_scores = {}
        alg_scores["Algorithm"] = name
        alg_scores["Balanced Accuracy"] = round(
            balanced_accuracy_score(y_test, y_pred), 4
        )
        y_test.to_csv("y_test.csv", index=False)
        alg_scores["f1-score"] = round(f1_score(y_test, y_pred), 4)
        try:
            alg_scores["ROC-AUC"] = round(roc_auc_score(y_test, y_proba), 4)
        except:
            alg_scores["ROC-AUC"] = "Not Available"

        for attr in prot_attr:
            alg_scores[f"Statistical Parity Difference ({attr})"] = round(
                statistical_parity_difference(y_test, y_pred, prot_attr=attr), 4
            )
            alg_scores[f"Disparate Impact Ratio ({attr})"] = round(
                disparate_impact_ratio(y_test, y_pred, prot_attr=attr), 4
            )
            alg_scores[f"Equal Opportunity Difference ({attr})"] = round(
                equal_opportunity_difference(y_test, y_pred, prot_attr=attr), 4
            )
            alg_scores[f"Average Odds Difference ({attr})"] = round(
                average_odds_difference(y_test, y_pred, prot_attr=attr), 4
            )

        fairness_metrics[name] = alg_scores
    final_report = pd.DataFrame(fairness_metrics).T
    return final_report


def model_bias_output(
    data: pd.DataFrame,
    preds_dict: Dict,
    categorical_features: List,
    X_test: pd.DataFrame,
    y_test: pd.DataFrame,
) -> pd.DataFrame:
    """
    Create a dataframe with the predictions from the model bias models.

    Args:
        data(pd.DataFrame): The preprocessed dataframe.
        preds_dict(Dict): A dictionary with keys the names of the models and values the predictions of every model.
        categorical_features(List): A list with all the categorical features from the initial dataframe.
        X_test(pd.DataFrame): The test set with columns of protected and non attributes attributes.
        y_test(pd.DataFrame): The test set with columns the target variable.

    Returns:
        output_data(pd.DataFrame): A dataframe with the predictions from the model bias models.
    """

    preds_list = []
    for name, values in preds_dict.items():
        y_pred = values[0]
        preds_list.append(pd.DataFrame(y_pred, columns=["preds_" + str(name)]))
    test = pd.concat(
        [X_test.reset_index(drop=True), y_test.reset_index(drop=True)], axis=1
    )
    test["source"] = "test"

    cat_features_init_categories = data[categorical_features]

    test = pd.concat([cat_features_init_categories, test], axis=1)
    output_data = pd.concat([test] + preds_list, axis=1)
    return output_data


def replace_non_compliant_floats(obj):
    """Replace non-compliant floats in the given object.

    This function recursively traverses the given object and replaces any non-compliant floats with appropriate values.

    Args:
        obj (object): The object to be processed.

    Returns:
        object: The processed object with non-compliant floats replaced.

    Examples:
        >>> replace_non_compliant_floats(3.14)
        3.14

        >>> replace_non_compliant_floats(np.nan)
        None

        >>> replace_non_compliant_floats(np.inf)
        1.7976931348623157e+308

        >>> replace_non_compliant_floats(-np.inf)
        -1.7976931348623157e+308

        >>> replace_non_compliant_floats({'a': 3.14, 'b': np.nan})
        {'a': 3.14, 'b': None}

        >>> replace_non_compliant_floats([3.14, np.nan])
        [3.14, None]
    """
    if isinstance(obj, float):
        if np.isnan(obj):
            return None
        if obj == np.inf:
            return np.finfo(np.float64).max
        if obj == -np.inf:
            return -np.finfo(np.float64).max
    elif isinstance(obj, dict):
        return {k: replace_non_compliant_floats(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [replace_non_compliant_floats(x) for x in obj]
    return obj


def make_json_serializable(df):
    """Converts the elements of a DataFrame to JSON serializable format.

    Args:
        df (pandas.DataFrame): The DataFrame to be converted.

    Returns:
        pandas.DataFrame: The DataFrame with elements converted to JSON serializable format.
    """
    for col in df.columns:
        df[col] = df[col].apply(
            lambda x: x.tolist() if isinstance(x, np.ndarray) else x
        )
        df[col] = df[col].apply(
            lambda x: (
                x.__dict__
                if not isinstance(
                    x, (np.ndarray, list, dict, str, int, float, bool, type(None))
                )
                else x
            )
        )
    return df


def predict_model_bias(
    my_clf,
    prot_attr: List,
    pref_attr: str,
    privileged_classes: List,
    target: str,
    models: List[Dict],
    fav_label: str,
    train: Dict,
    test: Dict,
    X_train: Dict,
    X_test: Dict,
) -> Dict:
    """Predicts model bias and returns the results.

    This function takes in various parameters including the classifier, protected attributes,
    preferred attribute, privileged classes, target variable, models, favorite label, training data,
    testing data, and feature data. It performs bias mitigation by creating models, standardizing
    the datasets, and computing fairness metrics. It then generates a final report, prediction output,
    and parameter dataframe.

    Args:
        my_clf (object): The classifier object used for prediction.
        prot_attr (List): A list of protected attributes.
        pref_attr (str): The preferred attribute.
        privileged_classes (List): A list of privileged classes.
        target (str): The target variable.
        models (List[Dict]): A list of dictionaries containing model information.
        fav_label (str): The favorite label.
        train (Dict): The training data.
        test (Dict): The testing data.
        X_train (Dict): The feature data for training.
        X_test (Dict): The feature data for testing.

    Returns:
        Dict: A dictionary containing the final report, prediction output, and parameter dataframe.
    """
    if X_train and isinstance(X_train, dict):
        X_train = pd.DataFrame(X_train)

    if X_test and isinstance(X_test, dict):
        X_test = pd.DataFrame(X_test)

    if train and isinstance(train, dict):
        train = pd.DataFrame(train)

    if test and isinstance(test, dict):
        test = pd.DataFrame(test)

    prot_attr_cols = [
        colname for attr in prot_attr for colname in X_train if attr in colname
    ]

    models_dict = create_models_dict(
        models, prot_attr, pref_attr, prot_attr_cols, my_clf
    )

    categorical_features = list(
        set(train.select_dtypes(include="object").columns) - set([target])
    )

    additional_features = prot_attr.copy()
    additional_features.append(target)
    X_train[additional_features] = train[additional_features]
    X_test[additional_features] = test[additional_features]

    df_train = StandardDataset(
        df=X_train,
        label_name=target,
        favorable_classes=[fav_label],
        protected_attribute_names=prot_attr,
        privileged_classes=privileged_classes,
    ).convert_to_dataframe()[0]

    df_test = (
        StandardDataset(
            df=X_test,
            label_name=target,
            favorable_classes=[fav_label],
            protected_attribute_names=prot_attr,
            privileged_classes=privileged_classes,
        )
        .convert_to_dataframe()[0]
        .reset_index(drop=True)
    )

    combined_prot_attr = "_".join(attr for attr in prot_attr)
    df_train[combined_prot_attr] = np.where(
        np.all(df_train[prot_attr] == 1, axis=1), 1, 0
    )
    df_test[combined_prot_attr] = np.where(
        np.all(df_test[prot_attr] == 1, axis=1), 1, 0
    )

    prot_attr.append(combined_prot_attr)
    X_train, y_train = standardized_dataset(df_train, prot_attr, target)
    X_test, y_test = standardized_dataset(df_test, prot_attr, target)
    X_train = X_train.drop(prot_attr, axis=1)
    X_test = X_test.drop(prot_attr, axis=1)

    computations = [
        delayed(create_predictions)(
            name, model, params, scorer, X_train, y_train, X_test, prot_attr
        )
        for name, model, params, scorer in models_dict
    ]
    results = dask.compute(*computations)

    preds_dict = {}
    for result in results:
        preds_dict.update(result)
    final_report = fairness_metrics_calc(y_test, prot_attr, preds_dict)
    params_df = params_calc(preds_dict)

    preds_output = model_bias_output(
        test, preds_dict, categorical_features, X_test, y_test
    )

    final_report = make_json_serializable(final_report)
    preds_output = make_json_serializable(preds_output)
    params_df = make_json_serializable(params_df)

    final_report_dict = replace_non_compliant_floats(final_report.to_dict())
    preds_output_dict = replace_non_compliant_floats(preds_output.to_dict())
    params_df_dict = replace_non_compliant_floats(params_df.to_dict())

    return {
        "final_report": final_report_dict,
        "preds_output": preds_output_dict,
        "params_df": params_df_dict,
    }
