import json
from typing import Dict, List, Union

from pydantic import BaseModel, model_validator
from pydantic.fields import Field

from app.bias_mitigation.model_bias.examples import EXAMPLES


# TODO: rename Model it is very generic
class Model(BaseModel):
    name: str
    metric: str
    params: Dict


class BiasMitigationModelBiasInput(BaseModel):

    # TODO: add the full name of the variables
    target: str = Field(..., description="Target attribute")
    fav_label: Union[str, int] = Field(..., description="Favorable label")

    prot_attr: List[str] = Field(..., description="Protected attributes")
    pref_attr: str = Field(..., description="Preferred attribute")
    privileged_classes: List[List[str]] = Field(..., description="Privileged classes")
    # TODO: consolidate logic with DataBias since it is common
    models: List[Model] = Field(
        ...,
        description="Contains the name (str), metric (str) and params (dict) of the models",
    )

    train: Dict = Field(..., description="Train data for the model")
    test: Dict = Field(..., description="Test data for the model")
    X_train: Dict = Field(..., description="X train data for the model")
    X_test: Dict = Field(..., description="X test data for the model")
    clf: str = Field(..., description="The classifier object")

    model_config = {"json_schema_extra": {"examples": EXAMPLES}}

    @model_validator(mode="before")
    @classmethod
    def validate_to_json(cls, value):
        if isinstance(value, str):
            return cls(**json.loads(value))
        return value

    # TODO:add validations (validate, target, validate_favorable_label)
