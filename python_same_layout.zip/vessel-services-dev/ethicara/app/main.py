from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.openapi.docs import get_redoc_html, get_swagger_ui_html
from fastapi.openapi.utils import get_openapi
from fastapi.staticfiles import StaticFiles

from app.bias_detection.data_bias.routes import (
    router as bias_detection_data_bias_router,
)
from app.bias_detection.model_bias.routes import (
    router as bias_detection_model_bias_router,
)
from app.bias_mitigation.data_bias.routes import (
    router as model_mitigation_data_bias_router,
)
from app.bias_mitigation.model_bias.routes import (
    router as model_mitigation_model_bias_router,
)
from app.core.healthcheck import router as health_check_router
from app.core.models import router as models_router
from app.core.settings import router as settings_router
from app.core.utils import router as utils_router
from app.shap_values.routes import router as shap_values_router

TAGS_METADATA = [
    {"name": "Healthcheck", "description": "Health Check."},
    {"name": "Models", "description": "Model operations."},
    {"name": "Utils", "description": "Utility operations."},
    {"name": "Bias Detection", "description": "Bias detection operations."},
    {"name": "Bias Mitigation", "description": "Bias mitigation operations."},
    {"name": "Shap Explainer", "description": "Shap values operations."},
]

DESCRIPTION = """
Ethicara Data Science Solutions aim to support AI practitioners at Pfizer with the tools address critical ethical considerations in AI projects.
Focusing on two of the most discussed areas of ethical concern in Artificial Intelligence, the first suite of Ethicara Data Science Solutions can help you mitigate risks and negative consequences that might arise due to bias and lack of transparency of AI systems.
"""
PREFIX = "/ethicara"


app = FastAPI(
    title="Ethicara",
    description=DESCRIPTION,
    version="0.0.1",
    # docs_url=f"/{PREFIX}/docs",
    docs_url=None,
    redoc_url=None,
    openapi_tags=TAGS_METADATA,
    swagger_ui_parameters={"defaultModelsExpandDepth": -1},
    openapi_url=f"{PREFIX}/openapi.json",
    servers=[
        {"url": "http://localhost:8000/ethicara", "description": "Localhost"},
        {
            "url": "https://vsl-dev.pfizer.com/ethicara",
            "description": "VSL Development",
        },
        {
            "url": "https://mule4api-comm-amer-dev.pfizer.com/ethicara-api-v1",
            "description": "Mulesoft Development",
        },
    ],
    root_path=PREFIX,
    root_path_in_servers=False,
)
app.mount("/static", StaticFiles(directory="static"), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def custom_openapi():
    # cache the generated schema
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
        tags=app.openapi_tags,
    )
    openapi_schema["info"]["x-logo"] = {"url": "../static/ethicara.png"}
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi


@app.get(f"{PREFIX}/home", include_in_schema=False)
async def redoc_html():
    return get_redoc_html(
        openapi_url=app.openapi_url,
        title=app.title,
        redoc_js_url="https://unpkg.com/redoc@next/bundles/redoc.standalone.js",
    )


@app.get(f"{PREFIX}/docs", include_in_schema=False)
async def doc_html():
    return get_swagger_ui_html(openapi_url=app.openapi_url, title=app.title)


app.include_router(health_check_router, prefix=PREFIX)
app.include_router(settings_router, prefix=PREFIX, include_in_schema=False)
app.include_router(models_router, prefix=PREFIX)
app.include_router(utils_router, prefix=PREFIX)
app.include_router(bias_detection_data_bias_router, prefix=PREFIX)
app.include_router(bias_detection_model_bias_router, prefix=PREFIX)
app.include_router(model_mitigation_data_bias_router, prefix=PREFIX)
app.include_router(model_mitigation_model_bias_router, prefix=PREFIX)
app.include_router(shap_values_router, prefix=PREFIX)
