import logging
import sys

import uvicorn


class NoModuleFilter(logging.Filter):
    def filter(self, record):
        if "No module named" not in record.getMessage():
            return record


logging.captureWarnings(True)
logger = logging.getLogger()
logger.addFilter(NoModuleFilter())

uvicorn_formatter = uvicorn.logging.ColourizedFormatter(
    "{levelprefix:<8} {name} - {message}", style="{", use_colors=True
)

stream_handler = logging.StreamHandler(sys.stdout)
stream_handler.setFormatter(uvicorn_formatter)
logger.addHandler(stream_handler)
logger.setLevel(logging.ERROR)
