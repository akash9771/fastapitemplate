import pickle
import base64


async def load_model(clf: str):
    """
    Load a machine learning model from a base64 encoded string.

    Args:
        model (str): The base64 encoded string representation of the model.

    Returns:
        The loaded machine learning model.
    """
    model_bytes = base64.b64decode(clf)
    model = pickle.loads(model_bytes)
    return model
