import base64
import pickle

from fastapi import APIRouter, File, Request, UploadFile

router = APIRouter(tags=["Utils"])


async def load_model(file: UploadFile = File(...)):
    """
    Load a machine learning model from the given file.

    Args:
        file (UploadFile): The file containing the model.

    Returns:
        The loaded machine learning model.
    """
    with open(f"{file.filename}", "wb") as buffer:
        buffer.write(await file.read())
    with open(f"{file.filename}", "rb") as f:
        model = pickle.load(f)
    return model


@router.post("/utils/convert-to-bytes")
async def convert_to_bytes(response: Request, file: UploadFile = File(...)):
    model = await load_model(file)
    pkl = pickle.dumps(model)
    return base64.b64encode(pkl).decode()
