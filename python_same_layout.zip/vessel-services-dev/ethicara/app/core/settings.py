from typing import Optional

from fastapi import APIRouter, Depends

from app.config import Settings, get_settings

router = APIRouter()


@router.get("/settings")
async def info(
    field: Optional[str] = None, settings: Settings = Depends(get_settings)
) -> dict:
    if field:
        settings = settings.model_dump()
        return settings.get(field)
    else:
        return settings
