from typing import List, Optional, Union

from fastapi import APIRouter, Depends, status
from fastapi.responses import JSONResponse

from app.config import EthicaraModelOutput, Settings, get_settings

router = APIRouter(
    tags=["Models"],
)


@router.get(
    "/models",
    summary="List all models",
    response_model=Union[EthicaraModelOutput, List[EthicaraModelOutput]],
)
async def model_list(
    name: Optional[str] = None, settings: Settings = Depends(get_settings)
) -> Union[EthicaraModelOutput, List[EthicaraModelOutput]]:
    info = settings.model_dump()
    if name:
        try:
            return [model for model in info.get("info") if model.get("name") == name][0]
        except IndexError:
            return JSONResponse(
                status_code=status.HTTP_404_NOT_FOUND,
                content={"message": f"Model {id} not found"},
            )
    else:
        return info.get("info")
