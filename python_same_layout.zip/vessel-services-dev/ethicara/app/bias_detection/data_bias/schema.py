from typing import Dict, List, Optional, Union

from pydantic import BaseModel, Field, field_validator, model_validator

from app.bias_detection.common import SensitiveGroup
from app.bias_detection.data_bias.examples import EXAMPLES
from app.constants import COMMON


class BiasDetectionDataBiasInput(BaseModel):

    input: Dict = Field(description=COMMON.get("args").get("input"))
    target: str = Field(description=COMMON.get("args").get("target"))
    favorable_label: Union[str, int] = Field(
        description=COMMON.get("args").get("favorable_label")
    )
    sensitive_group: List[SensitiveGroup] = Field(
        description=COMMON.get("args").get("sensitive_group")
    )
    confidence_level: Optional[float] = Field(
        default=0.95, description=COMMON.get("args").get("confidence_level")
    )
    has_intersections: Optional[bool] = Field(
        False, description=COMMON.get("args").get("has_intersections")
    )
    model_config = {"json_schema_extra": {"examples": EXAMPLES}}

    @field_validator("confidence_level")
    def validate_confidence_level(cls, value):
        if value not in [0.90, 0.95, 0.99]:
            raise ValueError(
                """Values supported currently for confidence level
                              are 0.90, 0.95, 0.99"""
            )
        return value

    @model_validator(mode="after")
    def validate_target(self):
        target = self.target
        values = self.input

        if target not in [str(x) for x in values.keys()]:
            raise ValueError(
                f"target {target} not found in input keys. Available keys are: {list(values.keys())}"
            )
        return self

    @model_validator(mode="after")
    def validate_favorable_label(self):
        favorable_label = self.favorable_label
        target_dict = self.input[self.target]

        if str(favorable_label) not in [str(x) for x in target_dict.values()]:

            raise ValueError(
                f"favorable_label {favorable_label} not found in input values. Available values are: {list(target_dict.values())}"
            )
        return self

    @model_validator(mode="after")
    def validate_sensitive_group(self):
        sensitive_group = self.sensitive_group

        for group in sensitive_group:
            sensitive_attribute = group.sensitive_attribute
            privileged_group = group.privileged_group

            if sensitive_attribute not in self.input.keys():
                raise ValueError(
                    f"sensitive_attribute {sensitive_attribute} not found in input keys. Available keys are: {list(self.input.keys())}"
                )

            if privileged_group not in self.input[sensitive_attribute].values():
                raise ValueError(
                    f"privileged_group {group.privileged_group} not found in input values. Available values are: {list(self.input[sensitive_attribute].values())}"
                )
        return self


class BiasDetectionDataBiasOutput(BaseModel):
    unprivileged_group: Dict = Field(
        description=COMMON.get("outputs").get("unpriveleged_group")
    )
    privileged_group: Dict = Field(
        description=COMMON.get("outputs").get("privileged_group")
    )
    feature: Dict = Field(description=COMMON.get("outputs").get("feature"))
    unprivileged_group_target_presence: Dict = Field(
        description=COMMON.get("outputs").get("unprivileged_group_target_presence")
    )
    unprivileged_group_target_absence: Dict = Field(
        description=COMMON.get("outputs").get("unprivileged_group_target_absence")
    )
    privileged_group_target_presence: Dict = Field(
        description=COMMON.get("outputs").get("privileged_group_target_presence")
    )
    privileged_group_target_absence: Dict = Field(
        description=COMMON.get("outputs").get("privileged_group_target_absence")
    )
    odds_ratio: Dict = Field(description=COMMON.get("outputs").get("odds_ratio"))
    odds_ratio_effect_size: Dict = Field(
        description=COMMON.get("outputs").get("odds_ratio_effect_size")
    )
    log_odds_ratio: Dict = Field(
        description=COMMON.get("outputs").get("log_odds_ratio")
    )
    p_value: Dict = Field(description=COMMON.get("outputs").get("p_value"))
    perc_ci_low: Dict = Field(description=COMMON.get("outputs").get("perc_ci_low"))
    perc_ci_high: Dict = Field(description=COMMON.get("outputs").get("perc_ci_high"))
    disparate_impact_ratio_presence: Dict = Field(
        description=COMMON.get("outputs").get("disparate_impact_ratio_presence")
    )
    log_disparate_impact_ratio_presence: Dict = Field(
        description=COMMON.get("outputs").get("log_disparate_impact_ratio_presence")
    )
    disparate_impact_ratio_absence: Dict = Field(
        description=COMMON.get("outputs").get("disparate_impact_ratio_absence")
    )
    log_disparate_impact_ratio_absence: Dict = Field(
        description=COMMON.get("outputs").get("log_disparate_impact_ratio_absence")
    )

    @model_validator(mode="after")
    def validate_p_value(self):
        p_values = self.p_value

        if not all(float(0) <= float(p) <= float(1) for p in p_values.values()):
            raise ValueError("p_values should be in the range of 0 to 1")
        return self
