from typing import Dict

from fastapi import APIRouter, Request

from app.bias_detection.data_bias.predict import predict_bias_detection_data_bias
from app.bias_detection.data_bias.schema import (
    BiasDetectionDataBiasInput,
    BiasDetectionDataBiasOutput,
)
from app.logger import logger
from validator.decorators import async_token_validation_and_metering

logger = logger.getChild(__name__)

router = APIRouter(
    prefix="/bias-detection/data-bias",
    tags=["Bias Detection"],
)


@router.get("/")
@async_token_validation_and_metering()
async def bias_detection_data_bias_info(request: Request) -> Dict:
    try:
        logger.info("Received request for the bias detection data bias endpoint.")
        return {
            "description": "This is the bias detection data bias endpoint.",
            "information": "Please use the /predict endpoint to make a prediction.",
        }
    except Exception as e:
        logger.error(f"Error in the bias detection data bias endpoint: {e}")
        raise e


@router.post(
    "/predict",
    summary="Bias detection data bias prediction",
    response_model=BiasDetectionDataBiasOutput,
)
@async_token_validation_and_metering()
async def bias_detection_data_bias_predict(
    request: Request, model: BiasDetectionDataBiasInput
) -> Dict:
    """
    ### Args:
        - input_dataset : A table in a dictionary format
        - target: A string of the target variable
        - favorable_label: The favorable lable of
        - confidence_level: The confidence level which is necessary for the p-value and the confidence interval calculation.
        - intersections_boolean: Boolean variable for any intersections
        - sensitive_group: A list of the sensitive attributes and the privileged groups

    ### Returns:
        - JSON: A JSON object with the prediction.
    """
    response = predict_bias_detection_data_bias(**model.model_dump())
    return BiasDetectionDataBiasOutput(**response)
