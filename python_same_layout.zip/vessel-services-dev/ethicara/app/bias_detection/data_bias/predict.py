from itertools import combinations

import numpy as np
import pandas as pd
import scipy
from aequitas.preprocessing import preprocess_input_df

from app.logger import logger

logger = logger.getChild(__name__)


def combinations_calculator(privileged_group, has_intersections, variables_all):
    """
    This function limits the privileged groups to 5, in case the intersections are selected.
    Also, it creates a nested list with all the possible combinations of the selected columns.

    Args:
        privileged_group(Dict): A dictionary with key a selected column
        and value the privilege category of the column.
        has_intersections(Any): A boolean refered
        to the selection of intersections from the user.
        variables_all(List): A list with all the variables
        that detect the association with the target.
    Returns:
        privileged_group(Dict): A dictionary with key a selected column
        and value the privilege category of the column.
        combinations_list(List): A nested list
        with all the possible combinations of the selected columns.
    """
    try:

        if has_intersections:

            # take max 5 keys for intersections
            keys = list(privileged_group.keys())[:5]
            privileged_group = {key: privileged_group[key] for key in keys}

            all_group_combinations = [
                list(combinations(privileged_group, i))
                for i in range(1, len(privileged_group) + 1)
            ]
            combinations_list = [
                list(item) for group in all_group_combinations for item in group
            ]
        else:
            combinations_list = [[var] for var in variables_all]
        return privileged_group, combinations_list
    except Exception as e:
        logger.error(f"Error in combinations_calculator: {e}")
        raise e


def pivot_reference_data(
    combinations_list,
    data_input,
    target,
    privileged_group,
    favorable_label,
    unfavorable_label,
) -> pd.DataFrame:
    """
    Creates a summary table with the total count of reference
    and non-reference categories based on the target variable.

    Args:
        combinations_list(List): A nested list
        with all the possible combinations of the selected columns.
        data_input(pd.DataFrame): The input dataframe.
        target(str): The target variable.
        privileged_group(Dict): A dictionary
        with key a selected column
        and value the privilege category of the column.
        favorable_label: The favorable label of the target variable
        unfavorable_label: The unfavorable label of the target variable

    Returns:
        data(pd.DataFrame): summary table
        with the total count of reference
        and non-reference categories based on the target variable.
    """
    try:
        arr = []
        for combination in combinations_list:
            comb_target = combination + [target]
            data = pd.get_dummies(data_input[comb_target], columns=[target])
            data = data.groupby(by=combination).sum().reset_index()
            data_item = pd.DataFrame(privileged_group, index=[0]).merge(
                data, how="inner", on=None, validate=None
            )
            data["reference_1"] = data_item[f"{target}_{favorable_label}"][0]
            data["reference_0"] = data_item[f"{target}_{unfavorable_label}"][0]
            data = data[
                [
                    f"{target}_{favorable_label}",
                    f"{target}_{unfavorable_label}",
                    "reference_1",
                    "reference_0",
                ]
            ]
            arr.append(data.values)
        data = pd.DataFrame(
            np.concatenate(arr)
        )  # dataframe with privileged group variables
        data.columns = range(data.shape[1])  # replace the index of columns to 0,1,2,3
        return data
    except Exception as e:
        logger.error(f"Error in pivot_reference_data: {e}")
        raise e


def create_reference_names(combination_list, privileged_group, data, target):
    """
    Creates three lists: the features, reference groups and non-reference groups.

    Args:
        combinations_list(List): A nested list with
        all the possible combinations of the selected columns.
        privileged_group(Dict): A dictionary with key a selected column
        and value the privilege category of the column.
        data(pd.DataFrame): summary table with the total count of reference
        and non-reference categories based on the target variable.
        target(str): The target variable.
    Returns:
        features_group (List): A list with all the features
        and theirs combination if intersections are selected.
        priv_group(List): A list with all the privileged groups.
        non_priv_group(List): A list with all the unprivileged groups

    """
    try:
        for item in privileged_group.keys():
            privileged_group[item] = str(privileged_group[item])
            data[item] = data[item].values.astype(str)

        priv_group = []
        non_priv_group = []
        features_group = []

        for combination in combination_list:
            data_dummies = pd.get_dummies(data, columns=[target])
            data_grouped = data_dummies.groupby(by=combination).sum().reset_index()

            features_group.append(
                [", ".join([str(item) for item in combination])] * len(data_grouped)
            )
            non_priv_group.append(
                data_grouped[
                    combination[0 : (len(data_grouped[combination].columns))]
                ].values.tolist()
            )
            data_item = pd.DataFrame(privileged_group, index=[0])
            priv_group.append(
                data_item[
                    combination[0 : (len(data_item[combination].columns))]
                ].values.tolist()
                * len(data_grouped)
            )
        features_group = [j for sub in features_group for j in sub]
        priv_group = [j for sub in priv_group for j in sub]
        priv_group = [", ".join(val) for val in priv_group]
        non_priv_group = [j for sub in non_priv_group for j in sub]
        non_priv_group = [", ".join(val) for val in non_priv_group]
        return features_group, priv_group, non_priv_group
    except Exception as e:
        logger.error(f"Error in create_reference_names: {e}")
        raise e


def metrics_calculator(data, conf_lvl) -> pd.DataFrame:
    """
    Creates a dataframe that calculates all the necessary fairness metrics.

    Args:
        data(pd.DataFrame): A summary table with the total count of reference
        and non-reference categories based on the target variable.
        conf_lvl(float): The confidence level which i necessary for the p-value
        and the confidence interval calculation.

    Returns:
        data(pd.DataFrame): A dataframe with all the necessary fairness metrics.

    """
    try:
        non_priv_total = data[0] + data[1]
        priv_total = data[2] + data[3]
        probability_non_priv_target_presence = data[0] / non_priv_total
        probability_non_priv_target_absence = data[1] / non_priv_total
        probability_priv_target_presence = data[2] / priv_total
        probability_priv_target_absence = data[3] / priv_total
        data["disparate_impact_ratio_presence"] = (
            probability_non_priv_target_presence / probability_priv_target_presence
        )
        data["disparate_impact_ratio_absence"] = (
            probability_non_priv_target_absence / probability_priv_target_absence
        )
        data["log_disparate_impact_ratio_presence"] = np.log(
            data["disparate_impact_ratio_presence"]
        )
        data["log_disparate_impact_ratio_absence"] = np.log(
            data["disparate_impact_ratio_absence"]
        )
        data["odds_ratio"] = (data[0] / data[2]) / (data[1] / data[3])
        data["odds_ratio_effect_size"] = np.where(
            (data["odds_ratio"] < 1.68) & (data["odds_ratio"] > 0.60),
            "Very Small",
            np.where(
                ((data["odds_ratio"] >= 1.68) & (data["odds_ratio"] < 3.47))
                | ((data["odds_ratio"] <= 0.60) & (data["odds_ratio"] > 0.29)),
                "Small",
                np.where(
                    ((data["odds_ratio"] >= 3.47) & (data["odds_ratio"] < 6.71))
                    | ((data["odds_ratio"] <= 0.29) & (data["odds_ratio"] > 0.15)),
                    "Medium",
                    "Large",
                ),
            ),
        )
        data["log_odds_ratio"] = np.log(data["odds_ratio"])
        data["perc_ci_low"] = np.exp(
            data["log_odds_ratio"]
            - conf_lvl
            * np.sqrt((1 / data[0]) + (1 / data[1]) + (1 / data[2]) + (1 / data[3]))
        )
        data["perc_ci_high"] = np.exp(
            data["log_odds_ratio"]
            + conf_lvl
            * np.sqrt((1 / data[0]) + (1 / data[1]) + (1 / data[2]) + (1 / data[3]))
        )
        standard_error = (
            np.log(data["perc_ci_high"]) - np.log(data["perc_ci_low"])
        ) / (2 * conf_lvl)
        z_score = data["log_odds_ratio"] / standard_error
        data["p_value"] = scipy.stats.norm.sf(abs(z_score))
        data = data.replace([np.inf, np.nan, -np.inf], " ")
        return data
    except Exception as e:
        logger.error(f"Error in metrics_calculator: {e}")
        raise e


def round_metrics(data, precision) -> pd.DataFrame:
    """
    Round all the values of the dataframe

    Args:
        data(pd.DataFrame): A dataframe with all the necessary fairness metrics.
        precision(int): The digits in which all the values will be rounded.
    Returns:
        data(pd.DataFrame): A dataframe with all the necessary fairness metrics
                            rounded.

    """
    try:
        data = data.round(precision)

        return data
    except Exception as e:
        logger.error(f"Error in round_metrics: {e}")
        raise e


def update_dataset_schema(
    data, non_priv_group, priv_group, features_group
) -> pd.DataFrame:
    """
    Update the schema of the dataframe.

    Args:
        data(pd.DataFrame): A dataframe with all the necessary fairness metrics rounded.
        priv_group(List): A list with all the privileged groups.
        non_priv_group(List): A list with all the unprivileged groups.
        features_group(List): A list with all the features
        and theirs combination if intersections are selected.
    Returns:
        data(pd.DataFrame): A dataframe with all the necessary fairness metrics rounded.

    """
    try:
        data = data.rename(
            columns={
                0: "unprivileged_group_target_presence",
                1: "unprivileged_group_target_absence",
                2: "privileged_group_target_presence",
                3: "privileged_group_target_absence",
            }
        )
        data.insert(0, "unprivileged_group", non_priv_group, True)
        data.insert(1, "privileged_group", priv_group, True)
        data.insert(2, "feature", features_group, True)
        data = data[
            [
                "unprivileged_group",
                "privileged_group",
                "feature",
                "unprivileged_group_target_presence",
                "unprivileged_group_target_absence",
                "privileged_group_target_presence",
                "privileged_group_target_absence",
                "odds_ratio",
                "odds_ratio_effect_size",
                "log_odds_ratio",
                "p_value",
                "perc_ci_low",
                "perc_ci_high",
                "disparate_impact_ratio_presence",
                "log_disparate_impact_ratio_presence",
                "disparate_impact_ratio_absence",
                "log_disparate_impact_ratio_absence",
            ]
        ]
        # exclude information where reference_group == non_reference_group
        n_output_rows = data.shape[0]
        for row in range(n_output_rows):
            if data["privileged_group"][row] == data["unprivileged_group"][row]:
                data = data.drop(row)
        return data
    except Exception as e:
        logger.error(f"Error in update_dataset_schema: {e}")
        raise e


def predict_bias_detection_data_bias(
    input, target, favorable_label, confidence_level, has_intersections, sensitive_group
):
    """
    This function is used to predict the bias detection data bias.
    """
    try:
        data = pd.DataFrame(input)

        conf_lvl_to_alpha_z = {
            0.90: (0.10, 1.645),
            0.95: (0.05, 1.96),
            0.99: (0.01, 2.576),
        }

        alpha_lvl, z = conf_lvl_to_alpha_z.get(confidence_level)

        privileged_group = {
            val["sensitive_attribute"]: val["privileged_group"]
            for val in sensitive_group
        }

        unique_labels = data[target].unique()

        favorable_label = (
            unique_labels[0]
            if unique_labels[0] == favorable_label
            else unique_labels[1]
        )
        unfavorable_label = (
            unique_labels[1]
            if unique_labels[0] == favorable_label
            else unique_labels[0]
        )

        for attr in list(privileged_group.keys()):
            if len(data[attr].unique()) >= 20:
                transformed_data, _ = preprocess_input_df(data[[attr]])
                data[attr] = transformed_data[attr]

        # get  list with all the variables that detect the association with the target.
        variables_all = [key for key in privileged_group.keys()]

        privileged_group, combinations_list = combinations_calculator(
            privileged_group, has_intersections, variables_all
        )

        data_pivot = pivot_reference_data(
            combinations_list,
            data,
            target,
            privileged_group,
            favorable_label,
            unfavorable_label,
        )

        features_group, priv_group, non_priv_group = create_reference_names(
            combinations_list, privileged_group, data, target
        )

        data_metrics = metrics_calculator(data_pivot, confidence_level)
        data_round = round_metrics(data_metrics, 3)
        data_final = update_dataset_schema(
            data_round, non_priv_group, priv_group, features_group
        )

        return data_final.to_dict()
    except Exception as e:
        logger.error(f"Error in predict_bias_detection_data_bias: {e}")
        raise e
