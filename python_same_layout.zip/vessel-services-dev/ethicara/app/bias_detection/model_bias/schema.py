from typing import Dict, Optional, Union

from pydantic import BaseModel, Field, field_validator, model_validator

from app.bias_detection.common import SensitiveGroup
from app.bias_detection.model_bias.examples import EXAMPLES
from app.constants import COMMON


class BiasDetectionModelBiasInput(BaseModel):

    input: Dict = Field(description=COMMON.get("args").get("input"))
    target: str = Field(description=COMMON.get("args").get("target"))
    favorable_label: Union[str, int] = Field(
        description=COMMON.get("args").get("favorable_label")
    )
    # TODO: sensitive_group should be a list of SensitiveGroup (fix all tests)
    sensitive_group: dict = Field(description=COMMON.get("args").get("sensitive_group"))
    confidence_level: Optional[float] = Field(
        default=0.95, description=COMMON.get("args").get("confidence_level")
    )
    has_intersections: Optional[bool] = Field(
        False, description=COMMON.get("args").get("has_intersections")
    )
    predictions: Optional[str] = Field(
        None, description=COMMON.get("args").get("predictions")
    )
    model_config = {"json_schema_extra": {"examples": EXAMPLES}}

    @field_validator("confidence_level")
    def validate_confidence_level(cls, value):
        if value not in [0.90, 0.95, 0.99]:
            raise ValueError(
                """Values supported currently for confidence level
                              are 0.90, 0.95, 0.99"""
            )
        return value

    @model_validator(mode="after")
    def validate_target(self):
        target = self.target
        values = self.input

        if target not in values.keys():
            raise ValueError(
                f"target {target} not found in input keys. Available keys are: {list(values.keys())}"
            )
        return self

    @model_validator(mode="after")
    def validate_favorable_label(self):
        favorable_label = self.favorable_label
        target_dict = self.input[self.target]

        if str(favorable_label) not in [str(x) for x in target_dict.values()]:

            raise ValueError(
                f"favorable_label {favorable_label} not found in input values. Available values are: {list(target_dict.values())}"
            )
        return self

    # TODO: add sensitive_group validation from bias_detection.data_bias.schema
