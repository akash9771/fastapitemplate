import itertools
from typing import Dict, Tuple

import pandas as pd
from aequitas.bias import Bias
from aequitas.group import Group

from app.logger import logger

logger = logger.getChild(__name__)


def convert_to_strings(
    sensitive_group: Dict,
    input: pd.DataFrame,
) -> Tuple[pd.DataFrame, Dict]:
    """
    This function converts sensitive attributes to strings in order to use aequitas.

    Args:
        sensitive_group: the reference dictionary of sensitive attributes
        with their privileged categories.
        input: a dataframe of sample features and model predictions.

    Returns:
        pd.Dataframe: the modified dataframe after the datatype
        manipulation of the sensitive attributes.
        Dict: the reference dictionary after the datatype
        manipulation of the sensitive attributes.
    """
    try:
        for attr in list(sensitive_group.keys()):
            input[attr] = input[attr].astype(str)
            sensitive_group[attr] = str(sensitive_group[attr])
        return input, sensitive_group
    except Exception as e:
        logger.error(f"Error in converting to strings: {e}")
        raise e


def prep_intersectional_combinations(
    sensitive_group: Dict, input: pd.DataFrame, has_intersections
) -> Tuple[Dict, pd.DataFrame, Dict]:
    """
    This function modifies the sensitive group and the scored dataframe
    in order to expand to intersectional comparisons.

    Args:
        sensitive_group: the reference dictionary of sensitive attributes
        with their privileged categories.
        input: a dataframe of sample features and model predictions.
        has_intersections: a boolean value of intersectional combinations option.

    Returns:
        Dict: The modified sensitive group after the insertion of the intersection combinations.
        pd.DataFrame: the modified dataframe after inserting the new intersectional column.
    """
    try:
        if has_intersections:
            # First limit the dictionary inputs to only 5 attributes as per specifications.
            sensitive_group = {
                key: sensitive_group[key] for key in list(sensitive_group.keys())[:5]
            }

            # Make a local copy of the sensitive group to modify w/ intersectional metrics.
            intersectional_sensitive_group = sensitive_group.copy()

            # Modify the input and the sensitive group
            ##to  add each attribute-combination as a new field for evaluation.
            for L in range(1, len(sensitive_group) + 1):
                for subset in itertools.combinations(sensitive_group, L):
                    attribute_combo_list = list(subset)
                    if L != 1:

                        # first determine the feature name
                        attribute_combo_feature_name = "intersectional_" + "_".join(
                            attribute_combo_list
                        )

                        # then combine the values for each of the features selected in the combination and assign to new variable in the dataframe
                        input[attribute_combo_feature_name] = input[
                            attribute_combo_list
                        ].apply(", ".join, axis=1)

                        # lastly add the intersectional metric to the attributes to audit dictionary
                        intersectional_sensitive_group[attribute_combo_feature_name] = (
                            ", "
                        ).join(list(map(sensitive_group.get, attribute_combo_list)))
            return intersectional_sensitive_group, input
        return sensitive_group, input
    except Exception as e:
        logger.error(f"Error in prep_intersectional_combinations: {e}")
        raise e


def filtered_scored_data(
    predictions: str, target: str, sensitive_group: Dict, input: pd.DataFrame
) -> pd.DataFrame:
    """
    This function is filtered the dataframe based on the sensitive attributes that need to be evaluated

    Args:
        predictions: column name with the predictions,
        target: target column name,
        sensitive_group: the reference dictionary of sensitive attributes with their privileged categories,
        input: a dataframe of sample features and model predictions

    Returns:
        pd.DataFrame: the filtered dataframe

    """
    try:
        # create an array of score and label value cols
        predictions_and_target = [predictions, target]

        # extract the attribute names from dictionary
        attributes_to_audit = list(sensitive_group.keys())

        # create final list of features to keep from above 2 lists:
        features_to_keep = attributes_to_audit + predictions_and_target

        # confirm that features to keep are indeed present in the dataframe:
        feature_to_keep_chk = all(
            item in list(input.columns) for item in features_to_keep
        )

        if feature_to_keep_chk:
            pass
        else:
            raise Exception(
                "Invalid Input: Attribute Columns OR Score / Label Value columns are not present in dataframe"
            )

        # subset dataframe to above list
        filtered_df = input[features_to_keep]
        return filtered_df
    except Exception as e:
        logger.error(f"Error in filtered_scored_data: {e}")
        raise e


def remapping_target_labels(
    filtered_df: pd.DataFrame, favorable_label: int
) -> pd.DataFrame:
    """
    Remap to numerical values (0/1) to work in the Aequitas class

    Args:
        filtered_df: a dataframe of sample features and model predictions
        favorable_label: the favorable label of target variable

    Returns:
        pd.DataFrame: the remapped dataframe
    """
    try:

        if filtered_df["label_value"].dtypes == "O":
            remap_target_values_dict = {}
            for val in list(filtered_df["label_value"].unique()):
                if val == favorable_label:
                    remap_target_values_dict[favorable_label] = 1
                else:
                    remap_target_values_dict[val] = 0
            filtered_df["label_value"].replace(remap_target_values_dict, inplace=True)
        if filtered_df["score"].dtypes == "O":
            remap_target_values_dict = {}
            for val in list(filtered_df["score"].unique()):
                if val == favorable_label:
                    remap_target_values_dict[favorable_label] = 1
                else:
                    remap_target_values_dict[val] = 0
            filtered_df["score"].replace(remap_target_values_dict, inplace=True)
        return filtered_df
    except Exception as e:
        logger.error(f"Error in remapping_target_labels: {e}")
        raise e


def prep_aequitas_data(
    predictions: str,
    target: str,
    sensitive_group: Dict,
    input: pd.DataFrame,
    favorable_label: float,
) -> pd.DataFrame:
    """
    This function is to prepare the dataframe filtering the predictions and the target variable and remapping them.

    Args:
        predictions: column name with the predictions
        target: target column name
        sensitive_group: the reference dictionary of sensitive attributes with their privileged categories
        input: a dataframe of sample features and model predictions
        favorable_label: the favorable label of target variable

    Returns:
        pd.DataFrame: the prepared dataframe for Aequitas implementation

    """
    try:
        filtered_df = filtered_scored_data(predictions, target, sensitive_group, input)

        ## Rename variables to match Aequitas pre-processing:
        remapped_df = filtered_df.rename(
            columns={predictions: "score", target: "label_value"}
        )

        remapped_df = remapping_target_labels(remapped_df, favorable_label)
        return remapped_df
    except Exception as e:
        logger.error(f"Error in prep_aequitas_data: {e}")
        raise e


def run_aequitas(
    target: str,
    predictions: str,
    sensitive_group: Dict,
    confidence_level: float,
    has_intersections: bool,
    favorable_label: float,
    input: pd.DataFrame,
) -> pd.DataFrame:
    """
    This function is to run aequitas module based on the parameters and input datasets/model

    Args:
        target: target column name.
        predictions: column name with the predictions.
        sensitive_group: the reference dictionary of sensitive attributes with their privileged categories,
        has_intersections : if the intersectional flag is True (examine the intersectional bias effects),
            the sensitive group is modified to add intersectional features and
            the input dataframe is modified to include the intersectional attribute columns.
        confidence_level: statistical significance level to use in significance determination.
        favorable_label: the favorable label of target variable
        input: a dataframe of sample features and model results.
            Includes a required ‘score ‘column and possible ‘label_value’ column

    Returns:
        pd.DataFrame: dataframe, the bias detection over attributes report

    """
    try:
        scored_df = pd.DataFrame(input)
        scored_df, sensitive_group = convert_to_strings(sensitive_group, scored_df)

        sensitive_group, scored_df = prep_intersectional_combinations(
            sensitive_group, scored_df, has_intersections
        )

        # now let's get the data in the right shape for the Aequitas evaluation:
        prepared_df = prep_aequitas_data(
            target, predictions, sensitive_group, scored_df, favorable_label
        )

        # define Aequitas Group method:
        g = Group()

        # compute cross-tab confusion matrix:
        xtab, _ = g.get_crosstabs(prepared_df)

        # define Aequitas Bias method:
        b = Bias()

        # run bias detection over attributes to audit
        bdf = b.get_disparity_predefined_groups(
            xtab,
            original_df=prepared_df,
            ref_groups_dict=sensitive_group,
            alpha=confidence_level,
            check_significance=True,
            mask_significance=True,
        ).fillna("-")

        return bdf.to_dict()
    except Exception as e:
        logger.error(f"Error in run_aequitas: {e}")
        raise e
