from fastapi import APIRouter, Request

from app.bias_detection.model_bias.predict import run_aequitas
from app.bias_detection.model_bias.schema import BiasDetectionModelBiasInput
from app.logger import logger
from validator.decorators import async_token_validation_and_metering

logger = logger.getChild(__name__)

router = APIRouter(
    prefix="/bias-detection/model-bias",
    tags=["Bias Detection"],
)


@router.get("/", summary="Bias Detection Model Bias Info")
@async_token_validation_and_metering()
async def model_bias_eval_info(request: Request):

    logger.info("Received request for the model bias evaluation info.")

    try:
        return {
            "description": "This is the model bias evaluation endpoint.",
            "information": "Please use the /predict endpoint to make a prediction.",
        }
    except Exception as e:
        logger.error(f"Error in model_bias_eval_info: {e}")
        return {"error": f"{e}"}


@router.post("/predict", summary="Bias Detection Model Bias prediction")
@async_token_validation_and_metering()
async def model_bias_eval_predict(request: Request, model: BiasDetectionModelBiasInput):
    """

    ### Args:
        - input : A table in a dictionary format
        - target: A string of the target variable
        - favorable_label: The favorable lable of the target variable
        - predictions: A string of the predictions variable
        - confidence_level: The confidence level which is necessary for the p-value and the confidence interval calculation.
        - has_intersections: Boolean variable for any intersections
        - sensitive_group: A list of the sensitive attributes and the privileged groups

    ### Returns:
        - JSON: A JSON object with the model bias metrics.
    """
    try:
        logger.info("Received request to predict the model bias metrics.")
        return run_aequitas(**model.model_dump())
    except Exception as e:
        logger.error(f"Error in model_bias_eval_predict: {e}")
        return {"error": f"{e}"}
