from pydantic import BaseModel, Field

from app.constants import COMMON


class SensitiveGroup(BaseModel):
    sensitive_attribute: str = Field(
        description=COMMON.get("args").get("sensitive_attribute")
    )
    privileged_group: str = Field(
        description=COMMON.get("args").get("privileged_group")
    )
