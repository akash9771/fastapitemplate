import os
import sys

import colorama
import uvicorn

if __name__ == "__main__":
    colorama.init()
    # config = uvicorn.Config("app.main:app", port=8000, log_level="info", reload=True)
    # server = uvicorn.Server(config)
    # server.run()
    os.chdir(".")
    sys.path.append(os.getcwd())
    uvicorn.run("app.main:app", port=8000, log_level="info", reload=True)
