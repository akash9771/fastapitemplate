rm -rf ethicara
git clone git@github.com:pfizer-analytics/ethicara-api.git ethicara

rm -rf ethicara/.git
rm -rf ethicara/.github
rm -rf ethicara/.gitignore
rm -rf ethicara/.pfizer.yaml
rm -rf ethicara/sonar-project.properties
rm -rf ethicara/validator
rm -rf ethicara/.pre-commit-config.yaml
rm -rf ethicara/requirements_dev.txt

git restore ethicara/Dockerfile
