#!/bin/bash
py -m pytest -v --disable-warnings