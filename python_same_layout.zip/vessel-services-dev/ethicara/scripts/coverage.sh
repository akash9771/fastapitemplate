#!/bin/bash
coverage run -m pytest
coverage report -m
# > coverage_report.txt
# coverage html
# rm -f static/coverage.svg
# coverage-badge -o static/coverage.svg
