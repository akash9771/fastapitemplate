import numpy as np
import pandas as pd
import pytest
from sklearn.metrics import balanced_accuracy_score, f1_score, roc_auc_score

from app.bias_mitigation.model_bias.predict import (
    create_models_dict,
    create_predictions,
    fairness_metrics_calc,
    make_json_serializable,
    model_bias_output,
    params_calc,
    replace_non_compliant_floats,
)


def test_create_models_dict():
    models_params = [
        {
            "name": "Exponentiated Gradient Reduction",
            "metric": "DemographicParity",
            "params": {
                "eta0": [0.01],
                "eps": [0.01],
            },
        },
        {"name": "Grid Search Reduction", "metric": "EqualizedOdds", "params": {}},
        {
            "name": "Calibrated Equalized Odds Postprocessing",
            "metric": "EqualizedOdds",
            "params": {},
        },
        {"name": "Adversarial Debiasing", "metric": "average_odds", "params": {}},
        {
            "name": "Reject Option Based Classification",
            "metric": "average_odds",
            "params": {},
        },
    ]
    prot_attr = ["gender", "race"]
    pref_attr = "gender"
    prot_attr_cols = ["gender_male", "gender_female", "race_white", "race_black"]
    my_clf = "My_Ultimate_Classifier"

    models = create_models_dict(
        models_params, prot_attr, pref_attr, prot_attr_cols, my_clf
    )

    assert len(models) == 6, "models length is not 6"
    assert isinstance(models, list), "models is not a list"
    assert models[0][0] == "Classifier", "models[0][0] is not Classifier"
    assert (
        models[1][0] == "Exponentiated Gradient Reduction"
    ), "models[1][0] is not Exponentiated Gradient Reduction"
    assert (
        models[2][0] == "Grid Search Reduction"
    ), "models[2][0] is not Grid Search Reduction"
    assert (
        models[3][0] == "Calibrated Equalized Odds"
    ), "models[3][0] is not Calibrated Equalized Odds"
    assert (
        models[4][0] == "Adversarial Debiasing"
    ), "models[4][0] is not Adversarial Debiasing"
    assert (
        models[5][0] == "Reject Option Classifier CV"
    ), "models[5][0] is not Reject Option Classifier CV"
    assert models[1][1] is not None, "models[1][1] is None"
    assert models[2][1] is not None, "models[2][1] is None"
    assert models[3][1] is not None, "models[3][1] is None"
    assert models[4][1] is not None, "models[4][1] is None"
    assert models[5][1] is not None, "models[5][1] is None"
    assert models[1][2] == {
        "eta0": [0.01],
        "eps": [0.01],
    }, "models[1][2] is not {'eta0': [0.01], 'eps': [0.01]}"
    assert models[2][2] == {}, "models[2][2] is not {}"
    assert models[3][2] is None, "models[3][2] is not None"
    assert models[4][2] == {}, "models[4][2] is not {}"
    assert models[5][2] is None, "models[5][2] is not None"
    assert models[1][3] is not None, "models[1][3] is None"
    assert models[2][3] is not None, "models[2][3] is None"
    assert models[3][3] is None, "models[3][3] is not None"
    assert models[4][3] is not None, "models[4][3] is None"
    assert models[5][3] is None, "models[5][3] is not None"


@pytest.mark.parametrize(
    "name,expected_length",
    [
        ("Reject Option Classifier CV", 2),
        ("Adversarial Debiasing", 4),
        ("Exponentiated Gradient Reduction", 4),
    ],
)
def test_create_predictions(name, expected_length, setup_data):
    X_train, y_train, X_test, prot_attr, model, params, scorer = setup_data

    preds_dict = create_predictions(
        name, model, params, scorer, X_train, y_train, X_test, prot_attr
    )

    assert len(preds_dict[name]) == expected_length
    assert name in preds_dict


@pytest.mark.parametrize(
    "preds_dict,expected_output",
    [
        # Test case 1: Empty dictionary
        ({}, pd.DataFrame({"Algorithm": ["No hyperparameter tuning"]})),
        # Test case 2: Dictionary with one model that requires hyperparameter tuning
        (
            {
                "Adversarial Debiasing": [
                    None,
                    None,
                    {
                        "mean_fit_time": 10,
                        "std_fit_time": 2,
                        "mean_test_score": 0.8,
                        "std_test_score": 0.1,
                        "params": {
                            "eta0": [0.01],
                            "eps": [0.01],
                        },
                    },
                    {
                        "mean_fit_time": 10,
                        "std_fit_time": 2,
                        "mean_test_score": 0.8,
                        "std_test_score": 0.1,
                        "params": {
                            "eta0": [0.01],
                            "eps": [0.01],
                        },
                    },
                ]
            },
            pd.DataFrame(
                {
                    "Algorithm": ["Adversarial Debiasing"],
                    "best_params": [
                        {
                            "mean_fit_time": 10,
                            "std_fit_time": 2,
                            "mean_test_score": 0.8,
                            "std_test_score": 0.1,
                            "params": {
                                "eta0": [0.01],
                                "eps": [0.01],
                            },
                        }
                    ],
                    "mean_fit_time": [10],
                    "std_fit_time": [2],
                    "mean_test_score": [0.8],
                    "std_test_score": [0.1],
                }
            ),
        ),
        # # Test case 3: Dictionary with one model that does not require hyperparameter tuning
        (
            {"Other Model": [None, None, {}, {}]},
            pd.DataFrame({"Algorithm": ["No hyperparameter tuning"]}),
        ),
    ],
)
def test_params_calc(preds_dict, expected_output):
    result = params_calc(preds_dict)
    pd.testing.assert_frame_equal(result, expected_output)


def test_fairness_metrics_calc_result_is_df(fairness_metrics_inputs):
    y_test, prot_attr, preds_dict = fairness_metrics_inputs
    result = fairness_metrics_calc(y_test, prot_attr, preds_dict)
    assert isinstance(result, pd.DataFrame), "The result should be a DataFrame"


def test_fairness_metrics_calc_result_shape(fairness_metrics_inputs):
    y_test, prot_attr, preds_dict = fairness_metrics_inputs
    result = fairness_metrics_calc(y_test, prot_attr, preds_dict)
    assert result.shape[0] == len(
        preds_dict
    ), "The number of rows should be equal to the number of models"


def test_fairness_metrics_calc_result_shape_is_16(fairness_metrics_inputs):
    y_test, prot_attr, preds_dict = fairness_metrics_inputs
    result = fairness_metrics_calc(y_test, prot_attr, preds_dict)
    assert result.shape[1] == 4 + 4 * len(
        prot_attr
    ), "The number of columns should be equal to 4 + 4 times the number of protective attributes"


def test_fairness_metrics_calc_balanced_acc(fairness_metrics_inputs):
    y_test, prot_attr, preds_dict = fairness_metrics_inputs
    result = fairness_metrics_calc(y_test, prot_attr, preds_dict)
    assert result.loc["Classifier", "Balanced Accuracy"] == balanced_accuracy_score(
        pd.DataFrame(y_test.tolist(), columns=["target"]), preds_dict["Classifier"][0]
    ), "The balanced accuracy is incorrect"


def test_fairness_metrics_calc_f1_score(fairness_metrics_inputs):
    y_test, prot_attr, preds_dict = fairness_metrics_inputs
    result = fairness_metrics_calc(y_test, prot_attr, preds_dict)
    assert result.loc["Classifier", "f1-score"] == f1_score(
        pd.DataFrame(y_test.tolist(), columns=["target"]), preds_dict["Classifier"][0]
    ), "The f1-score is incorrect"


def test_fairness_metrics_calc_roc_auc(fairness_metrics_inputs):
    y_test, prot_attr, preds_dict = fairness_metrics_inputs
    result = fairness_metrics_calc(y_test, prot_attr, preds_dict)
    assert result.loc["Classifier", "ROC-AUC"] == round(
        roc_auc_score(
            pd.DataFrame(y_test.tolist(), columns=["target"]),
            preds_dict["Classifier"][1][:, 1],
        ),
        4,
    ), "The ROC-AUC is incorrect"


def test_fairness_metrics_calc_balanced_acc_clf_2(fairness_metrics_inputs):
    y_test, prot_attr, preds_dict = fairness_metrics_inputs
    result = fairness_metrics_calc(y_test, prot_attr, preds_dict)
    assert result.loc[
        "Exponentiated Gradient Reduction", "Balanced Accuracy"
    ] == balanced_accuracy_score(
        pd.DataFrame(y_test.tolist(), columns=["target"]),
        preds_dict["Exponentiated Gradient Reduction"][0],
    ), "The balanced accuracy is incorrect"


def test_fairness_metrics_calc_f1_score_clf_2(fairness_metrics_inputs):
    y_test, prot_attr, preds_dict = fairness_metrics_inputs
    result = fairness_metrics_calc(y_test, prot_attr, preds_dict)
    assert result.loc["Exponentiated Gradient Reduction", "f1-score"] == f1_score(
        pd.DataFrame(y_test.tolist(), columns=["target"]),
        preds_dict["Exponentiated Gradient Reduction"][0],
    ), "The f1-score is incorrect"


def test_fairness_metrics_calc_roc_auc_clf_2(fairness_metrics_inputs):
    y_test, prot_attr, preds_dict = fairness_metrics_inputs
    result = fairness_metrics_calc(y_test, prot_attr, preds_dict)
    assert result.loc["Exponentiated Gradient Reduction", "ROC-AUC"] == roc_auc_score(
        pd.DataFrame(y_test.tolist(), columns=["target"]),
        preds_dict["Exponentiated Gradient Reduction"][1][:, 1],
    ), "The ROC-AUC is incorrect"


def test_model_bias_output_type(model_bias_data):
    data, preds_dict, categorical_features, X_test, y_test = model_bias_data
    result = model_bias_output(data, preds_dict, categorical_features, X_test, y_test)
    assert isinstance(result, pd.DataFrame), "The result should be a DataFrame"


def test_model_bias_output_columns(model_bias_data):
    data, preds_dict, categorical_features, X_test, y_test = model_bias_data
    result = model_bias_output(data, preds_dict, categorical_features, X_test, y_test)
    expected_columns = set(
        data.columns.tolist()
        + ["source", "target"]
        + ["preds_" + model for model in preds_dict.keys()]
    )
    assert (
        set(result.columns) == expected_columns
    ), "The result columns should match the expected columns"


def test_model_bias_output_values(model_bias_data):
    data, preds_dict, categorical_features, X_test, y_test = model_bias_data
    result = model_bias_output(data, preds_dict, categorical_features, X_test, y_test)
    for model in preds_dict.keys():
        assert (
            result["preds_" + model] == preds_dict[model][0]
        ).all(), f"The 'preds_{model}' column should match the predictions of {model}"


def test_replace_non_compliant_floats_with_floats():
    assert replace_non_compliant_floats(3.14) == 3.14
    assert replace_non_compliant_floats(np.nan) is None
    assert replace_non_compliant_floats(np.inf) == np.finfo(np.float64).max
    assert replace_non_compliant_floats(-np.inf) == -np.finfo(np.float64).max


def test_replace_non_compliant_floats_with_dict():
    assert replace_non_compliant_floats({"a": 3.14, "b": np.nan}) == {
        "a": 3.14,
        "b": None,
    }
    assert replace_non_compliant_floats({"a": np.inf, "b": -np.inf}) == {
        "a": np.finfo(np.float64).max,
        "b": -np.finfo(np.float64).max,
    }


def test_replace_non_compliant_floats_with_list():
    assert replace_non_compliant_floats([3.14, np.nan]) == [3.14, None]
    assert replace_non_compliant_floats([np.inf, -np.inf]) == [
        np.finfo(np.float64).max,
        -np.finfo(np.float64).max,
    ]


def test_replace_non_compliant_floats_with_other_types():
    assert replace_non_compliant_floats("test") == "test"
    assert replace_non_compliant_floats(123) == 123
    assert replace_non_compliant_floats(None) is None


def test_make_json_serializable_with_numpy_array():
    df = pd.DataFrame({"a": [np.array([1, 2, 3]), np.array([4, 5, 6])], "b": [7, 8]})
    result = make_json_serializable(df)
    assert (
        result["a"].apply(type).eq(list).all()
    ), "All numpy arrays should be converted to lists"


def test_make_json_serializable_with_non_serializable_objects():
    class NonSerializable:
        def __init__(self, x):
            self.x = x

    df = pd.DataFrame({"a": [NonSerializable(1), NonSerializable(2)], "b": [3, 4]})
    result = make_json_serializable(df)
    assert (
        result["a"].apply(type).eq(dict).all()
    ), "All non-serializable objects should be converted to dicts"


def test_make_json_serializable_with_serializable_objects():
    df = pd.DataFrame(
        {
            "a": [1, 2],
            "b": ["string1", "string2"],
            "c": [1.1, 2.2],
            "d": [True, False],
            "e": [None, None],
            "f": [[1, 2], [3, 4]],
            "g": [{"key1": "value1"}, {"key2": "value2"}],
        }
    )
    result = make_json_serializable(df)
    for col in df.columns:
        assert result[col].equals(
            df[col]
        ), f"Values in column '{col}' should not be changed"
