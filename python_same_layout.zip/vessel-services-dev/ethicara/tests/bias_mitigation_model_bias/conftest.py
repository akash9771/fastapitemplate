import base64
import pickle as pkl

import numpy as np
import pandas as pd
import pytest
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score


# Bias Mitigation Model Bias
@pytest.fixture(scope="session")
def bias_mitigation_model_bias_payload():

    df_train = (
        pd.read_parquet("tests/data/train.parquet").reset_index(drop=True).head(5)
    )
    df_test = pd.read_parquet("tests/data/test.parquet").reset_index(drop=True).head(5)
    df_X_train = (
        pd.read_parquet("tests/data/X_train.parquet").reset_index(drop=True).head(5)
    )
    df_X_test = (
        pd.read_parquet("tests/data/X_test.parquet").reset_index(drop=True).head(5)
    )

    model_data = {
        "prot_attr": ["sex", "race"],
        "pref_attr": "race",
        "privileged_classes": [["Male"], ["White"]],
        "target": "annual_income",
        "models": [
            {
                "name": "Exponentiated Gradient Reduction",
                "metric": "DemographicParity",
                "params": {
                    "eta0": [0.01],
                    "eps": [0.01],
                },
            }
        ],
        "fav_label": "1",
        "train": df_train.to_dict(),
        "test": df_test.to_dict(),
        "X_train": df_X_train.to_dict(),
        "X_test": df_X_test.to_dict(),
        "clf": "gASV9wYAAAAAAACMHnNrbGVhcm4ubGluZWFyX21vZGVsLl9sb2dpc3RpY5SMEkxvZ2lzdGljUmVncmVzc2lvbpSTlCmBlH2UKIwHcGVuYWx0eZSMAmwylIwEZHVhbJSJjAN0b2yURz8aNuLrHEMtjAFDlEc/8AAAAAAAAIwNZml0X2ludGVyY2VwdJSIjBFpbnRlcmNlcHRfc2NhbGluZ5RLAYwMY2xhc3Nfd2VpZ2h0lH2UKIwVbnVtcHkuY29yZS5tdWx0aWFycmF5lIwGc2NhbGFylJOUjAVudW1weZSMBWR0eXBllJOUjAJpOJSJiIeUUpQoSwOMATyUTk5OSv////9K/////0sAdJRiQwgAAAAAAAAAAJSGlFKUaBBoE4wCZjiUiYiHlFKUKEsDaBdOTk5K/////0r/////SwB0lGJDCNtEz7g2HuU/lIaUUpRoEGgWQwgBAAAAAAAAAJSGlFKUaBBoHkMIDt0ZhjyBAECUhpRSlHWMDHJhbmRvbV9zdGF0ZZRNOQWMBnNvbHZlcpSMCWxpYmxpbmVhcpSMCG1heF9pdGVylEtkjAttdWx0aV9jbGFzc5SMA292cpSMB3ZlcmJvc2WUSwCMCndhcm1fc3RhcnSUiYwGbl9qb2JzlE6MCGwxX3JhdGlvlE6MDm5fZmVhdHVyZXNfaW5flEtzjAhjbGFzc2VzX5RoDowMX3JlY29uc3RydWN0lJOUaBGMB25kYXJyYXmUk5RLAIWUQwFilIeUUpQoSwFLAoWUaBOMAmk4lImIh5RSlChLA2gXTk5OSv////9K/////0sAdJRiiUMQAAAAAAAAAAABAAAAAAAAAJR0lGKMBWNvZWZflGg2aDhLAIWUaDqHlFKUKEsBSwFLc4aUaBOMAmY4lImIh5RSlChLA2gXTk5OSv////9K/////0sAdJRiiUKYAwAAdpz+0bkK6D/EjP6SJfjaP4XJYsBpW9A/3JcIEFLP2T+10m5LA/oCQG6qwmI8/L+/iVFTiUEtob+eKGMO9EC/v41H1mQKHr+/ZRlOT3d/wL+veAqQk0PGv+Lg28Q58tm/wFlTiuzrcz8MPlvCl8OdvzZb/MgTGMc/QFtIhykXtz9l4+gRSbnFvwMBcdSNuag/crha6P402D/ZhZ2dvX7kPxeyGlf29vC/AAAAAAAAAADfWVQaN5XDP4Vx+Sg2l+Y/cIXLDW7r7D8uhPR7WnqcP2ynOoeGkNg/01TNhIvo5L/rM9PQSd/Iv7bHvzJgpNS/Hs3CkftyrD/zOaPWjjHiv8q2yH0BYO2/58IvC67Q6T9anRj4KxLlP52TqJa+Vv6/OnmiQFSlxb8AAAAAAAAAAEj2nIiFXrE/qvhLvltuwb9yhFiOU7rKPwvzLo+7ZuC/WI716PH05L8AAAAAAAAAAE+jPW+Sp7y/JLglhexH7b8AAAAAAAAAAFzJCwj3YNo//NAywsJ8nr/NRb6m0QS7PzatfUldNOY/GkbAA3la5j/pIdM4r4rOP+jhxiuU0uE/GNn9NaTZ078odiPN9FLovzEtlEjaOec/G8VHfs7v4z+v2j1deqzdv6SJ70xQjdY/WDItYI2p7T/K+si3QxDwv20D9z1u5N6/JPAYSddp5T/nZbAyHuzzv0lcIcoXg9C/JdgSY7Bc9b8yvVAW4fTQP3zS/YIEAsU/TI1nzEI5kj/1keNvPvjZP+FimYpAntC/A92lOpPa6r8koRUkxlfkP4EUzgKVIN2//1BcWFpb4D/WqtaRXRDMP8J4JCeJ8ty/RNPRtIiV8z+xxh1Mqjvev6q95oS+gMC/nk5JtZHB8L+mgLIvDQrNP/d2eCO2i6K/Vh0Y0LF2079Iks8k7DKTv5Jd5Py9kem/9rzLACAdlz+E7ZztVxWVvwAAAAAAAAAAW57fi6lm+D8zJDbDy+Pzv48zAOTHZ+a/BSNUCPSk778A1liZwKPhv5i1uFC7Bua/3OcCuU7q+T8AAAAAAAAAAP7axhTjq7g/U8fOvpIi0b8FXIFmZWa1v2jc8PJpdbq/5okaMtb10L/prs40PF7WP45bVqR/yeM/VXjf2uNv8r+SIQdsCw7MvwAAAAAAAAAAZpxuve7O179eDuo03cfLP4WPKwShNe+/CmNYpQbfiL8WKYDzrgzwP3PFz4mfZ+y/AAAAAAAAAACUdJRijAppbnRlcmNlcHRflGg2aDhLAIWUaDqHlFKUKEsBSwGFlGhLiUMIOjuHaW9u8L+UdJRijAduX2l0ZXJflGg2aDhLAIWUaDqHlFKUKEsBSwGFlGgTjAJpNJSJiIeUUpQoSwNoF05OTkr/////Sv////9LAHSUYolDBAgAAACUdJRijBBfc2tsZWFybl92ZXJzaW9ulIwFMS4yLjKUdWIu",
    }

    return model_data


@pytest.fixture(scope="session")
def setup_data():
    X_train = pd.DataFrame(np.random.rand(10, 3), columns=["A", "B", "C"])
    y_train = pd.DataFrame(np.random.randint(2, size=10), columns=["target"])
    X_test = pd.DataFrame(np.random.rand(5, 3), columns=["A", "B", "C"])
    prot_attr = ["A", "B"]
    model = LogisticRegression()
    params = {"C": [0.1, 1, 10]}
    scorer = accuracy_score
    return X_train, y_train, X_test, prot_attr, model, params, scorer


@pytest.fixture(scope="session")
def load_model(bias_mitigation_model_bias_payload):
    model = bias_mitigation_model_bias_payload["clf"]
    model_bytes = base64.b64decode(model)
    clf = pkl.loads(model_bytes)
    return clf


@pytest.fixture(scope="session")
def fairness_metrics_inputs():
    y_test = pd.Series(
        [1, 0, 1, 0, 1, 0, 0, 0, 0, 1],
        index=pd.MultiIndex.from_arrays(
            [
                [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
                [0, 0, 0, 1, 1, 1, 0, 0, 1, 0],
                [0, 0, 1, 0, 0, 0, 0, 1, 0, 0],
            ],
            names=["sex", "race", "sex_race"],
        ),
        name="annual_income",
    )
    prot_attr = ["sex", "race", "sex_race"]
    preds_dict = {
        "Classifier": [
            np.array([0, 0, 1, 0, 0, 0, 0, 0, 0, 0], dtype=np.int64),
            np.array(
                [
                    [0.90586971, 0.09413029],
                    [0.6147295, 0.3852705],
                    [0.20633088, 0.79366912],
                    [0.91071832, 0.08928168],
                    [0.80274204, 0.19725796],
                    [0.67319188, 0.32680812],
                    [0.85590052, 0.14409948],
                    [0.53637428, 0.46362572],
                    [0.93701021, 0.06298979],
                    [0.8102472, 0.1897528],
                ]
            ),
        ],
        "Exponentiated Gradient Reduction": [
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0], dtype=np.int64),
            np.array(
                [
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                ]
            ),
        ],
    }
    return y_test, prot_attr, preds_dict


@pytest.fixture(scope="session")
def model_bias_data():
    data = pd.DataFrame(
        {
            "cat1": ["A", "B", "A", "B"],
            "cat2": ["X", "Y", "X", "Y"],
            "num1": [1, 2, 3, 4],
            "num2": [5, 6, 7, 8],
        }
    )
    preds_dict = {
        "Classifier": [
            np.array([0, 0, 1, 0, 0, 0, 0, 0, 0, 0], dtype=np.int64),
            np.array(
                [
                    [0.90586971, 0.09413029],
                    [0.6147295, 0.3852705],
                    [0.20633088, 0.79366912],
                    [0.91071832, 0.08928168],
                    [0.80274204, 0.19725796],
                    [0.67319188, 0.32680812],
                    [0.85590052, 0.14409948],
                    [0.53637428, 0.46362572],
                    [0.93701021, 0.06298979],
                    [0.8102472, 0.1897528],
                ]
            ),
        ],
        "Exponentiated Gradient Reduction": [
            np.array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0], dtype=np.int64),
            np.array(
                [
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                    [1.0, 0.0],
                ]
            ),
        ],
    }
    categorical_features = ["cat1", "cat2"]
    X_test = pd.DataFrame({"num1": [9, 10, 11, 12], "num2": [13, 14, 15, 16]})
    y_test = pd.DataFrame({"target": [1, 0, 1, 0]})
    return data, preds_dict, categorical_features, X_test, y_test
