import pandas as pd
import pytest
from httpx import AsyncClient
from sklearn.linear_model import LogisticRegression

from app.main import app

ENDPOINT_URL = "/ethicara/bias-mitigation/model-bias/"


@pytest.fixture
def response(client, bias_mitigation_model_bias_payload):
    files = bias_mitigation_model_bias_payload
    return client.post(
        ENDPOINT_URL + "predict",
        json=files,
    )


def test_predict_is_active(response):
    assert response.status_code == 200
    assert response.json() is not None


def test_predict_output_keys_are_correct(response):
    json_response = response.json()

    # Check if the keys are in the response
    assert "final_report" in json_response, "final_report not in response"
    assert "preds_output" in json_response, "preds_output not in response"
    assert "params_df" in json_response, "params_df not in response"


def test_predict_output_can_be_converted_to_dataframe(response):
    json_response = response.json()
    assert isinstance(
        pd.DataFrame(json_response["final_report"]), pd.DataFrame
    ), "final_report cannot be converted to pd.DataFrame"
    assert isinstance(
        pd.DataFrame(json_response["preds_output"]), pd.DataFrame
    ), "preds_output cannot be converted to pd.DataFrame"
    assert isinstance(
        pd.DataFrame(json_response["params_df"]), pd.DataFrame
    ), "params_df cannot be converted to pd.DataFrame"


def test_predict_output_values_are_not_empty(response):
    json_response = response.json()

    # Check if the values of the keys are not empty
    assert json_response["final_report"], "final_report is empty"
    assert json_response["preds_output"], "preds_output is empty"
    assert json_response["params_df"], "params_df is empty"


def test_classifier_in_payload(bias_mitigation_model_bias_payload, load_model):
    # assert that the classifier object is in the payload and it is not empty
    assert (
        bias_mitigation_model_bias_payload["clf"] is not None
    ), "The classifier object is empty"
    assert (
        bias_mitigation_model_bias_payload["clf"] != ""
    ), "The classifier object is empty"
    # assert that the classifier object is a string
    assert isinstance(
        bias_mitigation_model_bias_payload["clf"], str
    ), "The classifier object is not a string"
    # assert that the classifier object is a LogisticRegression instance
    clf = load_model
    assert isinstance(
        clf, LogisticRegression
    ), "The model is not a LogisticRegression instance"


def test_keys_in_payload(bias_mitigation_model_bias_payload):
    assert "train" in bias_mitigation_model_bias_payload, "train not in response"
    assert "test" in bias_mitigation_model_bias_payload, "test not in response"
    assert "X_train" in bias_mitigation_model_bias_payload, "X_train not in response"
    assert "X_test" in bias_mitigation_model_bias_payload, "X_test not in response"
    assert (
        "prot_attr" in bias_mitigation_model_bias_payload
    ), "prot_attr not in response"
    assert (
        "pref_attr" in bias_mitigation_model_bias_payload
    ), "pref_attr not in response"
    assert (
        "privileged_classes" in bias_mitigation_model_bias_payload
    ), "privileged_classes not in response"
    assert "target" in bias_mitigation_model_bias_payload, "target not in response"
    assert "models" in bias_mitigation_model_bias_payload, "models not in response"
    assert (
        "fav_label" in bias_mitigation_model_bias_payload
    ), "fav_label not in response"


def test_prot_attr_in_payload(bias_mitigation_model_bias_payload):
    # assert that the prot_attr is not empty
    assert (
        bias_mitigation_model_bias_payload["prot_attr"] is not None
    ), "prot_attr is empty"
    assert bias_mitigation_model_bias_payload["prot_attr"] != "", "prot_attr is empty"
    # assert that the prot_attr is a list
    assert isinstance(
        bias_mitigation_model_bias_payload["prot_attr"], list
    ), "prot_attr is not a list"
    # assert that the prot_attr is within train columns
    assert all(
        prot_attr in bias_mitigation_model_bias_payload["train"]
        for prot_attr in bias_mitigation_model_bias_payload["prot_attr"]
    ), "prot_attr not in train columns"


def test_pref_attr_in_payload(bias_mitigation_model_bias_payload):
    # assert that the pref_attr is not empty
    assert (
        bias_mitigation_model_bias_payload["pref_attr"] is not None
    ), "pref_attr is empty"
    assert bias_mitigation_model_bias_payload["pref_attr"] != "", "pref_attr is empty"
    # assert that the pref_attr is a string
    assert isinstance(
        bias_mitigation_model_bias_payload["pref_attr"], str
    ), "pref_attr is not a string"
    # assert that the pref_attr is within train columns
    assert (
        bias_mitigation_model_bias_payload["pref_attr"]
        in bias_mitigation_model_bias_payload["train"]
    ), "pref_attr not in train columns"


def test_privileged_classes_in_payload(bias_mitigation_model_bias_payload):
    # assert that the privileged_classes is not empty
    assert (
        bias_mitigation_model_bias_payload["privileged_classes"] is not None
    ), "privileged_classes is empty"
    assert (
        bias_mitigation_model_bias_payload["privileged_classes"] != ""
    ), "privileged_classes is empty"
    # assert that the privileged_classes is a list
    assert isinstance(
        bias_mitigation_model_bias_payload["privileged_classes"], list
    ), "privileged_classes is not a list"


def test_privileged_classes_in_train(bias_mitigation_model_bias_payload):
    # assert that the privileged_classes is within train columns
    prot_attr = bias_mitigation_model_bias_payload["prot_attr"]
    privileged_classes = bias_mitigation_model_bias_payload["privileged_classes"]
    assert all(
        privileged_class[0]
        in set(list(bias_mitigation_model_bias_payload["train"][attr].values()))
        for privileged_class, attr in zip(privileged_classes, prot_attr)
    ), "privileged_classes not in unique elements of their corresponding prot_attr columns"


def test_input_target_not_in_input(client, bias_mitigation_model_bias_payload):
    dummy_payload = bias_mitigation_model_bias_payload.copy()
    dummy_payload["target"] = "not_in_input"
    try:
        response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)
    except KeyError as e:
        assert str(e) == "\"['not_in_input'] not in index\"", "Unexpected error message"
    else:
        assert False, "Expected KeyError, but got no error"


def test_input_wrong_model(client, bias_mitigation_model_bias_payload):

    dummy_payload = bias_mitigation_model_bias_payload.copy()
    dummy_payload["models"] = ["Wrong_Model"]
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)

    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "model_attributes_type"


def test_predict_output_dimensions_are_correct(response):

    assert pd.DataFrame(response.json()).shape == (148, 3)


@pytest.mark.asyncio
async def test_async():
    async with AsyncClient(app=app, base_url="https://test") as client:
        response = await client.get("/ethicara/bias-mitigation/model-bias/")
    assert response.status_code == 200
    assert response.json() is not None
