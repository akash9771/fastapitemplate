def test_health(client):
    response = client.get("/ethicara/health")
    assert response.json() == {"status": "OK"}
