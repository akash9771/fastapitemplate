import numpy as np
import pandas as pd
import pytest
from sklearn.base import BaseEstimator
from sklearn.datasets import make_classification
from sklearn.metrics import accuracy_score


# Bias Mitigation Data Bias
@pytest.fixture(scope="session")
def bias_mitigation_data_bias_payload():
    df = pd.read_parquet("tests/data/adult.parquet").reset_index(drop=True).head(100)

    bias_mitigation_data_bias_payload = {
        "input": df.to_dict(),
        "target": "annual_income",
        "protected_attributes": ["sex", "race"],
        "preferred_attribute": "race",
        "privileged_classes": [["Male"], ["White"]],
        "models": ["Reweighing", "Learning Fair Representations"],
        "favorable_label": "1",
        "lfr_params": {
            "reconstruct_weight": [0.0001, 0.001, 0.01],
            "target_weight": [1, 10],
            "fairness_weight": [10, 100],
        },
    }

    return bias_mitigation_data_bias_payload


@pytest.fixture(scope="session")
def y_true_index():
    return pd.DataFrame(
        {
            "target": [1, 0, 1, 0, 1],
            "gender": ["male", "female", "male", "male", "female"],
        }
    ).set_index("gender")


@pytest.fixture(scope="session")
def y_pred_index():
    return pd.DataFrame(
        {
            "target": [1, 0, 1, 0, 0],
            "gender": ["male", "female", "male", "male", "female"],
        }
    ).set_index("gender")


@pytest.fixture(scope="session")
def y_true():
    return pd.DataFrame(
        {
            "target": [1, 0, 1, 0, 1],
            "gender": ["male", "female", "male", "male", "female"],
        }
    )


@pytest.fixture(scope="session")
def y_pred():
    return pd.DataFrame(
        {
            "target": [1, 0, 1, 0, 0],
            "gender": ["male", "female", "male", "male", "female"],
        }
    )


@pytest.fixture(scope="session")
def y_true_empty():
    return pd.DataFrame({"target": []})


@pytest.fixture(scope="session")
def y_pred_empty():
    return pd.DataFrame({"target": []})


@pytest.fixture(scope="session")
def y_true_mismatched():
    return pd.DataFrame({"target": [1, 0, 1, 0, 1]})


@pytest.fixture(scope="session")
def y_pred_mismatched():
    return pd.DataFrame({"target": [1, 0, 1, 0]})


@pytest.fixture(scope="session")
def lfr_params():
    return {
        "reconstruct_weight": [0.0001, 0.001, 0.01],
        "target_weight": [1, 10],
        "fairness_weight": [10, 100],
    }


@pytest.fixture(scope="session")
def pref_attr():
    return "gender"


# Fixtures for predictions tests
class MockEstimator(BaseEstimator):

    def __init__(self, C=0.1):
        self.C = C

    def fit(self, X, y, sample_weight=None):
        return self

    def predict(self, X):
        return np.ones(X.shape[0])

    def predict_proba(self, X):
        return np.ones((X.shape[0], 2)) / 2

    def transform(self, X):
        return X


@pytest.fixture
def mock_model():
    return MockEstimator()


@pytest.fixture
def mock_params():
    return {"C": [0.1]}


@pytest.fixture
def mock_scorer():
    return accuracy_score


@pytest.fixture
def mock_data_index():
    X, y = make_classification(n_samples=100, n_features=20, random_state=42)
    X = pd.DataFrame(X)
    X["gender"] = np.random.choice(["Male", "Female"], size=X.shape[0])
    X = X.set_index("gender")
    return X, y


@pytest.fixture
def mock_data():
    df = pd.read_parquet("tests/data/adult.parquet").reset_index(drop=True).head(50)
    X = df.drop("target", axis=1)
    y = df[["target"]]
    return X, y


@pytest.fixture
def mock_prot_attr():
    return ["gender"]
