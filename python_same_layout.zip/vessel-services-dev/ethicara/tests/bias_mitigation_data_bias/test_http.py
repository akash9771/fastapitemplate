import pandas as pd
import pytest
from httpx import AsyncClient

from app.main import app

ENDPOINT_URL = "/ethicara/bias-mitigation/data-bias/"


@pytest.fixture
def response(client, bias_mitigation_data_bias_payload):
    return client.post(
        ENDPOINT_URL + "predict",
        json=bias_mitigation_data_bias_payload,
    )


def test_predict_is_active(response):
    assert response.status_code == 200
    assert response.json() is not None


def test_input_target_not_in_input(client, bias_mitigation_data_bias_payload):
    dummy_payload = bias_mitigation_data_bias_payload.copy()
    dummy_payload["target"] = "not_in_input"
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)
    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_favorite_label_not_in_input(client, bias_mitigation_data_bias_payload):

    dummy_payload = bias_mitigation_data_bias_payload.copy()
    dummy_payload["favorable_label"] = "422"
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)

    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_input_wrong_model(client, bias_mitigation_data_bias_payload):

    dummy_payload = bias_mitigation_data_bias_payload.copy()
    dummy_payload["models"] = ["Wrong_Model"]
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)

    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_predict_output_keys_are_correct(response):
    json_response = response.json()

    # Check if the keys are in the response
    assert "final_report" in json_response, "final_report not in response"
    assert "preds_output" in json_response, "preds_output not in response"
    assert "params_df" in json_response, "params_df not in response"


def test_predict_output_can_be_converted_to_dataframe(response):
    assert isinstance(pd.DataFrame(response.json()), pd.DataFrame)


def test_predict_output_values_are_not_empty(response):
    json_response = response.json()

    # Check if the values of the keys are not empty
    assert json_response["final_report"], "final_report is empty"
    assert json_response["preds_output"], "preds_output is empty"
    assert json_response["params_df"], "params_df is empty"


def test_predict_output_dimensions_are_correct(response):

    assert pd.DataFrame(response.json()).shape == (90, 3)


@pytest.mark.asyncio
async def test_async():
    async with AsyncClient(app=app, base_url="https://test") as client:
        response = await client.get("/ethicara/bias-mitigation/data-bias/")
    assert response.status_code == 200
    assert response.json() is not None
