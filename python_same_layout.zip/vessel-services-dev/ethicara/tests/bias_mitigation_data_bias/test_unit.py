import numpy as np
import pandas as pd
import pytest

from app.bias_mitigation.data_bias.predict import (
    create_models_dict,
    create_predictions,
    custom_preprocessing,
    hyperparameters_boolean,
    hyperparameters_converter,
    metrics_boolean,
    params_calc,
    replace_non_compliant_floats,
    scoring_converter,
    standardized_dataset,
)
from app.bias_mitigation.utils.scoring_strategies import scoring_func


# Scoring function tests
@pytest.mark.parametrize("scoring", ["Delta", "AverageOdds"])
def test_scoring_func(y_true_index, y_pred_index, scoring, pref_attr):
    result = scoring_func(y_true_index, y_pred_index, scoring, pref_attr)
    assert isinstance(result, float)


@pytest.mark.parametrize("scoring", ["StrategyNotExisting", "Delta"])
def test_scoring_func_errors(
    y_true,
    y_pred,
    y_true_empty,
    y_pred_empty,
    y_true_mismatched,
    y_pred_mismatched,
    scoring,
):
    pref_attr = "target"
    if scoring == "StrategyNotExisting":
        with pytest.raises(ValueError):
            scoring_func(y_true, y_pred, scoring, pref_attr)
    elif scoring == "Delta":
        with pytest.raises(ValueError):
            scoring_func(y_true_empty, y_pred_empty, scoring, pref_attr)
            scoring_func(y_true_mismatched, y_pred_mismatched, scoring, pref_attr)


# Create models dict tests
@pytest.mark.parametrize(
    "models_list, expected_length, expected_models",
    [
        (
            ["Learning Fair Representations", "Reweighing"],
            3,
            ["Logistic Regression", "Learning Fair Representations", "Reweighing"],
        ),
        ([], 1, ["Logistic Regression"]),
        (["Invalid Model"], 1, ["Logistic Regression"]),
    ],
)
def test_create_models_dict(
    models_list, expected_length, expected_models, lfr_params, pref_attr
):
    result = create_models_dict(models_list, lfr_params, pref_attr)

    assert isinstance(result, list)
    assert len(result) == expected_length
    for i, model in enumerate(expected_models):
        assert result[i][0] == model


# # Create predictions tests
@pytest.mark.parametrize(
    "name, expected_keys",
    [
        ("Reweighing", ["Reweighing"]),
        ("Reject Option Classifier CV", ["Reject Option Classifier CV"]),
        ("Learning Fair Representations", ["Learning Fair Representations"]),
        ("Adversarial Debiasing", ["Adversarial Debiasing"]),
        ("Exponentiated Gradient Reduction", ["Exponentiated Gradient Reduction"]),
        ("Invalid Model", ["Invalid Model"]),
    ],
)
def test_create_predictions(
    name,
    expected_keys,
    mock_model,
    mock_params,
    mock_scorer,
    mock_data_index,
    mock_prot_attr,
):
    X_train, y_train = mock_data_index
    X_test, _ = mock_data_index
    result = create_predictions(
        name,
        mock_model,
        mock_params,
        mock_scorer,
        X_train,
        y_train,
        X_test,
        mock_prot_attr,
    )

    # Check that the final report is a Dictionary
    assert isinstance(result, dict)

    # Check that the final result contains the expected keys
    assert list(result.keys()) == expected_keys


# Test params_calc function
@pytest.mark.parametrize(
    "preds_dict, expected_columns",
    [
        (
            {
                "Learning Fair Representations": [
                    np.random.rand(10),
                    np.random.rand(10),
                    {
                        "mean_fit_time": np.random.rand(),
                        "std_fit_time": np.random.rand(),
                        "mean_test_score": np.random.rand(),
                        "std_test_score": np.random.rand(),
                    },
                    {"best_params": np.random.rand()},
                ],
                "Exponentiated Gradient Reduction": [
                    np.random.rand(10),
                    np.random.rand(10),
                    {
                        "mean_fit_time": np.random.rand(),
                        "std_fit_time": np.random.rand(),
                        "mean_test_score": np.random.rand(),
                        "std_test_score": np.random.rand(),
                    },
                    {"best_params": np.random.rand()},
                ],
                "Grid Search Reduction": [
                    np.random.rand(10),
                    np.random.rand(10),
                    {
                        "mean_fit_time": np.random.rand(),
                        "std_fit_time": np.random.rand(),
                        "mean_test_score": np.random.rand(),
                        "std_test_score": np.random.rand(),
                    },
                    {"best_params": np.random.rand()},
                ],
                "Adversarial Debiasing": [
                    np.random.rand(10),
                    np.random.rand(10),
                    {
                        "mean_fit_time": np.random.rand(),
                        "std_fit_time": np.random.rand(),
                        "mean_test_score": np.random.rand(),
                        "std_test_score": np.random.rand(),
                    },
                    {"best_params": np.random.rand()},
                ],
                "Invalid Model": [
                    np.random.rand(10),
                    np.random.rand(10),
                    {
                        "mean_fit_time": np.random.rand(),
                        "std_fit_time": np.random.rand(),
                        "mean_test_score": np.random.rand(),
                        "std_test_score": np.random.rand(),
                    },
                    {"best_params": np.random.rand()},
                ],
            },
            [
                "Algorithm",
                "best_params",
                "mean_fit_time",
                "std_fit_time",
                "mean_test_score",
                "std_test_score",
            ],
        ),
        (
            {},
            ["Algorithm"],
        ),
    ],
)
def test_params_calc(preds_dict, expected_columns):
    params_df = params_calc(preds_dict)

    assert isinstance(params_df, pd.DataFrame)

    assert list(params_df.columns) == expected_columns

    assert not params_df.isin([np.inf, -np.inf, np.nan]).any().any()


def test_standardized_dataset():
    # Create a MultiIndex
    arrays = [["bar", "bar", "baz", "baz"], ["one", "two", "one", "two"]]
    tuples = list(zip(*arrays))
    index = pd.MultiIndex.from_tuples(tuples, names=["first", "second"])

    # Create a DataFrame with the MultiIndex
    df = pd.DataFrame(
        {"A": [1, 2, 3, 4], "B": [5, 6, 7, 8], "C": [9, 10, 11, 12]}, index=index
    )

    # Define the protective attributes and target
    protected_attributes = ["A", "B"]
    target = "C"

    # Call the function to be tested
    X_train, X_test, y_train, y_test, indices_train, indices_test = (
        standardized_dataset(df, protected_attributes, target)
    )

    # Perform some assertions on the result
    assert isinstance(X_train, pd.DataFrame)
    assert isinstance(X_test, pd.DataFrame)
    assert isinstance(y_train, pd.Series)
    assert isinstance(y_test, pd.Series)
    assert isinstance(indices_train, list)
    assert isinstance(indices_test, list)

    assert X_train.shape[0] == y_train.shape[0] == len(indices_train)
    assert X_test.shape[0] == y_test.shape[0] == len(indices_test)


# Scoring function tests
@pytest.mark.parametrize(
    "parameters, expected",
    [
        (
            {
                "calMetrics": "False Positive Rate",
                "expMetrics": "Demographic Parity",
                "gridMetrics": "Equalized Odds",
                "rejMetrics": "True Positive Rate Parity",
            },
            {
                "calMetrics": "fpr",
                "expMetrics": "DemographicParity",
                "gridMetrics": "EqualizedOdds",
                "rejMetrics": "EqualOpportunity",
            },
        )
    ],
)
def test_scoring_converter(parameters, expected):

    result = scoring_converter(parameters)

    assert isinstance(result, dict)
    assert result == expected


@pytest.mark.parametrize(
    "parameters, expected",
    [
        (
            {
                "calMetrics": "False Positive Rate False Negative Rate",
                "expMetrics": "Demographic Parity Equalized Odds",
                "gridMetrics": "Equalized Odds True Positive Rate Parity",
                "rejMetrics": "True Positive Rate Parity Disparate Impact",
            },
            {
                "calMetrics": "fpr fnr",
                "expMetrics": "DemographicParity EqualizedOdds",
                "gridMetrics": "EqualizedOdds TruePositiveRateParity",
                "rejMetrics": "EqualOpportunity disparate_impact",
            },
        )
    ],
)
def test_scoring_converter_with_multiple_values(parameters, expected):

    result = scoring_converter(parameters)

    assert isinstance(result, dict)
    assert result == expected


# hyperparameters_converter tests
@pytest.mark.parametrize(
    "parameters, expected",
    [
        (
            {
                "advGroup": [
                    {"hyperparameter": "adversary_loss_weight", "value": "0.5, 1.0"}
                ],
                "expGroup": [{"value": "0.1, 0.2"}],
                "fairGroup": [{"value": "0.3, 0.4"}],
                "gridGroup": [{"value": "0.5, 0.6"}],
            },
            {
                "advGroup": [
                    {"hyperparameter": "adversary_loss_weight", "value": [0.5, 1.0]}
                ],
                "expGroup": [{"value": [0.1, 0.2]}],
                "fairGroup": [{"value": [0.3, 0.4]}],
                "gridGroup": [{"value": [0.5, 0.6]}],
            },
        )
    ],
)
def test_hyperparameters_converter(parameters, expected):

    result = hyperparameters_converter(parameters)

    assert isinstance(result, dict)
    assert result == expected


# hyperparameters_boolean tests
@pytest.mark.parametrize(
    "parameters, expected",
    [
        (
            {"hyperparamBoolean": False},
            {
                "hyperparamBoolean": False,
                "fairGroup": [
                    {
                        "hyperparameter": "reconstruct_weight",
                        "value": "0.0001, 0.001, 0.01",
                    },
                    {"hyperparameter": "target_weight", "value": "1, 10"},
                    {"hyperparameter": "fairness_weight", "value": "10, 100"},
                ],
                "advGroup": [
                    {"hyperparameter": "adversary_loss_weight", "value": "0.1, 0.5"},
                    {"hyperparameter": "num_epochs", "value": "50, 100"},
                    {
                        "hyperparameter": "classifier_num_hidden_units",
                        "value": "100, 200",
                    },
                ],
                "expGroup": [
                    {"hyperparameter": "eta0", "value": "0.01, 0.1, 2.0"},
                    {"hyperparameter": "eps", "value": "0.01, 0.05, 0.1"},
                ],
                "gridGroup": [
                    {"hyperparameter": "constraint_weight", "value": "0.1, 0.5, 0.7"}
                ],
            },
        ),
        (
            {"hyperparamBoolean": True},
            {"hyperparamBoolean": True},
        ),
    ],
)
def test_hyperparameters_boolean(parameters, expected):

    result = hyperparameters_boolean(parameters)

    assert isinstance(result, dict)
    assert result == expected


# metrics_boolean tests
@pytest.mark.parametrize(
    "parameters, expected",
    [
        (
            {"metricsBoolean": False},
            {
                "metricsBoolean": False,
                "expMetrics": "EqualizedOdds",
                "gridMetrics": "EqualizedOdds",
                "rejMetrics": "AverageOdds",
                "calMetrics": "fnr",
            },
        ),
        (
            {"metricsBoolean": True},
            {"metricsBoolean": True},
        ),
    ],
)
def test_metrics_boolean(parameters, expected):

    result = metrics_boolean(parameters)

    assert isinstance(result, dict)
    assert result == expected


# custom_preprocessing tests
@pytest.mark.parametrize(
    "df, expected",
    [
        (
            pd.DataFrame({"num": [1, 2, np.nan, 4], "cat": ["a", "b", np.nan, "d"]}),
            pd.DataFrame(
                {"num": [1, 2, 2.3333333333333335, 4], "cat": ["a", "b", "Other", "d"]}
            ).astype({"cat": "object"}),
        ),
        (
            pd.DataFrame(
                {
                    "num": [np.nan, np.nan, np.nan, np.nan],
                    "cat": [np.nan, np.nan, np.nan, np.nan],
                }
            ),
            pd.DataFrame(
                {
                    "num": [np.nan, np.nan, np.nan, np.nan],
                    "cat": [np.nan, np.nan, np.nan, np.nan],
                }
            ).astype({"cat": "object"}),
        ),
    ],
)
def test_custom_preprocessing(df, expected):
    result = custom_preprocessing(df)

    assert isinstance(result, pd.DataFrame)
    pd.testing.assert_frame_equal(result, expected, check_dtype=False)


# replace_non_compliant_floats tests
def test_replace_non_compliant_floats_with_floats():
    assert replace_non_compliant_floats(3.14) == 3.14
    assert replace_non_compliant_floats(np.nan) == None
    assert replace_non_compliant_floats(np.inf) == np.finfo(np.float64).max
    assert replace_non_compliant_floats(-np.inf) == -np.finfo(np.float64).max


def test_replace_non_compliant_floats_with_dict():
    assert replace_non_compliant_floats({"a": 3.14, "b": np.nan}) == {
        "a": 3.14,
        "b": None,
    }
    assert replace_non_compliant_floats({"a": np.inf, "b": -np.inf}) == {
        "a": np.finfo(np.float64).max,
        "b": -np.finfo(np.float64).max,
    }


def test_replace_non_compliant_floats_with_list():
    assert replace_non_compliant_floats([3.14, np.nan]) == [3.14, None]
    assert replace_non_compliant_floats([np.inf, -np.inf]) == [
        np.finfo(np.float64).max,
        -np.finfo(np.float64).max,
    ]


def test_replace_non_compliant_floats_with_other_types():
    assert replace_non_compliant_floats("test") == "test"
    assert replace_non_compliant_floats(123) == 123
    assert replace_non_compliant_floats(None) == None
