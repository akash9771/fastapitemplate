import pandas as pd
import pytest

from app.bias_detection.data_bias.predict import (
    combinations_calculator,
    create_reference_names,
    metrics_calculator,
    pivot_reference_data,
    round_metrics,
)

target = "annual_income"
privileged_group = {"sex": "Male", "race": "White"}
intersections = False
variables_all = ["sex", "race"]
favorable_label = 1
unfavorable_label = 0
combinations_list = [["sex"], ["race"]]
confidence_level = 0.95


@pytest.mark.parametrize(
    "privileged_group, intersections, variables_all",
    [(privileged_group, intersections, variables_all)],
)
def test_combinations_calc_is_correct(privileged_group, intersections, variables_all):
    """
    This function tests that the output of combinations_calculator is correct.
    """
    _, result_combinations_list = combinations_calculator(
        privileged_group, intersections, variables_all
    )

    assert isinstance(result_combinations_list, list)
    assert result_combinations_list == combinations_list


@pytest.mark.parametrize(
    "combinations_list, target, privileged_group, favorable_label, unfavorable_label",
    [(combinations_list, target, privileged_group, favorable_label, unfavorable_label)],
)
def test_pivot_reference_data(
    combinations_list,
    target,
    privileged_group,
    favorable_label,
    unfavorable_label,
    bias_detection_data_bias_data,
    bias_detections_data_bias_pivot_data,
):
    """
    This function tests that the output of pivot_reference_data is correct.
    """
    data = bias_detection_data_bias_data

    result = pivot_reference_data(
        combinations_list,
        data,
        target,
        privileged_group,
        favorable_label,
        unfavorable_label,
    )
    assert isinstance(result, pd.DataFrame)
    assert result.shape == (7, 4)
    assert not result.isnull().any().any()
    assert result.equals(bias_detections_data_bias_pivot_data)


@pytest.mark.parametrize(
    "combinations_list, privileged_group,  target",
    [(combinations_list, privileged_group, target)],
)
def test_create_reference_names(
    combinations_list, privileged_group, target, bias_detection_data_bias_data
):
    """
    This function tests that the output of create_reference_names is correct.
    """
    data = bias_detection_data_bias_data

    assert isinstance(combinations_list, list)
    assert isinstance(privileged_group, dict)
    assert isinstance(target, str)

    features_group, priv_group, non_priv_group = create_reference_names(
        combinations_list, privileged_group, data, target
    )
    assert isinstance(features_group, list)
    assert isinstance(priv_group, list)
    assert isinstance(non_priv_group, list)
    assert features_group == ["sex", "sex", "race", "race", "race", "race", "race"]
    assert priv_group == ["Male", "Male", "White", "White", "White", "White", "White"]
    assert non_priv_group == [
        "Female",
        "Male",
        "Amer-Indian-Eskimo",
        "Asian-Pac-Islander",
        "Black",
        "Other",
        "White",
    ]


@pytest.mark.parametrize("confidence_level", [confidence_level])
def test_metrics_calculator(confidence_level, bias_detections_data_bias_pivot_data):

    data = bias_detections_data_bias_pivot_data
    result = metrics_calculator(data, confidence_level)

    assert isinstance(result, pd.DataFrame)
    assert result.shape == (7, 14)
    assert not result.isnull().any().any()


def test_round_metrics():
    df = pd.DataFrame(
        {
            "Metric1": [0.123456, 1.234567, 2.345678],
            "Metric2": [3.456789, 4.567890, 5.678901],
            "Metric3": [6.789012, 7.890123, 8.901234],
        }
    )
    rounded_df = round_metrics(df, 2)

    assert isinstance(rounded_df, pd.DataFrame)
    assert rounded_df.shape == (3, 3)
    assert not rounded_df.isnull().any().any()
    assert rounded_df.equals(
        pd.DataFrame(
            {
                "Metric1": {0: 0.12, 1: 1.23, 2: 2.35},
                "Metric2": {0: 3.46, 1: 4.57, 2: 5.68},
                "Metric3": {0: 6.79, 1: 7.89, 2: 8.9},
            }
        )
    )


# No need to test update_dataset_schema as it is the final output and tested in
# API tests
