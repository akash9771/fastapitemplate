import pandas as pd
import pytest
from httpx import AsyncClient

from app.main import app

ENDPOINT_URL = "/ethicara/bias-detection/data-bias/"


@pytest.fixture
def response(client, bias_detection_data_bias_payload):
    return client.post(
        ENDPOINT_URL + "predict",
        json=bias_detection_data_bias_payload,
    )


def test_predict_is_active(response):
    assert response.status_code == 200
    assert response.json() is not None


def test_confidence_level_not_in_range(client, bias_detection_data_bias_payload):
    dummy_payload = bias_detection_data_bias_payload.copy()
    dummy_payload["confidence_level"] = 0.5
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)
    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_input_target_not_in_input(client, bias_detection_data_bias_payload):
    dummy_payload = bias_detection_data_bias_payload.copy()
    dummy_payload["target"] = "not_in_input"
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)
    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_favorite_label_not_in_input(client, bias_detection_data_bias_payload):

    dummy_payload = bias_detection_data_bias_payload.copy()
    dummy_payload["favorable_label"] = "422"
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)

    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_priviliged_group_not_in_sensitive_group(
    client, bias_detection_data_bias_payload
):
    dummy_payload = bias_detection_data_bias_payload.copy()
    dummy_payload["sensitive_group"] = [
        {"sensitive_attribute": "sex", "privileged_group": "1"}
    ]
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)
    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_sensitive_group_not_in_keys(client, bias_detection_data_bias_payload):
    dummy_payload = bias_detection_data_bias_payload.copy()
    dummy_payload["sensitive_group"] = [
        {"sensitive_attribute": "not_in_keys", "privileged_group": "1"}
    ]
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)
    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_predict_returns_correct_keys(response, bias_detection_data_bias_return_keys):
    assert set(response.json().keys()) == set(bias_detection_data_bias_return_keys)


def test_predict_output_dimensions_are_correct(response):

    assert pd.DataFrame(response.json()).shape == (5, 17)


def test_predict_output_can_be_converted_to_dataframe(response):
    assert isinstance(pd.DataFrame(response.json()), pd.DataFrame)


def test_predict_output_has_no_nan_values(response):
    assert not pd.DataFrame(response.json()).isnull().any().any()


def test_predict_p_values_in_range_of_0_1(response):
    data = pd.DataFrame(response.json())
    p_values = data["p_value"]
    assert all(0 <= p <= 1 for p in p_values)


def test_predict_odds_ratio_is_positive(response):
    data = pd.DataFrame(response.json())
    odds_ratios = data["odds_ratio"]
    assert all(0 <= odds_ratio for odds_ratio in odds_ratios)


def test_predict_disparate_impact_ratio_presence_is_positive(response):
    data = pd.DataFrame(response.json())
    disparate_impact_ratios = data["disparate_impact_ratio_presence"]
    assert all(0 <= ratio for ratio in disparate_impact_ratios)


def test_predict_disparate_impact_ratio_absence_is_positive(response):
    data = pd.DataFrame(response.json())
    disparate_impact_ratios = data["disparate_impact_ratio_absence"]
    assert all(0 <= ratio for ratio in disparate_impact_ratios)


def test_predict_output_values_are_correct(response, bias_detection_data_bias_output):

    actual_df = bias_detection_data_bias_output
    expected_df = pd.DataFrame(response.json())

    assert actual_df.equals(expected_df)


@pytest.mark.asyncio
async def test_async():
    async with AsyncClient(app=app, base_url="https://test") as client:
        response = await client.get(ENDPOINT_URL)
    assert response.status_code == 200
    assert response.json() is not None
