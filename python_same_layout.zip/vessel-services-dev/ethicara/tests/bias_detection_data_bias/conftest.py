import pandas as pd
import pytest


@pytest.fixture(scope="session")
def bias_detection_data_bias_payload():
    df = pd.read_parquet("tests/data/adult_train.parquet")

    bias_detection_data_bias_payload = {
        "input": df.to_dict(),
        "target": "annual_income",
        "favorable_label": "1",
        "confidence_level": 0.95,
        "sensitive_group": [
            {"sensitive_attribute": "sex", "privileged_group": "Male"},
            {"sensitive_attribute": "race", "privileged_group": "White"},
        ],
        "has_intersections": False,
    }

    return bias_detection_data_bias_payload


@pytest.fixture(scope="session")
def bias_detection_data_bias_output():

    df = pd.read_parquet("tests/data/adult_bias_detection_data_bias_output.parquet")

    return df


@pytest.fixture(scope="session")
def bias_detection_data_bias_data():

    df = pd.read_parquet("tests/data/adult_train.parquet")

    return df


@pytest.fixture(scope="session")
def bias_detections_data_bias_pivot_data():

    df = pd.DataFrame(
        {
            0: {0: 931, 1: 5372, 2: 28, 3: 222, 4: 305, 5: 20, 6: 5728},
            1: {0: 7737, 1: 12101, 2: 230, 3: 612, 4: 2205, 5: 208, 6: 16583},
            2: {0: 5372, 1: 5372, 2: 5728, 3: 5728, 4: 5728, 5: 5728, 6: 5728},
            3: {0: 12101, 1: 12101, 2: 16583, 3: 16583, 4: 16583, 5: 16583, 6: 16583},
        }
    )

    return df


@pytest.fixture(scope="session")
def bias_detection_data_bias_return_keys():

    bias_detection_data_bias_keys = [
        "unprivileged_group",
        "privileged_group",
        "feature",
        "unprivileged_group_target_presence",
        "unprivileged_group_target_absence",
        "privileged_group_target_presence",
        "privileged_group_target_absence",
        "odds_ratio",
        "odds_ratio_effect_size",
        "log_odds_ratio",
        "p_value",
        "perc_ci_low",
        "perc_ci_high",
        "disparate_impact_ratio_presence",
        "log_disparate_impact_ratio_presence",
        "disparate_impact_ratio_absence",
        "log_disparate_impact_ratio_absence",
    ]

    return bias_detection_data_bias_keys
