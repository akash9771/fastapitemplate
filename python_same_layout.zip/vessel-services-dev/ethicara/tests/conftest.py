import pytest
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture(scope="session")
def client():
    app.root_path = "/ethicara"
    with TestClient(app) as client:
        yield client


def pytest_addoption(parser):
    parser.addoption(
        "--no-http",
        action="store_true",
        default=False,
        help="skip tests that require http",
    )


def pytest_collection_modifyitems(config, items):
    if config.getoption("--no-http"):
        skip = pytest.mark.skip(reason="Skipping tests that require http")

        for item in items:
            if "_http" in item.nodeid:
                item.add_marker(skip)
