import pandas as pd
from pandas.testing import assert_frame_equal

from app.bias_detection.model_bias.predict import (
    convert_to_strings,
    filtered_scored_data,
    prep_intersectional_combinations,
    remapping_target_labels,
    run_aequitas,
)

label_value = "annual_income"
score = "score"
favorable_label = 1
confidence_level = 0.95


def test_convert_to_strings(test_dataset):

    attributes_to_audit_dict = {"sex": "Male", "hours_per_week": 40}

    expected_df = pd.DataFrame(
        {
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "workclass": {
                0: "Private",
                1: "Private",
                2: "State-gov",
                3: "Private",
                4: "Private",
            },
            "education": {
                0: "HS-grad",
                1: "11th",
                2: "Some-college",
                3: "Some-college",
                4: "Some-college",
            },
            "education_num": {0: 9, 1: 7, 2: 10, 3: 10, 4: 10},
            "marital_status": {
                0: "Divorced",
                1: "Married-civ-spouse",
                2: "Married-civ-spouse",
                3: "Married-civ-spouse",
                4: "Divorced",
            },
            "occupation": {
                0: "Handlers-cleaners",
                1: "Sales",
                2: "Other-service",
                3: "Exec-managerial",
                4: "Adm-clerical",
            },
            "relationship": {
                0: "Not-in-family",
                1: "Husband",
                2: "Husband",
                3: "Wife",
                4: "Not-in-family",
            },
            "race": {0: "White", 1: "White", 2: "Black", 3: "Other", 4: "White"},
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "capital_gain": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "capital_loss": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "hours_per_week": {0: "40", 1: "50", 2: "15", 3: "40", 4: "40"},
            "native_country": {
                0: "United-States",
                1: "United-States",
                2: "United-States",
                3: "United-States",
                4: "United-States",
            },
            "annual_income": {0: 0, 1: 1, 2: 0, 3: 0, 4: 1},
            "score": {0: 1, 1: 0, 2: 0, 3: 0, 4: 1},
        }
    )

    actual_df, actual_dict = convert_to_strings(attributes_to_audit_dict, test_dataset)

    expected_dict = {"sex": "Male", "hours_per_week": "40"}

    assert_frame_equal(actual_df, expected_df, check_dtype=True)
    assert expected_dict == actual_dict


def test_prep_with_intersectional_combinations(test_dataset_converted):

    initial_dict = {"sex": "Male", "hours_per_week": "40"}

    expected_dataset_with_comb = pd.DataFrame(
        {
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "workclass": {
                0: "Private",
                1: "Private",
                2: "State-gov",
                3: "Private",
                4: "Private",
            },
            "education": {
                0: "HS-grad",
                1: "11th",
                2: "Some-college",
                3: "Some-college",
                4: "Some-college",
            },
            "education_num": {0: 9, 1: 7, 2: 10, 3: 10, 4: 10},
            "marital_status": {
                0: "Divorced",
                1: "Married-civ-spouse",
                2: "Married-civ-spouse",
                3: "Married-civ-spouse",
                4: "Divorced",
            },
            "occupation": {
                0: "Handlers-cleaners",
                1: "Sales",
                2: "Other-service",
                3: "Exec-managerial",
                4: "Adm-clerical",
            },
            "relationship": {
                0: "Not-in-family",
                1: "Husband",
                2: "Husband",
                3: "Wife",
                4: "Not-in-family",
            },
            "race": {0: "White", 1: "White", 2: "Black", 3: "Other", 4: "White"},
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "capital_gain": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "capital_loss": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "hours_per_week": {0: "40", 1: "50", 2: "15", 3: "40", 4: "40"},
            "native_country": {
                0: "United-States",
                1: "United-States",
                2: "United-States",
                3: "United-States",
                4: "United-States",
            },
            "annual_income": {0: 0, 1: 1, 2: 0, 3: 0, 4: 1},
            "score": {0: 1, 1: 0, 2: 0, 3: 0, 4: 1},
            "intersectional_sex_hours_per_week": {
                0: "Male, 40",
                1: "Male, 50",
                2: "Male, 15",
                3: "Female, 40",
                4: "Female, 40",
            },
        }
    )

    expected_dict_with_comb = {
        "sex": "Male",
        "hours_per_week": "40",
        "intersectional_sex_hours_per_week": "Male, 40",
    }

    actual_sensitive_group, actual_dataset_with_comb = prep_intersectional_combinations(
        initial_dict, test_dataset_converted, True
    )

    assert_frame_equal(
        actual_dataset_with_comb, expected_dataset_with_comb, check_dtype=True
    )
    assert expected_dict_with_comb == actual_sensitive_group


def test_prep_without_interesectional_combinations(test_dataset_converted):

    initial_dict = {"sex": "Male", "hours_per_week": "40"}

    expected_dataset_with_comb = pd.DataFrame(
        {
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "workclass": {
                0: "Private",
                1: "Private",
                2: "State-gov",
                3: "Private",
                4: "Private",
            },
            "education": {
                0: "HS-grad",
                1: "11th",
                2: "Some-college",
                3: "Some-college",
                4: "Some-college",
            },
            "education_num": {0: 9, 1: 7, 2: 10, 3: 10, 4: 10},
            "marital_status": {
                0: "Divorced",
                1: "Married-civ-spouse",
                2: "Married-civ-spouse",
                3: "Married-civ-spouse",
                4: "Divorced",
            },
            "occupation": {
                0: "Handlers-cleaners",
                1: "Sales",
                2: "Other-service",
                3: "Exec-managerial",
                4: "Adm-clerical",
            },
            "relationship": {
                0: "Not-in-family",
                1: "Husband",
                2: "Husband",
                3: "Wife",
                4: "Not-in-family",
            },
            "race": {0: "White", 1: "White", 2: "Black", 3: "Other", 4: "White"},
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "capital_gain": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "capital_loss": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "hours_per_week": {0: "40", 1: "50", 2: "15", 3: "40", 4: "40"},
            "native_country": {
                0: "United-States",
                1: "United-States",
                2: "United-States",
                3: "United-States",
                4: "United-States",
            },
            "annual_income": {0: 0, 1: 1, 2: 0, 3: 0, 4: 1},
            "score": {0: 1, 1: 0, 2: 0, 3: 0, 4: 1},
        }
    )

    actual_sensitive_group, actual_dataset_with_comb = prep_intersectional_combinations(
        initial_dict, test_dataset_converted, False
    )

    assert_frame_equal(
        actual_dataset_with_comb, expected_dataset_with_comb, check_dtype=True
    )
    assert initial_dict == actual_sensitive_group


def test_filtered_scored_data(test_dataset_converted):

    expected_filtered_df = pd.DataFrame(
        {
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "score": {0: 1, 1: 0, 2: 0, 3: 0, 4: 1},
            "annual_income": {0: 0, 1: 1, 2: 0, 3: 0, 4: 1},
        }
    )

    sensitive_group = {"sex": "Male", "age": 31}
    target = "annual_income"
    predictions = "score"

    actual_filtered_df = filtered_scored_data(
        predictions, target, sensitive_group, test_dataset_converted
    )

    assert_frame_equal(actual_filtered_df, expected_filtered_df, check_dtype=True)


def test_remapping_target_labels(expected_remapped_dataset):

    favorable_label = "yes"

    initial_dataset = pd.DataFrame(
        {
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "score": {0: 1, 1: 0, 2: 0, 3: 0, 4: 1},
            "label_value": {0: "no", 1: "yes", 2: "no", 3: "no", 4: "yes"},
        }
    )

    actual_remapped_dataset = remapping_target_labels(initial_dataset, favorable_label)

    assert_frame_equal(
        actual_remapped_dataset, expected_remapped_dataset, check_dtype=True
    )


def test_remapping_score_labels(expected_remapped_dataset):

    favorable_label = "yes"

    initial_dataset = pd.DataFrame(
        {
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "score": {0: "yes", 1: "no", 2: "no", 3: "no", 4: "yes"},
            "label_value": {0: 0, 1: 1, 2: 0, 3: 0, 4: 1},
        }
    )

    actual_remapped_dataset = remapping_target_labels(initial_dataset, favorable_label)

    assert_frame_equal(
        actual_remapped_dataset, expected_remapped_dataset, check_dtype=True
    )


def test_remapping_score_n_target_labels(expected_remapped_dataset):

    favorable_label = "yes"

    initial_dataset = pd.DataFrame(
        {
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "score": {0: "yes", 1: "no", 2: "no", 3: "no", 4: "yes"},
            "label_value": {0: "no", 1: "yes", 2: "no", 3: "no", 4: "yes"},
        }
    )

    actual_remapped_dataset = remapping_target_labels(initial_dataset, favorable_label)

    assert_frame_equal(
        actual_remapped_dataset, expected_remapped_dataset, check_dtype=True
    )


def test_without_remapping_labels(expected_remapped_dataset):

    favorable_label = "yes"

    initial_dataset = pd.DataFrame(
        {
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "score": {0: 1, 1: 0, 2: 0, 3: 0, 4: 1},
            "label_value": {0: 0, 1: 1, 2: 0, 3: 0, 4: 1},
        }
    )

    actual_remapped_dataset = remapping_target_labels(initial_dataset, favorable_label)

    assert_frame_equal(
        actual_remapped_dataset, expected_remapped_dataset, check_dtype=True
    )


def test_model_bias_evaluation(bias_detection_model_bias_output):

    initial_dataset = pd.read_parquet("tests/data/adult.parquet")
    expected_scored_dataset = bias_detection_model_bias_output

    sensitive_group = {"sex": "Male", "race": "White"}
    has_intersections = False
    confidence_level = 0.95
    target = "annual_income"
    predictions = "score"
    favorable_label = 1

    actual_scored_dataset = run_aequitas(
        target,
        predictions,
        sensitive_group,
        confidence_level,
        has_intersections,
        favorable_label,
        initial_dataset,
    )
    expected_scored_dataset_df = pd.DataFrame(expected_scored_dataset)
    actual_scored_dataset_df = pd.DataFrame(actual_scored_dataset)
    actual_scored_dataset_df.index = expected_scored_dataset_df.index.astype(str)

    assert_frame_equal(expected_scored_dataset_df, actual_scored_dataset_df)
