import json

import pandas as pd
import pytest


# Bias Detection Model Bias
@pytest.fixture(scope="session")
def model_bias_evaluation_payload():

    df = pd.read_parquet("tests/data/adult.parquet")
    model_bias_evaluation_payload = {
        "input": df.to_dict(),
        "has_intersections": True,
        "sensitive_group": {"sex": "Male", "race": "White"},
        "confidence_level": 0.95,
        "favorable_label": 1,
        "target": "annual_income",
        "predictions": "score",
    }

    return model_bias_evaluation_payload


@pytest.fixture(scope="session")
def model_bias_evaluation_keys():

    model_bias_evaluation_keys = [
        "model_id",
        "score_threshold",
        "k",
        "attribute_name",
        "attribute_value",
        "accuracy",
        "tpr",
        "tnr",
        "for",
        "fdr",
        "fpr",
        "fnr",
        "npv",
        "precision",
        "pp",
        "pn",
        "ppr",
        "pprev",
        "fp",
        "fn",
        "tn",
        "tp",
        "group_label_pos",
        "group_label_neg",
        "group_size",
        "total_entities",
        "prev",
        "label_value_significance",
        "score_significance",
        "fdr_disparity",
        "fdr_ref_group_value",
        "fdr_significance",
        "fnr_disparity",
        "fnr_ref_group_value",
        "fnr_significance",
        "for_disparity",
        "for_ref_group_value",
        "for_significance",
        "fpr_disparity",
        "fpr_ref_group_value",
        "fpr_significance",
        "npv_disparity",
        "npv_ref_group_value",
        "npv_significance",
        "ppr_disparity",
        "ppr_ref_group_value",
        "ppr_significance",
        "pprev_disparity",
        "pprev_ref_group_value",
        "pprev_significance",
        "precision_disparity",
        "precision_ref_group_value",
        "precision_significance",
        "tnr_disparity",
        "tnr_ref_group_value",
        "tnr_significance",
        "tpr_disparity",
        "tpr_ref_group_value",
        "tpr_significance",
    ]

    return model_bias_evaluation_keys


@pytest.fixture()
def test_dataset():
    test_dataset = pd.DataFrame(
        {
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "workclass": {
                0: "Private",
                1: "Private",
                2: "State-gov",
                3: "Private",
                4: "Private",
            },
            "education": {
                0: "HS-grad",
                1: "11th",
                2: "Some-college",
                3: "Some-college",
                4: "Some-college",
            },
            "education_num": {0: 9, 1: 7, 2: 10, 3: 10, 4: 10},
            "marital_status": {
                0: "Divorced",
                1: "Married-civ-spouse",
                2: "Married-civ-spouse",
                3: "Married-civ-spouse",
                4: "Divorced",
            },
            "occupation": {
                0: "Handlers-cleaners",
                1: "Sales",
                2: "Other-service",
                3: "Exec-managerial",
                4: "Adm-clerical",
            },
            "relationship": {
                0: "Not-in-family",
                1: "Husband",
                2: "Husband",
                3: "Wife",
                4: "Not-in-family",
            },
            "race": {0: "White", 1: "White", 2: "Black", 3: "Other", 4: "White"},
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "capital_gain": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "capital_loss": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "hours_per_week": {0: 40, 1: 50, 2: 15, 3: 40, 4: 40},
            "native_country": {
                0: "United-States",
                1: "United-States",
                2: "United-States",
                3: "United-States",
                4: "United-States",
            },
            "annual_income": {0: 0, 1: 1, 2: 0, 3: 0, 4: 1},
            "score": {0: 1, 1: 0, 2: 0, 3: 0, 4: 1},
        }
    )

    return test_dataset


@pytest.fixture()
def test_dataset_converted():
    test_dataset = pd.DataFrame(
        {
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "workclass": {
                0: "Private",
                1: "Private",
                2: "State-gov",
                3: "Private",
                4: "Private",
            },
            "education": {
                0: "HS-grad",
                1: "11th",
                2: "Some-college",
                3: "Some-college",
                4: "Some-college",
            },
            "education_num": {0: 9, 1: 7, 2: 10, 3: 10, 4: 10},
            "marital_status": {
                0: "Divorced",
                1: "Married-civ-spouse",
                2: "Married-civ-spouse",
                3: "Married-civ-spouse",
                4: "Divorced",
            },
            "occupation": {
                0: "Handlers-cleaners",
                1: "Sales",
                2: "Other-service",
                3: "Exec-managerial",
                4: "Adm-clerical",
            },
            "relationship": {
                0: "Not-in-family",
                1: "Husband",
                2: "Husband",
                3: "Wife",
                4: "Not-in-family",
            },
            "race": {0: "White", 1: "White", 2: "Black", 3: "Other", 4: "White"},
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "capital_gain": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "capital_loss": {0: 0, 1: 0, 2: 0, 3: 0, 4: 0},
            "hours_per_week": {0: "40", 1: "50", 2: "15", 3: "40", 4: "40"},
            "native_country": {
                0: "United-States",
                1: "United-States",
                2: "United-States",
                3: "United-States",
                4: "United-States",
            },
            "annual_income": {0: 0, 1: 1, 2: 0, 3: 0, 4: 1},
            "score": {0: 1, 1: 0, 2: 0, 3: 0, 4: 1},
        }
    )

    return test_dataset


@pytest.fixture()
def expected_remapped_dataset():

    expected_remapped_dataset = pd.DataFrame(
        {
            "sex": {0: "Male", 1: "Male", 2: "Male", 3: "Female", 4: "Female"},
            "age": {0: 38, 1: 38, 2: 22, 3: 25, 4: 28},
            "score": {0: 1, 1: 0, 2: 0, 3: 0, 4: 1},
            "label_value": {0: 0, 1: 1, 2: 0, 3: 0, 4: 1},
        }
    )

    return expected_remapped_dataset


@pytest.fixture(scope="session")
def bias_detection_model_bias_output():

    with open("tests/data/adult_output.json", "r") as f:
        model_bias_evaluation_payload = json.load(f)

    return model_bias_evaluation_payload
