import pandas as pd
import pytest
from httpx import AsyncClient

from app.main import app

ENDPOINT_URL = "/ethicara/bias-detection/model-bias/"


@pytest.fixture
def response(client, model_bias_evaluation_payload):
    return client.post(
        ENDPOINT_URL + "predict",
        json=model_bias_evaluation_payload,
    )


def test_predict_is_active(response):
    assert response.status_code == 200
    assert response.json() is not None


def test_confidence_level_not_in_range(client, model_bias_evaluation_payload):
    dummy_payload = model_bias_evaluation_payload.copy()
    dummy_payload["confidence_level"] = 0.5
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)
    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_input_target_not_in_input(client, model_bias_evaluation_payload):
    dummy_payload = model_bias_evaluation_payload.copy()
    dummy_payload["target"] = "not_in_input"
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)
    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_favorite_label_not_in_input(client, model_bias_evaluation_payload):

    dummy_payload = model_bias_evaluation_payload.copy()
    dummy_payload["favorable_label"] = "422"
    response = client.post(ENDPOINT_URL + "predict", json=dummy_payload)

    assert response.status_code == 422
    assert response.json()["detail"][0]["type"] == "value_error"


def test_predict_returns_correct_keys(response, model_bias_evaluation_keys):
    assert set(response.json().keys()) == set(model_bias_evaluation_keys)


def test_predict_output_dimensions_are_correct(response):
    assert pd.DataFrame(response.json()).shape == (17, 59)


def test_predict_output_can_be_converted_to_dataframe(response):
    assert isinstance(pd.DataFrame(response.json()), pd.DataFrame)


@pytest.mark.asyncio
async def test_async():
    async with AsyncClient(app=app, base_url="https://test") as client:
        response = await client.get(ENDPOINT_URL)
    assert response.status_code == 200
    assert response.json() is not None
