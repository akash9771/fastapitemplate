import os
import sys
import uuid
import json
import random
import boto3
import requests as req
from collections import defaultdict
from loguru import logger
import concurrent.futures
from datetime import datetime

# Reading Environment Variables which are constants to this Lambda
AWS_REGION_NAME = os.environ["AWS_REGION_NAME"]
ERROR_SQS_QUEUE = os.environ["ERROR_SQS_QUEUE"]
MULE_CLIENT_ID = os.environ["CLIENT_ID"]
MULE_CLIENT_SECRET = os.environ["CLIENT_SECRET"]
VESSEL_VERIFICATION_URL = os.environ["VESSEL_VERIFICATION_URL"]
STACK_HEALTH_CHECK_ENDPOINT = os.environ["STACK_HEALTH_CHECK_ENDPOINT"]
STATUS_ENDPOINT = os.environ["STATUS_ENDPOINT"]
PROCESS_ENDPOINT = os.environ["PROCESS_ENDPOINT"]
UPDATE_INGESTION_STATUS_ENDPOINT = os.environ["UPDATE_INGESTION_STATUS_ENDPOINT"]
DOCINSIGHT_LAMBDA_LOG_LEVEL = os.environ["DOCINSIGHT_LAMBDA_LOG_LEVEL"]

# Configure logger
logger.remove()
logger.add(sys.stderr, format="{level}:{function}:{line}:{message}",level=DOCINSIGHT_LAMBDA_LOG_LEVEL)

sqs = boto3.client("sqs", region_name=AWS_REGION_NAME)

def generate_mulesoft_token():
    url = f"{VESSEL_VERIFICATION_URL}?grant_type=client_credentials"
    payload = f"client_id={MULE_CLIENT_ID}&client_secret={MULE_CLIENT_SECRET}"
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response = req.post(url, headers=headers, data=payload)
    token = response.json()["access_token"]
    return "Bearer " + token

def get_ingestion_status(headers, request_id, error_dict,req_id=None):
    logger.info(f"req_id-{req_id}. The request_id Received inside the get_ingestion_status is :"+ str(request_id))
    ingestion_status = ""
    try:        
        status_response = req.get(f"{STATUS_ENDPOINT}?request_id={request_id}", headers=headers)

        logger.debug(f"req_id-{req_id}. Got response from status endpoint {STATUS_ENDPOINT}: " + str(status_response.json()))

        if status_response.status_code == 200:
            ingestion_status = status_response.json()['status']

    except Exception as e:
        error_msg = f"req_id-{req_id}. Unable to invoke ingestion status endpoint : {str(e)}"
        error_dict["list_of_errors"].append(error_msg)
        ingestion_status = "call_failed"
        logger.error(f"{error_msg}")
    return ingestion_status, error_dict

def invoke_process_api_endpoint(ingestion_payload, error_dict, headers, req_id=None):
    
    try:
        logger.info(f"req_id-{req_id}. The Payload Received inside the invoke process_api_endpoint is : {str(ingestion_payload)}")
        # headers = {"Content-Type": "application/json"}
        process_response = req.post(PROCESS_ENDPOINT, headers=headers, data=json.dumps(ingestion_payload))

        logger.debug(f"req_id-{req_id}. Process_response is : {str(process_response.json())}")
        logger.debug(f"req_id-{req_id}. Status code received in process_response is :{str(process_response.status_code)}")

    except Exception as IngestionInvocationException:
        error_msg = f"req_id-{req_id}. Unable to invoke endpoint({PROCESS_ENDPOINT}) with the payload : {str(IngestionInvocationException)}"
        error_dict["list_of_errors"].append(error_msg)
        logger.error(f"{error_msg}")

    return process_response.status_code, error_dict

def insert_msg_in_sqs_queue(queue_name, sqs_message,  error_dict, increment_retry_count=False, message_body=None,increment_read_count=False, req_id=None):
    """
    Insert the message into the SQS Queue
    """
    insert_message_result = False
    logger.info(f"req_id-{req_id}. Inserting the message in SQS Queue : {str(queue_name)}")
    
    try:
        if not message_body:
            message_body = json.loads(sqs_message['body'])
        
        # Extract the queue URL from the response
        queue_url = sqs_get_queue_url(queue_name)
        logger.debug(f"req_id-{req_id}. Queue URL is : {str(queue_url)}")
        # Insert Message in the Queue
        if increment_retry_count:
            message_body['retry_count'] = int(message_body['retry_count'])+1
        if increment_read_count:
            message_body['read_count'] = int(message_body['read_count'])+1
        updated_message_body= json.dumps(message_body)
        logger.debug(f"req_id-{req_id}. Inserting message - {updated_message_body}")

        insert_response  = sqs.send_message(
            QueueUrl=queue_url,
            MessageBody=updated_message_body,
            MessageGroupId=str(sqs_message['attributes']['MessageGroupId']),
            MessageDeduplicationId=str(uuid.uuid4()),
        )
        
        logger.debug(f"req_id-{req_id}. response from send_message is: {str(insert_response)}")
        if insert_response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            logger.info(f"req_id-{req_id}. Message Inserted Successfully in the Queue : {str(queue_name)}")
            insert_message_result = True
        else:
            insert_message_result = False
            logger.Error(f"req_id-{req_id}. Failed to insert message - {insert_response}")
            raise Exception(
                "Improper HTTPResponseCode received while inserting message from SQS queue."
            )
            
    except Exception as InsertMessageFromQueue:
        logger.error(f"req_id-{req_id}. Error occured while sending msg to Q is : {str(InsertMessageFromQueue)}")
        error_msg = "Unable to insert message in the SQS queue" + str(
            InsertMessageFromQueue
        )
        error_dict["insert_msg_in_sqs_queue"].append(error_msg)

    return error_dict,insert_message_result

def delete_msg_from_sqs_queue(queue_url, queue_name, sqs_message, error_dict, req_id=None):
    """
    Deletes the Message from Queue based on Message ReceiptHandle
    """
    logger.info(f"req_id-{req_id}. Inside the delete msg_from_sqs_queue function.")
    is_deleted = False

    try:
        receipt_handle = sqs_message["receiptHandle"]

        # trying to delete the message
        dlt_response = sqs.delete_message(
            QueueUrl=queue_url, ReceiptHandle=receipt_handle
        )

        if dlt_response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            logger.debug(f"req_id-{req_id}. Message Deleted Successfully from the Queue : " + str(queue_name))
            is_deleted = True
        else:
            raise Exception(
                "Improper HTTPResponseCode received while deleting message from SQS queue."
            )
    except Exception as DeleteMessageFromQueue:
        error_msg = "Unable to delete message from the SQS queue" + str(
            DeleteMessageFromQueue
        )
        error_dict["delete_msg_from_sqs_queue"].append(error_msg)
        logger.error(f"req_id-{req_id}. Error occured - {error_msg}")

    return is_deleted, error_dict

def handle_ingestion_process_failure(sqs_message,queue_name,error_dict,queue_url,headers, fail_type=None, req_id=None):
    try:
        
        logger.info(f"Processing req_id:{req_id}. Inside the handle ingestion_process_failure. Message is {sqs_message}")
        message_body = json.loads(sqs_message['body'])
        if "retry_count" not in message_body:
            message_body["retry_count"] = 0
            retry_count = 0
        else:
            # if "_dlq" in queue_name and batch_failed==False:
            #     message_body["retry_count"] = int(message_body["retry_count"]) +1
            retry_count = message_body["retry_count"]
        

        if "read_count" not in message_body:
            message_body["read_count"]=1
            read_count=1
        else:
            message_body['read_count'] = int(message_body['read_count']) +1
            read_count = int(message_body['read_count'])
            
        logger.info(f"req_id-{req_id}. Receive count:{read_count}, message_body: {message_body}")

        if retry_count>=6 or fail_type=="sqs_message_missing_body" or read_count>=10:
            if read_count>=10:
                retry_exceeded_error_msg = f"req_id-{req_id}. Message is read 10 times. Moving message to Error Q"
            else:
                retry_exceeded_error_msg = f"req_id-{req_id}. Message is retried 6 times or corrupted. Moving message to Error Q"
            logger.debug(retry_exceeded_error_msg)
            error_dict['retry_exceeded'] = retry_exceeded_error_msg            
            #insert into Error Q and delete from DLQ
            error_dict = insert_msg_in_sqs_queue(
                            ERROR_SQS_QUEUE,
                            sqs_message,
                            error_dict,
                            message_body=message_body,
                            req_id=req_id,
                        )
            logger.debug(f"req_id-{req_id}. Message inserted into Error Q")
            is_deleted, error_dict = delete_msg_from_sqs_queue(queue_url, queue_name, sqs_message, error_dict, req_id=req_id)
            if is_deleted:
                logger.debug(f"req_id-{req_id}. message deleted from original Q-{queue_name}")
            logger.debug(f"req_id-{req_id}. Call the update-ingestion-status endpoint to update the status")
            call_update_ingestion_status_endpoint(sqs_message,error_dict,status="Error", req_id=req_id)
            logger.debug(f"req_id-{req_id}. Updated ingestion status")
            return error_dict
        
        if fail_type in ["health_check","openai_service_unavaiable_or_over_loaded"]:
            #Issue with vessel, dont increment the retry count
            increment_retry_count=False
        else:
            increment_retry_count=True

        if "_dlq" in queue_name:
            insert_q_name = queue_name
            logger.debug(f"req_id-{req_id}. Message is from the DLQ - {queue_name}")
        else:
            # queue_url = sqs_get_queue_url(queue_name)
            # receipt_handle = sqs_message["receiptHandle"]
            # response = sqs.change_message_visibility(
            #     QueueUrl=queue_url,
            #     ReceiptHandle=receipt_handle,
            #     VisibilityTimeout=30
            # )
            # logger.debug(f"visibilitytimeout is changed. response is -{response}")
            #For the very first insert into DLQ, dont increment the retry count
            increment_retry_count=False
            logger.debug(f"req_id-{req_id}. insert into DLQ")
            insert_q_name = (queue_name.split(".")[0] + "_dlq." + queue_name.split(".")[1])

        logger.info(f"req_id-{req_id}. update the delay, retry count and insert into DLQ")
        error_dict = insert_msg_in_sqs_queue(
                        insert_q_name,
                        sqs_message,
                        error_dict,
                        message_body=message_body,
                        increment_retry_count=increment_retry_count,
                        req_id=req_id,
                    )
        logger.debug(f"req_id-{req_id}. message inserted into Q -{insert_q_name}")
        is_deleted, error_dict = delete_msg_from_sqs_queue(queue_url, queue_name, sqs_message, error_dict, req_id=req_id)
        if is_deleted:
            logger.debug(f"req_id-{req_id}. Message deleted from original Q-{queue_name}")
        else:
            logger.error(f"req_id-{req_id}. Failed to delete the message from original Q-{queue_name}")

        return error_dict
    except Exception as e:
        logger.error(f"req_id-{req_id}. Error occured-{e}")
        raise e
    
def call_update_ingestion_status_endpoint(sqs_message,error_dict,status,req_id=None):
    
    try:
        
        message_body = json.loads(sqs_message['body'])
        logger.info(f"req_id-{req_id}. calling update ingestion status endpoint. Updating status as -'{status}'. \n Message body- {message_body}")
        payload = {
            "client_id": message_body["client_id"],
            "request_id": message_body["requestID"],
            "status": str(status),
            "error_message": str(error_dict),
        }
        headers = {"Content-Type": "application/json"}
        response = req.post(
            UPDATE_INGESTION_STATUS_ENDPOINT,
            headers=headers,
            data= json.dumps(payload),
        )
        logger.debug(f"req_id-{req_id}. ingestion_status_endpoint response is - {str(response.json())}")

    except Exception as e:
        logger.error(f"req_id-{req_id}. Error occured while calling update ingestion status - {str(e)}")

def sqs_batch_failure_response():
    # Lambda treats a batch as a complete failure if  function returns- an empty string itemIdentifier                
    # batch_item_failures.append({"itemIdentifier":""})
    sqs_batch_response = {}
    sqs_batch_response["batchItemFailures"] = [{"itemIdentifier":""}]
    return sqs_batch_response

def sqs_get_queue_url(queue_name):
    response_get_url = sqs.get_queue_url(QueueName=queue_name)
    return response_get_url["QueueUrl"]

def health_check():
    # Check if the health is good. Otherwise set the visibility timeout in batch
    logger.debug(f"Checking vessel stack health")

    headers = {"Content-Type": "application/json"}
    # Check health of docinsight
    health_response = req.get(STACK_HEALTH_CHECK_ENDPOINT, headers=headers)

    logger.info(f"The Response Received from health Check({STACK_HEALTH_CHECK_ENDPOINT}) is : {health_response.json()}")

    stack_health = True

    if health_response.status_code != 200:
        stack_health = False
    else:
        for service in health_response.json():
            logger.debug(f"Service_name - {service['service_name']}. Status_code - {service['status_code']}")
            if service['status_code'] !=200:
                stack_health = False
                break
    return stack_health

def delay_entire_batch(records, queue_url,queue_name):
    messages=[]
    status_api_headers = {"Content-Type": "application/json"}
    error_dict = defaultdict(list)
    
    error_dict["stack_health_error"].append(f"Stack health was bad at {datetime.utcnow()}")
    for sqs_message in records:
        # receipt_handle = get_receipt_handle(sqs_message)
        # message_id = get_message_Id(sqs_message)
        # messages.append({"Id":str(message_id),"ReceiptHandle":str(receipt_handle),"VisibilityTimeout":30})
        req_id=get_req_Id(sqs_message)
        error_dict = handle_ingestion_process_failure(sqs_message=sqs_message,
                                                                queue_name=queue_name,
                                                                error_dict=error_dict,
                                                                queue_url=queue_url,
                                                                headers=status_api_headers,
                                                                fail_type="health_check",
                                                                req_id=req_id,
                                                                )
        
    # logger.debug("Changing visibilitytimeout for all the messages in this batch.")
    # response = sqs.change_message_visibility_batch(
    #             QueueUrl=queue_url,
    #             Entries=messages
    #         )
    # logger.debug(f"visibilitytimeout is changed for all the messages in this batch. response is -{response}")
    logger.debug(f"All messages are deleted and inserted to DLQ")

def get_req_Id(sqs_message):
    # Extract requestID
    message_body = json.loads(sqs_message['body'])
    return message_body['requestID']

def get_message_Id(sqs_message):
    # Extract message Id
    return sqs_message['messageId']

def get_receipt_handle(sqs_message):
    # Extract message receipt handle
    return sqs_message['receiptHandle']

def message_handler(sqs_message, queue_url, queue_name, mule_token):
    try:
        # Setting Error Dict
        error_dict = defaultdict(list)
        
        # Extract message body
        message_body = json.loads(sqs_message['body'])
        req_id = message_body['requestID']

        if message_body is None:
            logger.error(f"req_id-{req_id}. message_body is none - {message_body} ")
            error_dict = handle_ingestion_process_failure(sqs_message=sqs_message,
                                                                queue_name=queue_name,
                                                                error_dict=error_dict,
                                                                queue_url=queue_url,
                                                                fail_type="sqs_message_missing_body",
                                                                req_id=req_id
                                                                )
        elif message_body:
            
            # # For very first migration of code, existing messages on Q wont have attribute "retry_count"
            # if "retry_count" not in message_body:
            #     logger.debug(f"req_id-{req_id}. retry_count not found in the message body. adding it")
            #     sqs_message['body']['retry_count'] = 0
            #     message_body = json.loads(sqs_message['body'])
            # if "read_count" not in message_body:
            #     logger.debug(f"req_id-{req_id}. read_count not found in the message body req_id-{req_id}. adding it")
            #     sqs_message['body']['read_count'] = 0
            #     message_body = json.loads(sqs_message['body'])
            
            status_api_headers = {
                "Authorization": f"{mule_token}",
                "x-agw-client_id":f'{message_body["client_id"]}',
                "Content-Type": "application/json",
            }
            logger.debug(f"Getting status of ingestion")
            ingestion_status, error_dict = get_ingestion_status(
                    status_api_headers, message_body["requestID"], error_dict, req_id=req_id,
                )
            logger.debug(f"req_id-{req_id}. Ingestion status is : {ingestion_status}")

            if ingestion_status=="call_failed":
                # Failed to get ingestion status
                error_dict = handle_ingestion_process_failure(sqs_message=sqs_message,
                                                                queue_name=queue_name,
                                                                error_dict=error_dict,
                                                                queue_url=queue_url,
                                                                headers=status_api_headers,
                                                                fail_type="health_check",
                                                                req_id=req_id,
                                                                )
                logger.info(f"req_id-{req_id}. Ingestion status call failed. Visibility timeout increased and exit")                    
                return
            elif ingestion_status in ["Completed"]:                
                is_deleted, error_dict = delete_msg_from_sqs_queue(
                    queue_url, queue_name, sqs_message, error_dict, req_id=req_id
                )
                logger.info(f"req_id-{req_id}. Ingestion status is already completed. Deleted the message. delete status-{is_deleted}")
                return
            
            elif ingestion_status=="Error":
                logger.info(f"req_id-{req_id}. Current status of message is Error. insert into Error Q and delete from current Q")
                error_dict = insert_msg_in_sqs_queue(
                    ERROR_SQS_QUEUE,
                    sqs_message,
                    error_dict,
                    increment_read_count=True,
                    req_id=req_id,
                )
                is_deleted, error_dict = delete_msg_from_sqs_queue(
                    queue_url, queue_name, sqs_message, error_dict, req_id=req_id
                )

                return

            invocation_status_code, error_dict = invoke_process_api_endpoint(message_body, error_dict, status_api_headers, req_id=req_id)

            logger.info(f"req_id-{req_id}. Invocation Response Status Code Received is : {str(invocation_status_code)}")

            if invocation_status_code == 200:
                logger.debug("req_id-{req_id}. Invocation status code is 200")
                # Invoke the method to delete this message from the Queue since it is processed successfully
                is_deleted, error_dict = delete_msg_from_sqs_queue(queue_url, queue_name, sqs_message, error_dict, req_id=req_id)
                logger.info(f"req_id-{req_id}. Invocation status code is 200. Message processed, delete from Q. is_deleted:{is_deleted}")
                # call_update_ingestion_status_endpoint(sqs_message,error_dict,status="Completed",req_id=req_id)
                # logger.debug(f"message status is updated in DB")

            elif invocation_status_code in [502,503,429,408]:
                # 408 - timeout
                logger.info(f"req_id-{req_id}. Invocation_status_code in [502,503,429,408]")
                error_dict = handle_ingestion_process_failure(sqs_message=sqs_message,
                                                                queue_name=queue_name,
                                                                error_dict=error_dict,
                                                                queue_url=queue_url,
                                                                headers=status_api_headers,
                                                                fail_type="openai_service_unavaiable_or_over_loaded",
                                                                req_id=req_id,
                                                                )
                return
                
            else:
                logger.info(f"req_id-{req_id}. Invocation_status_code not in [502,503,429,408]. Unknown issue")
                error_dict = handle_ingestion_process_failure(sqs_message=sqs_message,
                                                                queue_name=queue_name,
                                                                error_dict=error_dict,
                                                                queue_url=queue_url,
                                                                headers=status_api_headers,
                                                                fail_type="unknown_issue",
                                                                req_id=req_id,
                                                                )
                return
    except Exception as e:
        logger.error(str(e))
        raise e
    
def handler(event, context):
    try:
        batch_item_failures = []
        sqs_batch_response = {}
        queue_name = event['Records'][0]['eventSourceARN'].split(':')[-1]
        logger.info(f"Batch contains {len(event['Records'])} messages from Queue: {queue_name}.")
        logger.debug(f"Batch messages: {event['Records']}")
        
        # Get Queue url.
        queue_url = sqs_get_queue_url(queue_name)

        # Check service health.
        healthy = health_check()
        # Do not process, wait till the services are up.
        if not healthy:
            logger.warning("DocInsights APIs are not healthy at the moment, delaying entire batch.")
            delay_entire_batch(event['Records'], queue_url,queue_name)
            return sqs_batch_failure_response()
            
        logger.debug(f"Docinsight health is good. Proceed with processing")
        mule_token = generate_mulesoft_token()
        # Do parallel processing.
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            # Create a dictionary to associate each future with its corresponding task identifier
            future_to_task = {executor.submit(message_handler, sqs_message, queue_url, queue_name, mule_token): sqs_message for sqs_message in event['Records']}
            for future in concurrent.futures.as_completed(future_to_task):
                sqs_message = future_to_task[future]
                req_id = get_req_Id(sqs_message)

                try:
                    # Check the result.
                    future.result()

                    logger.info(f"req_id-{req_id}. Current worker is successful") 
                except Exception as e:
                    logger.error(f"req_id-{req_id}. Current worker failed with exception: Exception: {repr(e)}. Moving the message to error queue. Setting the status as Error")
                    error_dict = defaultdict(list)
                    error_dict["list_of_errors"].append(str(e))
                    error_dict = insert_msg_in_sqs_queue(
                        ERROR_SQS_QUEUE,
                        sqs_message,
                        error_dict,
                        increment_read_count=True,
                        increment_retry_count=True,
                        req_id=req_id,
                    )

                    call_update_ingestion_status_endpoint(sqs_message,error_dict,status="Error",req_id=req_id)
        
        # Lambda treats a batch as a complete success if your function returns a null batchItemFailures list
        sqs_batch_response["batchItemFailures"] = batch_item_failures
        return sqs_batch_response
    except Exception as e:
        logger.error(f"Error occured - {str(e)}")
        return sqs_batch_failure_response()
