import os
import sys
import uuid
import json
import time
import boto3
import base64
import requests as req
from botocore.vendored import requests
from datetime import datetime
from collections import OrderedDict
from collections import defaultdict
from boto3.dynamodb.conditions import Attr

# Setting Constants
# DYNAMO_STATE_MANAGER_TABLE = 'dev-vsl-docinsight-State_Manager'
# RECORDS_TO_KEEP_IN_STATE_MANAGER = 100
# AWS_REGION_NAME = 'us-east-1'
# SECRET_NAME = "dev-vsl-docinsight-requestor-lambda-secrets"
# HEALTH_CHECK_ENDPOINT = "https://vsl-dev.pfizer.com/searchapi/health"

# Reading Environment Variables which are constants to this Lambda
DYNAMO_STATE_MANAGER_TABLE = os.environ["DYNAMO_STATE_MANAGER_TABLE"]
RECORDS_TO_KEEP_IN_STATE_MANAGER = os.environ["RECORDS_TO_KEEP_IN_STATE_MANAGER"]
AWS_REGION_NAME = os.environ["AWS_REGION"]
SECRET_NAME = os.environ["SECRET_NAME"]
HEALTH_CHECK_ENDPOINT = os.environ["HEALTH_CHECK_ENDPOINT"]
PROCESS_ENDPOINT = os.environ["PROCESS_ENDPOINT"]
ERROR_SQS_QUEUE = os.environ["ERROR_SQS_QUEUE"]
UPDATE_INGESTION_STATUS_ENDPOINT = os.environ["UPDATE_INGESTION_STATUS_ENDPOINT"]


# Validating if the Environment Variables were read properly
print("DYNAMO_STATE_MANAGER_TABLE : " + str(DYNAMO_STATE_MANAGER_TABLE))
print("RECORDS_TO_KEEP_IN_STATE_MANAGER : " + str(RECORDS_TO_KEEP_IN_STATE_MANAGER))
print("AWS_REGION_NAME : " + str(AWS_REGION_NAME))
print("SECRET_NAME : " + str(SECRET_NAME))
print("HEALTH_CHECK_ENDPOINT : " + str(HEALTH_CHECK_ENDPOINT))
print("PROCESS_ENDPOINT : " + str(PROCESS_ENDPOINT))
print("UPDATE_INGESTION_STATUS_ENDPOINT : " + str(UPDATE_INGESTION_STATUS_ENDPOINT))


def update_active_records_with_inactive_flag(
    dynamo_table_response, max_epoch_time, error_dict
):
    table = boto3.resource("dynamodb", region_name=AWS_REGION_NAME).Table(
        DYNAMO_STATE_MANAGER_TABLE
    )
    # Update items that are part of response but don't have MAX EPOCH Date
    for item in dynamo_table_response["Items"]:
        if int(item["Epoch_Time"]) < max_epoch_time:
            try:
                response = table.update_item(
                    Key={
                        "Application_State": item["Application_State"],
                        "Epoch_Time": item["Epoch_Time"],
                    },
                    UpdateExpression="SET IsActive = :new_value",
                    ExpressionAttributeValues={":new_value": int("0")},
                )
            except Exception as DynamoTableUpdateException:
                error_msg = (
                    "Unable to perform Table Update for older records having isActive flag as 1"
                    + str(DynamoTableUpdateException)
                )
                error_dict["update_active_records_with_inactive_flag"].append(error_msg)

    return error_dict


def extract_entry_with_highest_epoch(dynamo_table_response):
    # Taking in Latest Active Record in case of Multiple Records
    # Initialize variables to store the maximum epoch time and corresponding dictionary
    max_epoch_time = 0
    max_epoch_time_dict = None

    # Iterate through the dictionaries in the "Items" array to extract the entry with highest EPOCH Time
    for item in dynamo_table_response["Items"]:
        epoch_time = int(item["Epoch_Time"])
        if epoch_time > max_epoch_time:
            max_epoch_time = epoch_time
            max_epoch_time_dict = item

    return max_epoch_time_dict


def fetch_active_records_from_table(table_client, error_dict):
    try:
        response = table_client.scan(FilterExpression=Attr("IsActive").eq(int("1")))

        # Check if No Records are active, if so, make a default entry with 'Accepting' Status and isActive = 1
        if response["Count"] == 0:
            print("Response when table has no active records : " + str(response))
            print("Inserting default entry into the Dynamo DB State Manager Table")
            error_dict = insert_entry_in_state_table(
                DYNAMO_STATE_MANAGER_TABLE, "Accepting", error_dict
            )
            response = table_client.scan(FilterExpression=Attr("IsActive").eq(int("1")))
            print("Response after default entry has been Ingested : " + str(response))
    except Exception as TableScanException:
        error_msg = (
            "Unable to perform Table Scan to fetch Active records from State Manager table"
            + str(TableScanException)
        )
        error_dict["fetch_active_records_from_table"].append(error_msg)
        return None, error_dict

    return response, error_dict


def read_secret_manager_and_return_dict(error_dict):
    secret_value = None
    try:
        # Initialize the Secrets Manager client
        secret_client = boto3.client("secretsmanager", region_name=AWS_REGION_NAME)

        # Retrieve the secret value
        secret_response = secret_client.get_secret_value(SecretId=SECRET_NAME)

        # Check if the secret is in the 'SecretString' format
        if "SecretString" in secret_response:
            secret_value = secret_response["SecretString"]
            # {"open_ai_vessel_client_id":"SAMPLE_CLIENT_ID","open_ai_vessel_client_secret":"SAMPLE_CLIENT_SECRET"}
    except Exception as SecretFetchException:
        error_msg = (
            "Unable to fetch secret from Secret Managet to invoke Ingestion API endpoint"
            + str(SecretFetchException)
        )
        error_dict["read_secret_manager_and_return_dict"].append(error_msg)

    return secret_value, error_dict


def invoke_ingestion_api_endpoint(headers, ingestion_payload, error_dict):
    ingestion_response_code = 300
    print(
        "The Ingestion Payload Received inside the invoke_ingestion_api_endpoint is :"
        + str(ingestion_payload)
    )
    try:
        # ingestion_response = req.post(PROCESS_ENDPOINT, headers=headers, data=json.dumps(ingestion_payload))
        ingestion_response = req.post(
            PROCESS_ENDPOINT, headers=headers, data=ingestion_payload
        )

        print("Raw ingestion_response is : " + str(ingestion_response.json()))
        print(
            "Status code received in ingestion_response is : "
            + str(ingestion_response.status_code)
        )

        ingestion_response_code = ingestion_response.status_code
        # ingestion_response_data : {'status': 'success', 'index': '42b690e4642714839b0ba6b51e5a9bd6', 'request_id': '8dee0b36-74a6-4a53-9a5d-ed61ba61c398'}
        # Check the response status code

        if ingestion_response.status == "success":
            # Successful response
            ingestion_response_data = ingestion_response.json()
            print("ingestion_response_data :", ingestion_response_data)
            ingestion_response_code = 200

    except Exception as IngestionInvocationException:
        error_msg = "Unable to invoke ingestion endpoint with the payload : " + str(
            IngestionInvocationException
        )
        error_dict["invoke_ingestion_api_endpoint"].append(error_msg)

    payload = json.loads(ingestion_payload)
    print(
        f"The Ingestion Response Code inside invoke_ingestion_api_endpoint is {str(ingestion_response_code)} for payload: {payload}"
    )
    print("The error_dict inside invoke_ingestion_api_endpoint : " + str(error_dict))

    return ingestion_response_code, error_dict


def read_latest_msg_from_sqs_queue(queue_name, error_dict):
    """
    Fetches the latest message from the queue.
    """
    try:
        sqs = boto3.client("sqs", region_name=AWS_REGION_NAME)
        response_get_url = sqs.get_queue_url(QueueName=queue_name)

        # Extract the queue URL from the response
        queue_url = response_get_url["QueueUrl"]

        sqs_response = sqs.receive_message(QueueUrl=queue_url, MaxNumberOfMessages=1)

        print(
            "The sqs_response value while reading the message is : " + str(sqs_response)
        )

        if (
            sqs_response["ResponseMetadata"]["HTTPStatusCode"] == 200
            and sqs_response["Messages"]
        ):
            print(
                "Message being Read from the Queue : "
                + str(queue_name)
                + " is : "
                + str(sqs_response["Messages"][0]["Body"])
            )
            return sqs_response, error_dict
        else:
            raise Exception(
                "Unable to fetch Message from the Queue. Either the Response Code wasn't proper or there are no messages in the queue"
            )
    except Exception as ReadMessageFromQueue:
        error_msg = "Unable to read message from the SQS queue" + str(
            ReadMessageFromQueue
        )
        error_dict["read_latest_msg_from_sqs_queue"].append(error_msg)

    return None, error_dict


def insert_msg_in_sqs_queue(queue_name, msg_json, error_dict):
    """
    Insert the message into the SQS Queue
    """
    print("Inserting the message in Error Queue : " + str(queue_name))
    print("Inserting the message : " + str(msg_json))
    try:
        sqs = boto3.client("sqs", region_name=AWS_REGION_NAME)
        response_get_url = sqs.get_queue_url(QueueName=queue_name)

        # Extract the queue URL from the response
        queue_url = response_get_url["QueueUrl"]
        print(
            "Queue URL successfully generated in method insert_msg_in_sqs_queue : "
            + str(queue_url)
        )
        # Insert Message in the Queue
        insert_response = sqs.send_message(
            QueueUrl=queue_url,
            MessageBody=msg_json,
            MessageGroupId="DocInsightsGroup",
            MessageDeduplicationId=str(uuid.uuid4()),
        )
        print(
            "insert_response in method insert_msg_in_sqs_queue : "
            + str(insert_response)
        )
        if insert_response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            print("Message Inserted Successfully in the Queue : " + str(queue_name))
        else:
            raise Exception(
                "Improper HTTPResponseCode received while inserting message from SQS queue."
            )
    except Exception as InsertMessageFromQueue:
        print("Value of InsertMessageFromQueue is : " + str(InsertMessageFromQueue))
        error_msg = "Unable to insert message in the SQS queue" + str(
            InsertMessageFromQueue
        )
        error_dict["insert_msg_in_sqs_queue"].append(error_msg)

    return error_dict


def delete_msg_from_sqs_queue(queue_name, msg_json, error_dict):
    """
    Deletes the Message from Queue based on Message ReceiptHandle
    """
    print("Message inside the delete_msg_from_sqs_queue function is : ")
    print(str(msg_json))
    try:
        sqs = boto3.client("sqs", region_name=AWS_REGION_NAME)
        response_get_url = sqs.get_queue_url(QueueName=queue_name)

        # Extract the queue URL from the response
        queue_url = response_get_url["QueueUrl"]

        receipt_handle = msg_json["Messages"][0]["ReceiptHandle"]

        # trying to delete the message
        dlt_response = sqs.delete_message(
            QueueUrl=queue_url, ReceiptHandle=receipt_handle
        )

        if dlt_response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            print("Message Deleted Successfully from the Queue : " + str(queue_name))
        else:
            raise Exception(
                "Improper HTTPResponseCode received while deleting message from SQS queue."
            )
    except Exception as DeleteMessageFromQueue:
        error_msg = "Unable to delete message from the SQS queue" + str(
            DeleteMessageFromQueue
        )
        error_dict["delete_msg_from_sqs_queue"].append(error_msg)

    return error_dict


def limit_dynamo_records(dynamo_table_name, error_dict):
    """
    This function ensures only a maximum of 100 records are maintained in Dynamo Table.
    Any historical records older than 100 latest records will be deleted.
    """
    try:
        table = boto3.resource("dynamodb", region_name=AWS_REGION_NAME).Table(
            dynamo_table_name
        )

        # Query the table to retrieve all the Records
        scan_response = table.scan()

        # Sort All Items in Reverse order based on Epoch_Time
        # Sort the dictionaries inside 'Items' based on 'Epoch_Time' in descending order
        sorted_scanned_response = sorted(
            scan_response["Items"], key=lambda x: x["Epoch_Time"], reverse=True
        )
        filtered_sorted_scanned_response = sorted_scanned_response[
            RECORDS_TO_KEEP_IN_STATE_MANAGER:
        ]

        # Deleting the Items accounted in filtered_sorted_scanned_response List

        with table.batch_writer() as batch:
            for item in filtered_sorted_scanned_response:
                response = batch.delete_item(
                    Key={
                        "Application_State": item["Application_State"],
                        "Epoch_Time": item["Epoch_Time"],
                    }
                )

        print(f"Deleted {len(filtered_sorted_scanned_response)} items.")

    except Exception as DynamoItemDeleteException:
        error_msg = (
            "Unable to perform Table Item Delete to ensure only latest N records are maintained in table."
            + str(DynamoItemDeleteException)
        )
        error_dict["limit_dynamo_records"].append(error_msg)

    return error_dict


def convert_to_python_dict_format(dynamo_formatted_dict):
    """
    Input Format : {'Application_State': 'Halted', 'IsActive': Decimal('1'), 'Epoch_Time': Decimal('1694170692')}
    Output Format : {'Application_State': 'Halted', 'IsActive': 1, 'Epoch_Time': 1694170692}
    """
    expected_format_dict = {}
    expected_format_dict["Application_State"] = dynamo_formatted_dict[
        "Application_State"
    ]
    expected_format_dict["IsActive"] = int(dynamo_formatted_dict["IsActive"])
    expected_format_dict["Epoch_Time"] = int(dynamo_formatted_dict["Epoch_Time"])
    return expected_format_dict


def insert_entry_in_state_table(dynamo_table_name, state, error_dict):
    """
    Assists in Ingesting new Record in a State Table with isActive flag as 1.
    """
    try:
        table = boto3.resource("dynamodb", region_name=AWS_REGION_NAME).Table(
            dynamo_table_name
        )
        active_state_dict = {
            "Application_State": state,
            "IsActive": 1,
            "Epoch_Time": int(time.time()),
        }
        table.put_item(Item=active_state_dict)
        print("Entry successfully ingested into the Table")
    except Exception as DynamoPutItemException:
        error_msg = "Unable to perform Table Insert for new active record." + str(
            DynamoPutItemException
        )
        error_dict["read_active_state_of_table"].append(error_msg)
        print(
            "Error Encountered while ingesting entry into the State table : "
            + str(error_msg)
        )
    return error_dict


def read_active_state_of_table(dynamo_table_name, error_dict):
    """
    Assists in reading the Active Status from the Ingestion State Manger table.
    If multiple Items are active, ensures only the latest active record remains active.
    If no records are active, ensures a new entry is made into table.
    Calls the method to limit the number of records to just N records.
    """

    try:
        table = boto3.resource("dynamodb", region_name=AWS_REGION_NAME).Table(
            dynamo_table_name
        )
    except Exception as TableClientException:
        error_msg = "Unable to create client for State Manager table" + str(
            TableClientException
        )
        error_dict["read_active_state_of_table"].append(error_msg)
        return None, error_dict

    # Fetch the Active Record(s) from the table
    active_record_response, error_dict = fetch_active_records_from_table(
        table, error_dict
    )

    # Ensure only 1 record is in Active state currently
    if int(active_record_response["Count"]) == 1:
        print("As per the expectation, only 1 record is in active state")
        active_state_dict = convert_to_python_dict_format(
            active_record_response["Items"][0]
        )

    elif int(active_record_response["Count"]) > 1:
        print("More Active Records in State Manager Table than expected")
        error_msg = "More Active records in the Dynamo State Manager table : " + str(
            int(active_record_response["Count"])
        )
        error_dict["read_active_state_of_table"].append(error_msg)

        max_epoch_time_dict = extract_entry_with_highest_epoch(active_record_response)
        active_state_dict = convert_to_python_dict_format(max_epoch_time_dict)

        error_dict = update_active_records_with_inactive_flag(
            active_record_response, int(max_epoch_time_dict["Epoch_Time"]), error_dict
        )
        error_dict = limit_dynamo_records(DYNAMO_STATE_MANAGER_TABLE, error_dict)

    print("The Active Entry in Dynamo DB Table is : " + str(active_state_dict))
    return active_state_dict, error_dict


def handler(event, context):
    # Setting Error Dict
    error_dict = defaultdict(list)

    api_access_secret, error_dict = read_secret_manager_and_return_dict(error_dict)
    # {"open_ai_vessel_client_id":"SAMPLE_CLIENT_ID","open_ai_vessel_client_secret":"SAMPLE_CLIENT_SECRET"}
    if not api_access_secret:
        print(
            "Ingestion API access secrets couldn't be fetched, hence existing the Lambda execution."
        )
        return {"statusCode": 200, "body": "Success", "error_dict": error_dict}
        sys.exit(0)
    else:
        # print("api_access_secret : " + str(api_access_secret))
        api_access_secret_dict = json.loads(api_access_secret)
        ingestion_api_client_id = api_access_secret_dict["open_ai_vessel_client_id"]
        ingestion_api_client_secret = api_access_secret_dict[
            "open_ai_vessel_client_secret"
        ]

    # Iterations to Process Requests from Queues.
    # Since it's an ordered dict, we need to ensure priority queues get processed first completely.
    if event:
        print(
            "Processing of Messages from Queues is required. Ensure that the event dict is maintained as an Ordered Dict"
        )
        sqs_queue_request_map = OrderedDict(event)

        # Flag Depicting if overall Ingestion Process is going fine. If even 1 message fails with inappropriate Response Code. Flag Turns ON.
        INGESTION_FLAG = 0
        ITERATION_COUNT = 1
        for queue, num_of_requests in sqs_queue_request_map.items():
            print("The Iteration Count is : " + str(ITERATION_COUNT))
            ITERATION_COUNT = ITERATION_COUNT + 1
            print("Queue to be processed as part of this iteration is : " + str(queue))
            if INGESTION_FLAG == 0:
                # while int(num_of_requests):
                if int(num_of_requests) == 0:
                    continue
                print(
                    "The number of requests for the queue : "
                    + str(queue)
                    + " is : "
                    + str(num_of_requests)
                )
                for num in range(int(num_of_requests)):
                    sqs_message, error_dict = read_latest_msg_from_sqs_queue(
                        queue, error_dict
                    )
                    if sqs_message is None:
                        print(
                            "No Message Available in the Queue. Skip to the Next Queue"
                        )
                        break
                    elif sqs_message["Messages"][0]["Body"]:
                        # <WRITE PLACEHOLDER CODE TO INVOKE THE "/process" endpoint with Ingestion Payload>

                        headers = {
                            "Authorization": f"Basic {base64.b64encode(f'{ingestion_api_client_id}:{ingestion_api_client_secret}'.encode()).decode()}",
                            "Content-Type": "application/json",
                        }
                        health_response = req.get(
                            HEALTH_CHECK_ENDPOINT, headers=headers
                        )
                        print(
                            "The Response Received from health Check is : "
                            + str(health_response)
                        )
                        print(
                            "The type of Response Received from health Check is : "
                            + str(type(health_response))
                        )

                        if health_response.status_code == 200:
                            (
                                invocation_status_code,
                                error_dict,
                            ) = invoke_ingestion_api_endpoint(
                                headers, sqs_message["Messages"][0]["Body"], error_dict
                            )
                        else:
                            error_msg = "Health of DocInsights API doesn't seem to be expected since a Non 200 Response code was returned. No messages will be further processed as part of this iteration."
                            error_dict["lambda_handler"].append(error_msg)
                            INGESTION_FLAG = 1
                            break

                        # HARDCODING THE INVOCATION_STATUS_CODE JUST FOR DUMMY EXECUTION STANDPOINT
                        # invocation_status_code = 200
                        print(
                            f"Invocation Reponse Status Code Received is : {str(invocation_status_code)}"
                        )

                        if invocation_status_code == 200:
                            print(
                                "Inside the Clause when invocation_status_code == 200"
                            )
                            # Invoke the method to delete this message from the Queue since it was processed successfully
                            error_dict = delete_msg_from_sqs_queue(
                                queue, sqs_message, error_dict
                            )
                            # Since Ingestion "/process" endpoint was called successfully, ensure that "Accepting" entry is present in the table
                            active_state_dict, error_dict = read_active_state_of_table(
                                DYNAMO_STATE_MANAGER_TABLE, error_dict
                            )
                            if active_state_dict["Application_State"] == "Accepting":
                                num_of_requests = num_of_requests - 1
                                continue
                            elif active_state_dict["Application_State"] == "Halted":
                                print(
                                    "The Active state of the Dynamo DB table need to be updated to Accepting"
                                )
                                error_dict = insert_entry_in_state_table(
                                    DYNAMO_STATE_MANAGER_TABLE, "Accepting", error_dict
                                )

                                # Ensure entry is made is the only Active entry in table and Limit of N records is maintained
                                state_table_client = boto3.resource(
                                    "dynamodb", region_name=AWS_REGION_NAME
                                ).Table(DYNAMO_STATE_MANAGER_TABLE)
                                (
                                    active_record_response,
                                    error_dict,
                                ) = fetch_active_records_from_table(
                                    state_table_client, error_dict
                                )
                                max_epoch_time_dict = extract_entry_with_highest_epoch(
                                    active_record_response
                                )
                                error_dict = update_active_records_with_inactive_flag(
                                    active_record_response,
                                    int(max_epoch_time_dict["Epoch_Time"]),
                                    error_dict,
                                )
                                error_dict = limit_dynamo_records(
                                    DYNAMO_STATE_MANAGER_TABLE, error_dict
                                )
                                num_of_requests = num_of_requests - 1
                                continue
                            else:
                                error_msg = (
                                    "Acceptable Application_State is only 'Accepting' or 'Halted'. Unknown state encountered"
                                    + str(active_state_dict)
                                )
                                error_dict["lambda_handler"].append(error_msg)
                        elif (
                            invocation_status_code == 503
                            or invocation_status_code == 429
                        ):
                            INGESTION_FLAG = 1
                            print(
                                "Inside the Clause when invocation_status_code == 503 or invocation_status_code == 429"
                            )
                            # If this message is from Original Queue, Move to DLQ, if from DLQ leave it intact
                            if "_dlq" in queue:
                                print(
                                    "Message is from the DLQ only, hence this message will not be moved."
                                )
                            else:
                                print(
                                    "The Message seems to be from the Original Queue, Move it to the DLQ"
                                )
                                dlq_queue_name = (
                                    queue.split(".")[0] + "_dlq." + queue.split(".")[1]
                                )

                                # Insert Message into the DLQ
                                error_dict = insert_msg_in_sqs_queue(
                                    dlq_queue_name,
                                    sqs_message["Messages"][0]["Body"],
                                    error_dict,
                                )
                                # Delete Message from Existing Queue
                                error_dict = delete_msg_from_sqs_queue(
                                    queue, sqs_message, error_dict
                                )

                            # Since Ingestion "/process" endpoint couldn't be called successfully, ensure that "Halted" entry is present in the table
                            active_state_dict, error_dict = read_active_state_of_table(
                                DYNAMO_STATE_MANAGER_TABLE, error_dict
                            )

                            if active_state_dict["Application_State"] == "Accepting":
                                print(
                                    "The Active state of the Dynamo DB table need to be updated to Halted"
                                )
                                error_dict = insert_entry_in_state_table(
                                    DYNAMO_STATE_MANAGER_TABLE, "Halted", error_dict
                                )

                                # Ensure entry made is the only Active entry in table and Limit of N records is maintained
                                state_table_client = boto3.resource(
                                    "dynamodb", region_name=AWS_REGION_NAME
                                ).Table(DYNAMO_STATE_MANAGER_TABLE)

                                # Fetch All Active Records, Extract the Highest EPOCH timestamp, Ensure record with highest Epoch is turned ON
                                # Finally Limit the Number of Records in Dynamo DB Table to what's being configured.
                                (
                                    active_record_response,
                                    error_dict,
                                ) = fetch_active_records_from_table(
                                    state_table_client, error_dict
                                )
                                print(
                                    "active_record_response : "
                                    + str(active_record_response)
                                )
                                max_epoch_time_dict = extract_entry_with_highest_epoch(
                                    active_record_response
                                )
                                print(
                                    "max_epoch_time_dict : " + str(max_epoch_time_dict)
                                )
                                error_dict = update_active_records_with_inactive_flag(
                                    active_record_response,
                                    int(max_epoch_time_dict["Epoch_Time"]),
                                    error_dict,
                                )
                                error_dict = limit_dynamo_records(
                                    DYNAMO_STATE_MANAGER_TABLE, error_dict
                                )
                                break
                            elif active_state_dict["Application_State"] == "Halted":
                                print(
                                    "The Active state of the Dynamo DB table is already 'Halted'"
                                )
                                break
                        elif (
                            invocation_status_code != 503
                            and invocation_status_code != 429
                            and invocation_status_code != 200
                        ):
                            INGESTION_FLAG = 1
                            print(
                                "Inside the Clause when invocation_status_code != 503 and invocation_status_code != 429 and invocation_status_code != 200"
                            )
                            # Insert Message into the Error Queue
                            print(
                                "Invoking the Insert Message to ensure that the message ends up in the Error Queue"
                            )
                            error_dict = insert_msg_in_sqs_queue(
                                ERROR_SQS_QUEUE,
                                sqs_message["Messages"][0]["Body"],
                                error_dict,
                            )
                            print(
                                "Invoking the Delete Message to ensure that the message ends up in the Error Queue"
                            )
                            # Delete Message from Existing Queue
                            error_dict = delete_msg_from_sqs_queue(
                                queue, sqs_message, error_dict
                            )

                            # Since Ingestion "/process" endpoint was called but the Message gas issues, hence we should ensure the entry is for "Accepting"
                            active_state_dict, error_dict = read_active_state_of_table(
                                DYNAMO_STATE_MANAGER_TABLE, error_dict
                            )
                            if active_state_dict["Application_State"] == "Accepting":
                                num_of_requests = num_of_requests - 1
                                continue
                            elif active_state_dict["Application_State"] == "Halted":
                                print(
                                    "The Active state of the Dynamo DB table need to be updated to Accepting"
                                )
                                error_dict = insert_entry_in_state_table(
                                    DYNAMO_STATE_MANAGER_TABLE, "Accepting", error_dict
                                )

                                # Ensure entry is made is the only Active entry in table and Limit of N records is maintained
                                state_table_client = boto3.resource(
                                    "dynamodb", region_name=AWS_REGION_NAME
                                ).Table(DYNAMO_STATE_MANAGER_TABLE)
                                (
                                    active_record_response,
                                    error_dict,
                                ) = fetch_active_records_from_table(
                                    state_table_client, error_dict
                                )
                                max_epoch_time_dict = extract_entry_with_highest_epoch(
                                    active_record_response
                                )
                                error_dict = update_active_records_with_inactive_flag(
                                    active_record_response,
                                    int(max_epoch_time_dict["Epoch_Time"]),
                                    error_dict,
                                )
                                error_dict = limit_dynamo_records(
                                    DYNAMO_STATE_MANAGER_TABLE, error_dict
                                )
                                num_of_requests = num_of_requests - 1
                                continue
                            else:
                                error_msg = (
                                    "Acceptable Application_State is only 'Accepting' or 'Halted'. Unknown state encountered"
                                    + str(active_state_dict)
                                )
                                error_dict["lambda_handler"].append(error_msg)

                            print("Calling the update-ingestion-status endpoint")
                            # Call the update-ingestion-status endpoint to update the status
                            payload = {
                                "client_id": sqs_message["Messages"][0]["Body"][
                                    "client_id"
                                ],
                                "request_id": sqs_message["Messages"][0]["Body"][
                                    "requestID"
                                ],
                                "status": "Error",
                                "error_message": f"Unable to process request: {str(error_dict['invoke_ingestion_api_endpoint'])}",
                            }
                            response = req.post(
                                UPDATE_INGESTION_STATUS_ENDPOINT,
                                headers=headers,
                                data=payload,
                            )
                            print(response.status)

            elif INGESTION_FLAG == 1:
                error_msg = "One of the Message has hit error while sending request to DocInsights Ingestion API. Hence exiting the run."
                error_dict["lambda_handler"].append(error_msg)
                break
    else:
        print("No messages received from Orchestrator Lambda to perform processing.")

    return {"statusCode": 200, "body": "Success", "error_dict": error_dict}
