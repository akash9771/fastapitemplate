"""Added reingest flag

Revision ID: 519706cea3fd
Revises: ac830407634c
Create Date: 2024-05-08 01:13:13.151355

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '519706cea3fd'
down_revision: Union[str, None] = 'ac830407634c'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "data_ingestion_status_table", sa.Column("re_ingested", sa.Boolean, default=False)
    )
    

def downgrade() -> None:
    op.drop_column("data_ingestion_status_table", "re_ingested")


