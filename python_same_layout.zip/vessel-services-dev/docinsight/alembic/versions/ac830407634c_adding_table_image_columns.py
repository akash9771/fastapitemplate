"""adding table image columns

Revision ID: ac830407634c
Revises: f45d93572a53
Create Date: 2024-04-25 00:47:33.221229

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


# revision identifiers, used by Alembic.
revision: str = 'ac830407634c'
down_revision: Union[str, None] = 'f45d93572a53'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "data_ingestion_status_table",
        sa.Column("table_figure_metadata", postgresql.JSONB(astext_type=sa.Text()), nullable=True),
    )
def downgrade() -> None:
    op.drop_column("data_ingestion_status_table", "table_figure_metadata")
