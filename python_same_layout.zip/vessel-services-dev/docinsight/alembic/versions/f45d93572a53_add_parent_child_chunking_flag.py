"""add_parent_child_chunking_flag

Revision ID: f45d93572a53
Revises: a606bbe2ffba
Create Date: 2024-04-22 15:21:24.485552

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'f45d93572a53'
down_revision: Union[str, None] = 'a606bbe2ffba'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "data_ingestion_status_table",
        sa.Column("chunked_as_parent_child", sa.Boolean),
    )
    op.execute("UPDATE data_ingestion_status_table SET chunked_as_parent_child=False WHERE chunked_as_parent_child is null")

def downgrade() -> None:
    op.drop_column("data_ingestion_status_table", "chunked_as_parent_child")
