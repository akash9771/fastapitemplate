"""Add new column file_path to data_ingestion_status_table

Revision ID: a606bbe2ffba
Revises: c283fc765c7d
Create Date: 2024-03-12 17:35:07.013656

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'a606bbe2ffba'
down_revision: Union[str, None] = 'c283fc765c7d'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "data_ingestion_status_table", sa.Column("file_path", sa.String)
    )
    


def downgrade() -> None:
    op.drop_column("data_ingestion_status_table", "file_path")

