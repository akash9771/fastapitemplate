"""update data ingestion table to include delete columns

Revision ID: 14381c292667
Revises: d366799f82b4
Create Date: 2023-11-16 22:54:13.097028

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from datetime import datetime


# revision identifiers, used by Alembic.
revision: str = "14381c292667"
down_revision: Union[str, None] = "d366799f82b4"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "data_ingestion_status_table",
        sa.Column("created_ts", sa.DateTime(timezone=True), default=datetime.utcnow),
    )
    op.add_column(
        "data_ingestion_status_table", sa.Column("vec_db_deletion_status", sa.String)
    )
    op.add_column(
        "data_ingestion_status_table",
        sa.Column("is_file_deleted", sa.Boolean, default=False),
    )
    op.add_column(
        "data_ingestion_status_table",
        sa.Column(
            "modified_ts",
            sa.DateTime(timezone=True),
            default=datetime.utcnow,
            onupdate=datetime.utcnow,
        ),
    )

    op.execute("UPDATE data_ingestion_status_table SET created_ts=queued_ts")
    op.execute("UPDATE data_ingestion_status_table SET modified_ts=queued_ts")
    op.execute("UPDATE data_ingestion_status_table SET is_file_deleted=False")


def downgrade() -> None:
    op.drop_column("data_ingestion_status_table", "created_ts")
    op.drop_column("data_ingestion_status_table", "vec_db_deletion_status")
    op.drop_column("data_ingestion_status_table", "is_file_deleted")
    op.drop_column("data_ingestion_status_table", "modified_ts")
