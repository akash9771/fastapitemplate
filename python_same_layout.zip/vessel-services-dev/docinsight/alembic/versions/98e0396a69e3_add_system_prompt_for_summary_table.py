"""add system prompt for summary table

Revision ID: 98e0396a69e3
Revises: ae324c199f4b
Create Date: 2024-01-23 16:33:46.163365

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "98e0396a69e3"
down_revision: Union[str, None] = "ae324c199f4b"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column("document_summary", "temperature", type_=sa.Float)


def downgrade() -> None:
    op.alter_column("document_summary", "temperature", type_=sa.Integer)
