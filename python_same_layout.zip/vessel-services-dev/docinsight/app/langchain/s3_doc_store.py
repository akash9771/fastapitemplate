import asyncio
from concurrent.futures import ThreadPoolExecutor
import aioboto3
import json
from langchain_core.stores import BaseStore
from langchain_core.documents import Document
from typing import Optional, List, Sequence, Tuple, TypeVar,Iterator
import boto3
 
K = TypeVar("K")
V = TypeVar("V")
 
class S3DocStore(BaseStore):
    def __init__(self, bucket_name):
        self.bucket = bucket_name
        self.s3 = boto3.client("s3")
        self.session = aioboto3.Session()
 
    async def _serialize(self, obj):
        if isinstance(obj, Document) or not isinstance(obj, str):
            return json.dumps(dict(obj))
        else:
            return json.dumps(obj)
 
    async def mset(self, key_value_pairs: Sequence[Tuple[K, V]]) -> None:
        async with self.session.client("s3") as s3:
            tasks = [asyncio.ensure_future(self.put_object_async(s3, key, document))
                     for key, document in key_value_pairs]
            await asyncio.wait(tasks, return_when=asyncio.ALL_COMPLETED)

    async def mmget(self, keys: Sequence[K]) -> List[Optional[V]]:
        results = []
        
        async with self.session.client("s3") as s3:
            tasks = [asyncio.ensure_future(self.get_object_async(s3, key)) for key in keys]
            done, _ = await asyncio.wait(tasks, return_when=asyncio.ALL_COMPLETED)
            results = [(task.result()[0], task.result()[1]) for task in done if task.result() is not None]
        return results
 
    async def put_object_async(self, s3, key, document):
        body = await self._serialize(document)
        return await s3.put_object(Body=body, Bucket=self.bucket, Key=str(key))
 
    def mget(self, keys: Sequence[K]) -> List[Optional[V]]:
        """
        Fetch multiple items from an S3 bucket.
        Args:
            keys (Sequence[K]): A sequence of keys to fetch objects for.
 
        Returns:
            List[Optional[V]]: A list of parsed JSON data or Document instances,
                                corresponding to each key. None is appended if an error occurs.
        """
        results = []
        for key in keys:
            try:
                response = self.s3.get_object(Bucket=self.bucket, Key=str(key))
                body = response['Body'].read()
                document_data = json.loads(body)
                if isinstance(document_data, dict):
                    # Assuming Document is a class that can be initialized with keyword arguments
                    results.append(Document(**document_data))
                else:
                    # If document_data is not a dict, append it directly (could be a list or a plain type)
                    results.append(document_data)
            except Exception as e:
                # Handle exceptions such as the object not existing or other AWS errors
                
                results.append(None)  # Append None or handle as needed
 
        return results       
       
 
    async def get_object_async(self, s3, key):
        try:
            response = await s3.get_object(Bucket=self.bucket, Key=f"{key}")
            body = await response['Body'].read()
            document_data = json.loads(body)
            if isinstance(document_data, dict):
                return (key, Document(**document_data))
            else:
                return (key, json.loads(body))  # or handle as needed
        except Exception as e:
            return None  # Handle exceptions or log errors as necessary
 

    async def mdelete(self, keys: Sequence) -> None:
        async with self.session.client("s3") as s3:
            for key in keys:
                await s3.delete_object(Bucket=self.bucket, Key=key)
 
    async def yield_keys(self, *, prefix: str | None = None) -> Iterator | Iterator[str]:
        pass
