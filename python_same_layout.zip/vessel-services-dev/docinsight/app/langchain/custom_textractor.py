import os
import PyPDF2
from textractor import Textractor
from textractor.data.constants import TextractFeatures
from langchain_core.documents import Document
import base64

import uuid

from app.langchain.s3_doc_store import S3DocStore
from app.utils.custom_loguru import logger

PARENT_CHUNKS_BUCKET_NAME = os.environ.get("PARENT_CHUNKS_BUCKET_NAME", "")

class CustomTextractException(Exception):
    """Exception class for errors in the textract processing pipeline."""

    def __init__(self, error_type, original_exception):
        super().__init__(f"{error_type} error: {str(original_exception)}")
        self.original_exception = original_exception


class CustomTextractor:
    def __init__(
        self,
        file_source: str,
        custom_extraction_document_path: str,
        s3_upload_path: str,
        filename: str,
        additional_metadata: dict,
        client_id: str,
        index_name: str,
        advance_table_filter: bool,
        embed_raw_table:bool,
        table_confidence_score:int = 20
    ):
        self.file_source = file_source
        self.filename = filename
        self.client_id = client_id
        self.index_name = index_name
        self.custom_extraction_document_path = custom_extraction_document_path
        self.s3_upload_path = s3_upload_path
        self.additional_metadata = additional_metadata
        self.extracted_figures = []
        self.extracted_tables = []
        self.filtered_image_details = []
        self.page_num_collection_images=[]
        self.page_num_collection_tables=[]
        self.embed_raw_table=embed_raw_table
        self.document_text_layouts = []
        self.table_confidence_score = table_confidence_score
        self.advance_table_filter=advance_table_filter
        self.textractor = Textractor(region_name="us-east-1")
        self.memory_store = S3DocStore(PARENT_CHUNKS_BUCKET_NAME)
        self.document = None
        self.total_extracted_tables = 0

    def _encode_image(self, img_path):
        with open(img_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8")
    
    def _get_images_information(self, image_list, path, image_layout_mapping):
        img_base64_list = []
        img_ids = []
        image_summaries = []
        
        # Iterate over the sorted list of files that are relevant
        for img_file in sorted(image_list):
            if img_file.endswith(".jpg"):
                img_path = os.path.join(path, img_file)
                id_key = "{}/{}/{}".format(self.client_id, self.index_name, uuid.uuid4())
                base64_image = self._encode_image(img_path)
                img_base64_list.append(f"data:image/jpeg;base64,{base64_image}")
                img_ids.append(id_key)

                if img_file in image_layout_mapping:
                    details = image_layout_mapping[img_file]
                    page_content = f"{self.filename} {details['figure_name']} page {details['figure_page']}"
                    
                   
                    metadata = {
                        **self.additional_metadata,
                        "docinsight_custom_extraction_id_key": id_key,
                        "document_name": self.filename,
                        "docinsight_custom_extraction_type":"image",
                        "figure_name": details["figure_name"],
                        "page": details["figure_page"]
                    }
                    self.page_num_collection_images.append(metadata)
                    
                    image_summaries.append(Document(page_content=page_content, metadata=metadata))
        
        return img_base64_list, img_ids, image_summaries

    async def _ingest_image(self):
        extra_image_summaries = []
        extra_image_uuids = []
        image_summaries = []
        img_uuids = []
        
        # Determine the correct path based on the input parameter
        figures_path = ""
        if os.path.exists(os.path.join(self.custom_extraction_document_path, 'figures')):
            figures_path = os.path.join(self.custom_extraction_document_path, 'figures')
        
        if figures_path:
            # List all files in the path
            # Filter the files based on specific conditions
            final_image_list = os.listdir(figures_path)
            
            if len(final_image_list):
                image_layout_mapping = {item["figure_name"]:item for item in self.extracted_figures}
                
                img_base64_list, img_uuids, image_summaries = self._get_images_information(final_image_list, figures_path, image_layout_mapping)
            
                await self.memory_store.mset(list(zip(img_uuids, img_base64_list)))

           
        if self.advance_table_filter:
            table_figures_path = ""
            if os.path.exists(os.path.join(self.custom_extraction_document_path, 'tables', 'img')):
                table_figures_path = os.path.join(self.custom_extraction_document_path, 'tables', 'img')
            
            if table_figures_path:
                final_image_list = os.listdir(table_figures_path)

                if len(final_image_list):
                    table_image_layout_mapping = {item["figure_name"]:item for item in self.filtered_image_details}

                    final_image_list = table_image_layout_mapping.keys()
                    img_base64_list, extra_image_uuids, extra_image_summaries = self._get_images_information(final_image_list, table_figures_path, table_image_layout_mapping)
                    await self.memory_store.mset(list(zip(extra_image_uuids, img_base64_list)))

    
        return image_summaries, img_uuids, extra_image_uuids, extra_image_summaries

    async def _ingest_tables(self):
        table_uuids = []
       
        # Preparing metadata dict outside the loop for efficiency
        metadata_dict = self.additional_metadata
               
        # Summary table preparation
        table_summaries = []

        for item in self.extracted_tables:
            table_uuid = "{}/{}/{}".format(self.client_id, self.index_name, uuid.uuid4())
            page_content = f"{self.filename} {item.get('figure_page', '')} {item.get('table_title', '')} {' '.join(item.get('footers', []))} {' '.join(item.get('column_headers', []))} {item.get('table_html', '') if self.embed_raw_table else ''}".strip()
            metadata={
                    **metadata_dict,
                    "page": item.get("figure_page", ""),
                    "document_name": self.filename,
                    "docinsight_custom_extraction_id_key": table_uuid,
                    "docinsight_custom_extraction_type": "table",
                }
            
            table_summaries.append(Document(
                page_content=page_content,
                metadata=metadata
            ))
            
            table_uuids.append(table_uuid)
            
            self.page_num_collection_tables.append(metadata)
        

        if len(self.extracted_tables):
            # HTML content extraction for tables
            html_content_list = [table["table_html"] for table in self.extracted_tables]
        
            await self.memory_store.mset(list(zip(table_uuids, html_content_list)))
       
        return table_summaries, table_uuids

    async def _process_document_pages(self):
        for page in self.document.pages:
            for index, layout in enumerate(page.layouts):
                # For Images
                if layout.layout_type == "LAYOUT_FIGURE":
                    self._process_page_for_figures(page, layout, index)

                # For Text
                if layout.layout_type not in ["LAYOUT_FIGURE", "LAYOUT_TABLE"]:
                    # Storing text information
                    page_text_layout = {
                        "page_num": page.page_num,
                        "page_full_text": page.text
                    }
                    self.document_text_layouts.append(page_text_layout)

            # For tables   
            for index, table in enumerate(page.tables):
                await self._process_page_for_tables(table, page, index)

            self.total_extracted_tables += len(page.tables)
            
    
    def _process_page_for_figures(self, page, layout, index):
        cropped_img = self._crop_image(page.image, layout.bbox, page.image.size)
        figure_path = self._save_cropped_image(
            cropped_img,
            "figures",
            f"page_{page.page_num}_figure_{index + 1}.jpg",
        )
        figure_info = self._gather_figure_metadata(
            layout, figure_path, page.page_num
        )
        self.extracted_figures.append(figure_info)
               
    async def _verify_table_layout(self, cropped_image, table_info):
        
        layout_doc =  self.textractor.analyze_document(features=[TextractFeatures.LAYOUT], file_source=cropped_image)
        
        table_info['verification_layouts'] = [
            {'type': layout.layout_type, 'confidence': layout.confidence} for layout in layout_doc.layouts
        ]

        for layout in table_info['verification_layouts']:
            if layout['type'] == 'LAYOUT_TABLE' and layout['confidence'] > (self.table_confidence_score / 100) and table_info['table_confidence'] > self.table_confidence_score:
                self.extracted_tables.append(table_info)
            else:
                self.filtered_image_details.append(table_info)

    async def _process_page_for_tables(self, table, page, index):
        unique_id=uuid.uuid4()
        dynamic_part=f"page_{page.page_num}_table_{index + 1}_{unique_id}"
        
        cropped_image = self._crop_image(page.image, table.bbox, page.image.size)
        table_img_path = self._save_cropped_image(
            cropped_image, "tables/img", f"{dynamic_part}.jpg"
        )
        
        table_info = self._gather_table_metadata(table, table_img_path, page.page_num)      

        # Verify table layout by analyzing the cropped table image
        if self.advance_table_filter:
            await self._verify_table_layout(cropped_image, table_info)
        else:
            self.extracted_tables.append(table_info)
               
    def _crop_image(self, image, bbox, size):
        page_width, page_height = size
        area_to_crop = (
            bbox.x * page_width,
            bbox.y * page_height,
            (bbox.x + bbox.width) * page_width,
            (bbox.y + bbox.height) * page_height,
        )
        return image.crop(area_to_crop)

    def _save_cropped_image(self, image, subdir, filename):
        path = os.path.join(self.custom_extraction_document_path, subdir)
        if not os.path.exists(path):
            os.makedirs(path)
        image_path = os.path.join(path, filename)
        image.save(image_path)
        return image_path

    def _gather_figure_metadata(self, figure, figure_path, page_num):
        return {
            "document_path": self.custom_extraction_document_path,
            "figure_id": figure.id,
            "figure_name": os.path.basename(figure_path),
            "figure_page": page_num,
            "figure_confidence": figure.confidence,
            "figure_bbox": figure.bbox,
            "figure_height": figure.height,
            "figure_width": figure.width,
            "figure_x": figure.x,
            "figure_y": figure.y,
            "figure_path": figure_path,
        }

    def _gather_table_metadata(self, table, table_img_path, page_num):
        column_headers = [
            cell.text for cell in table.table_cells if cell.is_column_header
        ]
        footers = [footer.text for footer in table.footers]

        return {
            "document_path": self.custom_extraction_document_path,
            "table_id": table.id,
            "figure_name": os.path.basename(table_img_path),
            "table_bbox": table.bbox,
            "table_column_count": table.column_count,
            "table_title": getattr(table.title, "text", None),
            "column_headers": column_headers,
            "footers": footers,
            "table_height": table.height,
            "table_metadata": table.metadata,
            "figure_page": page_num,
            "table_page_id": table.page_id,
            "table_confidence": table.raw_object["Confidence"],
            "table_row_count": table.row_count,
            "table_img_path": table_img_path,
            "table_html": table.to_html(),
            "table_markdown": table.to_markdown(),
            "table_width": table.width,
            "table_x": table.x,
            "table_y": table.y,
        }

    def _custom_textract_text_loader(self):
        pages = [
            Document(
                page_content=item["page_full_text"],
                metadata={"page": item["page_num"], "docinsight_custom_extraction_type": "text"},
            )
            for _, item in enumerate(self.document_text_layouts)
        ]
        return pages

    async def load(self):
        try:
            features = [TextractFeatures.LAYOUT, TextractFeatures.TABLES]

            logger.info("Started document document_analysis")
            self.document = self.textractor.start_document_analysis(
                file_source=self.file_source,
                s3_upload_path=self.s3_upload_path,
                features=features,
            )
            logger.info("Completed document document_analysis")


            total_pages=len(PyPDF2.PdfReader(self.filename).pages)

            logger.info("Processing extracted pages")

            await self._process_document_pages()   
            
            logger.info("Storing images")
            image_summaries, img_uuids, extra_image_uuids, extra_image_summaries = await self._ingest_image()
            
            logger.info("Storing tables")
            table_summaries, table_uuids = await self._ingest_tables()
            
            raw_texts = self._custom_textract_text_loader()
            
                
        except Exception as e:
            error_type = e.__class__.__name__.replace("Error", "")
            logger.error(f"Error during {error_type.lower()} process", exc_info=True)
            raise CustomTextractException(error_type, e)
        
        metering_data={'totalPages':total_pages,'totalTable':self.total_extracted_tables, 'filteredTable':len(self.extracted_tables),  'advTableFilter':self.advance_table_filter}
        rds_metadata = {"images": img_uuids, "table_confidence_score":self.table_confidence_score, "tables": table_uuids,"extra_image_uuids":extra_image_uuids,"metering_data":metering_data,'extra_table_data':self.page_num_collection_tables,'extra_image_data':self.page_num_collection_images}
        
        logger.info("Extracted pages information")

        return { "image_summaries": image_summaries, "table_summaries": table_summaries, "raw_texts":raw_texts, "metadata":rds_metadata, "extra_image_summaries":extra_image_summaries}

