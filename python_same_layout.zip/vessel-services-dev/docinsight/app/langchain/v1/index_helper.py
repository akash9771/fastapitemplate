from opensearchpy import OpenSearch, ImproperlyConfigured, OpenSearchException
from app.utils.custom_loguru import logger
from app.utils.config_vars import CHUNKS_METADATA, OPEN_SEARCH_TIMEOUT_SECONDS


class IASOpenSerachHelper:
    def __init__(self, host, username, password, index) -> None:
        self.host = host
        self.username = username
        self.password = password
        self.index = index

        self.client_initialization()

    def client_initialization(self):
        try:
            self.opensearch_client = OpenSearch(
                hosts=[self.host],
                http_auth=(self.username, self.password),
                timeout=OPEN_SEARCH_TIMEOUT_SECONDS,
            )
        except ImproperlyConfigured as e:
            logger.error("The config passed to the client is inconsistent or invalid")
            raise e

        except OpenSearchException as e:
            logger.error("Couldn't create opensearch client")
            raise e

    def delete_documents(self, document_md5=None, request_id=None):
        try:
            if document_md5:
                query = {"query": {"term": {"metadata.md5": f"{document_md5}"}}}

            if request_id:
                query = {"query": {"term": {"metadata.request_id.keyword": {"value":f"{request_id}"}}}}

            size = self.opensearch_client.count(body=query, index=self.index)["count"]

            response = self.opensearch_client.search(
                body=query, index=self.index, size=size
            )
            
            hits = response["hits"]["hits"]

            if hits:
                logger.info(f"Deleting the document for the given document_md5:{document_md5} / request_id:{request_id}")
                bulk_request = [
                    {"delete": {"_index": hit["_index"], "_id": hit["_id"]}}
                    for hit in hits
                ]
                
                response = self.opensearch_client.bulk(body=bulk_request)
                logger.info("Deleted the documents from opensearch")
                
                return True
            else:
                return False

        except Exception as e:
            logger.error(str(e))
            raise e

    def update_opensearch_metadata(
        self, document_md5, updated_metadata
    ):
        try:

            # Extract existing_metadata key, values from OpenSearch
            query = {"query": {"term": {"metadata.md5": document_md5}}}
            size = self.opensearch_client.count(body=query, index=self.index)["count"]
            query["_source"] ="metadata"
            
            response = self.opensearch_client.search(
                index=self.index,
                body=query,
                size=size
            )
            hits = response["hits"]["hits"]

            if hits:
                updated_payload = []
                
                for hit in hits:
                    updated_payload.append({"update":{"_index": hit["_index"], "_id": hit["_id"]}})
                    existing_metadata=hit["_source"]["metadata"]
                    opensearch_updated_metadata = {}
            
                    if existing_metadata is not None:
                        # Creating new dictionary to keep system generated key values from OpenSearch and include updated metadata from db.
                        opensearch_metadata_keys = CHUNKS_METADATA

                        for key, value in existing_metadata.items():
                            if key in opensearch_metadata_keys:
                                opensearch_updated_metadata[key] = value

                        for key, value in updated_metadata.items():
                            if key not in opensearch_updated_metadata.keys():
                                opensearch_updated_metadata[key] = value
                    
                    updated_metadata= opensearch_updated_metadata if opensearch_updated_metadata else existing_metadata
                    updated_payload.append({"doc": {"metadata":updated_metadata}})

                logger.info(f"Updating metadata for the given document_md5 :{document_md5}")
                response = self.opensearch_client.bulk(body=updated_payload)
                logger.info("Updated metadata")
   
            else:
                raise Exception("No records found in OpenSearch Vectordb")

        except Exception as e:
            logger.error(f"Failed to update metadata: {str(e)}")
            raise e
