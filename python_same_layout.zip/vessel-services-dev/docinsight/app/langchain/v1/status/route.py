from fastapi import APIRouter, Depends

from app.langchain.v1.models import UpdateIngestionStatus, Status

from sqlalchemy.orm import Session

from app.langchain.database import get_db

from app.utils.custom_loguru import logger, configure_logger

from app.langchain.v1.status.controller import UpdateIngestionTable


router = APIRouter()


@router.post(
    "/update-ingestion-status",
    status_code=200,
    tags=["API Module Service"],
    description="This endpoint updates the database when the lambda fails to invoke process endpoint",
)
async def update_ingestion_status(
    request_payload: UpdateIngestionStatus, db: Session = Depends(get_db)
):
    try:
        logger.debug(f"Request received to update the status for Client ID {request_payload.client_id} with Request ID {request_payload.request_id}")
        UpdateIngestionTable.update_ingestion_table(request_payload, db)
        return {"status": Status.success}

    except Exception as e:
        logger.error(f"Status update failed for payload{str(request_payload)}. Error is -{str(e)}")
        raise e
