from app.utils.custom_loguru import logger
from app.langchain.v1.helper import (
    create_retriever,
    filter_docs,
    get_llm_response,
    get_vector_db_details,
)
from app.langchain.v1.utils.ias_openai_langchain import (
    IAS_OpenSearchVectorSearch,
    IASOpenaiEmbeddings
)


async def invoke_retrieval_qa(
    db,
    client_id,
    x_vsl_client_id,
    bearer_auth,
    final_index_dict,
    document_names,
    rw,
    index_name: str,
):
    logger.info("invoke_retrieval_qa started")

    try:
        logger.info("Reading secret manager details to fetch OS Vector DB credentials.")
        (
            AWS_OPENSEARCH_HOST,
            AWS_OPENSEARCH_USERNAME,
            AWS_OPENSEARCH_PASSWORD,
        ) = await get_vector_db_details(client_id, db)
    except Exception as e:
        logger.error(f"Error while retrieving secrets of OS Vector DB.")
        raise e

    # Get only non-tabular docs.
    document_names = filter_docs(document_names, is_tabular=False)
    md5_list = [item[2] for item in document_names]
    score_threshold = (
            rw.vector_score_threshold if rw.vector_score_threshold else 0.0
        )
    
    if rw.llm_response_flag == False and rw.filter in ["post", "pre"]:
        if rw.parent_document_retriever:
            retriever = create_retriever(
                index_doc_map=final_index_dict,
                embeddings=IASOpenaiEmbeddings(
                    engine=rw.embedding_engine,
                    client_id=client_id,
                    x_vsl_client_id=x_vsl_client_id,
                    bearer_auth=bearer_auth,
                ),
                AWS_OPENSEARCH_HOST=AWS_OPENSEARCH_HOST,
                AWS_OPENSEARCH_USERNAME=AWS_OPENSEARCH_USERNAME,
                AWS_OPENSEARCH_PASSWORD=AWS_OPENSEARCH_PASSWORD,
                no_of_doc=rw.num_of_citations,
                vector_score_threshold=score_threshold,
                parent_document_retriever=rw.parent_document_retriever,
                max_tokens=rw.max_tokens,
                response_if_no_docs_found=rw.response_if_no_docs_found,
                llm_response_flag=rw.llm_response_flag,
                answer_from_llm_if_no_docs_found=rw.answer_from_llm_if_no_docs_found,
            )
            docs = retriever._get_relevant_documents(rw.user_query, run_manager=None)

        else:
            vector_db = IAS_OpenSearchVectorSearch(
                index_name=index_name,
                embedding_function=IASOpenaiEmbeddings(
                    engine=rw.embedding_engine,
                    client_id=client_id,
                    x_vsl_client_id=x_vsl_client_id,
                    bearer_auth=bearer_auth,
                ),
                opensearch_url=AWS_OPENSEARCH_HOST,
                http_auth=(AWS_OPENSEARCH_USERNAME, AWS_OPENSEARCH_PASSWORD),
                is_aoss=False,
            )

       
            search_kwargs = {"terms": {"metadata.md5": final_index_dict[index_name]}}

            docs = vector_db.similarity_search_with_relevance_scores(
                query=rw.user_query,
                k=rw.num_of_citations,
                filter=search_kwargs,
                score_threshold=score_threshold,
            )
        
        if rw.with_score:  
            citation_basic = [
                {
                    "page_content": doc[0].page_content,
                    "metadata": doc[0].metadata,
                    "score": doc[1],
                }
                for doc in docs
            ]
        else:
            citation_basic = [
                {"text": doc[0].page_content, "metadata": doc[0].metadata} for doc in docs
            ]

        llm_answer = "Vector db response is not passed to LLM. Below are the Similarity search results"
        total_token = [0, 0]
    elif (rw.filter == "post" or rw.filter == "pre") and rw.llm_response_flag == True:
        vector_db_retreiver = create_retriever(
            index_doc_map=final_index_dict,
            embeddings=IASOpenaiEmbeddings(
                engine=rw.embedding_engine,
                client_id=client_id,
                x_vsl_client_id=x_vsl_client_id,
                bearer_auth=bearer_auth,
            ),
            AWS_OPENSEARCH_HOST=AWS_OPENSEARCH_HOST,
            AWS_OPENSEARCH_USERNAME=AWS_OPENSEARCH_USERNAME,
            AWS_OPENSEARCH_PASSWORD=AWS_OPENSEARCH_PASSWORD,
            no_of_doc=rw.num_of_citations,
            vector_score_threshold=score_threshold,
            parent_document_retriever=rw.parent_document_retriever,
            max_tokens=rw.max_tokens,
            response_if_no_docs_found=rw.response_if_no_docs_found,
            llm_response_flag=rw.llm_response_flag,
            answer_from_llm_if_no_docs_found=rw.answer_from_llm_if_no_docs_found,
        )

        llm_answer, citation_basic, total_token = get_llm_response(
            vector_db=vector_db_retreiver,
            llm_engine=rw.llm_engine,
            temperature=rw.temperature,
            max_tokens=rw.max_tokens,
            system_message=rw.system_message,
            context=rw.context,
            user_query=rw.user_query,
            num_of_citations=rw.num_of_citations,
            files_md5=md5_list,
            filter_citations=rw.filter_citations,
            min_response_token=rw.min_response_token,
            vector_score_threshold=rw.vector_score_threshold,
            response_if_no_docs_found=rw.response_if_no_docs_found,
            client_id=client_id,
            x_vsl_client_id=x_vsl_client_id,
            bearer_auth=bearer_auth,
            llm_response_flag=rw.llm_response_flag,
            answer_from_llm_if_no_docs_found=rw.answer_from_llm_if_no_docs_found,
        )
    return (llm_answer, citation_basic, total_token)
