import json
import pathlib
from fastapi import HTTPException
from sqlalchemy.orm.session import Session
from sqlalchemy import func, and_
from app.langchain.v1.utils.ias_openai_langchain import (
    IASBedrockLLM,
    IASOpenaiConversationalLLM,
    IAS_OpenSearchVectorSearch,
    IAS_ConversationalRetrievalChain,
    LLMNotCalledException,
)
from app.langchain.v1.ias_document_retriever import IASDocumentRetriever
from app.langchain.s3_doc_store import S3DocStore
from app.utils.custom_loguru import logger

import time
import ast
import boto3
import uuid, hashlib, urllib
import os
from io import BytesIO
from langchain.retrievers.merger_retriever import MergerRetriever
from app.langchain.models import DataIngestionStatusTableNew
from app.utils.custom_loguru import logger
from app.utils.config_cache import cache_get, cache_set
from app.langchain.models import ClientMapping
from app.utils.config_vars import (
    MODEL_TOKEN_MAPPING,
    RETRIEVAL_QA_RESPONSE,
    TABULAR_EXTENSIONS,
    TOKEN_COUNTER_MULTIPLIER,
    RETRIEVAL_QA_CITATION_FILTER_KEYWORDS
)
import math
from app.utils.misc import is_anthropic_model, calculate_max_tokens
PARENT_CHUNKS_BUCKET_NAME = os.environ.get("PARENT_CHUNKS_BUCKET_NAME", "")


def calculate_approx_tokens(strings):
    token_count = 0
    if isinstance(strings, list):
        for string in strings:
            token_count += len(str(string).split())
    else:
        token_count += len(str(strings).split())
    return math.ceil(token_count * TOKEN_COUNTER_MULTIPLIER)


def create_chat_history_string(context: list):
    result = ""
    context.reverse()

    for i in range(len(context)):
        if i % 2 == 0:
            result += "Human: " + context[i] + " "
        else:
            result += "Assistant: " + context[i] + " "
    return result


def create_chat_history(context: list):
    try:
        chat_hist = []
        context_len = len(context)
        context.reverse()
        if context_len <= 1:
            return chat_hist
        else:
            for item in range(0, context_len - 1, 2):
                chat_hist.append((context[item], context[item + 1]))
        return chat_hist

    except Exception as e:
        logger.error(str(e))
        raise HTTPException(status_code=500, detail="Error while creating chat history")


def calculate_consumed_token(llm_response):
    # calculate total tokens for questions
    try:
        tokens_in_questions = len(llm_response["question"].split())
        # calculate total tokens for answer
        tokens_in_answer = len(llm_response["answer"].split())
        # calculate total tokens for chat history
        token_in_history = sum(
            sum(len(itr) for itr in history)
            for history in llm_response["chat_history"]
        )
        # calculate total tokens for document chunks
        token_in_documents = sum(
            len(doc.page_content) for doc in llm_response["source_documents"]
        )
        # calculate total token consumed by adding all the token in questions history and documents, and return the same
        return [
            (token_in_history + tokens_in_questions + tokens_in_answer),
            token_in_documents,
        ]
    except Exception as e:
        logger.error(str(e))
        raise HTTPException(
            status_code=500, detail="Error in calculating consumed token"
        )


def read_secret_manager_and_return_dict(SECRET_NAME: str, us: str, pw: str):
    secret_value = None
    try:
        secret_client = boto3.client("secretsmanager")

        secret_response = secret_client.get_secret_value(SecretId=SECRET_NAME)

        if "SecretString" in secret_response:
            secret_value = secret_response["SecretString"]

            finj = secret_value
            conv1 = ast.literal_eval(finj)
            pwd = conv1[pw]
            usd = conv1[us]

        return secret_value, pwd, usd

    except Exception as e:
        logger.error(str(e))
        raise e


def fetch_actual_doc(client_id: str, grabber: list, db: Session):
    try:
        val_to_fetch = grabber
        max_timestamp_subquery = (
            db.query(
                DataIngestionStatusTableNew.document,
                func.max(DataIngestionStatusTableNew.completed_errored_ts).label(
                    "max_timestamp"
                ),
            )
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.document.in_(val_to_fetch),
                DataIngestionStatusTableNew.status == "Completed",
                DataIngestionStatusTableNew.is_file_deleted == False,
            )
            .group_by(DataIngestionStatusTableNew.document)
            .subquery()
        )
        files = (
            db.query(DataIngestionStatusTableNew)
            .join(
                max_timestamp_subquery,
                and_(
                    DataIngestionStatusTableNew.document
                    == max_timestamp_subquery.c.document,
                    DataIngestionStatusTableNew.completed_errored_ts
                    == max_timestamp_subquery.c.max_timestamp,
                ),
            )
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.document.in_(val_to_fetch),
                DataIngestionStatusTableNew.status == "Completed",
            )
            .all()
        )

        if len(files) != 0:
            file_safe_values_custom = [file.document_md5 for file in files]
            return file_safe_values_custom
        else:
            logger.info("No Document Found")

        return []
    except Exception as e:
        logger.error(str(e))
        raise HTTPException(status_code=500, detail="Error while fetching document")


def fetch_actual_md5(md5_list: list, indices: list, db: Session, client_id_list: list):
    try:
        # Filter for specific indexes
        files = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.client_id.in_(client_id_list),
                DataIngestionStatusTableNew.index.in_(indices),
                DataIngestionStatusTableNew.document_md5.in_(md5_list),
                DataIngestionStatusTableNew.status == "Completed",
                DataIngestionStatusTableNew.is_file_deleted == False,
            )
            .all()
        )

        if len(files):
            document_md5_list = list(set([file.document_md5 for file in files]))
            return document_md5_list
        else:
            logger.info("No Documents MD5 Found")

    except Exception as e:
        logger.error(str(e))
        raise HTTPException(status_code=500, detail="Error while fetching actual md5")


def fetch_file_name(
    md5_list: list, indices: list, db: Session, client_id_list: list
):
    """This function is to fetch the actual file name and SS3 path from dataingestionstatus table"""

    try:
        # Filter for specific indexes
        files = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.client_id.in_(
                    client_id_list
                ),  # TODO: Check if the index and md5 combination.
                DataIngestionStatusTableNew.index.in_(indices),
                DataIngestionStatusTableNew.document_md5.in_(md5_list),
                DataIngestionStatusTableNew.status == "Completed",
                DataIngestionStatusTableNew.is_file_deleted == False,
            )
            .all()
        )

        if len(files):
            document = list(
                set(
                    [
                        (file.document, file.file_path, file.document_md5)
                        for file in files
                    ]
                )
            )
            return document

        else:
            logger.info("No files Found")

    except Exception as e:
        logger.error(str(e))
        raise HTTPException(
            status_code=500, detail="Error while fetching file"
        )


def fetch_actual_meta_latest(
    client_id: str,
    grabber: dict,
    db: Session,
    multi_metadata: list = None,
    metadata_filter_condition="or",
):
    try:
        val_to_fetch = grabber
        max_timestamp_subquery = (
            db.query(
                DataIngestionStatusTableNew.attached_metadata,
                func.max(DataIngestionStatusTableNew.completed_errored_ts).label(
                    "max_timestamp"
                ),
            )
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.status == "Completed",
                DataIngestionStatusTableNew.is_file_deleted == False,
            )
            .group_by(DataIngestionStatusTableNew.attached_metadata)
            .subquery()
        )

        # Main query to join with the subquery and retrieve the latest record for the specified client_id and completed status
        files = (
            db.query(DataIngestionStatusTableNew)
            .join(
                max_timestamp_subquery,
                and_(
                    DataIngestionStatusTableNew.attached_metadata
                    == max_timestamp_subquery.c.attached_metadata,
                    DataIngestionStatusTableNew.completed_errored_ts
                    == max_timestamp_subquery.c.max_timestamp,
                ),
            )
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.status == "Completed",
            )
            .all()
        )

        if len(files):
            mat_recrd = []
            justo = [file.attached_metadata for file in files]

            for dctnry in justo:
                conv = ast.literal_eval(dctnry)

                if metadata_filter_condition == "and":
                    include_file_on_metadata_match = (
                        include_file_on_multi_metadata_match
                    ) = False
                    if val_to_fetch:
                        if all(
                            k in conv and conv[k] == v for k, v in val_to_fetch.items()
                        ):
                            include_file_on_metadata_match = True

                    if multi_metadata:
                        if all(
                            key in conv and conv[key] in list_vals
                            for key, list_vals in multi_metadata.items()
                        ):
                            include_file_on_multi_metadata_match = True

                    if (val_to_fetch and multi_metadata) and (
                        include_file_on_metadata_match
                        and include_file_on_multi_metadata_match
                    ):
                        mat_recrd.append(conv.get("md5", None))
                    elif (
                        val_to_fetch
                        and include_file_on_metadata_match
                        and not multi_metadata
                    ) or (
                        not val_to_fetch
                        and multi_metadata
                        and include_file_on_multi_metadata_match
                    ):
                        mat_recrd.append(conv.get("md5", None))

                else:
                    if val_to_fetch:
                        if any(
                            k in conv and conv[k] == v for k, v in val_to_fetch.items()
                        ):
                            mat_recrd.append(conv.get("md5", None))
                    if multi_metadata:
                        if any(
                            key in conv and conv[key] in list_vals
                            for key, list_vals in multi_metadata.items()
                        ):
                            mat_recrd.append(conv.get("md5", None))

            return mat_recrd
        else:
            logger.info("No Documents meta")

    except Exception as e:
        logger.error(str(e))
        raise HTTPException(status_code=500, detail="Error in fetching attached metadata")


def extract_data(restui):
    try:
        for hit in restui["hits"]["hits"]:
            yield hit["_source"]["text"], hit["_source"]["metadata"]
    except Exception as e:
        logger.error(str(e))
        raise HTTPException(
            status_code=500, detail="Error while yielding hits"
        )


def request_generation():
    try:
        request_id = uuid.uuid4()
        return str(request_id)
    except Exception as e:
        logger.error(str(e))
        raise HTTPException(
            status_code=500, detail="Error while generating request"
        )


def index_generation():
    m = hashlib.md5(str(uuid.uuid4()).encode("UTF-8"))
    index_value = m.hexdigest()
    return index_value


def fetch_file_from_s3_using_purl(presigned_url, write_to_local=True):
    try:
        # Parse the URL
        parsed_url = urllib.parse.urlparse(presigned_url)
        logger.warning(f"xxDEBUGxx parsed_url: {parsed_url}")
        # Extract the filename from the last segment of the path
        path_segments = parsed_url.path.split("/")
        logger.warning(f"xxDEBUGxx path_segments: {path_segments}")
        filename_temp = path_segments[-1]
        logger.warning(f"xxDEBUGxx filename_temp: {filename_temp}")
        # Decode the filename to handle special characters
        filename_temp = urllib.parse.unquote(filename_temp)
        logger.warning(f"xxDEBUGxx decoded filename_temp: {filename_temp}")
        current_timestamp = str(int(time.time()))
        filetype = os.path.splitext(filename_temp)[1]
        logger.warning(f"xxDEBUGxx filetype: {filetype}")
        # Get the file extension, including the dot
        basename = os.path.splitext(filename_temp)[0]
        logger.warning(f"xxDEBUGxx basename: {basename}")
        # Get the base filename (without extension
        filename = f"{basename}_{current_timestamp}{filetype}"
        logger.warning(f"xxDEBUGxx filename: {filename}")
        with urllib.request.urlopen(presigned_url) as response:
            file_content = response.read()
        if write_to_local:
            with open(filename, "wb") as local_file:
                local_file.write(file_content)
        else:
            return filename, filename_temp, file_content

        logger.info(f"Document fetched and saved locally as {filename}")
        return filename, filename_temp, ""
    except Exception as e:
        logger.error(f"Error fetching document from S3: {str(e)}")
        raise e


def calculate_md5_hash(filename, file_content=False, chunk_size=8192):
    try:
        logger.info(f"Calculating MD5 for {filename}")
        md5_hash = hashlib.md5()
        if not file_content:
            with open(filename, "rb") as f:
                while chunk := f.read(chunk_size):
                    md5_hash.update(chunk)
        else:
            # File content is passed. File_content on memory
            bytes_io = BytesIO(file_content)
            while chunk := bytes_io.read(chunk_size):
                md5_hash.update(chunk)

        return md5_hash.hexdigest()
    except Exception as e:
        logger.error(str(e))
        logger.error("Error in calculating md5 hash value: ", exc_info=True)
        raise e


def insert_msg_in_sqs_queue(msg_json, indices, client_info, client_id: str = None):
    """
    Insert the message into the SQS Queue
    """
    try:
        sqs = boto3.client("sqs")
        queue_name = client_info.queue
        logger.info(f"queue_name: {queue_name}")
        response_get_url = sqs.get_queue_url(QueueName=queue_name)

        # Extract the queue URL from the response
        queue_url = response_get_url["QueueUrl"]
        if client_info.usecase.lower() == "vox":
            index_str = "_" + str(indices[0]) if len(indices) > 0 else ""
        else:
            index_str = ""
        # Insert Message in the Queue
        insert_response = sqs.send_message(
            QueueUrl=queue_url,
            MessageBody=msg_json,
            # MessageGroupId="DocInsightsGroup",
            MessageGroupId=client_id + index_str,
            MessageDeduplicationId=str(uuid.uuid4()),
        )
        if insert_response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            logger.info(
                "Message Inserted Successfully in the Queue : " + str(queue_name)
            )
        else:
            raise Exception(
                "Improper HTTPResponseCode received while inserting message from SQS queue."
            )
    except Exception as e:
        raise e


def Validation_error():
    validation_dict = {}

    validation_dict["src_document_path"] = (
        "src_document_path must not be empty and should contain presigned url value"
    )
    validation_dict["client_id"] = (
        "client_id should be integer and should not have empty space"
    )
    validation_dict["index"] = (
        "index can be empty for non VOX cases and must not contain empty space in it"
    )
    validation_dict["engine"] = (
        "engine is an optional field and if specified must contain text-embedding-ada-002"
    )
    validation_dict["document_chunk_size"] = (
        "document_overlap_size is an optional field and if passed must contain token less than 8197"
    )
    validation_dict["document_overlap_size"] = (
        "document_overlap_size is an optional field and if passed must be less than document_chunk_size 8197"
    )
    validation_dict["duplication"] = (
        "this index and md5 combination already exist please upload new document"
    )
    validation_dict["file_type"] = (
        "The supported documents formats are ['.pdf', '.docx', '.pptx', '.xls', '.xlsx', '.csv', '.png', '.jpg']"
    )
    return validation_dict


def ias_opensearch_vectorsearch_payload(
        index_name: str, 
        embeddings: list, 
        opensearch_url: str, 
        opensearch_username: str, 
        opensearch_pass: str, 
        is_aoss: bool):
    return IAS_OpenSearchVectorSearch(
                                index_name=index_name,
                                embedding_function=embeddings if embeddings else None,
                                opensearch_url=opensearch_url,
                                http_auth=(opensearch_username, opensearch_pass),
                                is_aoss=is_aoss,
                            )


def define_search_kwargs(
        index_name: str,
        no_of_doc: int,
        vector_score_threshold: float = 0.0
        ) -> dict:
    return {
            "filter": {"terms": {"metadata.md5": index_name}},
            "k": no_of_doc,
            "score_threshold": vector_score_threshold if vector_score_threshold else 0.0
            }


def create_retriever(
    index_doc_map,
    embeddings,
    AWS_OPENSEARCH_HOST,
    AWS_OPENSEARCH_USERNAME,
    AWS_OPENSEARCH_PASSWORD,
    no_of_doc,
    max_tokens: int,
    vector_score_threshold=0.0,
    parent_document_retriever=True,
    response_if_no_docs_found=None,
    llm_response_flag: bool = True,
    answer_from_llm_if_no_docs_found=None

):
    search_type = "similarity_score_threshold" 
                
    if parent_document_retriever:

        retrievers = [
            # Loop thorugh all the index provided by user & create a list of documents fetched
            IASDocumentRetriever(
                vectorstore=ias_opensearch_vectorsearch_payload(
                    index_name=index_name,
                    embeddings=embeddings,
                    opensearch_url=AWS_OPENSEARCH_HOST,
                    opensearch_username=AWS_OPENSEARCH_USERNAME,
                    opensearch_pass=AWS_OPENSEARCH_PASSWORD,
                    is_aoss=False
                ),
                docstore=S3DocStore(PARENT_CHUNKS_BUCKET_NAME),
                parent_document_retriever=parent_document_retriever,
                search_kwargs=define_search_kwargs(
                    index_name=index_doc_map[index_name],
                    no_of_doc=no_of_doc,
                    vector_score_threshold=vector_score_threshold
                    ),
                search_type=search_type,
                max_tokens_limit=max_tokens,
                response_if_no_docs_found=response_if_no_docs_found,
                llm_response_flag=llm_response_flag,
                answer_from_llm_if_no_docs_found=answer_from_llm_if_no_docs_found
            )
            for index_name in index_doc_map.keys()
        ] 
    else:
        retrievers = [
            ias_opensearch_vectorsearch_payload(
                    index_name=index_name,
                    embeddings=embeddings,
                    opensearch_url=AWS_OPENSEARCH_HOST,
                    opensearch_username=AWS_OPENSEARCH_USERNAME,
                    opensearch_pass=AWS_OPENSEARCH_PASSWORD,
                    is_aoss=False
            ).as_retriever(
                search_kwargs=define_search_kwargs(
                    index_name=index_doc_map[index_name],
                    no_of_doc=no_of_doc,
                    vector_score_threshold=vector_score_threshold
                    ),
                search_type=search_type,
            )
            for index_name in index_doc_map.keys()
        ]

    if len(index_doc_map) == 1:
        return retrievers[0]
    else:
        return MergerRetriever(retrievers=retrievers)


def get_llm_response(
    vector_db,
    llm_engine: str,
    temperature: float,
    max_tokens: int,
    context: list,
    user_query: str,
    num_of_citations: int,
    files_md5: list,
    system_message: str = None,
    filter_citations=True,
    min_response_token=500,
    vector_score_threshold=None,
    response_if_no_docs_found=None,
    client_id=None,
    x_vsl_client_id=None,
    bearer_auth=None,
    llm_response_flag: bool = True,
    answer_from_llm_if_no_docs_found=None,
):
    try:

        llm_config = {
            "engine" if llm_engine.startswith("gpt") else "model": llm_engine,
            "temperature": temperature,
            "max_tokens": calculate_max_tokens(
                max_tokens, str(llm_engine), min_response_token
            ),
            "system_message": system_message,
            "client_id": client_id,
            "x_vsl_client_id": x_vsl_client_id,
            "bearer_auth": bearer_auth,
        }
        if response_if_no_docs_found is not None and vector_score_threshold is not None:
            answer_if_no_docs_found = response_if_no_docs_found
        elif vector_score_threshold is not None and response_if_no_docs_found is None:
            answer_if_no_docs_found = "I don't know"

        llm_class = (
            IASOpenaiConversationalLLM
            if llm_engine.startswith("gpt")
            else IASBedrockLLM
        )
        qa = IAS_ConversationalRetrievalChain.from_llm(
            llm_class(**llm_config),
            chain_type="stuff",
            retriever=vector_db,
            return_source_documents=True,
            max_tokens_limit=calculate_max_tokens(
                max_tokens, str(llm_engine), min_response_token
            ),
            response_if_no_docs_found=(
                answer_if_no_docs_found if vector_score_threshold else None
            ),
            llm_response_flag=llm_response_flag,
            answer_from_llm_if_no_docs_found=answer_from_llm_if_no_docs_found,
        )

        chat_history = create_chat_history(context)

        if answer_from_llm_if_no_docs_found:
            # Added for Vox Flow.
            answer_with_llm_knowledge = "If you don't know the answer, then answer from your own knowledge base."
        else:
            answer_with_llm_knowledge = "If you don't know the answer, just say that you don't know, don't try to make up an answer."

        llm_response = qa(
            {
                "question": user_query,
                "chat_history": chat_history,
                "answer_with_llm_knowledge": answer_with_llm_knowledge,
            }
        )

        total_token = calculate_consumed_token(llm_response)

        if llm_response is None:
            raise HTTPException(
                status_code=400,
                detail="Some issue with Search API. Report to IAS please",
            )

        matching_texts = [
            {"text": doc.page_content, "metadata": doc.metadata}
            for doc in llm_response["source_documents"]
        ]

        #########ONE SCENARIO##########
        llm_answer = llm_response["answer"]
        PRESENT = False

        if filter_citations:
            for string in RETRIEVAL_QA_CITATION_FILTER_KEYWORDS:
                if string in llm_answer:
                    PRESENT = True
                    break

        if PRESENT:
            citation_basic = []
            answer = llm_answer
        else:
            answer = llm_answer
            citation_basic = matching_texts[: int(num_of_citations)]

        return answer, citation_basic, total_token
    except LLMNotCalledException:
        logger.info(
            "LLM is not triggered, as there were no documents obtained during the similarity search."
        )
        message = (
            response_if_no_docs_found
            if response_if_no_docs_found is not None
            else RETRIEVAL_QA_RESPONSE
        )
        return message, [], [0, 0]
    except Exception as e:
        logger.error("Failed while getting llm response")
        raise e


async def get_vector_db_details(client_id: str, db):
    client_info = await aget_client_info(db, client_id)

    if client_info is None:
        raise HTTPException(
            status_code=400,
            detail=f"Provided Client id -->{client_id} does not exist in mapping table, please provide the correct client_id to use search API.",
        )

    vector_db_details = client_info.vectorDBdetails
    db_info = ast.literal_eval(vector_db_details)
    AWS_OPENSEARCH_HOST = db_info["vectorDBAccessURL"]

    (
        _,
        AWS_OPENSEARCH_PASSWORD,
        AWS_OPENSEARCH_USERNAME,
    ) = read_secret_manager_and_return_dict(
        SECRET_NAME=db_info["Secretdetails"],
        us=db_info["UserNameVar"],
        pw=db_info["PasswordVar"],
    )

    return (
        AWS_OPENSEARCH_HOST,
        AWS_OPENSEARCH_USERNAME,
        AWS_OPENSEARCH_PASSWORD,
    )


async def client_id_info(client_id, db):
    client_info = await aget_client_info(db, client_id)
    if client_info.usecase.lower() == "vox":
        client_id_list = client_info.alternate_client_ids
    else:
        client_id_list = [client_id]
    return client_id_list


def delete_doc_s3(bucket_name: str, file_name: str):
    s3_client = boto3.client("s3")
    s3_client.delete_object(Bucket=bucket_name, Key=file_name)


def fetch_all_docs_for_client_id(client_id: str, db: Session):
    try:
        # fetch_all_docs_for_client_id

        files = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.status == "Completed",
                DataIngestionStatusTableNew.is_file_deleted == False,
            )
            .all()
        )

        if len(files) != 0:
            doc_md5_values = [file.document_md5 for file in files]
            return doc_md5_values
        else:
            logger.info(f"No Document Found")

        return []
    except Exception as e:
        logger.error(str(e))
        raise HTTPException(status_code=400, detail=f"Error while fetching documents")


def save_s3_file_to_local(s3_file_path):
    """This functon fetches file from S3 folders, and saves to local"""

    try:
        current_timestamp = str(int(time.time()))
        s3 = boto3.client("s3")

        split_url = s3_file_path.split("/")
        bucket_name = split_url[2]
        key = "/".join(split_url[3:])
        file_name = split_url[-1]
        local_file_name = f"temp_{current_timestamp}_{file_name}"
        response = s3.download_file(bucket_name, key, local_file_name)
        logger.info(f"local_file_name is {local_file_name}")
        return local_file_name, response

    except Exception as e:
        logger.error(str(e))
        raise HTTPException(
            status_code=500, detail="Error while fetching file from S3."
        )


def filter_non_tabular_files(final_index_dict, document_names):
    # Removing excel/csv/xml md5s from final_index_dict to pass it to retrieval QA
    tabular_docs = filter_docs(document_names, is_tabular=True)
    for index, docmd5 in final_index_dict.items():
        delete_docmd5 = [md5[2] for md5 in tabular_docs]

    # Deleting tabular md5 values from the keys.
    for key in list(final_index_dict.keys()):
        if key in final_index_dict:
            for value_to_delete in delete_docmd5:
                if value_to_delete in final_index_dict[key]:
                    final_index_dict[key].remove(value_to_delete)

    # Deleting empty keys from the dict
    final_index_dict_filtered = {key:val for key, val in final_index_dict.items() if val != []}

    return final_index_dict_filtered


def filter_docs(document_names, is_tabular):
    """Filter documents based on is_tabular condition."""
    if is_tabular:
        return [
            files
            for files in document_names
            if pathlib.Path(files[0]).suffix in TABULAR_EXTENSIONS
            and files[1] != None
        ]
    else:
        return [
            files
            for files in document_names
            if pathlib.Path(files[0]).suffix not in TABULAR_EXTENSIONS
            or (
                pathlib.Path(files[0]).suffix in TABULAR_EXTENSIONS and files[1] == None
            )
        ]


def delete_folder_docs_s3(bucket_name, folder_name):
    s3 = boto3.resource("s3")
    bucket = s3.Bucket(bucket_name)

    # List all objects in the folder
    objects_to_delete = [
        {"Key": obj.key} for obj in bucket.objects.filter(Prefix=folder_name)
    ]

    # Delete the objects in the folder
    if len(objects_to_delete) > 0:
        bucket.delete_objects(Delete={"Objects": objects_to_delete})


async def aget_client_info(db, client_id):
    # Check in cache.
    client_info = await cache_get(f"client_info_{client_id}", model_class=ClientMapping)

    if client_info is None:
        logger.info("Reading ClientMapping settings from database")

        client_info = get_client_info(db, client_id)
        if client_info:
            # Cache the client info.
            await cache_set(
                f"client_info_{client_id}", client_info, expire=24 * 60 * 60
            )
        else:
            logger.debug(f"client_info not found in DB. New client_id-({client_id})")
            return None
    
    return client_info


# Keeping synchronous as it is for now.
# TODO: Need to remove after all the instances are converted to async.
def get_client_info(db, client_id):
    client_info = (
        db.query(ClientMapping)
        .filter(ClientMapping.client_id == f"{client_id}")
        .first()
    )

    return client_info


def validate_token_limit(rw):
    model_mapping = json.loads(MODEL_TOKEN_MAPPING)
    if str(rw.llm_engine) in model_mapping.keys():
        engine_max_token = int(model_mapping[str(rw.llm_engine)])

        if rw.max_tokens > engine_max_token:
            logger.error(
                f"Max tokens({rw.max_tokens}) passed. - Allowed({engine_max_token}) for the selected model {rw.llm_engine} "
            )
            raise HTTPException(
                status_code=400,
                detail=f"Max tokens({rw.max_tokens}) passed is more than allowed({engine_max_token}) for the selected model {rw.llm_engine}",
            )
    else:
        logger.warning(
            f"Max token mapping for engine-{rw.llm_engine} is missing in the environment variable"
        )

    if not is_anthropic_model(str(rw.llm_engine)):
        estimated_token_consumption = (
            calculate_approx_tokens([rw.user_query, rw.system_message, rw.context])
            + rw.min_response_token
        )
        logger.debug(f"Estimated_token_consumption:{estimated_token_consumption}")
        if rw.max_tokens < estimated_token_consumption:
            raise HTTPException(
                status_code=400,
                detail=f"Max tokens({rw.max_tokens}) passed is less than minimum estimated token consumption:{estimated_token_consumption}",
            )
