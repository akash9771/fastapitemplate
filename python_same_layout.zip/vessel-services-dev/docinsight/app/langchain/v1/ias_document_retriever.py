from typing import Dict, List, ClassVar, Collection, Optional
from langchain_core.documents import Document
from langchain_core.pydantic_v1 import Field, root_validator
from langchain_core.retrievers import BaseRetriever
from langchain_core.vectorstores import VectorStore
from langchain.storage._lc_store import create_kv_docstore
from langchain.callbacks.manager import CallbackManagerForRetrieverRun
from langchain_core.stores import BaseStore
from transformers import GPT2TokenizerFast

from app.utils.custom_loguru import logger

class LLMNotCalledException(Exception):
    """Custom exception to indicate that LLM is not called."""
    pass


class IASDocumentRetriever(BaseRetriever):
    """Base Retriever class for VectorStore."""

    """The storage interface for the parent documents"""
    vectorstore: VectorStore
    """VectorStore to use for retrieval."""
    search_type: str = "similarity"
    """Type of search to perform. Defaults to "similarity"."""
    search_kwargs: dict = Field(default_factory=dict)
    """Keyword arguments to pass to the search function."""
    allowed_search_types: ClassVar[Collection[str]] = (
        "similarity",
        "similarity_score_threshold",
        "mmr",
    )
    docstore: BaseStore[str, Document] = None
    """The lower-level backing storage layer for the parent documents"""
    parent_doc_id_key: str = "docinsight_parent_doc_id"
    parent_document_retriever: bool = True
    documents_with_scores: list = []
    max_tokens_limit: Optional[int] = None
    """If set, enforces that the documents returned are less than this limit.
    This is only enforced if `combine_docs_chain` is of type StuffDocumentsChain."""
    llm_response_flag: Optional[bool] = True
    """Specify whether to call LLM or not."""
    answer_from_llm_if_no_docs_found: Optional[bool] = False
    """Answer from LLM knowledge if no matching docs found."""
    tokenizer = GPT2TokenizerFast.from_pretrained("gpt2")

    class Config:
        """Configuration for this pydantic object."""

        arbitrary_types_allowed = True

    def _reduce_tokens_below_limit(self, docs: List[Document]) -> List[Document]:
        num_docs = len(docs)

        if self.max_tokens_limit:
            tokens = [
                len(self.tokenizer.encode(doc.page_content))
                for doc, _ in docs
            ]
            token_count = sum(tokens[:num_docs])
            while token_count > self.max_tokens_limit:
                num_docs -= 1
                token_count -= tokens[num_docs]

        return [doc for doc, _ in docs[:num_docs]]

    def _condition_check_docs_token(self, final_docs):
        if self.llm_response_flag is True and len(final_docs):
            return self._reduce_tokens_below_limit(final_docs)
        elif len(final_docs):
            return final_docs
        else:
            return []

    @root_validator(pre=True)
    def shim_docstore(cls, values: Dict) -> Dict:
        byte_store = values.get("byte_store")
        docstore = values.get("docstore")
        if byte_store is not None:
            docstore = create_kv_docstore(byte_store)
        elif docstore is None:
            raise Exception("You must pass a `byte_store` parameter.")
        values["docstore"] = docstore
        return values

    @root_validator()
    def validate_search_type(cls, values: Dict) -> Dict:
        """Validate search type."""
        search_type = values["search_type"]
        if search_type not in cls.allowed_search_types:
            raise ValueError(
                f"search_type of {search_type} not allowed. Valid values are: "
                f"{cls.allowed_search_types}"
            )
        if search_type == "similarity_score_threshold":
            score_threshold = values["search_kwargs"].get("score_threshold")
            if (score_threshold is None) or (not isinstance(score_threshold, float)):
                raise ValueError(
                    "`score_threshold` is not specified with a float value(0~1)"
                    "in `search_kwargs`."
                )
        return values

    def _get_parent_docs(self, documents:List[Document], with_score=False) -> List[Document]:
        """
        For a query fetch chunks from vector DB. If the matching documents have parent chunks,
        fetch the parent chunks and return the combination of parent & original chunks
        (excluding any original chunks for which parent chunks are available))
        """
        scores = {}
        for document in documents:
            doc, score = document if with_score else (document , 0)
            
            if self.parent_doc_id_key in doc.metadata:
                parent_doc_id = doc.metadata[self.parent_doc_id_key]
                scores[parent_doc_id] = max(scores.get(parent_doc_id, 0), score)
                
        parent_ids = list(set(scores.keys()))
        parent_docs_with_score = []
        final_docs = documents

        if len(parent_ids):
            # Retrieve the parent documents using mget if any IDs are available
            parent_docs = self.docstore.mget(parent_ids) if parent_ids else []

            parent_docs_with_score = list(zip(parent_docs, scores.values()))

            # Ensure all retrieved documents from mget are valid (not None)
            parent_docs_with_score = [(doc, score) for doc, score in parent_docs_with_score if isinstance(doc, Document)]

        # Combine enhanced docs with original docs, excluding any original docs that have been enhanced
        if len(parent_docs_with_score):
            logger.info("Found parents documents")
            final_docs = parent_docs_with_score
            normal_docs = [
                (document, score)
                for document, score in documents
                if self.parent_doc_id_key not in document.metadata
                or document.metadata[self.parent_doc_id_key] not in parent_ids
            ]
            final_docs.extend(normal_docs)
        else:
            logger.info("No parents documents found")

        final_docs = self._condition_check_docs_token(final_docs)

        return final_docs

    def _get_relevant_documents(
        self, query: str, *, run_manager: Optional[CallbackManagerForRetrieverRun | None]
    ) -> List[Document]:
        """
        GET docs
        """
        if self.search_type == "similarity":
            docs = self.vectorstore.similarity_search(
                query, **self.search_kwargs
            )

            if not docs:
                return []
            
            final_docs = self._get_parent_docs(docs)

        elif self.search_type == "similarity_score_threshold":
            docs = (
                self.vectorstore.similarity_search_with_relevance_scores(
                    query, **self.search_kwargs
                )
            )
            
            if not docs:
                return []

            final_docs = self._get_parent_docs(docs, True)

        elif self.search_type == "mmr":
            docs = self.vectorstore.max_marginal_relevance_search(
                query, **self.search_kwargs
            )

            if not docs:
                return []

            final_docs = self._get_parent_docs(docs)

        else:
            raise ValueError(f"search_type of {self.search_type} not allowed.")

        return final_docs
