import timeit
from typing import List
from fastapi import APIRouter, HTTPException
from opensearchpy import ImproperlyConfigured, OpenSearch, OpenSearchException
from langchain.docstore.document import Document
from langchain.chains.summarize import load_summarize_chain
from app.langchain.v1.models import SummarizeRequest, SummarizeStatusResponse, Status
from app.langchain.v1.helper import (
    get_client_info,
    fetch_actual_md5,
    get_vector_db_details,
    fetch_actual_doc,
    fetch_actual_meta_latest,
)
from app.langchain.models import ClientMapping, DocumentSummary
from app.langchain.v1.utils.ias_openai_langchain import (
    IASOpenaiConversationalLLM,
    IASBedrockLLM,
)
from app.utils.custom_loguru import logger

router = APIRouter()


class SummarizeDocument:
    def __init__(self, client_id, request_payload: SummarizeRequest, db):
        self.client_id = client_id
        self.request_payload = request_payload
        self.db = db
        self.client_id_list = self._return_allowed_client_ids()

    def _return_allowed_client_ids(self):
        client_info = get_client_info(self.db, self.client_id)
        if client_info.usecase.lower() == "vox":
            client_id_list = client_info.alternate_client_ids
        else:
            client_id_list = [self.client_id]
        return client_id_list

    def get_indices_and_md5(self):
        logger.info("Fetching vectorDB details from database")
        client_info = get_client_info(self.db, self.client_id)
        client_id_list = client_info.alternate_client_ids

        if client_info is None:
            raise HTTPException(
                status_code=400,
                detail=f"Provided Client id {self.client_id} does not exist in mapping table, please provide the correct client_id to use search API",
            )

        try:
            if self.request_payload.index_document_map and len(
                self.request_payload.index_document_map
            ):
                logger.info("Assigning index for VOX use-case")
                index_look_up = self.request_payload.index_document_map
                md5_list = [
                    value for values in index_look_up.values() for value in values
                ]
                indices = list(index_look_up.keys())
                doc_md5_list = fetch_actual_md5(
                    client_id_list=self.client_id_list,
                    md5_list=md5_list,
                    indices=indices,
                    db=self.db,
                )

                if doc_md5_list is None:
                    raise HTTPException(
                        status_code=400,
                        detail="Provided Document MD5 does not exist in clientid Index mapping table. Please look into the request and make sure you are passing the correct MD5 of doc to include. Try with existing MD5",
                    )

                final_index_dict = {
                    index_name: [md5 for md5 in md5_list_lookup if md5 in doc_md5_list]
                    for index_name, md5_list_lookup in index_look_up.items()
                }

            else:
                logger.info(
                    f"Assigning index for Non-VOX use-case: {client_info.index}"
                )
                non_vox_index = client_info.index
                client_id_list = [self.client_id]

                cus_meta = self.request_payload.metadata
                generic_index = non_vox_index
                generic_indices = [generic_index]
                # always be post filter
                file_to_include = []

                if cus_meta.document:
                    val_to_fetch = cus_meta.document
                    act_doc = fetch_actual_doc(
                        client_id=self.client_id, grabber=val_to_fetch, db=self.db
                    )

                    if act_doc != None:
                        file_to_include.extend(act_doc)

                if cus_meta.documentmd5:
                    md5_list = cus_meta.documentmd5
                    act_doc_md5 = fetch_actual_md5(
                        client_id_list=self.client_id_list,
                        md5_list=md5_list,
                        indices=generic_indices,
                        db=self.db,
                    )

                    if act_doc_md5 != None:
                        file_to_include.extend(act_doc_md5)

                if cus_meta.metadata:
                    val_to_fetch = cus_meta.metadata

                    # Create a subquery to find the maximum timestamp for each unique metadata value
                    meta_list_street = fetch_actual_meta_latest(
                        client_id=self.client_id, grabber=val_to_fetch, db=self.db
                    )

                    if meta_list_street != None:
                        file_to_include.extend(meta_list_street)

                if len(file_to_include) == 0:
                    raise HTTPException(
                        status_code=400,
                        detail="Provided Document MD5 does not exist in clientid Index mapping table. Please look into the request and make sure you are passing the correct MD5 of doc to include. Try with existing MD5",
                    )

                final_index_dict = {generic_index: list(set(file_to_include))}

            return final_index_dict

        except Exception as e:
            raise e

    def assign_index_and_md5(self, final_index_md5_dict):
        self.index_name = list(final_index_md5_dict.keys())[0]
        self.md5 = list(final_index_md5_dict.values())[0][0]

    def get_summarization_info(self):
        try:
            summarization_info = (
                self.db.query(DocumentSummary)
                .filter(
                    DocumentSummary.client_id.in_(self.client_id_list),
                    DocumentSummary.index == self.index_name,
                    DocumentSummary.document_md5 == self.md5,
                    DocumentSummary.engine == self.request_payload.llm_engine,
                    DocumentSummary.temperature == self.request_payload.temperature,
                )
                .first()
            )

            return summarization_info

        except Exception:
            raise HTTPException(
                status_code=500,
                detail="Error in getting data from database",
            )

    def is_summary_exists(self):
        try:
            summarization_info = self.get_summarization_info()
            response_dict = {}

            if summarization_info:
                response_dict = {
                    "is_summary_info_present": True,
                    "request_id": summarization_info.request_id,
                    "request_status": summarization_info.status,
                    "summary": summarization_info.summary,
                    "total_tokens_llm": 0,
                }
            else:
                response_dict = {"is_summary_info_present": False}

            return response_dict

        except Exception as e:
            raise e

    def add_summarize_request_to_db(self, request_id):
        try:
            data_to_insert = DocumentSummary(
                request_id=request_id,
                client_id=self.client_id,
                index=self.index_name,
                document_md5=self.md5,
                engine=self.request_payload.llm_engine,
                temperature=self.request_payload.temperature,
                summary="",
                total_tokens_llm=0,
                status="InProgress",
                error_message="",
            )
            self.db.add(data_to_insert)
            self.db.commit()

        except Exception as e:
            logger.error(str(e))
            raise HTTPException(
                status_code=500, detail="Error while inserting summarize request to db"
            )

    async def get_open_search_client_instance(self):
        logger.info("Reading secret manager details")
        (
            AWS_OPENSEARCH_HOST,
            AWS_OPENSEARCH_USERNAME,
            AWS_OPENSEARCH_PASSWORD,
        ) = await get_vector_db_details(self.client_id, self.db)

        logger.info("Creating OS client")
        try:
            opensearch_client = OpenSearch(
                hosts=[AWS_OPENSEARCH_HOST],
                http_auth=(AWS_OPENSEARCH_USERNAME, AWS_OPENSEARCH_PASSWORD),
            )
            return opensearch_client

        except ImproperlyConfigured as e:
            columns_to_update = {
                "status": "Error",
                "error_message": f"Error while creating opensearch client - The config passed to the client is inconsistent or invalid : {str(e)}",
            }
            self.update_db(columns_to_update)

            logger.error("The config passed to the client is inconsistent or invalid")
            logger.error(str(e))
            raise e

        except OpenSearchException as e:
            columns_to_update = {
                "status": "Error",
                "error_message": f"Error while creating opensearch client : {str(e)}",
            }
            self.update_db(columns_to_update)

            logger.error("Couldn't create opensearch client")
            logger.error(str(e))
            raise e

    async def summarize(self):
        try:
            opensearch_client = await self.get_open_search_client_instance()

            texts = self.get_text_from_opensearch_db(opensearch_client)

            doc_texts = [Document(page_content=text) for text in texts]

            summary = self.get_llm_summary(doc_texts)
            total_tokens_llm = len(summary.split())

            columns_to_update = {
                "status": "Completed",
                "error_message": "",
                "summary": summary,
                "total_tokens_llm": total_tokens_llm,
            }

            self.update_db(columns_to_update)

        except Exception as e:
            raise e

    def get_text_from_opensearch_db(self, opensearch_client):
        try:
            query = {
                "query": {
                    "bool": {
                        "filter": {
                            "bool": {
                                "must": [{"match_phrase": {"metadata.md5": self.md5}}]
                            }
                        }
                    }
                }
            }

            start = timeit.default_timer()

            size = opensearch_client.count(body=query, index=self.index_name)["count"]
            response = opensearch_client.search(
                body=query, index=self.index_name, size=size
            )

            logger.info(
                f"Time taken for fetching text from opensearch db: {timeit.default_timer()-start}"
            )

            texts = []
            for hit in response["hits"]["hits"]:
                texts.append(hit["_source"]["text"])

            return texts

        except Exception as e:
            columns_to_update = {
                "status": "Error",
                "error_message": f"Error while fetching text from opensearch db: {str(e)}",
            }

            self.update_db(columns_to_update)
            logger.error(str(e))
            raise HTTPException(
                status_code=500, detail="Error while fetching text from opensearch db"
            )

    def get_llm_summary(self, doc_texts):
        try:
            llm_config = {
                "engine"
                if self.request_payload.llm_engine.startswith("gpt")
                else "model": self.request_payload.llm_engine,
                "temperature": self.request_payload.temperature,
                "max_tokens": self.request_payload.max_tokens
                - self.request_payload.min_response_token,
            }
            llm_object = (
                IASOpenaiConversationalLLM
                if self.request_payload.llm_engine.startswith("gpt")
                else IASBedrockLLM
            )

            # map_prompt = """
            # Write a concise summary of the following:
            # "{text}"
            # CONCISE SUMMARY:
            # """
            # map_prompt_template = PromptTemplate(template=map_prompt, input_variables=["text"])

            # combine_prompt = """
            # Write a concise summary of the following text with {number_of_words} words.
            # ```{text}```
            # """
            # combine_prompt_template = PromptTemplate(template=combine_prompt, input_variables=["text"], partial_variables={'number_of_words': 500})

            summary_chain = load_summarize_chain(
                llm=llm_object(**llm_config),
                chain_type="map_reduce",
                #  map_prompt=map_prompt_template,
                #  combine_prompt=combine_prompt_template,
            )

            summary = summary_chain.run(doc_texts)
            return summary

        except Exception as e:
            columns_to_update = {
                "status": "Error",
                "error_message": f"Failed while getting llm summary: {str(e)}",
            }
            self.update_db(columns_to_update)

            logger.error(str(e))
            raise HTTPException(
                status_code=500, detail="Failed while getting llm summary"
            )

    def update_db(self, columns_to_update_dict):
        try:
            summarization_info = self.get_summarization_info()

            if summarization_info:
                self.db.query(DocumentSummary).filter(
                    DocumentSummary.client_id.in_(self.client_id_list),
                    DocumentSummary.index == self.index_name,
                    DocumentSummary.document_md5 == self.md5,
                    DocumentSummary.engine == self.request_payload.llm_engine,
                    DocumentSummary.temperature == self.request_payload.temperature,
                ).update(columns_to_update_dict)
                self.db.commit()

            else:
                raise HTTPException(
                    status_code=404,
                    detail=f"Given Index {self.index_name} and md5 {self.md5} with other given details not found in database",
                )

        except Exception as e:
            raise e


class SummarizeStatus:
    @staticmethod
    def get_status(client_id_list: List, request_ids: List, db):
        try:
            summarization_info = (
                db.query(DocumentSummary)
                .filter(
                    DocumentSummary.client_id.in_(client_id_list),
                    DocumentSummary.request_id.in_(request_ids),
                )
                .all()
            )

            summary_status = []

            if len(summarization_info):
                for row in summarization_info:
                    summary_status.append(
                        SummarizeStatusResponse(
                            status=Status.success,
                            request_status=row.status,
                            error_message=row.error_message,
                            client_id=row.client_id,
                            request_id=row.request_id,
                            index=row.index,
                            document_md5=row.document_md5,
                            engine=row.engine,
                            temperature=row.temperature,
                            summary=row.summary,
                            total_tokens_llm=row.total_tokens_llm,
                        )
                    )

                return summary_status

            else:
                raise HTTPException(
                    status_code=404,
                    detail=f"Given request_ids {request_ids} not found in database",
                )

        except Exception as e:
            raise e
