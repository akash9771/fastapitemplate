from io import BytesIO
import io
from fastapi import HTTPException
from loguru import logger
import boto3
import pandas as pd

from app.utils.config_vars import (
    AGENT_CITATION_FILTER_KEYWORDS,
    AGENT_FAILED_RESPONSE,
    AGENT_STOPPED_MAX_ITERATIONS,
)
from app.langchain.v1.helper import (
    filter_docs,
    calculate_approx_tokens,
)
from app.langchain.v1.utils.ias_openai_langchain import IAS_ChatModel
from langchain_experimental.agents.agent_toolkits import create_pandas_dataframe_agent
from app.langchain.v1.models import QueryEmbeddingsRequest


async def invoke_tabular_agent(
    client_id,
    x_vsl_client_id,
    bearer_token,
    document_names: any,
    all_files_are_tabular,
    rw: QueryEmbeddingsRequest,
):
    """Function to call the dataframe agent to generate answers for tabular data."""
    try:
        logger.info("invoke_tabular_agent started")

        # Get only tabular docs.
        document_names = filter_docs(document_names, is_tabular=True)

        # Extracting file names for citation
        file_names = [file[0] for file in document_names]

        # Extracting file paths from input
        parquet_s3_file_paths = [x[1] for x in document_names]

        logger.info(f"S3 parquet path: {parquet_s3_file_paths}")

        # Fetch parquet files from S3.
        sheet_names = []
        dataframe_list = []
        dataframe_names = []
        index = 0
        s3_client = boto3.client("s3", "us-east-1")
        try:
            with io.BytesIO() as parquet_buffer:
                try:
                    for s3_file_path in parquet_s3_file_paths:
                        for s3_uri in s3_file_path.split(","):
                            split_uri = s3_uri.split("/")
                            bucket_name = split_uri[2]
                            key = "/".join(split_uri[3:])
                            sheet_name = split_uri[-1]

                            obj = s3_client.get_object(Bucket=bucket_name, Key=key)
                            parquet_buffer = BytesIO(obj["Body"].read())
                            dataframe_list.append(pd.read_parquet(parquet_buffer))
                            dataframe_names.append(f"df{index+1}")
                            sheet_names.append(sheet_name.replace(".parquet", ""))
                            index = index + 1
                except Exception as e:
                    raise e
                finally:
                    parquet_buffer.close()
        except Exception as e:
            logger.error(
                f"Error while loading the parquet from S3 and converting parquet file to dataframe. {repr(e)}"
            )
            raise HTTPException(
                status_code=500, detail="Error while loading loading tabular files."
            )

        agent_prefix_prompt = f"""
    Background:
    You are proficient data analyst who is well versed with Excel, Python, Pandas and has thorough command to handle tabular data.
    You also understand statistics and are familiar with general business insight requirements.
    You will be provided with all of the excel sheet names and list of referenced dataframe names.

    Instructions:
    Users will provide you a query which you will need to answer based on the context and tools available to you. 
    User queries may require you to refer to multiple columns which could require you to perform operations such as "group by column" or other complex operations.
    Queries may be a general query or a specific statistical query which will need to be solved for.
    User queries may require you to make assumptions based on the question. Queries may refer to information that may not be explicitly identifiable within the column headers and will require you to make assumptions.
    Your task is to reply to the user query after performing above analysis enough if the user query contains complex analytical questions which require complex coding. You might need to refer to multiple sheets i.e. multiple dataframes to retrieve the answer.
    If the question is not relevant to the data provided, do not provide any answers. Just say I don't know the answer.
    DO NOT RESPOND OR SEARCH THE ANSWER ONLY IN ONE SHEET.
    DO NOT RESPOND WITH Pandas code as response to user message. DO NOT MENTION WORDS LIKE DATAFRAMES IN THE FINAL ANSWER.
    DO NOT MAKE UP YOUR ANSWER. IF THE RELEVANT ANSWER CANNOT BE FIND, JUST SAY I DON'T KNOW. DON'T FIND ANY GENERIC ANSWERS FOR THOSE QUESTIONS.

    Assumptions:
    You already have the data loaded from excel/csv files into dataframes.
    These are the available sheets and dataframes to work with presented in list format: 
    Sheet names:{sheet_names}
    dataframe names:{dataframe_names}

    {"System Instructions:" + rw.system_message if rw.system_message else ""}
    """

        # Since agent is allowed only for openAI models currently, overriding the engine and the max-token
        # TODO: Remove this logic once agent calling is enabled for Bedrock models.
        if not rw.llm_engine.startswith("gpt"):
            logger.warning(
                f"Model/Engine selected for agent by user {rw.llm_engine} cannot be used."
            )
            rw.llm_engine = "gpt-4-32k"
            logger.warning(f"Hence, Model/Engine used will be: {rw.llm_engine}")
            rw.max_tokens = 12000

        llm_config = {
            "engine": rw.llm_engine,
            "temperature": rw.temperature,
            "max_tokens": rw.max_tokens,
            "system_message": rw.system_message,
            "client_id": client_id,
            "x_vsl_client_id": x_vsl_client_id,
            "bearer_token": bearer_token,
            "user_query": rw.user_query,
            "min_response_token": rw.min_response_token,
            "context": rw.context,
        }

        # Create ChatModel.
        llm = IAS_ChatModel(**llm_config)
        logger.info("Creating pandas dataframe agent")
        agent = create_pandas_dataframe_agent(
            llm,
            dataframe_list,
            verbose=True,
            agent_type="openai-tools",
            include_df_in_prompt=True,
            number_of_head_rows=2,
            max_iterations=10,
            max_execution_time=60,  # seconds
            prefix=agent_prefix_prompt,
            agent_executor_kwargs={"handle_parsing_errors": True},
        )

        # Invoke agent with user query.
        agent_answer = await agent.ainvoke(rw.user_query)

        # To check if the documentation provided and user query match. Based on that, citations are generated.
        PRESENT = False
        if agent_answer:
            agent_answer = agent_answer["output"]
            for string in AGENT_CITATION_FILTER_KEYWORDS:
                if string in agent_answer:
                    PRESENT = True
                    break

            if PRESENT:
                citation_basic = []
                if all_files_are_tabular:
                    if AGENT_STOPPED_MAX_ITERATIONS in agent_answer:
                        agent_answer = AGENT_FAILED_RESPONSE
                else:
                    agent_answer = ""
            else:
                file_names_string = ", ".join(file_names)
                citation_basic = [
                    {
                        "page_content": f"Answer is retrieved from {file_names_string}",
                        "metadata": {"filename": file_names_string},
                    }
                ]

            total_token = []
            tokens_consumed_by_llm = calculate_approx_tokens(
                [agent_answer, llm_config["user_query"], llm_config["system_message"]]
            )
            total_token.append(tokens_consumed_by_llm)
            total_token.append(0)
            llm_answer = agent_answer
            return (llm_answer, citation_basic, total_token)
        else:
            return ("", [], [0, 0])
    except Exception as e:
        raise e
    finally:
        # Dispose of the DataFrame
        if "dataframe_list" in locals():
            del dataframe_list
