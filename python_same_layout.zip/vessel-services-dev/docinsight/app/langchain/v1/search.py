import asyncio
import pathlib
from fastapi import HTTPException
from loguru import logger

from app.langchain.v1.retrieval_qa import invoke_retrieval_qa
from app.langchain.v1.tabular_agent import invoke_tabular_agent
from app.langchain.v1.models import QueryEmbeddingsRequest
from app.langchain.v1.utils.ias_openai_langchain import (
    ias_openai_chat_completion,
)
from app.langchain.v1.helper import (
    fetch_actual_doc,
    fetch_actual_md5,
    fetch_actual_meta_latest,
    fetch_all_docs_for_client_id,
    fetch_file_name,
    filter_non_tabular_files,
)
from app.utils.config_vars import (
    TABULAR_EXTENSIONS,
    RETRIEVAL_QA_CITATION_FILTER_KEYWORDS,
    RETRIEVAL_QA_RESPONSE,
)
from operator import add


async def invoke_search(
    db, client_id, x_vsl_client_id, bearer_auth, client_info, rw: QueryEmbeddingsRequest
):
    logger.info("Search started.")

    index_name = client_info.index

    # Get index-md5 dict and document names to search.
    if client_info.usecase.lower() == "vox":
        (final_index_dict, document_names) = get_vox_docs(db, rw, client_info)
    else:
        (final_index_dict, document_names) = get_non_vox_docs(db, rw, client_info)

    all_files_are_tabular = all(
        pathlib.Path(files[0]).suffix in TABULAR_EXTENSIONS and files[1] != None
        for files in document_names
    )
    all_files_are_non_tabular = all(
        pathlib.Path(files[0]).suffix not in TABULAR_EXTENSIONS
        for files in document_names
    )

    if all_files_are_tabular:
        logger.info("All files are tabular.")

        # Agent calling.
        (llm_answer, citation_basic, total_token) = await invoke_tabular_agent(
            client_id,
            x_vsl_client_id,
            bearer_auth,
            document_names,
            all_files_are_tabular,
            rw,
        )

    elif all_files_are_non_tabular:
        logger.info("All files are non-tabular.")

        # Retrieval QA.
        (llm_answer, citation_basic, total_token) = await invoke_retrieval_qa(
            db,
            client_id,
            x_vsl_client_id,
            bearer_auth,
            final_index_dict,
            document_names,
            rw,
            index_name,
        )
    else:
        logger.info("The documents selected are of multiple extensions.")

        # Step 1: Removing tabular md5s from final_index_dict to pass it to retrieval QA
        final_index_dict = filter_non_tabular_files(final_index_dict, document_names)

        # Step 2: Create tasks.
        invoke_agent_task = asyncio.ensure_future(
            invoke_tabular_agent(
                client_id,
                x_vsl_client_id,
                bearer_auth,
                document_names,
                all_files_are_tabular,
                rw,
            )
        )
        invoke_retrieval_qa_task = asyncio.ensure_future(
            invoke_retrieval_qa(
                db,
                client_id,
                x_vsl_client_id,
                bearer_auth,
                final_index_dict,
                document_names,
                rw,
                index_name,
            )
        )
        tasks = [invoke_agent_task, invoke_retrieval_qa_task]

        # Step 3: Invoke all the tasks.
        done, pending = await asyncio.wait(tasks, return_when=asyncio.ALL_COMPLETED)

        # Step 4: Error handling: if both task fails, raise exception, else continue generating response
        failed_tasks = [task for task in done if task.exception() is not None]

        if len(failed_tasks) == len(tasks):
            # All tasks failed, return as failure.
            raise Exception("invoke_search completed with errors. All tasks failed.")

        else:
            # Aggregate result.
            (llm_answer, citation_basic, total_token) = ("", [], [0, 0])
            llm_method_response_dict = {}
            actual_citation_dict = {}
            for task in done:
                try:
                    # Check the result.
                    (llmtask_answer, actual_citation_basic, task_token) = task.result()
                    active_task = task._coro.__name__
                    active_task_short_name = " ".join(active_task.split("_")[1:])

                    logger.info(f"Task {active_task} finished successfully.")
                    llm_method_response_dict[active_task_short_name] = llmtask_answer
                    actual_citation_dict[active_task_short_name] = actual_citation_basic
                    total_token = list(map(add, total_token, task_token))

                except Exception as e:
                    logger.error(
                        f"Task {task._coro.__name__} failed with exception {repr(e)}."
                    )

            # If retrieval qa response is available, check for citation keywords. If found, return empty qa response.
            if "retrieval qa" in llm_method_response_dict:
                if llm_method_response_dict["retrieval qa"]:
                    original_retrievalqa_response = llm_method_response_dict[
                        "retrieval qa"
                    ]
                    for words in RETRIEVAL_QA_CITATION_FILTER_KEYWORDS:
                        if words in original_retrievalqa_response:
                            llm_method_response_dict["retrieval qa"] = ""

            # Cond 1: If qa and agent responses available, both responses will be passed through another LLM to decide which response is accurate.
            if (
                "retrieval qa" in llm_method_response_dict
                and "tabular agent" in llm_method_response_dict
            ) and (
                llm_method_response_dict["retrieval qa"]
                and llm_method_response_dict["tabular agent"]
            ):

                logger.info("Agent and RetrievalQA answers are available.")
                # Concat both responses
                answer_list = [
                    llm_method_response_dict["retrieval qa"],
                    llm_method_response_dict["tabular agent"],
                ]

                # Passing both the responses to LLM for the decision making.
                llm_answer, citation_key = finalize_answer(
                    client_id,
                    x_vsl_client_id,
                    bearer_auth,
                    rw.user_query,
                    answer_list,
                    llm_method_response_dict,
                )

                # Deciding the citation.
                if len(citation_key) == 1:
                    citation_basic = actual_citation_dict[citation_key[0]]
                else:
                    citation_basic = (
                        actual_citation_dict[citation_key[0]]
                        + actual_citation_dict[citation_key[1]]
                    )

            # Cond 2: If only qa response available and agent response either empty or key not present in the dict
            elif (
                "retrieval qa" in llm_method_response_dict
                and llm_method_response_dict["retrieval qa"]
            ):
                if (
                    "tabular agent" not in llm_method_response_dict
                    or llm_method_response_dict["tabular agent"] == ""
                ):
                    logger.info("RetrievalQA answer available.")
                    llm_answer = llm_method_response_dict["retrieval qa"]
                    citation_basic = actual_citation_dict["retrieval qa"]

            # Cond 3: If only agent response available and qa response either empty or key not present in the dict
            elif (
                "tabular agent" in llm_method_response_dict
                and llm_method_response_dict["tabular agent"]
            ):
                if (
                    "retrieval qa" not in llm_method_response_dict
                    or llm_method_response_dict["retrieval qa"] == ""
                ):
                    logger.info("Agent answer available.")
                    llm_answer = llm_method_response_dict["tabular agent"]
                    citation_basic = actual_citation_dict["tabular agent"]

            else:
                logger.error("QA and Agent responses are empty.")
                llm_answer = RETRIEVAL_QA_RESPONSE
                citation_basic = []

    return (llm_answer, citation_basic, total_token)


def finalize_answer(
    client_id,
    x_vsl_client_id,
    bearer_auth,
    question,
    answers: list[tuple],
    llm_method_response_dict,
) -> str:
    logger.info(
        "Answer retrieved from both agent and retrieval qa. Finalizing the answer."
    )
    system_message = """You are expert decision maker. 
    You are given with user's question and two answers generated. 
    Read through both the answers and make a decision.
    If both the answers are correct then combine the answers and respond.
    IF ANY ONE ANSWER IS CORRECT, THEN JUST respond with that answer.
    REMOVE answer prefix from the answer"""

    user_message = f"""Question: {question}

    Answer:
    {answers[0]} 
    
    Answer:
    {answers[1]}
    """

    response = ias_openai_chat_completion(
        user_message=user_message,
        engine="gpt-35-turbo-16k",
        temperature=0.1,
        max_tokens=5000,
        system_message=system_message,
        client_id=client_id,
        x_vsl_client_id=x_vsl_client_id,
        bearer_token=bearer_auth,
    )

    logger.info(f"Finalized answer: {response}")

    for key, val in llm_method_response_dict.items():
        if val == response:
            citation_key = [key]
            break
        else:
            citation_key = ["retrieval qa", "tabular agent"]

    return response, citation_key


def get_vox_docs(db, rw, client_info):
    logger.info("Assigning index for VOX use-case")
    client_id_list = client_info.alternate_client_ids
    index_look_up = rw.index_document_map
    md5_list = [value for values in index_look_up.values() for value in values]
    indices = list(index_look_up.keys())

    # Fetching the index and md5 inserted by user from dataingestionstatustablenew table
    doc_md5_list = fetch_actual_md5(
        client_id_list=client_id_list,
        md5_list=md5_list,
        indices=indices,
        db=db,
    )

    if doc_md5_list is None:
        raise HTTPException(
            status_code=400,
            detail="Provided Document MD5 does not exist in clientid Index mapping table. Please look into the request and make sure you are passing the correct MD5 of doc to include. Try with existing MD5",
        )

    # {index:[md51, md52]}
    final_index_dict = {
        index_name: [md5 for md5 in md5_list_lookup if md5 in doc_md5_list]
        for index_name, md5_list_lookup in index_look_up.items()
    }

    # fetching file names from the dataingestionstatustablenew table
    document_names = fetch_file_name(
        client_id_list=client_id_list,
        md5_list=doc_md5_list,
        indices=indices,
        db=db,
    )

    return (final_index_dict, document_names)


def get_non_vox_docs(db, rw, client_info):
    logger.info(f"Assigning index for Non-VOX use-case: {client_info.index}")
    client_id = client_info.client_id
    cus_meta = rw.metadata
    generic_index = client_info.index
    generic_indices = [generic_index]
    file_to_include = []
    client_id_list = [client_id]

    if cus_meta and (
        cus_meta.document
        or cus_meta.documentmd5
        or cus_meta.metadata
        or cus_meta.multi_metadata
    ):
        if cus_meta.document:
            val_to_fetch = cus_meta.document
            act_doc = fetch_actual_doc(client_id=client_id, grabber=val_to_fetch, db=db)

            if act_doc != None:
                file_to_include.extend(act_doc)

        if cus_meta.documentmd5:
            md5_list = cus_meta.documentmd5
            act_doc_md5 = fetch_actual_md5(
                client_id_list=client_id_list,
                md5_list=md5_list,
                indices=generic_indices,
                db=db,
            )

            if act_doc_md5 != None:
                file_to_include.extend(act_doc_md5)

        if cus_meta.metadata or cus_meta.multi_metadata:
            # Create a subquery to find the maximum timestamp for each unique metadata value
            meta_list_street = fetch_actual_meta_latest(
                client_id=client_id,
                grabber=cus_meta.metadata,
                db=db,
                multi_metadata=cus_meta.multi_metadata,
                metadata_filter_condition=rw.metadata_filter_condition,
            )
            if meta_list_street != None:
                file_to_include.extend(meta_list_street)

    else:
        logger.info(
            f"User did not pass any values for metadata(doc name/md5/metadata/multi_metadata). Include all files for search"
        )
        all_doc_md5 = fetch_all_docs_for_client_id(
            client_id=client_id,
            db=db,
        )

        if all_doc_md5 != None:
            file_to_include.extend(all_doc_md5)

    if len(file_to_include):
        final_index_dict = {generic_index: list(set(file_to_include))}

        doc_md5_list = file_to_include
        indices = list(final_index_dict.keys())

        # Fetching file names from the dataingestionstatustablenew table
        document_names = fetch_file_name(
            client_id_list=client_id_list,
            md5_list=doc_md5_list,
            indices=indices,
            db=db,
        )
        return (final_index_dict, document_names)
    else:
        raise HTTPException(
            status_code=400,
            detail=f"No matching docs found to search",
        )
