import copy
from typing import (
    Any,
    Dict,
    List,
    Mapping,
    Optional,
    Union,
)
from langchain.llms.base import LLM
import json
import os
import backoff
from fastapi import HTTPException
import httpx
from langchain.embeddings.base import Embeddings
import requests
from langchain_community.vectorstores import OpenSearchVectorSearch
from app.utils.custom_loguru import logger
from app.utils.custom_httpx import CustomHttpX
from app.utils.config_cache import cache_get, cache_set
from langchain_core.retrievers import BaseRetriever
from langchain_core.callbacks import AsyncCallbackManagerForLLMRun
from langchain_core.documents.base import Document
from langchain.chains.question_answering import load_qa_chain
from langchain.chains import StuffDocumentsChain, LLMChain
from langchain.chains.conversational_retrieval.base import (
    BaseConversationalRetrievalChain
)
from langchain_core.callbacks import (
    AsyncCallbackManagerForChainRun,
    CallbackManagerForChainRun,
    Callbacks,
)
from langchain_core.language_models import BaseLanguageModel
from langchain_core.prompts import BasePromptTemplate, PromptTemplate
from langchain.chains.conversational_retrieval.prompts import CONDENSE_QUESTION_PROMPT
import openai
from langchain_core.callbacks import CallbackManagerForLLMRun
from langchain_core.language_models import BaseChatModel
from langchain_core.outputs import ChatGeneration, ChatResult
from langchain_core.tools import BaseTool
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    ChatMessage,
    FunctionMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from app.utils.misc import is_anthropic_model, calculate_max_tokens

httpx_client = CustomHttpX(raise_for_status=False)

CLIENT_ID = os.environ.get("CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET", "")
PINGFEDERATE_URL = os.environ.get("PINGFEDERATE_URL", "")
IAS_OPENAI_CHAT_URL = os.environ.get("IAS_OPENAI_CHAT_URL", "")
IAS_OPENAI_URL = os.environ.get("IAS_OPENAI_URL", "")
IAS_EMBEDDINGS_URL = os.environ.get("IAS_EMBEDDINGS_URL", "")
IAS_BEDROCK_URL = os.getenv("IAS_BEDROCK_URL")


# To Raise Generic OPENAI EMBEDDING ERROR
class GenericException(Exception):
    def __init__(self, message, status_code: int = None):
        super().__init__(message)
        self.status_code = (
            status_code
            if status_code
            else message.status_code if isinstance(message, GenericException) else ""
        )


def is_http_4xx_error(exception):
    return isinstance(exception, GenericException) and exception.status_code in [
        400,
        401,
        403,
        404,
        405,
        422,
    ]


async def afederate_auth() -> str:
    """Obtains auth access token for accessing GPT endpoints"""
    try:
        # Check in cache.
        token = await cache_get(f"{CLIENT_ID}-token")
        if token is None:
            payload = f"client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}"
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
            }
            response = await httpx_client.request(
                "post", PINGFEDERATE_URL, data=payload, headers=headers
            )
            if response.status_code != 200:
                logger.error(
                    f"Error calling OpenAI access token API: {response.status_code}, {response.json()}"
                )
                raise Exception(
                    f"Error calling OpenAI access token API: {response.status_code}, {response.json()}"
                )

            token = response.json()["access_token"]

            # Cache the token.
            await cache_set(f"{CLIENT_ID}-token", token)
        return token
    except httpx.TimeoutException as e:
        logger.error(f"Federate Auth Timeout {e}")
        raise HTTPException(status_code=408, detail=f"Error: Federate Auth Timeout")
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        raise e


# This is a temporary function to support synchronous.
# TODO: The proper solution is to use asynchronous
# asynchronous in the OpenSearch vector store implementations which is not available currently.
def federate_auth() -> str:
    """Obtains auth access token for accessing GPT endpoints"""
    try:
        payload = f"client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
        }
        response = requests.post(PINGFEDERATE_URL, headers=headers, data=payload)
        if response.status_code != 200:
            logger.error(
                f"Error calling OpenAI access token API: {response.status_code}, {response.json()}"
            )
            raise Exception(
                f"Error calling OpenAI access token API: {response.status_code}, {response.json()}"
            )

        token = response.json()["access_token"]
        return token
    except httpx.TimeoutException as e:
        logger.error(f"Federate Auth Timeout {e}")
        raise HTTPException(status_code=408, detail=f"Error: Federate Auth Timeout")
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        raise e


async def aget_auth_token(bearer_auth):
    # If the x-vsl-client_id is not provided in headers, then get the token from federate_auth
    if bearer_auth is None:
        token = await afederate_auth()
    else:
        token = (
            bearer_auth.split(" ")[1]
            if len(bearer_auth.split(" ")) > 1 and len(bearer_auth.split(" ")[1]) > 1
            else await afederate_auth()
        )
    return token


# This is a temporary function to support synchronous.
# TODO: The proper solution is to use asynchronous
# asynchronous in the OpenSearch vector store implementations which is not available currently.
def get_auth_token(bearer_auth):
    # If the x-vsl-client_id is not provided in headers, then get the token from federate_auth
    if bearer_auth is None:
        token = federate_auth()
    else:
        token = (
            bearer_auth.split(" ")[1]
            if len(bearer_auth.split(" ")) > 1 and len(bearer_auth.split(" ")[1]) > 1
            else federate_auth()
        )
    return token


@backoff.on_exception(
    backoff.expo, GenericException, max_tries=20, max_time=60, giveup=is_http_4xx_error
)
def ias_openai_chat_completion(
    user_message: str,
    engine: str,
    temperature: float,
    max_tokens: int,
    system_message: str = None,
    client_id: str = None,
    x_vsl_client_id: str = None,
    bearer_token: str = None,
) -> str:
    """
    Generates a chat completion response for OpenAI model
    :param token: auth token
    :param user_message: user's prompt
    :param engine: model capable for chat completion i.e. gpt*
    :param temperature: value 0-1 that tells model to be more precise or generative
    :param max_tokens: max tokens the prompt & response should be. It depends on the model's capacity
    :return: response from OpenAI model
    """
    try:
        payload = {
            "engine": engine,
            "messages": [
                {"role": "user", "content": user_message},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if system_message:
            payload["messages"].insert(0, {"role": "system", "content": system_message})

        token = get_auth_token(bearer_token)
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }
        if x_vsl_client_id is not None:
            headers["x-vsl-client_id"] = x_vsl_client_id
        elif client_id is not None:
            headers["x-vsl-client_id"] = client_id

        logger.info("Calling chat completion endpoint")
        response = requests.post(IAS_OPENAI_CHAT_URL, headers=headers, json=payload)

        if response.status_code != 200:
            logger.error(
                f"Error calling OpenAI chat completion  API: {response.status_code}, {response.json()}"
            )
            raise GenericException(
                f"Error calling OpenAI chat completion API: {response.status_code}, {response.json()}",
                status_code=response.status_code,
            )

        logger.info("Received response from llm")
        logger.info(response.json())
        chat_completion = json.loads(response.json()["result"])["content"]

        return chat_completion
    except Exception as e:
        logger.error("Got the Exception", str(e))
        # raising backoff exception
        raise GenericException(e)


@backoff.on_exception(
    backoff.expo, GenericException, max_tries=20, max_time=60, giveup=is_http_4xx_error
)
async def ias_openai_chat_completion_with_tools(
    engine: str,
    temperature: float,
    max_tokens: int,
    client_id: str = None,
    x_vsl_client_id: str = None,
    bearer_token: str = None,
    messages: List[BaseMessage] = None,
    tools: List[BaseTool] = None,
    tool_choice: str = None,
) -> str:
    """
    Generates a chat completion response for OpenAI model
    :param token: auth token
    :param user_message: user's prompt
    :param engine: model capable for chat completion i.e. gpt*
    :param temperature: value 0-1 that tells model to be more precise or generative
    :param max_tokens: max tokens the prompt & response should be. It depends on the model's capacity
    :return: response from OpenAI model
    """
    try:
        payload = {
            "engine": engine,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "tools": tools,
            "tool_choice": tool_choice,
        }

        token = await aget_auth_token(bearer_token)

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }
        if x_vsl_client_id is not None:
            headers["x-vsl-client_id"] = x_vsl_client_id
        elif client_id is not None:
            headers["x-vsl-client_id"] = client_id

        logger.info("Calling chat completion endpoint with tools")
        logger.info(payload)

        response = await httpx_client.request(
            "post", IAS_OPENAI_CHAT_URL, json=payload, headers=headers
        )

        logger.info("Received response from llm")
        logger.info(response.json())

        if response.status_code != 200:
            logger.error(
                f"Error calling OpenAI chat completion API: {response.status_code}, {response.json()}"
            )
            raise GenericException(
                f"Error calling OpenAI chat completion API: {response.status_code}, {response.json()}",
                status_code=response.status_code,
            )
        chat_completion = json.loads(response.json()["result"])
        return chat_completion
    except Exception as e:
        logger.error("Got the Exception", str(e))
        # raising backoff exception
        raise GenericException(e)


@backoff.on_exception(
    backoff.expo, GenericException, max_tries=20, max_time=60, giveup=is_http_4xx_error
)
def ias_openai_embeddings(
    raw_text,
    engine: str,
    client_id: str = None,
    x_vsl_client_id: str = None,
    bearer_token: str = None,
):
    try:
        url = IAS_EMBEDDINGS_URL
        payload = {"input": raw_text, "engine": engine}
        token = get_auth_token(bearer_token)
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {token}",
        }

        if x_vsl_client_id is not None:
            headers["x-vsl-client_id"] = x_vsl_client_id
        elif client_id is not None:
            headers["x-vsl-client_id"] = client_id

        logger.info("Triggering embedding endpoint")
        response = requests.post(url, headers=headers, json=payload)

        if response.status_code != 200:
            logger.error(
                f"Error calling OpenAI embedding API: {response.status_code}, {response.json()}"
            )
            raise GenericException(
                f"Error calling OpenAI embedding API: {response.status_code}, {response.json()}",
                status_code=response.status_code,
            )

        embeddings = json.loads(response.json()["result"])
        logger.info("Received response from embedding endpoint")

        return embeddings
    except Exception as e:
        logger.error("Got the Exception", str(e))
        # raising backoff exception
        raise GenericException(e)


class IASOpenaiConversationalLLM(LLM):
    """Wrapper for IAS secured OpenAI chat API"""

    engine: str
    temperature: float
    max_tokens: int
    system_message: str = None
    client_id: str = None
    x_vsl_client_id: str = None
    bearer_auth: str = None

    @property
    def _llm_type(self) -> str:
        return "IAS_OpenAI"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
    ) -> str:

        prompt_message = prompt

        if self.system_message:
            prompt_message = prompt_message + self.system_message

        token_consumed = self.get_num_tokens(prompt_message)
        response = ias_openai_chat_completion(
            prompt,
            self.engine,
            self.temperature,
            calculate_max_tokens(self.max_tokens, str(self.engine), token_consumed),
            self.system_message,
            self.client_id,
            self.x_vsl_client_id,
        )
        return response

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        """Get the identifying parameters."""
        params = {
            "engine": self.engine,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        return params


class IASOpenaiEmbeddings(Embeddings):
    """Wrapper for IAS secured OpenAI embedding API"""

    engine = str
    client_id: str = None
    x_vsl_client_id: str = None
    bearer_auth: str = None

    def __init__(self, engine, client_id, x_vsl_client_id=None, bearer_auth=None):
        self.engine = engine
        self.client_id = client_id
        self.x_vsl_client_id = x_vsl_client_id
        self.bearer_auth = bearer_auth

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embeddings search docs."""
        # NOTE: to keep things simple, we assume the list may contain texts longer
        #       than the maximum context and use length-safe embedding function.

        response = ias_openai_embeddings(
            texts, self.engine, self.client_id, self.x_vsl_client_id, self.bearer_auth
        )

        # Extract the embeddings
        embeddings: list[list[float]] = [data["embedding"] for data in response]
        return embeddings

    def embed_query(self, text: str) -> List[float]:
        """Embeddings  query text."""

        response = ias_openai_embeddings(
            text, self.engine, self.client_id, self.x_vsl_client_id, self.bearer_auth
        )

        # Extract the embeddings and total tokens
        embeddings: list[list[float]] = [data["embedding"] for data in response]
        return embeddings[0]


@backoff.on_exception(
    backoff.expo, GenericException, max_tries=20, max_time=60, giveup=is_http_4xx_error
)
def ias_bedrock_completion(
    token: str,
    user_message: str,
    model: str,
    temperature: float,
    max_tokens: int,
    system_message: str = None,
    client_id: str = None,
) -> str:
    """
    Generates a completion response for Bedrock model
    :param token: auth token
    :param user_message: user's prompt
    :param model: model capable for completion
    :param temperature: value 0-1 that tells model to be more precise or generative
    :param max_tokens: max tokens the prompt & response should be. It depends on the model's capacity
    :param system_message: system's prompt for instructions to the LLM
    :return: response from Bedrock model
    """
    try:
        if model.startswith("anthropic"):
            user_message = f"\n\nHuman:{user_message}\n\nAssistant:"
        elif model.startswith("amazon"):
            user_message = f"\n\nUser:{user_message}\n\nBot:"

        payload = {
            "model": model,
            "prompt": user_message,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }

        if system_message:
            payload["prompt"] = " ".join([system_message, user_message])

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }

        if client_id is not None:
            # Add x-agw-client_id if client id is present.
            headers["x-agw-client_id"] = client_id

        logger.info("Calling IAS Bedrock completion API")
        response = requests.post(IAS_BEDROCK_URL, headers=headers, json=payload)

        if response.status_code != 200:
            logger.error(
                f"Error calling IAS Bedrock completion API: {response.status_code}, {response.json()}"
            )
            raise GenericException(
                f"Error calling IAS Bedrock completion API: {response.status_code}, {response.json()}",
                status_code=response.status_code,
            )

        logger.info("Completion created from IAS Bedrock completion API")
        completion_resp = response.json()
        completion = completion_resp["result"]
        return completion
    except Exception as e:
        logger.error(f"Exception calling IAS Bedrock Completion API: {str(e)}")
        raise GenericException(e)


class IASBedrockLLM(LLM):
    """Wrapper for IAS secured Bedrock completion API"""

    model: str
    temperature: float
    max_tokens: int
    system_message: str = None
    client_id: str = None

    @property
    def _llm_type(self) -> str:
        return "IAS_Bedrock"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """Run the LLM on the given prompt and input."""

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
    ) -> str:
        token = federate_auth()
        prompt_message = prompt

        if self.system_message:
            prompt_message = prompt_message + self.system_message

        token_consumed = self.get_num_tokens(prompt_message)
        response = ias_bedrock_completion(
            token,
            prompt,
            self.model,
            self.temperature,
            calculate_max_tokens(self.max_tokens, str(self.model), token_consumed),
            self.system_message,
            self.client_id,
        )
        return response

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        """Get the identifying parameters."""
        params = {
            "model": self.model,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        return params


class IAS_OpenSearchVectorSearch(OpenSearchVectorSearch):
    def _select_relevance_score_fn(self):
        return lambda score: score


class LLMNotCalledException(Exception):
    """Custom exception to indicate that LLM is not called."""

    pass


class IAS_ConversationalRetrievalChain(BaseConversationalRetrievalChain):
    """Chain for having a conversation based on retrieved documents.

    This chain takes in chat history (a list of messages) and new questions,
    and then returns an answer to that question.
    The algorithm for this chain consists of three parts:

    1. Use the chat history and the new question to create a "standalone question".
    This is done so that this question can be passed into the retrieval step to fetch
    relevant documents. If only the new question was passed in, then relevant context
    may be lacking. If the whole conversation was passed into retrieval, there may
    be unnecessary information there that would distract from retrieval.

    2. This new question is passed to the retriever and relevant documents are
    returned.

    3. The retrieved documents are passed to an LLM along with either the new question
    (default behavior) or the original question and chat history to generate a final
    response.

    Example:
        .. code-block:: python

            from langchain.chains import (
                StuffDocumentsChain, LLMChain, ConversationalRetrievalChain
            )
            from langchain_core.prompts import PromptTemplate
            from langchain_community.llms import OpenAI

            combine_docs_chain = StuffDocumentsChain(...)
            vectorstore = ...
            retriever = vectorstore.as_retriever()

            # This controls how the standalone question is generated.
            # Should take `chat_history` and `question` as input variables.
            template = (
                "Combine the chat history and follow up question into "
                "a standalone question. Chat History: {chat_history}"
                "Follow up question: {question}"
            )
            prompt = PromptTemplate.from_template(template)
            llm = OpenAI()
            question_generator_chain = LLMChain(llm=llm, prompt=prompt)
            chain = ConversationalRetrievalChain(
                combine_docs_chain=combine_docs_chain,
                retriever=retriever,
                question_generator=question_generator_chain,
            )
    """

    retriever: BaseRetriever
    """Retriever to use to fetch documents."""
    max_tokens_limit: Optional[int] = None
    """If set, enforces that the documents returned are less than this limit.
    This is only enforced if `combine_docs_chain` is of type StuffDocumentsChain."""
    llm_response_flag: Optional[bool] = True
    """Specify whether to call LLM or not."""
    answer_from_llm_if_no_docs_found: Optional[bool] = False
    """Answer from LLM knowledge if no matching docs found."""

    def _reduce_tokens_below_limit(self, docs: List[Document]) -> List[Document]:
        num_docs = len(docs)

        if self.max_tokens_limit and isinstance(
            self.combine_docs_chain, StuffDocumentsChain
        ):
            tokens = [
                self.combine_docs_chain.llm_chain._get_num_tokens(doc.page_content)
                for doc in docs
            ]
            token_count = sum(tokens[:num_docs])
            while token_count > self.max_tokens_limit:
                num_docs -= 1
                token_count -= tokens[num_docs]

        return docs[:num_docs]

    def _get_docs(
        self,
        question: str,
        inputs: Dict[str, Any],
        *,
        run_manager: CallbackManagerForChainRun,
    ) -> List[Document]:
        """Get docs."""
        docs = self.retriever.get_relevant_documents(
            question, callbacks=run_manager.get_child()
        )

        if self.llm_response_flag is True and len(docs) > 0:
            return self._reduce_tokens_below_limit(docs)
        elif self.answer_from_llm_if_no_docs_found:
            return self._reduce_tokens_below_limit(docs)
        else:
            raise LLMNotCalledException()

    async def _aget_docs(
        self,
        question: str,
        inputs: Dict[str, Any],
        *,
        run_manager: AsyncCallbackManagerForChainRun,
    ) -> List[Document]:
        """Get docs."""
        docs = await self.retriever.aget_relevant_documents(
            question, callbacks=run_manager.get_child()
        )

        if self.llm_response_flag is True and len(docs) > 0:
            return self._reduce_tokens_below_limit(docs)
        elif self.answer_from_llm_if_no_docs_found:
            return self._reduce_tokens_below_limit(docs)
        else:
            raise LLMNotCalledException()

    @classmethod
    def from_llm(
        cls,
        llm: BaseLanguageModel,
        retriever: BaseRetriever,
        condense_question_prompt: BasePromptTemplate = CONDENSE_QUESTION_PROMPT,
        chain_type: str = "stuff",
        verbose: bool = False,
        condense_question_llm: Optional[BaseLanguageModel] = None,
        combine_docs_chain_kwargs: Optional[Dict] = None,
        callbacks: Callbacks = None,
        **kwargs: Any,
    ) -> BaseConversationalRetrievalChain:
        """Convenience method to load chain from LLM and retriever.

        This provides some logic to create the `question_generator` chain
        as well as the combine_docs_chain.

        Args:
            llm: The default language model to use at every part of this chain
                (eg in both the question generation and the answering)
            retriever: The retriever to use to fetch relevant documents from.
            condense_question_prompt: The prompt to use to condense the chat history
                and new question into a standalone question.
            chain_type: The chain type to use to create the combine_docs_chain, will
                be sent to `load_qa_chain`.
            verbose: Verbosity flag for logging to stdout.
            condense_question_llm: The language model to use for condensing the chat
                history and new question into a standalone question. If none is
                provided, will default to `llm`.
            combine_docs_chain_kwargs: Parameters to pass as kwargs to `load_qa_chain`
                when constructing the combine_docs_chain.
            callbacks: Callbacks to pass to all subchains.
            **kwargs: Additional parameters to pass when initializing
                ConversationalRetrievalChain
        """

        prompt_template = """Use the following pieces of context to answer the question at the end. {answer_with_llm_knowledge}

        {context}

        Question: {question}
        Helpful Answer:"""

        QA_PROMPT = PromptTemplate(
            template=prompt_template,
            input_variables=["context", "question", "answer_with_llm_knowledge"],
        )

        combine_docs_chain_kwargs = combine_docs_chain_kwargs or {"prompt": QA_PROMPT}
        doc_chain = load_qa_chain(
            llm,
            chain_type=chain_type,
            verbose=verbose,
            callbacks=callbacks,
            **combine_docs_chain_kwargs,
        )

        _llm = condense_question_llm or llm
        condense_question_chain = LLMChain(
            llm=_llm,
            prompt=condense_question_prompt,
            verbose=verbose,
            callbacks=callbacks,
        )
        return cls(
            retriever=retriever,
            combine_docs_chain=doc_chain,
            question_generator=condense_question_chain,
            callbacks=callbacks,
            **kwargs,
        )


class IAS_ChatModel(BaseChatModel):
    engine: str
    temperature: float
    max_tokens: int
    user_query: str
    min_response_token: int
    system_message: Optional[str] = (None,)
    client_id: str = (None,)
    x_vsl_client_id: str = None
    bearer_token: str = None
    context: list = None

    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Top Level call"""
        messages_dict = [convert_message_to_dict(s) for s in messages]

        # Create chat history array.
        if self.context:
            chat_history = create_chat_history_array(self.context)
            messages_dict[1:1] = chat_history

        if not is_anthropic_model(str(self.engine)):
            # Reduce max token based on token consumed
            all_msgs = ""
            for message in messages_dict:
                all_msgs += str(message["content"])

            token_consumed = (
                self.get_num_tokens(
                    (
                        "" + all_msgs + self.user_query + json.dumps(kwargs["tools"])
                        if kwargs["tools"]
                        else ""
                    )
                )
                + self.min_response_token
            )
            if self.max_tokens - token_consumed <= 0:
                token_consumed = 0

            logger.info(
                f"total token by system_message, user_query, kwargs[tools] is - {token_consumed}"
            )
        else:
            token_consumed = 0

        response = await ias_openai_chat_completion_with_tools(
            self.engine,
            self.temperature,
            self.max_tokens - token_consumed,
            self.client_id,
            self.x_vsl_client_id,
            self.bearer_token,
            messages_dict,
            kwargs["tools"],
            "auto",
        )
        return self._create_chat_result(response)

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        pass

    def _create_chat_result(
        self, response: Union[dict, openai.BaseModel, str]
    ) -> ChatResult:
        generations = []

        gen = ChatGeneration(
            message=convert_dict_to_message(response),
            generation_info=dict(finish_reason="stop"),
        )
        generations.append(gen)
        llm_output = {
            "token_usage": 0,
            "model_name": self.engine,
        }
        return ChatResult(generations=generations, llm_output=llm_output)

    @property
    def _llm_type(self) -> str:
        """Get the type of language model used by this chat model."""
        return "IAS_OpenAI"


def create_chat_history_array(context: list) -> list[dict]:
    chat_context = copy.deepcopy(context)
    chat_context.reverse()
    chat_history = []

    for i in range(len(context)):
        if i % 2 == 0:
            chat_history.append({"role": "user", "content": chat_context[i]})
        else:
            chat_history.append({"role": "assistant", "content": chat_context[i]})

    return chat_history


def convert_dict_to_message(_dict: Mapping[str, Any]) -> BaseMessage:
    """Convert a dictionary to a LangChain message.

    Args:
        _dict: The dictionary.

    Returns:
        The LangChain message.
    """
    role = _dict.get("role")
    id_ = _dict.get("id")
    if role == "user":
        return HumanMessage(content=_dict.get("content", ""), id=id_)
    elif role == "assistant":
        # Fix for azure
        # Also OpenAI returns None for tool invocations
        content = _dict.get("content", "") or ""
        additional_kwargs: Dict = {}
        if function_call := _dict.get("function_call"):
            additional_kwargs["function_call"] = dict(function_call)
        if tool_calls := _dict.get("tool_calls"):
            additional_kwargs["tool_calls"] = tool_calls
        return AIMessage(content=content, additional_kwargs=additional_kwargs, id=id_)
    elif role == "system":
        return SystemMessage(content=_dict.get("content", ""), id=id_)
    elif role == "function":
        return FunctionMessage(
            content=_dict.get("content", ""), name=_dict.get("name"), id=id_
        )
    elif role == "tool":
        additional_kwargs = {}
        if "name" in _dict:
            additional_kwargs["name"] = _dict["name"]
        return ToolMessage(
            content=_dict.get("content", ""),
            tool_call_id=_dict.get("tool_call_id"),
            additional_kwargs=additional_kwargs,
            id=id_,
        )
    else:
        return ChatMessage(content=_dict.get("content", ""), role=role, id=id_)


def convert_message_to_dict(message: BaseMessage) -> dict:
    """Convert a LangChain message to a dictionary.

    Args:
        message: The LangChain message.

    Returns:
        The dictionary.
    """
    message_dict: Dict[str, Any]
    if isinstance(message, ChatMessage):
        message_dict = {"role": message.role, "content": message.content}
    elif isinstance(message, HumanMessage):
        message_dict = {"role": "user", "content": message.content}
    elif isinstance(message, AIMessage):
        message_dict = {"role": "assistant", "content": message.content}
        if "function_call" in message.additional_kwargs:
            message_dict["function_call"] = message.additional_kwargs["function_call"]
            # If function call only, content is None not empty string
            if message_dict["content"] == None:
                message_dict["content"] = ""
        if "tool_calls" in message.additional_kwargs:
            message_dict["tool_calls"] = message.additional_kwargs["tool_calls"]
            # If tool calls only, content is None not empty string
            if message_dict["content"] == None:
                message_dict["content"] = ""
    elif isinstance(message, SystemMessage):
        message_dict = {"role": "system", "content": message.content}
    elif isinstance(message, FunctionMessage):
        message_dict = {
            "role": "function",
            "content": message.content,
            "name": message.name,
        }
    elif isinstance(message, ToolMessage):
        message_dict = {
            "role": "tool",
            "content": message.content,
            "tool_call_id": message.tool_call_id,
        }
    else:
        raise TypeError(f"Got unknown type {message}")
    if "name" in message.additional_kwargs:
        message_dict["name"] = message.additional_kwargs["name"]
    return message_dict