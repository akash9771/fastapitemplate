import pathlib
import shutil
from fastapi import Request as fastapi_request
from datetime import datetime
import json
import httpx
from typing import List, Dict, Optional, Union
import os
import ast
from fastapi import APIRouter, Depends
from fastapi import Depends, HTTPException
from pydantic import UUID4
from sqlalchemy.orm import Session
from sqlalchemy import desc, func
import uuid
from app.langchain.file_processor import (
    FileProcessor,
    ChunkingException,
    FileLoaderException,
)
from app.langchain.database import get_db

from app.langchain.v1.helper import (
    aget_client_info,
    insert_msg_in_sqs_queue,
    Validation_error,
    request_generation,
    index_generation,
    fetch_file_from_s3_using_purl,
    calculate_md5_hash,
    get_vector_db_details,
    client_id_info,
    delete_doc_s3,
    delete_folder_docs_s3,
    save_s3_file_to_local,
    validate_token_limit,
)

from app.langchain.v1.index_helper import IASOpenSerachHelper
from app.langchain.v1.models import (
    Status,
    HealthCheckResponse,
    QueryEmbeddingsRequest,
    QueryEmbeddingsResponse,
    DocumentIngestRequest,
    DocumentIngestResponse,
    DocumentEmbeddingsRequest,
    DocumentEmbeddingsResponse,
    DeleteRequest,
    DeleteResponse,
    IngestionInfoResponse,
    Order_By,
    StatusList,
    EditMetadataRequest,
    EditMetadataResponse,
)
from app.langchain.models import ClientMapping, DataIngestionStatusTableNew
from app.langchain.v1.utils.ias_openai_langchain import (
    IASOpenaiEmbeddings,
    IAS_OpenSearchVectorSearch,
)
from app.utils.custom_loguru import logger
from validator.decorators import async_token_validation_and_metering
from app.langchain.v1.search import invoke_search
from app.utils.config_vars import (
    OPEN_SEARCH_TIMEOUT_SECONDS,
    TABULAR_EXTENSIONS,
    CHUNKS_METADATA
)

client = httpx.AsyncClient(timeout=None, verify=False)

Failed_validation = Validation_error()
router = APIRouter()


GEN_VEC_DB = os.environ.get("GEN_VEC_DB_DET", "")
ENV = os.environ.get("ENV", "")
OCR_BUCKET_NAME = os.environ.get("OCR_BUCKET_NAME", "")
TEXTRACT_ENABLED = json.loads(os.getenv("TEXTRACT_ENABLED", "false").lower())
OPENAI_HEALTH_URL = os.environ.get("OPENAI_HEALTH_URL", "")
MULESOFT_HEALTH_URL = os.environ.get("MULESOFT_HEALTH_URL", "")
DOCS_BUCKET_NAME = os.environ.get("DOCS_BUCKET_NAME", "")


@router.get(
    "/health",
    status_code=200,
    tags=["Health check"],
)
async def health_check():
    return HealthCheckResponse(status=Status.success, message="Healthy")


@router.get("/stack_health", status_code=200, tags=["Stack Health check"])
async def stack_health_check():
    """Check the health of Vessel openai, mulesoft vessel api used in docinsight"""
    api_statuses = []

    # Define the API URLs
    api_urls = [
        {"service": "vessel_openai", "url": OPENAI_HEALTH_URL},
        {"service": "vessel_mulesoft", "url": MULESOFT_HEALTH_URL},
    ]
    try:
        for api in api_urls:
            response = await client.get(api["url"])
            api_statuses.append(
                {"service_name": api["service"], "status_code": response.status_code}
            )

            logger.info(
                f"Health check done for {api['service']}: response code is - {response.status_code}"
            )
    except Exception as exc:
        logger.error(f"Error occured at stack health check - {exc}")
        raise HTTPException(
            status_code=500, detail=f"stack health check failed - {exc}"
        )

    return api_statuses


@router.post(
    "/search",
    status_code=200,
    tags=["text embeddings"],
    description="This performs the similarity search on opensearch vectordb and returns the best N results from the stored documents on an Index",
    response_model=QueryEmbeddingsResponse,
)
@async_token_validation_and_metering(uom=7)
async def search(
    request: fastapi_request, rw: QueryEmbeddingsRequest, db: Session = Depends(get_db)
):
    try:

        logger.info("Fetching request headers for /search endpoint")

        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )

        # Necessary for handling LLM load balancing
        x_vsl_client_id = request.headers.get("x-vsl-client_id", None)
        bearer_auth = request.headers.get("Authorization", None)

        logger.info(f"Search request payload: {rw.json()}")

        # Validate the max token limit.
        validate_token_limit(rw)

        client_info = await aget_client_info(db, client_id)

        if client_info is None:
            raise HTTPException(
                status_code=400,
                detail=f"Provided Client id-->{client_id} does not exist in mapping table, please provide the correct client_id to use search API",
            )

        try:
            (llm_answer, citation_basic, total_token) = await invoke_search(
                db, client_id, x_vsl_client_id, bearer_auth, client_info, rw
            )

            return QueryEmbeddingsResponse(
                status=Status.success,
                llm_response=llm_answer,
                citation=citation_basic,
                requestid=str(uuid.uuid4()),
                totaltokensllm=total_token[0],
                totaltokensembedding=total_token[1],
            )

        except Exception as e:
            logger.error(f"Error in invoke_search method. {repr(e)}")
            raise e

    except Exception as e:
        logger.error(f"Error in search endpoint. {repr(e)}")
        raise e


@router.get("/status", status_code=200, tags=["API Module Service"])
@async_token_validation_and_metering()
async def get_status(
    request: fastapi_request, request_id: str, db: Session = Depends(get_db)
):
    try:
        logger.info("Fetching headers for /status endpoint")

        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )

        logger.info("Fetching database details for status endpoint")
        client_id_list = await client_id_info(client_id=client_id, db=db)

        ingestion_status = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.request_id == request_id,
                DataIngestionStatusTableNew.client_id.in_(client_id_list),
            )
            .first()
        )

        if ingestion_status:
            request_id_data = ingestion_status.request_id
            request_client_id_data = ingestion_status.client_id
            request_index_data = ingestion_status.index
            request_document_name_data = ingestion_status.document
            request_document_md5_data = ingestion_status.document_md5
            request_metadata_data = ingestion_status.attached_metadata
            request_last_index_timestamp_data = ingestion_status.completed_errored_ts
            request_status_data = ingestion_status.status
            request_error_message_data = ingestion_status.error_message
            request_current_status_timestamp_data = ingestion_status.queued_ts
            request_inprogress_ts_status_timestamp_data = ingestion_status.inprogress_ts
            request_completed_errored_ts = ingestion_status.completed_errored_ts

            status_info = {
                "request_id": request_id_data,
                "client_id": request_client_id_data,
                "index": request_index_data,
                "document_name": request_document_name_data,
                "document_md5": request_document_md5_data,
                "metadata_attached": request_metadata_data,
                "status": request_status_data,
            }
            if ingestion_status.status == "Error":
                return {
                    **status_info,
                    "error_message": request_error_message_data,
                    "completed_errored_ts": request_completed_errored_ts,
                }
            elif ingestion_status.status == "InProgress":
                return {
                    **status_info,
                    "current_status_timestamp": request_inprogress_ts_status_timestamp_data,
                }
            elif ingestion_status.status == "Queued":
                return {
                    **status_info,
                    "current_status_timestamp": request_current_status_timestamp_data,
                }
            else:
                return {
                    **status_info,
                    "last_index_timestamp": request_last_index_timestamp_data,
                }
        else:
            logger.error(
                f"request_id - {request_id} or client_id - {client_id} is not found in RDS table"
            )
            return {"message": "request_id or client_id is not found in RDS table "}
    except Exception as e:
        raise e


@router.get("/read_metadata", status_code=200, tags=["API Module Service"])
@async_token_validation_and_metering()
async def read_metadata(
    request: fastapi_request,
    request_id: str,
    document: str,
    db: Session = Depends(get_db),
):
    logger.info("Fetching headers for /read_metadata endpoint")

    try:
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )
        client_id_list = await client_id_info(client_id=client_id, db=db)

        logger.info("Started processing the request")
        ingestion_info = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.request_id == request_id,
                DataIngestionStatusTableNew.client_id.in_(client_id_list),
                DataIngestionStatusTableNew.document == document,
            )
            .first()
        )

        if ingestion_info:
            return {
                "request_id": ingestion_info.request_id,
                "client_id": ingestion_info.client_id,
                "document_name": ingestion_info.document,
                "metadata_attached": ingestion_info.attached_metadata,
            }
        else:
            return {
                "message": "request_id or client_id or document is not found in RDS table.."
            }
    except Exception as e:
        raise e


@router.post(
    "/ingest",
    status_code=200,
    tags=["data ingestion"],
    description="This is to ingest the document",
    response_model=DocumentIngestResponse,
)
@async_token_validation_and_metering()
async def data_ingestion(
    request: fastapi_request, rw: DocumentIngestRequest, db: Session = Depends(get_db)
):
    logger.info("Fetching headers for /ingest endpoint")
    try:
        data_to_insert = None
        file_name = ""
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )
        extract_table_image_element = rw.extract_table_image_element
        src_document_path = rw.src_document_path

        logger.info(f"Fetching client info for {client_id}")

        client_info = await aget_client_info(db, client_id)

        requestID = request_generation()

        if client_info is None:
            vector = f'{{"vectorDBAccessURL":"{GEN_VEC_DB}","vectorDBType":"OpenSearch","UserNameVar": "uc-os-username", "PasswordVar": "usecaseospassword","Secretdetails": "{ENV}-vsl-docinsight-secrets"}}'
            queue = f"{ENV}-vsl-docinsight-generic_queue.fifo"
            new_item = ClientMapping(
                client_id=f"{client_id}",
                usecase="non_vox",
                queue=queue,
                vectorDBdetails=vector,
                index=index_generation(),
            )
            db.add(new_item)
            db.commit()
            db.refresh(new_item)
            client_info = await aget_client_info(db, client_id)

        if client_info.usecase.lower() == "vox":
            logger.info("Index not generated since its a VOX usecase")
            indices = rw.index
            index = indices[0]
        else:
            index = client_info.index
            indices = [index]

        document_chunk_size = rw.document_chunk_size

        if document_chunk_size <= 8197 and type(document_chunk_size) == int:
            logger.info("Document_chunk_size is validated")
        else:
            return DocumentIngestResponse(
                status=Status.failure,
                requestID=requestID,
                Failed_request_reason=Failed_validation["document_chunk_size"],
            )

        document_overlap_size = rw.document_overlap_size

        if (
            document_overlap_size <= document_chunk_size
            and type(document_overlap_size) == int
        ):
            logger.info("document_overlap_size is validated")
        else:
            return DocumentIngestResponse(
                status=Status.failure,
                requestID=requestID,
                Failed_request_reason=Failed_validation["document_overlap_size"],
            )

        engine = rw.engine
        custom_metadata = rw.metadata if rw.metadata else {}
        request_status = "Queued"

        # Ignoring docinsight metadata
        updated_metadata  = {} 
        for key, value in custom_metadata.items():
            if key not in CHUNKS_METADATA:
                updated_metadata[key] = value

        try:
            # file_name is unique name of file saved in local, file_temp is original file name
            file_name, file_temp, file_content = fetch_file_from_s3_using_purl(
                presigned_url=src_document_path, write_to_local=True
            )
        except Exception as e:
            raise HTTPException(
                status_code=400,
                detail="Unable to read the file from the provided path. Please validate the pre-signed URL",
            )
        file_type = pathlib.Path(file_temp).suffix

        if file_type.lower() not in [
            ".pdf",
            ".docx",
            ".pptx",
            ".xlsx",
            ".csv",
            ".xls",
            ".png",
            ".jpg",
            ".jpeg",
            ".xml",
        ]:
            raise HTTPException(status_code=400, detail=Failed_validation["file_type"])

        document_md5 = calculate_md5_hash(filename=file_name)
        logger.info(f"Md5 of the given file {file_name}: {document_md5}")

        # overwriting metadata
        updated_metadata["filename"] = file_temp
        updated_metadata["md5"] = document_md5
        updated_metadata["request_id"] = requestID
        
        file_info_query = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.document_md5 == document_md5,
                DataIngestionStatusTableNew.index == index,
                DataIngestionStatusTableNew.is_file_deleted == False,
                DataIngestionStatusTableNew.status != "Error"
            )
        )

        file_info = file_info_query.first()

        if not file_info or rw.update_document:

            # Uploading all types of files to S3.
            instance = FileProcessor(
                filename=file_name,
                chunk_size=document_chunk_size,
                chunk_overlap=document_overlap_size,
                cust_metadata=updated_metadata,
            )
            s3_uri = instance.upload_docs_to_s3(
                file_name=file_name,
                client_id=client_id,
                request_id=requestID,
                final_folder="Landing",
            )
            logger.info(
                f"User passed S3 URL is -{src_document_path} - Newly generated S3 path: {s3_uri}"
            )

            queued_timestamp = datetime.utcnow()

            if file_info:
                # Soft delete old entry to reingest the document
                file_info_query.update({"is_file_deleted": True})
                db.commit()
                attached_metadata = eval(file_info.attached_metadata)

                # check and update opensearch metadata with request_id
                if "request_id" not in attached_metadata.keys():
                    (
                        AWS_OPENSEARCH_HOST,
                        AWS_OPENSEARCH_USERNAME,
                        AWS_OPENSEARCH_PASSWORD,
                    ) = await get_vector_db_details(client_id, db)
                    logger.info("Creating OS client")
                    os_client=IASOpenSerachHelper(host=AWS_OPENSEARCH_HOST, username=AWS_OPENSEARCH_USERNAME, password=AWS_OPENSEARCH_PASSWORD, index=index)
                    attached_metadata["request_id"] = file_info.request_id
                    os_client.update_opensearch_metadata(document_md5=document_md5, updated_metadata=attached_metadata)

            logger.info(
                "Inserting ingestion info into DataIngestionStatusTableNew table"
            )
            data_to_insert = DataIngestionStatusTableNew(
                request_id=requestID,
                client_id=client_id,
                index=index,
                document=file_temp,
                document_md5=document_md5,
                attached_metadata=str(updated_metadata),
                status=request_status,
                error_message="",
                queued_ts=queued_timestamp,
                file_path=s3_uri,
                chunked_as_parent_child=rw.chunked_as_parent_child,
                re_ingested=rw.update_document
            )
            db.add(data_to_insert)
            db.commit()

            try:
                logger.info("Generating message in the Generic queue")
                processed_responsed = {
                    "src_document_path": s3_uri,
                    # "src_document_path": src_document_path,
                    "index": indices,
                    "client_id": client_id,
                    "requestID": requestID,
                    "document_chunk_size": document_chunk_size,
                    "document_overlap_size": document_overlap_size,
                    "metadata": updated_metadata,
                    "engine": engine,
                    "retry_count": 0,
                    "read_count": 0,
                    "parent_document_chunk_size": rw.parent_document_chunk_size,
                    "parent_document_chunk_overlap": rw.parent_document_chunk_overlap,
                    "extract_table_image_element":extract_table_image_element,
                    "table_confidence_score": rw.table_confidence_score,
                    "advance_table_filter":rw.advance_table_filter,
                    "embed_raw_table":rw.embed_raw_table,
                    "update_document":rw.update_document,
                    "old_request_id": file_info.request_id if file_info else None
                }
                processed_response = json.dumps(processed_responsed)

                # logger.debug(f"processed_response===== {processed_response}")
                
                insert_msg_in_sqs_queue(
                    msg_json=processed_response,
                    client_id=client_id,
                    client_info=client_info,
                    indices=indices,
                )
            except Exception as e:
                db.rollback()
                raise e

            logger.info("Sending success response to user")

            return DocumentIngestResponse(
                status=Status.success,
                requestID=requestID,
                client_id=client_id,
                request_status=request_status,
                metadata=updated_metadata,
                queued_timestamp=queued_timestamp,
            )
        else:
            logger.info(
                "Posting the response from generic queue for already existing document"
            )

            return DocumentIngestResponse(
                status=Status.failure,
                requestID=file_info.request_id,
                Failed_request_reason=Failed_validation["duplication"],
                metadata=(
                    ast.literal_eval(file_info.attached_metadata)
                    if file_info.attached_metadata
                    else None
                ),
                queued_timestamp=file_info.queued_ts,
            )

    except Exception as exc:
        #Reversing the re-ingestion process in case of failure
        if data_to_insert:
            db.query(DataIngestionStatusTableNew).filter(DataIngestionStatusTableNew.request_id == requestID).update({"is_file_deleted": True})
            db.commit()
        if rw.update_document and file_info:
            db.query(DataIngestionStatusTableNew).filter(DataIngestionStatusTableNew.request_id == file_info.request_id).update({"is_file_deleted": False})
            db.commit()
        raise exc

    finally:
        if file_name and os.path.exists(file_name):
            os.remove(file_name)


@router.post(
    "/process_endpoint",
    status_code=200,
    tags=["text embeddings"],
    description="Creates chunks of the uploaded data and provides embeddings",
    response_model=DocumentEmbeddingsResponse,
)
@async_token_validation_and_metering()
async def process_file(
    request: fastapi_request,
    rw: DocumentEmbeddingsRequest,
    db: Session = Depends(get_db),
):
    try:
        s3_path_uri = rw.src_document_path
        separators = rw.chunking_strategy
        chunk = rw.document_chunk_size
        overlap = rw.document_overlap_size
        req_id = rw.requestID
        client_id = rw.client_id
        index = rw.index
        filename = ""
        cust_md = {} if rw.metadata is None else rw.metadata
        parent_document_chunk_size = rw.parent_document_chunk_size
        parent_document_chunk_overlap = rw.parent_document_chunk_overlap
        extract_table_image_element = rw.extract_table_image_element
        embed_raw_table = rw.embed_raw_table
        custom_extraction_document_path = f"{req_id}"

        logger.info(
            f"Ingesting the document for the client_id: {client_id} and req_id: {req_id}"
        )
      

        """ Update status 'InProgress' in database """
        index_detail = (
            db.query(DataIngestionStatusTableNew)
            .filter_by(request_id=req_id, client_id=client_id)
            .first()
        )

        if index_detail is None:
            logger.error(
                f"For client_id: {client_id} and req_id: {req_id} - Request ID not found in the database"
            )
            raise HTTPException(
                status_code=400, detail="Request ID not found in the database"
            )

        index_detail.status = "InProgress"
        index_detail.inprogress_ts = datetime.utcnow()
        db.commit()

        chunked_as_parent_child = index_detail.chunked_as_parent_child

        if overlap > chunk:
            index_detail.status = "Error"
            index_detail.error_message = "Overlap size should be less than chunk size"
            index_detail.completed_errored_ts = datetime.utcnow()
            db.commit()
            logger.error(
                f"For client_id: {client_id} and req_id: {req_id} - Overlap size should be less than chunk size"
            )
            raise HTTPException(
                status_code=428, detail="Overlap size should be less than chunk size"
            )

        """ Fetch file from S3 """
        try:
            # filename, _, _ = fetch_file_from_s3_using_purl(s3_path_uri)
            filename, _ = save_s3_file_to_local(s3_path_uri)
        except Exception as e:
            filename = "docinsight-error-1.pdf"
            index_detail.status = "Error"
            index_detail.error_message = f"Error in fetching document from S3: {str(e)}"
            index_detail.completed_errored_ts = datetime.utcnow()
            db.commit()
            logger.error(
                f"For client_id: {client_id} and req_id: {req_id} - Error while fetching document from S3: {str(e)}"
            )
            raise HTTPException(
                status_code=400, detail="Error while fetching the document from S3"
            )

        """ Determine file type (pdf/docx) """
        file_type = pathlib.Path(filename).suffix
        file_supported_type = [
            ".pdf",
            ".docx",
            ".pptx",
            ".xlsx",
            ".csv",
            ".xls",
            ".png",
            ".jpg",
            ".jpeg",
            ".xml",
        ]

        try:
            if file_type.lower() in file_supported_type:

                # Checking for .csv/.xlsx/.xls fie types
                if file_type in TABULAR_EXTENSIONS:
                    try:

                        # Uploading all types of files to S3.
                        instance1 = FileProcessor(
                            filename=filename,
                            chunk_size=chunk,
                            chunk_overlap=overlap,
                            cust_metadata=cust_md,
                        )
                        parquet_path = instance1.process_tabular_file(
                            client_id=client_id,
                            request_id=req_id,
                            file_type=file_type,
                            filename=filename,
                            final_folder="Processed",
                        )
                        parquet_path = ",".join(parquet_path)
                        index_detail.file_path = parquet_path
                        index_detail.status = "Completed"
                        index_detail.error_message = ""
                        index_detail.completed_errored_ts = datetime.utcnow()
                        db.commit()

                        logger.info(
                            f"For client_id: {client_id} and req_id: {req_id} - {filename} added to S3 as parquet file. "
                        )
                        return DocumentEmbeddingsResponse(
                            status=Status.success, index=index, request_id=req_id
                        )
                    except Exception as e:
                        index_detail.status = "Error"
                        index_detail.error_message = (
                            f"Excel/CSV file processing error: {str(e)}"
                        )
                        index_detail.completed_errored_ts = datetime.utcnow()
                        db.commit()
                        logger.error(
                            f"For client_id: {client_id} and req_id: {req_id} - Excel/CSV file processing error: {str(e)}"
                        )
                        raise e

                else:  # for all other file types
                    try:
                        processor = FileProcessor(
                            filename=filename,
                            separators=separators,
                            chunk_size=chunk,
                            chunk_overlap=overlap,
                            cust_metadata=cust_md,
                            chunked_as_parent_child=chunked_as_parent_child,
                            client_id=client_id,
                            index_name=index[0],
                            parent_document_chunk_size=parent_document_chunk_size,
                            parent_document_chunk_overlap=parent_document_chunk_overlap,
                            custom_extraction_document_path=custom_extraction_document_path,
                            extract_images_tables=extract_table_image_element,
                            advance_table_filter_flag=rw.advance_table_filter,
                            embed_raw_table=embed_raw_table,
                        )

                        page_content, metadata, large_file = (
                            await processor.process_files()
                        )
                        logger.info(
                            f"For client_id: {client_id} and req_id: {req_id} - chunked the given file: {filename}"
                        )

                        (
                            AWS_OPENSEARCH_HOST,
                            AWS_OPENSEARCH_USERNAME,
                            AWS_OPENSEARCH_PASSWORD,
                        ) = await get_vector_db_details(rw.client_id, db)

                        try:
                            for idx in index:
                                logger.info(
                                    f"For client_id: {client_id} and req_id: {req_id} - Creating embeddings and ingesting into opensearch"
                                )
                                vector_db = IAS_OpenSearchVectorSearch(
                                    index_name=idx,
                                    embedding_function=IASOpenaiEmbeddings(
                                        engine=rw.engine, client_id=client_id
                                    ),
                                    opensearch_url=AWS_OPENSEARCH_HOST,
                                    http_auth=(
                                        AWS_OPENSEARCH_USERNAME,
                                        AWS_OPENSEARCH_PASSWORD,
                                    ),
                                    is_aoss=False,
                                )

                                if large_file:
                                    for i in range(0, len(page_content)):
                                        vectors = vector_db.add_texts(
                                            texts=page_content[i], metadatas=metadata[i]
                                        )
                                else:
                                    vectors = vector_db.add_texts(
                                        texts=page_content, metadatas=metadata
                                    )

                                index_detail.status = "Completed"
                                index_detail.error_message = ""
                                index_detail.table_figure_metadata = (
                                    processor.fetch_custom_metadata()
                                )
                                index_detail.completed_errored_ts = datetime.utcnow()
                                db.commit()

                                # Deleting old document after reingest from opensearch
                                if rw.update_document and rw.old_request_id:
                                     os_client=IASOpenSerachHelper(host=AWS_OPENSEARCH_HOST, username=AWS_OPENSEARCH_USERNAME, password=AWS_OPENSEARCH_PASSWORD, index=idx)
                                     os_client.delete_documents(request_id=rw.old_request_id)
                                    
                                
                                logger.info(
                                    f"For client_id: {client_id} and req_id: {req_id} - Ingested the embeddings into opensearch"
                                )
                                # delete the file uploaded to our s3 by ingest API - Except csv/xls/xlsx
                                split_url = s3_path_uri.split("/")
                                file_name_with_path = "/".join(split_url[3:])
                                if file_type.lower() not in TABULAR_EXTENSIONS:
                                    delete_doc_s3(
                                        bucket_name=DOCS_BUCKET_NAME,
                                        file_name=file_name_with_path,
                                    )
                                    logger.info(
                                        f"Deleted file -{file_name_with_path}, from bucket -{DOCS_BUCKET_NAME}"
                                    )

                        except Exception as e:
                            index_detail.status = "Error"
                            index_detail.error_message = (
                                f"Langchain document embeddings error: {str(e)}"
                            )
                            index_detail.completed_errored_ts = datetime.utcnow()
                            db.commit()
                            delete_doc_s3(
                                bucket_name=OCR_BUCKET_NAME, file_name=filename
                            )
                            logger.error(
                                f"For client_id: {client_id} and req_id: {req_id} - Langchain document embeddings error: {str(e)}"
                            )

                            raise HTTPException(
                                status_code=500,
                                detail="Langchain document embeddings error",
                            )

                        if filename and os.path.exists(filename):
                            os.remove(filename)

                        if (
                            file_type.lower() in [".pdf", ".jpg", ".png", ".jpeg"]
                            and TEXTRACT_ENABLED
                        ):
                            delete_doc_s3(
                                bucket_name=OCR_BUCKET_NAME, file_name=filename
                            )

                        return DocumentEmbeddingsResponse(
                            status=Status.success, index=index, request_id=req_id
                        )
                    except ChunkingException as e:
                        index_detail.status = "Error"
                        index_detail.error_message = (
                            f"Error while chunking the file: {str(e)}"
                        )
                        index_detail.completed_errored_ts = datetime.utcnow()
                        db.commit()
                        delete_doc_s3(bucket_name=OCR_BUCKET_NAME, file_name=filename)
                        logger.error(f"Error while chunking the file: {str(e)}")
                        raise e
                    except FileLoaderException as e:
                        index_detail.status = "Error"
                        index_detail.error_message = f"Error in file loader: {str(e)}"
                        index_detail.completed_errored_ts = datetime.utcnow()
                        db.commit()
                        delete_doc_s3(bucket_name=OCR_BUCKET_NAME, file_name=filename)
                        logger.error(f"Error while loading the file: {str(e)}")
                        raise e
                    except Exception as e:
                        logger.error(f"Failed to process the request: {str(e)}")
                        raise e

            else:
                error_message = f"Requested file format not supported: {file_type}"
                logger.error(error_message)
                page_content = ["No page_content"]
                metadata = ["No metadata"]
                index_detail.status = "Error"
                index_detail.error_message = error_message
                index_detail.completed_errored_ts = datetime.utcnow()
                db.commit()
                logger.error(f"Requested file format not supported: {file_type}")
                raise HTTPException(status_code=400, detail=error_message)

        except Exception as e:
            index_detail.status = "Error"
            index_detail.error_message = f"Error while loading the file: {str(e)}"
            index_detail.completed_errored_ts = datetime.utcnow()
            db.commit()
            logger.error(f"Error while processing the file: {str(e)}")
            delete_doc_s3(bucket_name=OCR_BUCKET_NAME, file_name=filename)
            raise HTTPException(
                status_code=500, detail="Error in processing the uploaded file"
            )

    except Exception as e:
        # In case re-ingestion fails, we are enabling old document
        if rw.update_document and rw.old_request_id:
            db.query(DataIngestionStatusTableNew).filter(DataIngestionStatusTableNew.request_id == rw.old_request_id).update({"is_file_deleted": False})
            db.query(DataIngestionStatusTableNew).filter(DataIngestionStatusTableNew.request_id == rw.requestID).update({"is_file_deleted": True})
            db.commit()
        
        raise e
    finally:
        if filename and os.path.exists(filename):
            os.remove(filename)

        shutil.rmtree(custom_extraction_document_path, ignore_errors=True)


@router.post(
    "/delete-files",
    status_code=200,
    tags=["Delete Document"],
    description="This endpoint deletes the document from VectorDB and docinsight RDS",
    response_model=DeleteResponse,
)
@async_token_validation_and_metering()
async def delete_file(
    request: fastapi_request, rw: DeleteRequest, db: Session = Depends(get_db)
):
    try:
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )

        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )

        # Get the client ids.
        client_id_list = await client_id_info(client_id=client_id, db=db)

        # Get Ingestion info based on request ids.
        ingestion_info = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.client_id.in_(client_id_list),
                DataIngestionStatusTableNew.request_id.in_(rw.request_ids),
            )
            .all()
        )

        # Check if ingestion_info(db) has any data
        if len(ingestion_info):
            delete_response = []
            opensearch_client = None

            # Check if list contains any non tabular file types.
            non_tabular_file_exist = any(
                pathlib.Path(row.document).suffix not in TABULAR_EXTENSIONS
                for row in ingestion_info
            )

            # Create Open Search Client only if the file has to be deleted from Vector DB.
            if non_tabular_file_exist:
                (
                    AWS_OPENSEARCH_HOST,
                    AWS_OPENSEARCH_USERNAME,
                    AWS_OPENSEARCH_PASSWORD,
                ) = await get_vector_db_details(client_id, db)


            for row in ingestion_info:
                deletion_msg = "Found in Database."
                deletion_status = False

                try:
                    if (
                        pathlib.Path(row.document).suffix in TABULAR_EXTENSIONS
                        and row.file_path
                    ):
                        # File is tabular data, delete processed files from S3.
                        s3_folder_path = f"{client_id}/{row.request_id}"
                        delete_folder_docs_s3(
                            bucket_name=DOCS_BUCKET_NAME, folder_name=s3_folder_path
                        )
                        deletion_status = True
                        deletion_msg = f"{deletion_msg} Deleted file."
                    else:
                        # Delete the content from Vector DB.
                        if row.status == "Completed":
                            os_client=IASOpenSerachHelper(host=AWS_OPENSEARCH_HOST, username=AWS_OPENSEARCH_USERNAME, password=AWS_OPENSEARCH_PASSWORD, index=row.index)
                            deletion_status= os_client.delete_documents(document_md5=row.document_md5)

                            

                        # Update vec_db_deletion_status as deleted.
                        deletion_msg = f"{deletion_msg} {'Successfully deleted from Vectordb' if deletion_status else 'Not Found in Vectordb'}"

                        # Update VectorDB deletion status as deleted.
                        row.vec_db_deletion_status = "Deleted"
                except Exception as e:
                    logger.error(
                        f"Unable to delete the file {row.document}. Error: {repr(e)}"
                    )
                finally:
                    # Marking file as deleted.
                    row.is_file_deleted = True
                    db.commit()

                # Add delete response.
                delete_response.append(
                    {
                        "request_id": row.request_id,
                        "message": deletion_msg,
                        "status": deletion_status,
                    }
                )

            # Filter the given list of request_id's which are not found in database.
            missing_records = [
                request_id
                for request_id in rw.request_ids
                if request_id not in [row.request_id for row in ingestion_info]
            ]

            # Return the status as not found in database for missing records.
            for missing_request_id in missing_records:
                delete_response.append(
                    {
                        "request_id": missing_request_id,
                        "message": "Not Found in Database.",
                        "status": False,
                    }
                )
        else:
            msg = f"Provided Request ids: {rw.request_ids} not present in DB"
            logger.error(msg)
            raise HTTPException(
                status_code=400, detail="Please check the request payload"
            )

        return DeleteResponse(delete_status=delete_response)

    except Exception as e:
        raise e


@router.get(
    "/ingestion-info",
    status_code=200,
    tags=["API Module Service"],
    description="This endpoint provides the list of documents used by the given client",
    response_model=Dict[str, Union[List[IngestionInfoResponse], int, str]],
)
@async_token_validation_and_metering()
async def get_ingestion_info(
    request: fastapi_request,
    request_id: Optional[str] = None,
    db: Session = Depends(get_db),
    page_limit: Optional[int] = 25,
    page_number: Optional[int] = 1,
    sort_order: Order_By = Order_By.ASC,
    status: Optional[StatusList] = None,
    is_file_deleted: Optional[bool] = None,
):
    try:
        logger.info("Fetching client header")
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )
        client_id_list = await client_id_info(client_id=client_id, db=db)

        if request_id:  # Check if request_id is provided in the query
            logger.info(f"Fetching record for request_id: {request_id}")
            record = (
                db.query(DataIngestionStatusTableNew)
                .filter(DataIngestionStatusTableNew.request_id == request_id)
                .first()
            )
            logger.info(f"Fetching client info for {record}")

            document_list = []
            if record:
                document_list.append(
                    IngestionInfoResponse(
                        request_id=record.request_id,
                        index=record.index,
                        document_name=record.document,
                        document_md5=record.document_md5,
                        attached_metadata=record.attached_metadata,
                        status=record.status,
                        error_msg=record.error_message,
                        is_file_deleted=record.is_file_deleted,
                        created_ts=record.created_ts,
                        queued_ts=record.queued_ts,
                        inprogress_ts=record.inprogress_ts,
                        completed_errored_ts=record.completed_errored_ts,
                        modified_ts=record.modified_ts,
                        table_figure_metadata=record.table_figure_metadata,
                        re_ingested=record.re_ingested
                    )
                )
                
                return {"ingestion_data": document_list}
            else:
                raise HTTPException(
                    status_code=404,
                    detail="No record found with the provided request_id",
                )
        if page_number >= 1:
            if page_number > 1 and page_limit is None:
                logger.error("Page limit is also required with page number")
                raise HTTPException(
                    status_code=400,
                    detail="Page limit is also required with page number",
                )
            elif page_limit is not None and page_limit <= 0:
                logger.error("Page limit cannot be less than 1")
                raise HTTPException(
                    status_code=400, detail="Page limit cannot be less than 1"
                )
            elif page_limit is not None and page_limit > 1000:
                logger.error("Page limit cannot be greater than 1000")
                raise HTTPException(
                    status_code=400, detail="Page limit cannot be greater than 1000"
                )
        elif page_number < 1:
            logger.error("Page number cannot be less than 1")
            raise HTTPException(
                status_code=400, detail="Page number cannot be less than 1"
            )

        # Apply ordering and sorting
        order_column = DataIngestionStatusTableNew.modified_ts
        if sort_order == Order_By.DESC:
            order_column = desc(order_column)

        client_id_list = await client_id_info(client_id=client_id, db=db)
        query = (
            db.query(DataIngestionStatusTableNew)
            .filter(DataIngestionStatusTableNew.client_id.in_(client_id_list))
            .order_by(order_column)
        )

        # Applying status filter if provided
        if status:
            query = query.filter(
                func.lower(DataIngestionStatusTableNew.status) == status.lower()
            )

        # Applying is_file_deleted filter if provided
        if is_file_deleted is not None:
            query = query.filter(
                DataIngestionStatusTableNew.is_file_deleted == is_file_deleted
            )

        total_count = query.count()

        # Calculate total number of pages based on page_limit and total_count
        page_size = -(
            -total_count // page_limit
        )  # Ceiling division to get a positive integer

        # Apply pagination
        if page_limit is not None:
            start_index = (page_number - 1) * page_limit
            end_index = start_index + page_limit
            query = query.offset(start_index).limit(page_limit)

        ingestion_info = query.all()
        ingestion_data = []

        if len(ingestion_info):
            logger.info(f"Fetching details containing {total_count} entries")
            for row in ingestion_info:
                ingestion_data.append(
                    IngestionInfoResponse(
                        request_id=row.request_id,
                        index=row.index,
                        document_name=row.document,
                        document_md5=row.document_md5,
                        attached_metadata=row.attached_metadata,
                        status=row.status,
                        error_msg=row.error_message,
                        is_file_deleted=row.is_file_deleted,
                        created_ts=row.created_ts,
                        queued_ts=row.queued_ts,
                        table_figure_metadata=row.table_figure_metadata,
                        re_ingested=row.re_ingested,
                        inprogress_ts=row.inprogress_ts,
                        completed_errored_ts=row.completed_errored_ts,
                        modified_ts=row.modified_ts,
                    )
                )
        else:
            logger.error("No records found in DB")

        # Check if requested page_number exceeds page_size
        if page_number > page_size:
            logger.error("Requested page_number exceeds available page_size.")
            raise HTTPException(
                status_code=400,
                detail="Requested page_number exceeds available page_size.",
            )

        # Return a dictionary containing both ingestion data and pagination information
        return {
            "ingestion_data": ingestion_data,
            "total_count": total_count,
            "page_number": page_number,
            "page_limit": page_limit,
            "page_size": page_size,
        }
    except Exception as e:
        raise e


@router.put(
    "/metadata",
    status_code=200,
    tags=["metadata"],
    description="Edit metadata for an already ingested document",
    response_model=EditMetadataResponse,
)
@async_token_validation_and_metering()
async def edit_metadata(
    request: fastapi_request, rw: EditMetadataRequest, db: Session = Depends(get_db)
):
    try:
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )

        if not client_id:
            raise HTTPException(
                status_code=400, detail="Client Id is not sent in headers"
            )

        # request_id check
        if not (rw.request_id):
            raise HTTPException(
                status_code=400,
                detail="request_id must be provided in request body",
            )

        # Apply filter based on client_id,request_id and status.
        document = (
            db.query(DataIngestionStatusTableNew)
            .filter(
                DataIngestionStatusTableNew.client_id == client_id,
                DataIngestionStatusTableNew.request_id == rw.request_id,
                DataIngestionStatusTableNew.status == "Completed",
            )
            .first()
        )

        if not document:
            raise HTTPException(
                status_code=404,
                detail="Document not found for the provided client_id, request_id",
            )

        # convert attached_metadata data into dictionary format.
        document_metadata = eval(document.attached_metadata)

        # update the "attached_metadata" as per the user request and include filename and md5 from "data_ingestion_status_table".
        updated_metadata = {}
        metadata_keys = ["filename", "md5", "request_id"]
        for key, value in document_metadata.items():
            if key in metadata_keys:
                updated_metadata[key] = value

        for key, value in rw.metadata.items():
            if key not in metadata_keys:
                updated_metadata[key] = value

        # Convert the values of the "updated_metadata" dictionary to a string.
        updated_metadata_string = repr(updated_metadata)

        # In db Update the attached_metadata column with the updated_metadata_string values.
        document.attached_metadata = updated_metadata_string
        db.commit()

        (
            AWS_OPENSEARCH_HOST,
            AWS_OPENSEARCH_USERNAME,
            AWS_OPENSEARCH_PASSWORD,
        ) = await get_vector_db_details(client_id, db)

        logger.info("Creating OS client")
        os_client=IASOpenSerachHelper(host=AWS_OPENSEARCH_HOST, username=AWS_OPENSEARCH_USERNAME, password=AWS_OPENSEARCH_PASSWORD, index=document.index)
        os_client.update_opensearch_metadata(document_md5=document.document_md5, updated_metadata=updated_metadata)


        return EditMetadataResponse(
            status=Status.success,
            request_id=rw.request_id,
            document_name=document.document,
            document_md5=document.document_md5,
            metadata=updated_metadata,
        )

    except Exception as e:
        raise e
