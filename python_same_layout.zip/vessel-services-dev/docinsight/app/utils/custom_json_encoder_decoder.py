import json
from sqlalchemy.ext.declarative import DeclarativeMeta


class CustomJSONEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj.__class__, DeclarativeMeta):
            # If the object is a SQLAlchemy model, convert it to a normal class.
            data = {
                "__class__": obj.__class__.__name__,
                "__data__": {
                    c.name: getattr(obj, c.name) for c in obj.__table__.columns
                },
            }
            return data
        return super().default(obj)


class CustomJSONDecoder(json.JSONDecoder):
    def __init__(self, *args, **kwargs):
        self.model_class = kwargs.pop("model_class", None)
        super().__init__(object_hook=self.object_hook, *args, **kwargs)

    def object_hook(self, dct):
        if "__class__" in dct and "__data__" in dct:
            # If the dictionary has '__class__' and '__data__' keys,
            # assume it represents a SQLAlchemy model and create a new instance of the model.
            if self.model_class:
                data = dct["__data__"]
                return self.model_class(**data)
        return dct
