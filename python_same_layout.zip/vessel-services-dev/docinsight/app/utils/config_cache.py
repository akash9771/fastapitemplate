import os
from redis import asyncio as aioredis
from redis.asyncio.cluster import RedisCluster
from redis.exceptions import RedisClusterException
import asyncio
from typing import Optional
from fastapi import Request, Response
from fastapi_cache import FastAPICache
import json

from app.utils.custom_loguru import logger
from app.utils.custom_json_encoder_decoder import CustomJSONDecoder, CustomJSONEncoder

# Get Redis Connection parameters.
REDIS_ENV = os.getenv("REDIS_ENV", "")
REDIS_KEY_PREFIX = os.getenv("REDIS_KEY_PREFIX", "docinsight")
REDIS_HOST_PORT = os.getenv("REDIS_HOST_PORT", "redis-stack-server:6379")
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")


class RedisClient:
    def __init__(
        self,
        host_port=REDIS_HOST_PORT,
        password=REDIS_PASSWORD,
        encoding="utf8",
        decode_responses=True,
    ):
        self.host_port = host_port
        self.password = password
        self.encoding = encoding
        self.decode_responses = decode_responses
        self.redis = None

    async def connect(self):
        try:
            self.redis = await RedisCluster.from_url(
                f"{self.host_port}",
                password=self.password,
                encoding=self.encoding,
                decode_responses=self.decode_responses,
            )
            pong = await asyncio.wait_for(self.redis.ping(), timeout=5)
            logger.info(f"Connected to Redis: {pong}")
        except RedisClusterException as e:
            logger.warning(
                "Cluster mode is not enabled on this redis - trying standard mode"
            )
            self.redis = await aioredis.from_url(
                f"{self.host_port}",
                password=self.password,
                encoding=self.encoding,
                decode_responses=self.decode_responses,
            )
            pong = await asyncio.wait_for(self.redis.ping(), timeout=5)
            logger.info(f"Connected to Redis: {pong}")
        except asyncio.TimeoutError:
            logger.error("Connection to Redis timed out")
            logger.warning("Proceeding without Redis Cache")
        except Exception as e:
            logger.error(f"Failed connecting to Redis: {str(e)}")
            logger.warning("Proceeding without Redis Cache")

    async def close(self):
        if self.redis:
            await self.redis.close()
            self.redis = None


redis_client = RedisClient()


def cache_key_builder(
    func,
    namespace: Optional[str] = "",
    request: Request = None,
    response: Response = None,
    *args,
    **kwargs,
):
    prefix = FastAPICache.get_prefix()
    nested_string = kwargs.get("kwargs", {})
    cache_string = nested_string.get("cache_string", "default")

    cache_key = f"{prefix}:{cache_string}:{request.method.lower()}:{request.url.path}:{repr(sorted(request.query_params.items()))}"
    return cache_key


def __get_cache_key(key_arg) -> str:
    if REDIS_ENV:
        key = f"{REDIS_ENV}:{REDIS_KEY_PREFIX}:{key_arg}"
    else:
        key = f"{REDIS_KEY_PREFIX}:{key_arg}"
    return key


def function_cache(key_arg, expire=30):
    def cache_decorator(func):
        async def wrapper(*args, **kwargs):
            key = __get_cache_key(key_arg)
            result = await redis_client.redis.get(key)
            if result is not None:
                logger.debug(f"Key served from cache: {key} ")
                return json.loads(result)
            result = await func(*args, **kwargs)
            await redis_client.redis.set(key, json.dumps(result), ex=expire)
            return result

        return wrapper

    return cache_decorator


async def cache_get(key_arg, model_class=None):
    try:
        key = __get_cache_key(key_arg)
        result = await redis_client.redis.get(key)
        if result is not None:
            logger.debug(f"Key served from cache: {key} ")
            return json.loads(result, cls=CustomJSONDecoder, model_class=model_class)
    except Exception as e:
        logger.error(f"Failed get key-{key} from Redis: {str(e)}")
        return None


async def cache_set(key_arg, data, expire=30 * 60):
    try:
        key = __get_cache_key(key_arg)
        await redis_client.redis.set(
            key, json.dumps(data, cls=CustomJSONEncoder), expire
        )
    except Exception as e:
        logger.error(f"Failed to set key-{key} in Redis: {str(e)}")


async def cache_delete(key_arg):
    try:
        key = __get_cache_key(key_arg)
        await redis_client.redis.delete(key)
    except Exception as e:
        logger.error(f"Failed delete key from Redis: {str(e)}")
