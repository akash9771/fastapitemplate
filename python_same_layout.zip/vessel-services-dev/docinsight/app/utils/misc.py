def is_anthropic_model(llm_engine:str):
    if llm_engine.startswith("anthropic") or llm_engine.startswith("amazon"):
        return True
    else:
        return False

def calculate_max_tokens(max_tokens, model, token_consumed):
    if is_anthropic_model(model):
        return max_tokens
    else:
        return max_tokens-token_consumed