from fastapi import Request
from fastapi.responses import JSONResponse

from app.utils.error_codes import get_human_status_code_msg
from app.utils.custom_loguru import logger
from app.utils.ai_haikunator import AIHaikunator

import traceback

random_error_code_gen = AIHaikunator()


def gen_error_log_code():
    return random_error_code_gen.haikunate(token_hex=True, token_length=4)


generic_exceptions = [
    SyntaxError,
    TypeError,
    NameError,
    IndexError,
    KeyError,
    ValueError,
    AttributeError,
    IOError,
    ZeroDivisionError,
    ImportError,
    Exception,
]


def get_client_id(request):
    client_id = (
        request.headers.get("x-agw-client_id")
        if request.headers.get("x-agw-client_id") is not None
        else None
    )
    return client_id


def generic_exception_handler(exc, request=None):
    # Handle application-level exceptions
    # Log or handle the exception as required
    url_path = ""
    client_id = None

    if request:
        url_path = request.url.path
        client_id = get_client_id(request)

    error_code = gen_error_log_code()

    # Return an appropriate response
    status_code = 500

    status_code, user_message = get_human_status_code_msg(status_code)

    pre_formatted_exc = str(exc).replace("\n", "\r")

    logger.error(
        f"| status_code={status_code} | client_id={client_id} | error_type={type(exc).__name__} | error_code={error_code} | msg_to_human={user_message} | url_path={url_path} | exception={pre_formatted_exc} | stack_trace={traceback.format_exc()} |"
    )

    return JSONResponse(
        status_code=status_code,
        content={
            "error_code": error_code,
            "status_code": status_code,
            "status": "error",
            "message": f"{user_message} | Error Code: {error_code}",
        },
        media_type="application/json",
    )


def validation_exception_handler(exc, request=None):
    # Handle request validation errors
    # Log or handle the exception as required
    url_path = ""
    client_id = None

    if request:
        url_path = request.url.path
        client_id = get_client_id(request)

    error_code = gen_error_log_code()

    status_code = 422  # fastapi throws 422 as default

    if hasattr(exc, "status_code"):
        status_code = exc.status_code

    status_code, user_message = get_human_status_code_msg(status_code)

    pre_formatted_exc = str(exc).replace("\n", "\r")

    logger.error(
        f"| status_code={status_code} | client_id={client_id} | error_type={type(exc).__name__} | error_code={error_code} | msg_to_human={user_message} | url_path={url_path} | exception={pre_formatted_exc} | stack_trace={traceback.format_exc()} |"
    )

    # check if the exception has an 'error()' method:
    # found some cases where it was missing.
    error_details = exc.errors() if hasattr(exc, "errors") else str(exc)
    # Return an appropriate response
    return JSONResponse(
        status_code=status_code,
        content={
            "error_code": error_code,
            "status_code": status_code,
            "message": f"{user_message} | Error Code: {error_code}",
            "details": error_details,
        },
    )


def http_exception_handler(exc, request=None):
    # Handle HTTP exceptions raised by your application
    # Log or handle the exception as required

    url_path = ""
    client_id = None

    if request:
        url_path = request.url.path
        client_id = get_client_id(request)

    error_code = gen_error_log_code()

    status_code = 400

    if hasattr(exc, "status_code"):
        status_code = exc.status_code

    message = ""

    if hasattr(exc, "detail"):
        message = exc.detail

    status_code, user_message = get_human_status_code_msg(
        status_code, message=str(message)
    )

    pre_formatted_exc = str(exc).replace("\n", "\r")

    logger.error(
        f"| status_code={status_code} | client_id={client_id} | error_type={type(exc).__name__} | error_code={error_code} | msg_to_human={user_message} | url_path={url_path} | exception={pre_formatted_exc} | stack_trace={traceback.format_exc()} |"
    )

    # Return an appropriate response
    return JSONResponse(
        status_code=status_code,
        content={
            "error_code": error_code,
            "status_code": status_code,
            "status": "error",
            "message": f"{user_message} | Error Code: {error_code}",
        },
    )


def httpx_exception_handler(exc, request=Request):
    # Handle HTTP exceptions raised by your application
    # Log or handle the exception as required
    # attributes = [item for item in dir(exc) if not item.startswith("__")]
    # logger.debug(attributes)

    url_path = ""
    client_id = None

    if request:
        url_path = request.url.path
        client_id = get_client_id(request)

    error_code = gen_error_log_code()

    status_code = exc.response.status_code

    external_api_message = ""

    try:
        external_api_message = exc.response.json()
    except Exception as e:
        external_api_message = exc.response.text
        logger.warning("External API msg is not in JSON format.")

    status_code, user_message = get_human_status_code_msg(
        status_code, upstream_msg=str(external_api_message)
    )

    pre_formatted_exc = str(exc).replace("\n", "\r")
    logger.error(
        f"| status_code={status_code} | client_id={client_id} | error_type={type(exc).__name__} | error_code={error_code} | msg_to_human={user_message} | url_path={url_path} | exception={pre_formatted_exc} | upstream_api_msg={str(external_api_message)} | stack_trace={traceback.format_exc()} |"
    )

    # Return an appropriate response
    return JSONResponse(
        status_code=status_code,
        content={
            "error_code": error_code,
            "status_code": status_code,
            "status": "error",
            "message": f"{user_message} | Error Code: {error_code}",
            "upstream": {
                "message": str(external_api_message),
                "url": str(exc.request.url),
                "method": str(exc.request.method),
            },
        },
    )
