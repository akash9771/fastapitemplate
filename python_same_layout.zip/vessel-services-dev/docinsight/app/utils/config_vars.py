import os

REQUEST_TIMEOUT_SECONDS = 135
OPEN_SEARCH_TIMEOUT_SECONDS = 60
TOKEN_COUNTER_MULTIPLIER = 1.35
TABULAR_EXTENSIONS = [".xlsx", ".csv", ".xls"]
CHUNKS_METADATA = ["filename", "md5", "chunk_no", "batch", "page", "request_id", "docinsight_custom_extraction_id_key", "docinsight_custom_extraction_type", "docinsight_parent_doc_id"]
AGENT_STOPPED_MAX_ITERATIONS = "Agent stopped due to max iterations"
AGENT_FAILED_RESPONSE = "I'm sorry, I don't know the answer to the question. Could you please rephrase or elaborate on your question?"
RETRIEVAL_QA_RESPONSE = "I'm sorry, but the provided context lacks sufficient details about your query. Could you please rephrase or elaborate on your question?"
AGENT_CITATION_FILTER_KEYWORDS = [
    "does not provide information",
    "not possible to determine",
    "does not provide any information",
    "sorry",
    "don't know",
    "no information",
    "this information is not relevant to the data provided in the dataframes",
    AGENT_STOPPED_MAX_ITERATIONS,
]
RETRIEVAL_QA_CITATION_FILTER_KEYWORDS = [
    "no relevant text",
    "context does not mention anything",
    "context is not specified",
    "does not provide information",
    "not possible to determine",
    "does not provide any information",
    "I apologize that I cannot generate the requested",
    "don't know",
    # "sorry",
    # "don't",
    # "does not",
    # "no information"
]
MODEL_TOKEN_MAPPING = os.environ.get("MODEL_TOKEN_MAPPING", {})
