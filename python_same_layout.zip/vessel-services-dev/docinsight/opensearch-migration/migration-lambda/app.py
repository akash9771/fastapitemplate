import requests
from requests_aws4auth import AWS4Auth
import os
import boto3
import json

AWS_REGION_NAME = os.environ["AWS_REGION_NAME"]
SECRET_NAME = os.environ["SECRET_NAME"]


def read_secret_manager_and_return_dict():
    secret_value = None
    try:
        # Initialize the Secrets Manager client
        secret_client = boto3.client("secretsmanager", region_name=AWS_REGION_NAME)

        # Retrieve the secret value
        secret_response = secret_client.get_secret_value(SecretId=SECRET_NAME)

        # Check if the secret is in the 'SecretString' format
        if "SecretString" in secret_response:
            secret_value = secret_response["SecretString"]

    except Exception as SecretFetchException:
        error_msg = f"Unable to fetch secret from Secret Managet to invoke Ingestion API endpoint {str(SecretFetchException)}"
        print(error_msg)
        raise SecretFetchException

    return json.loads(secret_value)


def lambda_handler(event, context):
    try:
        print("Fetching secrets from secrets manager")
        secret_manager_dict = read_secret_manager_and_return_dict()
        print("Fetched secrets from secrets manager")

        register_on_dev = json.loads(secret_manager_dict["register_on_dev"].lower())
        register_on_test = json.loads(secret_manager_dict["register_on_test"].lower())
        register_on_prod = json.loads(secret_manager_dict["register_on_prod"].lower())

        snapshot_bucket = secret_manager_dict["snapshot_bucket"]
        repository_name = secret_manager_dict["repository_name"]
        snapshot_path = secret_manager_dict["snapshot_path"]
        role_arn = secret_manager_dict["role_arn"]

        headers = {"Content-Type": "application/json"}
        service = "es"

        credentials = boto3.Session().get_credentials()
        awsauth = AWS4Auth(
            credentials.access_key,
            credentials.secret_key,
            AWS_REGION_NAME,
            service,
            session_token=credentials.token,
        )
        payload = {
            "type": "s3",
            "settings": {
                "bucket": snapshot_bucket,
                "base_path": snapshot_path,
                "region": AWS_REGION_NAME,
                "role_arn": role_arn,
            },
        }

        # Send the request.
        path = f"/_snapshot/{repository_name}"

        if register_on_dev:
            print("Registering dev repository")
            dev_open_search_domain = secret_manager_dict["dev_open_search_domain"]
            dev_url = dev_open_search_domain + path
            response = requests.put(
                dev_url, auth=awsauth, headers=headers, json=payload
            )
            print(response.status_code)
            print(response.text)

            if response.status_code == 200:
                print(f"Successfully to registered the repository: {repository_name}")
            else:
                print(f"Failed to registered the repository: {repository_name}")

        if register_on_test:
            print("Registering stage repository")
            test_open_search_domain = secret_manager_dict["test_open_search_domain"]
            stage_url = test_open_search_domain + path
            response = requests.put(
                stage_url, auth=awsauth, headers=headers, json=payload
            )
            print(response.status_code)
            print(response.text)

            if response.status_code == 200:
                print(f"Successfully to registered the repository: {repository_name}")
            else:
                print(f"Failed to registered the repository: {repository_name}")

        if register_on_prod:
            print("Registering stage repository")
            prod_open_search_domain = secret_manager_dict["prod_open_search_domain"]
            prod_url = prod_open_search_domain + path
            response = requests.put(
                prod_url, auth=awsauth, headers=headers, json=payload
            )
            print(response.status_code)
            print(response.text)

            if response.status_code == 200:
                print(f"Successfully to registered the repository: {repository_name}")
            else:
                print(f"Failed to registered the repository: {repository_name}")

        return "success"
    except Exception as e:
        print(f"Failed to register the repository {str(e)}")
        return "failure"
