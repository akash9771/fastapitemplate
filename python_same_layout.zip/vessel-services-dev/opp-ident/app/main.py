import logging

from fastapi import FastAPI
from validator.decorators import async_token_validation_and_metering

DEMO_DOSSIER_RESPONSE = {
    "status": "success",
    "trackingId": "3fa85f64-5717-4562-b3fc-2c963f66afa6",
}

DEMO_STATUS_RESPONSE = {
    "status": "success",
    "process_status": "Pending",
    "dossier_pdf_location": "https://assets-12345656-us-east-1.s3.amazonaws.com/dossier.pdf",
    "dossier_json_location": "https://assets-12345656-us-east-1.s3.amazonaws.com/dossier.json",
}

app = FastAPI()

logger = logging.getLogger()
logger.setLevel(logging.WARNING)


@app.get("/opp-ident/health", status_code=200)
async def get_health():
    return {"status": "success"}


@app.post("/opp-ident/dossier", status_code=200)
@async_token_validation_and_metering()
async def create_dossier():
    return DEMO_DOSSIER_RESPONSE


@app.post("/opp-ident/dossier/mock", status_code=200)
@async_token_validation_and_metering()
async def create_dossier_mock():
    return DEMO_DOSSIER_RESPONSE


@app.get("/opp-ident/dossier/status/{tracking_id}", status_code=200)
@async_token_validation_and_metering()
async def get_status(tracking_id):
    return DEMO_STATUS_RESPONSE


@app.get("/opp-ident/dossier/status/mock/{tracking_id}", status_code=200)
@async_token_validation_and_metering()
async def get_status_mock(tracking_id):
    return DEMO_STATUS_RESPONSE
