import logging
import os

import requests

AICORE_API_SERVER_HOST = os.environ.get("VESSEL_REGISRY_API_HOST", "localhost")
AICORE_API_SERVER_PORT = os.environ.get("VESSEL_REGISRY_API_PORT", "80")

AICORE_API_V1_GET_URL_TEMPLATE = 'http://{0}:{1}/api/v4/'.format(AICORE_API_SERVER_HOST, AICORE_API_SERVER_PORT) + '{0}'

HEADER = {
            'Content-Type': 'application/json'
        }

                
class ServiceRegistryAccessor:
    
    @staticmethod
    def get_vsl_app_details(table_name):
        sv_registry_url = AICORE_API_V1_GET_URL_TEMPLATE.format(table_name)
        try:
            vsl_response = requests.request("GET", sv_registry_url)
            if vsl_response.status_code != 200:
                #log exception and raise error
                print('Error Service Registry Status is :', vsl_response.status_code)

            #TBD: move back to python3 json optimization
            return vsl_response.json()['vessel_app']['data']
        
        except Exception as ex:
            print('Error occurred in CreateVesselApp API call. %s', str(ex))
            raise