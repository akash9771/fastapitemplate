import os

from fastapi import FastAPI, Request, BackgroundTasks
from validator.decorators import async_token_validation_and_metering
from .dynamodb_accessor import DynamoDBAccessor
from .service_registry_accessor import ServiceRegistryAccessor
import uuid
import json
import requests
import copy

TEST_ENV  = False

app = FastAPI()

@app.get("/health")
def health():
    return {"message": "I'm healthy"}


@app.post("/contractapi/create_contract")
@async_token_validation_and_metering()
async def contract_api(request: Request=None):
    svc_req = await request.json()
    svc_req = svc_req["service_request"]["data"][0]
    print("testing 4", svc_req)
    if "cost_centre" not in svc_req:
        cost_centre = "N/A"
    else:
        cost_centre = svc_req['cost_centre']
    Item = {
            'contract_id': svc_req['client_id']+svc_req['api_id'],  # mule will send client id + api id
            'client_id': svc_req['client_id'],
            ## not uuid but we will encode it to a uuid and put it in the subsc. table.
            'project_name': svc_req['project_name'], #app_name
            'api_id': svc_req['api_id'],
            ## not uuid but we will encode it to a uuid and put it in the subsc. table.
            'business_email': svc_req['business_email'],
            'support_email': svc_req["support_email"],
            'cost_centre': cost_centre,  # optional for Mule to invoke
            'status': 1,  # not for Mule to invoke
            'cmdb_id': svc_req["cmdb_id"],
            # subscription_id (because uuid) no need to keep this in contract table. Directly can create uuid in subs. table.
            'sub_notes': "Sub Notes of the API",  # not for Mule to invoke
            'contract_status' : str(svc_req["contract_status"]),
            # 'bedrock_regions' : str(svc_req['bedrock_regions']),
            # 'openai_regions' : str(svc_req['openai_regions']),
            'approved_timestamp': str(svc_req["approved_timestamp"]),
            'updated_date': str(svc_req["updated_date"]), 
            'app_name': svc_req['app_name'],
            'environment': svc_req['environment'],
            'api_name': svc_req['api_name'],
            'iprm': svc_req['iprm']
        }
    
    try:
        if svc_req['contract_status'] == 'A':
            svc_req['status'] = 1
        elif svc_req['contract_status'] == 'I':
            svc_req['status'] = 0
        elif svc_req['contract_status'] == 'R':
            svc_req['status'] = 2
        else:
            pass
        status = DynamoDBAccessor.save_contract_details(copy.deepcopy(Item))
    except Exception as error:
        print("Unable to save data in Contract Table:",error)
        return {"service_response":{"success":"0","message": "Failed to acknowledge"}}
        
    try:
        
        # sub_save_data = save_subscription(Item)
        status_sub,sub_save_data = set_subscription_tables(Item)
        if not sub_save_data:
            Item['subscripton_update_status'] = False
        else:
            Item['subscripton_update_status'] = True
    except Exception as e:
        print(e)
    
    
    if status != "success":
        return {"service_response":{"success":"0","message": "Failed to acknowledge"}}
    
    
    return {"service_response":{"success":"1","message": "Acknowledged"}}  # Saved in contract table irrespective of other tables. 




# we might need to right threading code to connect below function with the endpoint call
# usecase id and access token will_get generate by service registry

TRANSACT_ITEMS=[]

def create_transact_items(table_name, json_body):
    print("creating transact items for table-", table_name)
    environment = os.environ.get("ENV", "dev")
    table_name = "vessel-{env}-svc_registry-{table}".format(env=environment, table=table_name)
    temp_dict_items = {
                'Put': {
                    'TableName': table_name,
                    'Item': json_body,
                }
            }
    TRANSACT_ITEMS.append(temp_dict_items)


def set_subscription_tables(svc_request):
    try:
        usecase_id =  str(uuid.UUID(hex=svc_request['client_id']))
        split_app_id = usecase_id.split('-')[4]
        access_token = usecase_id.replace(split_app_id,svc_request['api_id'])

        vsl_service_map_table = os.environ.get("VESSEL_SERVICE_MAP_TABLE", "vessel-dev-svc_mule-mapping")
        vsl_service_cateogry_table = os.environ.get("VESSEL_SERVICE_CATEGORY_TABLE", "vessel-dev-svc_registry-svc_category")
        vsl_service_provider_table = os.environ.get("VESSEL_SERVICE_PROVIDER_TABLE", "vessel-dev-svc_registry-provider_svc_version")
        vsl_service_svc_table = os.environ.get("VESSEL_SERVICE_SVC_TABLE", "vessel-dev-svc_registry-svc")
        version_id_json = DynamoDBAccessor.get_svc_mule_mapping_data(svc_request['api_id'],vsl_service_map_table)
        if len(version_id_json['Items'])<=0:
            version_id = DynamoDBAccessor.create_new_mapping_row(vsl_service_map_table,svc_request['api_id'],svc_request['api_name'])
            svc_rows = DynamoDBAccessor.create_new_svc_rows(version_id,svc_request['api_name'], vsl_service_cateogry_table, vsl_service_svc_table, vsl_service_provider_table)
            if svc_rows:
                print("svc_rows created")
            else:
                print("svc_rows not created")
        else:
            version_id = version_id_json['Items'][0]['svc_version_id']
        
        contract_id = svc_request['client_id'] + svc_request['api_id']
        subscription_id =  str(uuid.uuid5(uuid.NAMESPACE_OID,contract_id))
        print(subscription_id)
        subscription_table = os.environ.get("SUBSCRIPTION", "subscription")
        check_subscription = DynamoDBAccessor.check_subscription(usecase_id,version_id,subscription_table)
        # print(check_subscription)
        # quit()
        if len(check_subscription['Items'])>0:
            app_id = check_subscription['Items'][0]['app_id']
            subscription_id = check_subscription['Items'][0]['subscription_id']
        else:
            app_id =  str(uuid.uuid4())
        
        
        #To do - need to make subnotes more clear
        sub_notes = {
            'contract_status' : svc_request['contract_status'],
            'updated_date' : svc_request['updated_date']
        }
        sub_notes = json.dumps(sub_notes)

        vsl_app_table_sv_registry = os.environ.get("SVC_REGISTRY_VESSEL_APP", "vessel_app")
        #check if data exist in vessel app, if yes then don't makea  new entry in table
        # get_vsl_apps_data =  ServiceRegistryAccessor.get_vsl_app_details(vsl_app_table_sv_registry)
        vsl_app_table = os.environ.get("VESSEL_APP_TABLE", "vsl_app")
 
        # if not vsl_app_exists:
        print('Saving data in Vsl_app')
        # print(app_id)
        if svc_request['cmdb_id'] == '' or svc_request['cmdb_id'] is None or svc_request['cmdb_id'] == ' ':
            svc_request['cmdb_id'] = "None"
        else:
            print(svc_request['cmdb_id'], "cmdb_id")
        vsl_app_body={
                    "app_id": app_id,
                    "app_cmdb" : svc_request['cmdb_id'],
                    "app_cost_center":svc_request['cost_centre'],
                    "app_meta" :"None",
                    "app_iprm" : "None",
                    "app_name" : svc_request['app_name'],
                    "app_type_id" : 1,
                    "status_id" : 1
                }
            
            # print(vsl_app_body)
        vsl_app_table = os.environ.get("VESSEL_APP_TABLE", "vsl_app")
        create_transact_items(vsl_app_table,vsl_app_body)      
        sub_usecase_id_body = {
                    "usecase_id" :usecase_id,
                    "usecase_code" : svc_request['project_name'],
                    "usecase_name" :svc_request['project_name']
                    }
        sub_usecase_id_table = os.environ.get("SUBSCRIPTION_USECASE_ID_TABLE", "subscription_usecase_id")
        create_transact_items(sub_usecase_id_table,sub_usecase_id_body)
        
        subscription_body = {
            "svc_version_id" : version_id,
            "subscription_id" : subscription_id,
            "access_token" : access_token,
            "app_id":app_id,
            "cost_center" : svc_request['cost_centre'],
            "email" : svc_request['business_email'],
            "status_id" : svc_request['status'],
            "sub_notes" : sub_notes,
            "usecase_id":usecase_id,
            "tok_exp_date" : "12/31/2120"
        }
        subscription_table = os.environ.get("SUBSCRIPTION", "subscription")
        create_transact_items(subscription_table,subscription_body)
        print('All Items Before Transact', len(TRANSACT_ITEMS))
        print(TRANSACT_ITEMS)
        transactions = DynamoDBAccessor.save_transaction(TRANSACT_ITEMS)
        TRANSACT_ITEMS.clear()

        #we need to refresh the cache
        try:
            refresh_cache_test()
        except Exception as e:
            raise "Unable to refresh cache"
        # fetch data from the cache
        # access_token = "54abfae3-844d-4502-a893-18691005"
        # print('access_token',access_token)
        # get_cache_details = AppCache.get_cache_contract_details(f'ai_sub:api_key_{access_token}')
        # print('fdsfdfs')
        # print(get_cache_details,"cache detals")
        # print('gettting cachec data')
        if TEST_ENV:
            print('Running in Test Environment')
            return_json = {
                'data':{
                    'usecase_id' : usecase_id,
                    'app_id' : app_id,
                    'api_id' : version_id,
                    'access_token' : access_token
                },
                'status' : True
            }
        else:
            return_json = {
                'status' : True
            }
        return True, return_json
    except Exception as e:
        print("Error coming while saving data in subscription tables", e)
        return_json = {
                'status' : False,
                'Message' : f"Error coming while saving data in subscription tables: {e}"
            }
        return False, return_json


def refresh_cache_test():
    url = os.environ.get("CACHE_URL", "http://vessel-dev.pfizer.com/api/admin/cache/refresh")
    response = requests.request("GET", url)
    print(response.text)

