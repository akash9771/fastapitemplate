# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import abc
import json
import os
import logging
import uuid
import json
import datetime

import boto3

import requests

from boto3.dynamodb.conditions import Key
from botocore.exceptions import ClientError

aws_access_key_id = os.environ.get(
    "DYNAMO_DB_AWS_ACCESS_KEY_ID", "DYNAMO_DB_AWS_ACCESS_KEY_ID"
)
aws_secret_access_key = os.environ.get(
    "DYNAMO_DB_AWS_SECRET_ACCESS_KEY", "DYNAMO_DB_AWS_SECRET_ACCESS_KEY"
)
aws_region = os.environ.get("DYNAMO_DB_AWS_REGION", "us-east-1")
contract_table = os.environ.get("CONTRACT_TABLE", "vessel-test-contract-details")


# DynamoDB accessor that implements MeteringSvcDbAccessor protocol
class DynamoDBAccessor:
    g_aicore_sess = None

    # Handle transient errors using exponential backoff with Jitter
    # Wait 2^i * 100 ms, on the i-th retry | wait 20 second per try maximum
    # (TODO: Move these values to Configuration)
    @staticmethod
    def get_db_session(force_reset=False):
        # VESSEL_DB_HOST env contain the DB host
        #

        try:
            session = boto3.Session()
            DynamoDBAccessor.g_aicore_sess = session.resource(
                "dynamodb", region_name=aws_region
            )

            return DynamoDBAccessor.g_aicore_sess
        except Exception as ex:
            DynamoDBAccessor.g_aicore_sess = None
            logging.warning(
                "Error in Opening a Dynamodb Connection. It will be Retried. %s",
                str(ex),
            )
            raise

    @staticmethod
    def save_contract_details(record):
        try:
            aicore_sess = DynamoDBAccessor.get_db_session()

            table = aicore_sess.Table(contract_table)
            response = table.get_item(
                Key={
                    "contract_id": record["contract_id"],
                    "client_id": record["client_id"],
                }
            )
            if "Item" in response:
                print("Item found, doing the update")
                # existing_item =  response['Item']
                update_key = {
                    "contract_id": record["contract_id"],
                    "client_id": record["client_id"],
                }
                del record["contract_id"]
                del record["client_id"]
                del record["status"]
                update_expression = "SET "
                expression_attribute_values = {}
                for key, value in record.items():
                    update_expression += f"{key} = :{key}, "
                    expression_attribute_values[f":{key}"] = value

                update_expression = update_expression[:-2]
                table.update_item(
                    Key=update_key,
                    UpdateExpression=update_expression,
                    ExpressionAttributeValues=expression_attribute_values,
                )

            else:
                print("Item Not Found, creting the item in contract table")
                table.put_item(Item=record)
            return "success"
        except Exception as ex:
            logging.warn(
                "Error occurred in Vessel Contract DB :DynamoDBAccessor. %s", str(ex)
            )
            return "failure"

    @staticmethod
    def get_svc_mule_mapping_data(api_id, table_name):

        try:
            aicore_sess = DynamoDBAccessor.get_db_session()

            svc = aicore_sess.Table(table_name)

            response = svc.query(
                KeyConditionExpression=Key("api_id").eq(api_id),
                ConsistentRead=True,
            )
            print("gettting mapping version data")
            return response
        except Exception as error:
            print("Unable to get data from mule mapping table", error)
            raise error

    @staticmethod
    def check_subscription(sub_id, version_id, table_name):
        environment = os.environ.get("ENV", "dev")
        aicore_sess = DynamoDBAccessor.get_db_session()
        table_name = "vessel-{env}-svc_registry-{table}".format(
            env=environment, table=table_name
        )

        print(table_name)

        svc = aicore_sess.Table(table_name)
        # response = svc.get_item(
        # TableName=table_name,
        # Key={
        #     'api_id' : {'S':'18674674'}
        # }
        # )

        scan_kwargs = {
            "FilterExpression": Key("usecase_id").eq(sub_id),
            # & Key("svc_version_id").eq(version_id),
            # "ExpressionAttributeValues": {":val": {"S": sub_id}, ":version_id" : {"S" : version_id}},
            "ProjectionExpression": "app_id, subscription_id",
        }
        response = svc.scan(**scan_kwargs)
        print("getting subscripiton dat")
        return response

    
    @staticmethod
    def create_new_mapping_row(table_name, api_id, api_name):
        version_id = str(uuid.uuid4())
        item = {
            'svc_name' : api_name,
            'api_id' : api_id,
            'svc_version_id' : version_id
        }
        
        aicore_sess = DynamoDBAccessor.get_db_session()
        try:
            svc = aicore_sess.Table(table_name)
            response = svc.put_item(Item=item)
            return version_id
        except Exception as e: 
            raise f"Unable to create new row in mapping table for the new api id {api_id}, error coming--,{e}"
    
    
    @staticmethod
    def create_new_svc_rows(version_id, api_name, category_table_name, svc_table_name, provider_table_name):
        aicore_sess = DynamoDBAccessor.get_db_session()
        category_id = str(uuid.uuid4())
        provider_id = str(uuid.uuid4())
        svc_id = str(uuid.uuid4())
        category_item = {
            "svc_cat_id" : category_id,
            "cat_desc" : api_name,
            "cat_name" : api_name,
            "status_id" : 1        
        }
        provider_item = {
            "svc_id" : svc_id,
            "version_id" : version_id,
            "docu_notes" : "https://confluence.pfizer.com/pages/viewpage.action?pageId=302695827",
            "is_deprecated" : 0,
            "provider_id" : provider_id,
            "provider_version" : "1,0",
            "sunset_date" : "3520-11-25",
            "svc_classifier_id" : 1,
            "version_num" : "1,0"

        }
        svc_item = {
            "svc_id" : svc_id,
            "status_id" : 1,
            "svc_cat_id" : category_id,
            "svc_desc" : api_name,
            "svc_type_id" : 1,
            "svc_name" : api_name,
            "svc_url_label" : api_name
            
        }
        svc_category = aicore_sess.Table(category_table_name)
        response_category = svc_category.put_item(Item = category_item)
        
        svc_provider  = aicore_sess.Table(provider_table_name)
        response_provider= svc_provider.put_item(Item = provider_item)
        
        svc  = aicore_sess.Table(svc_table_name)
        response_svc = svc.put_item(Item = svc_item)
        
        if response_category['ResponseMetadata']['HTTPStatusCode'] ==200 and response_provider['ResponseMetadata']['HTTPStatusCode'] ==200 and response_svc['ResponseMetadata']['HTTPStatusCode'] ==200:
           return True
        else:
            return False
            
    @staticmethod
    def get_all_vessel_app_data(table_name):
        environment = os.environ.get("ENV", "dev")
        aicore_sess = DynamoDBAccessor.get_db_session()
        table_name = "vessel-{env}-svc_registry-{table}".format(
            env=environment, table=table_name
        )
        print(table_name)

        svc = aicore_sess.Table(table_name)
        # response = svc.get_item(
        # TableName=table_name,
        # Key={
        #     'api_id' : {'S':'18674674'}
        # }
        # )

        scan_kwargs = {
            #    "FilterExpression": Key('subscription_id').eq(sub_id) & Key('svc_version_id').eq(version_id),
            # "ExpressionAttributeValues": {":val": {"S": sub_id}, ":version_id" : {"S" : version_id}},
            # "ProjectionExpression": "app_id, usecase_id"
        }
        response = svc.scan(**scan_kwargs)
        print("getting vessel app dat")
        return response.get("Items")

    @staticmethod
    def save_transaction(Items):
        print("runing transaction")
        aicore_sess = DynamoDBAccessor.get_db_session()
        # transaction = aicore_sess.meta.create_transaction()
        client = aicore_sess.meta.client
        # ?client.transact_write_items(TransactItems = Items)
        # print(dir(client))
        # quit()

        # svc = aicore_sess.Table(contract_table)
        try:
            # transaction.put_transact_item(TransactItems = Items)
            response = client.transact_write_items(TransactItems=Items)
        except ClientError as e:
            print(e)
            print(e.response["Error"]["Message"])
            raise e
        else:
            print("response", response)
            print("Transact Write succeeded")
            
