from fastapi import Request
import traceback
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
import json

class CustomJSONResponse(JSONResponse):
    def __init__(self,content,status_code,totaltokensllm=None,totaltokensembedding=None):
        super().__init__(status_code=status_code,content=content)
        self.totaltokensembedding = totaltokensembedding
        self.totaltokensllm=totaltokensllm
     
    def json(self):
        return self.body

def get_client_id(request):
    url_path = ""
    client_id = None

    if request:
        url_path = request.url.path
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
    return url_path,client_id


def generate_api_success_response(status_code = 200 , message="", body={}):
    """Handles success response"""

    return CustomJSONResponse(
        status_code=status_code,
        content= {
            "success": True,
            "message": message,
            "details":jsonable_encoder((body))
        }
    )

def generate_api_success_response_raw(status_code = 200 , body={},totaltokensllm=None,totaltokensembedding=None):
    """Handles success response rw"""

    return CustomJSONResponse(
        status_code=status_code,
        content= jsonable_encoder((body))
        ,
        totaltokensllm=totaltokensllm,
        totaltokensembedding=totaltokensembedding
    )

