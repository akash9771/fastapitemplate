cust_separators_list = ['paragraph','sentence','word', 'character']
no_of_files = 20
file_size = 30
split_by = ['tokens','characters']