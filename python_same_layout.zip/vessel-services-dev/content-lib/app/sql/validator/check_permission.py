from functools import wraps
import requests
from starlette.responses import JSONResponse
from fastapi import status
import json
from app.commons.config import config
import os

USER_MANAGEMENT_URL = config.USER_MANAGEMENT_URL
PINGFEDERATE_URL = config.PINGFEDERATE_URL
CLIENT_ID = os.environ.get("CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET", "")

def federate_auth() -> str:
    """Obtains auth access token for accessing UMS endpoints"""
    try:
        payload = f"client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
        }
        response = requests.post(PINGFEDERATE_URL, headers=headers, data=payload)
        token = response.json()["access_token"]
        return token
    except requests.exceptions.HTTPError as e:
        print("HTTP Error:", e.response.status_code, e)
    except requests.exceptions.ConnectionError as e:
        print("Connection Error:", e.response.status_code, e)
    except requests.exceptions.Timeout as e:
        print("Timeout Error:", e.response.status_code, e)
    except requests.exceptions.RequestException as e:
        print("Other Error:", e.response.status_code, e)

AUTHORIZATION_TOKEN = None
X_AUTH_TOKEN = None

def validate_permission():
    def decorator(func):
        @wraps(func)
        async def wrapper(request, *args, **kwargs):
            token=federate_auth()
            AUTHORIZATION_TOKEN = f"Bearer {token}"
            X_AUTH_TOKEN = request.headers["x-auth"]
            headers = {
                "Authorization" : AUTHORIZATION_TOKEN,
                "x-auth": X_AUTH_TOKEN
            }
            tenant_id = request.headers["x-agw-client_id"]
            print("tenant_id - ", tenant_id)
            userInfo = request.state.userInfo
            user_groups = userInfo['group']
            service_name = str(request.scope["raw_path"]).split("/")[1]
            entity_id = request.scope["route"].__dict__["path"]
            print(entity_id)
            action = request.method
            user_group_list = []
            for group in user_groups:
                group_name = group.split("=")[1].split(",")[0]
                user_group_list.append(group_name)
            payload = {"groups": user_group_list,"entity": entity_id, "action": action}
            response = requests.post(USER_MANAGEMENT_URL.format(f"tenant/{tenant_id}/permissions"), json=payload, headers=headers,verify=True)  # Use verify=True for certificate validation
            try:
                response.raise_for_status()  # Raise an error for bad responses
                response_data = response.json()
                if response_data.get("success", False):
                    return await func(request, *args, **kwargs)
            except requests.exceptions.RequestException as e:
                return JSONResponse(status_code=status.HTTP_403_FORBIDDEN,
                                        content={
                                            "success": False,
                                            "status_code": 403,
                                            "detail": "Access to the requested resource is denied"})
        return wrapper
    return decorator