from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum, JSON
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.sql.database.db_manager import Base
from app.sql.schemas.enums import IndexTypeEnum, ContentStatus, LengthType, ChunkAlgoType, DocType, ChunkType

class ContentSplittingORM(Base):
    __tablename__ = "content_splitting"
    __table_args__ = {"extend_existing": True}
    content_splitting_id = Column(Integer, primary_key=True, autoincrement=True)
    chunk_size = Column(Integer)
    chunk_overlap = Column(Integer)
    chunking_algorithm = Column(Enum(ChunkAlgoType))
    split_document_by = Column(String)
    length = Column(Enum(LengthType))
    content_index_id = Column(Integer, ForeignKey('content_index.content_index_id'))
    content_index = relationship('ContentIndexORM')

class ChunkMetadataORM(Base):
    __tablename__ = "content_metadata_table"
    __table_args__ = {"extend_existing": True}
    chunk_metadata = Column(String)
    content_metadata_id = Column(Integer, primary_key=True, autoincrement=True)
    chunk_type = Column(Enum(ChunkType))
    created_at = Column(DateTime, default=func.now())
    content_index_id = Column(Integer, ForeignKey('content_index.content_index_id'))
    document_id = Column(Integer, ForeignKey('document_table.document_id'))
    content_index = relationship('ContentIndexORM')
    document = relationship('DocumentORM')

class DocumentORM(Base):
    __tablename__ = "document_table"
    __table_args__ = {"extend_existing": True}
    document_id = Column(Integer, primary_key=True, autoincrement=True)
    content_index_id = Column(Integer, ForeignKey('content_index.content_index_id'))
    content_index = relationship('ContentIndexORM')
    doc_type = Column(Enum(DocType))
    file_name = Column(String)
    doc_source = Column(String)
    md5 = Column(String)
    chunks = relationship('ChunkMetadataORM', back_populates='document', cascade='all, delete')

class ClientContentMappingORM(Base):
    __tablename__ = "client_content_mapping"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, autoincrement=True)
    client_id = Column(String)
    content_id = Column(Integer, ForeignKey('content_index.content_index_id'))
    content_index = relationship('ContentIndexORM')

class ContentIndexORM(Base):
    __tablename__ = "content_index"
    __table_args__ = {"extend_existing": True}
    nt_id = Column(String)
    index_type = Column(Enum(IndexTypeEnum))
    content_index_id = Column(Integer, primary_key=True, autoincrement=True)
    content_index_name = Column(String,unique=True)
    content_description = Column(String)
    content_status = Column(Enum(ContentStatus))
    meta_tags = Column(String)
    created_by = Column(String)
    created_date = Column(DateTime)
    last_modified_date = Column(DateTime)
    last_modified_by = Column(String)
    chunks = relationship('ChunkMetadataORM', back_populates='content_index', cascade='all, delete')
    content_splitting = relationship('ContentSplittingORM', back_populates='content_index', cascade='all, delete')
    document = relationship('DocumentORM', back_populates='content_index', cascade='all, delete')