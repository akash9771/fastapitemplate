import setuptools
from setuptools import find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="user_management",
    version="0.1.0",
    author="Akinkunmi, Akinbode Akinpo",
    author_email="akinbode.akinkunmi@pfizer.com",
    description="Pfizer User Management built from IAS Engineering Team",
    long_description=long_description,
    py_modules=['Adapter'],
    long_description_content_type="text/markdown",
    license="MIT",
    packages=find_packages(),
    package_data={'':["model.conf"]},
    install_requires=[
        'casbin',
        'SQLAlchemy'
    ],
)