import casbin
from app.sql.dependencies.abac.user_management.Adapter import Adapter,CasbinRule
import os
from sqlalchemy import or_,cast,String,exc
from sqlalchemy.orm import sessionmaker


class PolicyStore():

    def __init__(self,engine):
        self.engine = engine
        self.session = sessionmaker(bind=engine)

    def initialize_casbin(self):
        Adapter_ = Adapter(self.engine)
        model_conf_path = os.path.join(os.path.dirname(__file__), 'model.conf')
        enforcer = casbin.Enforcer(model_conf_path, Adapter_)
        return enforcer

    def fetch_policies(self, tenant_id):
        enforcer = self.initialize_casbin()
        policies = enforcer.get_filtered_policy(0, tenant_id)
        return policies

    def check_access(self,tenant_id,requester,entity,permission):
        enforcer = self.initialize_casbin()  
        policy = enforcer.get_filtered_policy(0,tenant_id,"INDIVIDUAL",requester,entity,permission)

        if len(policy)<1:
            policy = enforcer.get_filtered_policy(0,tenant_id,"GROUP",requester,entity,permission)

        if len(policy) > 0 and policy[0][5] == "TRUE":
            return True
        else:
            return False
    
    def add_policy(self,tenant_id,user_type,requester,entity,permission):
        enforcer = self.initialize_casbin()  
        user_type = user_type.upper()
        existing_policy = enforcer.get_filtered_policy(0,tenant_id,user_type,requester,entity,permission)

        if len(existing_policy)>0 and existing_policy[0][5] == "FALSE":
                enforcer.remove_policy(tenant_id, user_type, requester, entity, permission, "FALSE")
        elif len(existing_policy)>0 and existing_policy[0][5] == "TRUE":
            return "Policy already exists"
            
        enforcer.add_policy(tenant_id, user_type, requester, entity, permission, "TRUE")
        return "Policy added successfully"

    def remove_policy(self,tenant_id,user_type,requester,entity,permission):
        enforcer = self.initialize_casbin()  
        user_type = user_type.upper()
        existing_policy = enforcer.get_filtered_policy(0,tenant_id,user_type,requester,entity,permission)

        if len(existing_policy)>0 and existing_policy[0][5] == "FALSE":
                return "Policy already removed"
        elif len(existing_policy)>0 and existing_policy[0][5] == "TRUE":
            enforcer.remove_policy(tenant_id, user_type, requester, entity, permission, "TRUE")
            enforcer.add_policy(tenant_id, user_type, requester, entity, permission, "FALSE")
            return "Policy removed successfully"
        return "Policy doesn't exist"
    
    def copy_policy(self,tenant_id,source_grp,target_grp,entity_override = None):
        enforcer = self.initialize_casbin()  
        policies_in_target = enforcer.get_filtered_policy(0,tenant_id,"GROUP",source_grp)
        override_resources = None
        total_added_policy_count = 0
        if type(entity_override) == dict:
            override_resources = list(entity_override.keys())
        for _,_,_,entity,permission,_ in policies_in_target:    
                if override_resources is not None and (entity in override_resources or "*" in override_resources) :
                    permission = entity_override[entity] if entity in override_resources else entity_override["*"]
                    for override_permission in permission:
                        self.add_policy(tenant_id,"GROUP",target_grp,entity,override_permission)
                        total_added_policy_count+=1
                else:
                    self.add_policy(tenant_id,"GROUP",target_grp,entity,permission)   
                    total_added_policy_count+=1
        return f"Policies copied successfully. Total copied policy : {total_added_policy_count}"
    
    def get_accessible_records(self,tenant_id, groups, Model, joinColumnName):
        try:
            with self.session() as transaction_session:
                query = transaction_session.query(Model)
                query = query.join(CasbinRule, cast(CasbinRule.entity, String) == cast(getattr(Model, joinColumnName), String))
                query = query.filter(CasbinRule.tenant_id == tenant_id)
                or_filters = [CasbinRule.group == group for group in groups]
                query = query.filter(or_(*or_filters))
                return query
        except exc.SQLAlchemyError as e:
            print(f"An error occurred: {e}")


