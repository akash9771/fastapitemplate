import psycopg2
from psycopg2 import sql
import json
import os
import uuid
from datetime import datetime
from fastapi import HTTPException
from app.commons.config import config

BIOPHARMA_CONTENT_LIB_INDEX=os.getenv("BIOPHARMA_CONTENT_LIB_INDEX")
SOURCE_DB_NAME=os.getenv("DB_NAME")
SOURCE_DB_USERNAME=os.getenv("DB_USERNAME")
SOURCE_DB_PASSWORD=os.getenv("DB_PASSWORD")
SOURCE_DB_ENDPOINT=os.getenv("DB_ENDPOINT")
PORT='5432'
BIOPHARMA_OPENSEARCH_INDEX=os.getenv("BIOPHARMA_OPENSEARCH_INDEX")
TARGET_DB_NAME=os.getenv("TARGET_DB_NAME")
TARGET_DB_USERNAME=os.getenv("TARGET_DB_USERNAME")
TARGET_DB_PASSWORD=os.getenv("TARGET_DB_PASSWORD")
TARGET_DB_ENDPOINT=os.getenv("TARGET_DB_ENDPOINT")

def generate_uuid():
    """
    Generate a UUID (Universally Unique Identifier).

    Returns:
        str: UUID in string format.
    """
    return str(uuid.uuid4())

def connect_to_source_database():
    try:
        connection = psycopg2.connect(dbname=SOURCE_DB_NAME, user=SOURCE_DB_USERNAME, password=SOURCE_DB_PASSWORD, host=SOURCE_DB_ENDPOINT, port=PORT)
        return connection
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Error: Unable to connect to the database\n{e}")

def connect_to_target_database():
    try:
        connection = psycopg2.connect(dbname=TARGET_DB_NAME, user=TARGET_DB_USERNAME, password=TARGET_DB_PASSWORD, host=TARGET_DB_ENDPOINT, port=PORT)
        return connection
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Error: Unable to connect to the database\n{e}")

def extract_data(cursor, content_index_id):
    try:
        source_data_query="select * from public.document_table where content_index_id = {} and md5 is not NULL".format(content_index_id)
        cursor.execute(source_data_query)
        col_names = [desc[0] for desc in  cursor.description]
        result=[
            {col_name:row[value] for value,col_name in enumerate(col_names)}
            for row in cursor.fetchall()
        ]
        return result
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Error during data extraction\n{e}")

def transform_data(source_data, client_id):
    try:
        transformed_data = []
        for data in source_data:
            target_data = {
                "client_id": client_id,
                "request_id": generate_uuid(),
                "index": BIOPHARMA_OPENSEARCH_INDEX,
                "document": data['file_name'],
                "document_md5": data['md5'],
                "attached_metadata": "",
                "status": "Completed",
                "error_message": None,
                "queued_ts": datetime.now(),
                "inprogress_ts": datetime.now(),
                "completed_errored_ts": None,
                "created_ts": datetime.now(),
                "vec_db_deletion_status": None,
                "is_file_deleted": False,
                "modified_ts": datetime.now(),
                "file_path": None
            }
            transformed_data.append(target_data)
        return transformed_data
    except Exception as e:
        raise HTTPException(status_code=404, detail=f"Error during data transformation\n{e}")

def load_data(transformed_data):
    connection = connect_to_target_database()
    if connection:
        print("Successfully connected to the target database")
        try:
            with connection:
                with connection.cursor() as cursor:
                    insert_query = sql.SQL("""
                    INSERT INTO public.data_ingestion_status_table (
                        client_id, request_id, index, document, document_md5, attached_metadata,
                        status, error_message, queued_ts, inprogress_ts, completed_errored_ts,
                        created_ts, vec_db_deletion_status, is_file_deleted, modified_ts, file_path
                    ) VALUES (
                        %(client_id)s, %(request_id)s, %(index)s, %(document)s, %(document_md5)s, %(attached_metadata)s,
                        %(status)s, %(error_message)s, %(queued_ts)s, %(inprogress_ts)s, %(completed_errored_ts)s,
                        %(created_ts)s, %(vec_db_deletion_status)s, %(is_file_deleted)s, %(modified_ts)s, %(file_path)s
                    )""")
                    # Insert multiple records
                    total_records_migrated=0
                    for record in transformed_data:
                        attached_metadata = {
                            'filename': record['document'].replace("'", "''"),
                            'md5': record['document_md5'],
                            'group': 'biopharma',
                            'tag': 'migrated'
                        }
                        values = {
                            'client_id': record['client_id'],
                            'request_id': record['request_id'],
                            'index': record['index'],
                            'document': record['document'],
                            'document_md5': record['document_md5'],
                            'attached_metadata': str(attached_metadata),
                            'status': record['status'],
                            'error_message': record['error_message'],
                            'queued_ts': record['queued_ts'],
                            'inprogress_ts': record['inprogress_ts'],
                            'completed_errored_ts': record['completed_errored_ts'],
                            'created_ts': record['created_ts'],
                            'vec_db_deletion_status': record['vec_db_deletion_status'],
                            'is_file_deleted': record['is_file_deleted'],
                            'modified_ts': record['modified_ts'],
                            'file_path': record['file_path']
                        }
                        cursor.execute(insert_query, values)
                        total_records_migrated+=1
                    # Commit the changes to the database
                    connection.commit()
                    return total_records_migrated
        except Exception as e:
            raise HTTPException(status_code=404, detail=f"Error during data loading\n{e}")
        finally:
            connection.close()
    else:
        raise HTTPException(status_code=404, detail="Failed to connect to the target database")

class DataMigrateController:
    def data_migrate(self,client_id):
        if config.IS_MIGRATION=="False":
            raise HTTPException(status_code=401, detail="Unauthorized access")
        connection = connect_to_source_database()
        if connection:
            try:
                with connection:
                    with connection.cursor() as cursor:
                        source_data= extract_data(cursor,content_index_id=BIOPHARMA_CONTENT_LIB_INDEX)
                        transformed_data=transform_data(source_data=source_data,client_id=client_id)
                        total_records_migrated=load_data(transformed_data=transformed_data)
                        return total_records_migrated
            except Exception as e:
                raise HTTPException(status_code=404, detail=f"Error during migration process\n{e}")
            finally:
                connection.close()