from app.sql.crud.chunk_metadata_crud import CRUDChunkMetadata
from app.logs.logger_config import logger
import ast
from app.commons.exceptions import BadRequestException
from app.commons.errors import get_err_json_response

class ChunkMetadataController:
    def __init__(self):
        self.CRUDChunkMetadata = CRUDChunkMetadata()

    def create_chunk_metadata_controller(self, request):
        chunk_metadata = request.__dict__ 
        content_res =  self.CRUDChunkMetadata.create(**chunk_metadata)
        return content_res
    def get_chunk_metadata(self,content_index_id,document_id):
        try:
            obj =  self.CRUDChunkMetadata.get(content_index_id,document_id)
            if obj is None:
                raise BadRequestException("chunks not found")
            res = []
            section_set = set()
            for chunk in obj:
                chunk = chunk.__dict__
                chunk_metadata = self.extract_chunk_metadata(chunk) 

                if "section" in chunk_metadata.keys() and chunk_metadata["section"] is not None and len(chunk_metadata["section"]) > 0 and chunk_metadata["section"] not in section_set:
                    section_set.add(chunk_metadata["section"])
                    res.append({
                    "content_metadata_id": chunk["content_metadata_id"],
                    "section": chunk_metadata["section"]
                    })
            return res
        except BadRequestException as e:
            logger.error("error in get chunk-metadata controller")
            return get_err_json_response(
                f"Error in chunk-metadata controller: {str(e)}",
                e.args,
                404
            )
            
    def get_chunk_by_metadata_id(self,content_metadata_id):
        obj = self.CRUDChunkMetadata.get_by_metadata_id(content_metadata_id)
        return obj
    def extract_chunk_metadata(self,chunk_metadata_dict):
        return ast.literal_eval(chunk_metadata_dict["chunk_metadata"])