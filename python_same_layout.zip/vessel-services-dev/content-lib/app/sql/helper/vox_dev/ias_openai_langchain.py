from typing import Any, List, Mapping, Optional

from langchain.callbacks.manager import CallbackManagerForLLMRun
from langchain.llms.base import LLM
import requests
import json
from langchain.embeddings.base import Embeddings
import os
import backoff
import logging

logger = logging.getLogger()

CLIENT_ID = os.environ.get("CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET", "")
PINGFEDERATE_URL = os.environ.get("PINGFEDERATE_URL", "")
IAS_OPENAI_CHAT_URL = os.environ.get("IAS_OPENAI_CHAT_URL", "")
IAS_OPENAI_URL = os.environ.get("IAS_OPENAI_URL", "")
IAS_EMBEDDINGS_URL = os.environ.get("IAS_EMBEDDINGS_URL", "")


#To Raise Generic OPENAI EMBEDDING ERROR
class GenericEmbeddingException(Exception):
    pass

# Raise a Genering Exception for OpenAI Throttling
class OpenAIThrottlingException(Exception):
    pass

def federate_auth() -> str:
    """Obtains auth access token for accessing GPT endpoints"""
    try:
        payload = f"client_id={CLIENT_ID}&client_secret={CLIENT_SECRET}"
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
        }
        response = requests.post(PINGFEDERATE_URL, headers=headers, data=payload)
        token = response.json()["access_token"]
        return token
    except requests.exceptions.HTTPError as e:
        print("HTTP Error:", e.response.status_code, e)
    except requests.exceptions.ConnectionError as e:
        print("Connection Error:", e.response.status_code, e)
    except requests.exceptions.Timeout as e:
        print("Timeout Error:", e.response.status_code, e)
    except requests.exceptions.RequestException as e:
        print("Other Error:", e.response.status_code, e)

@backoff.on_exception(backoff.expo, OpenAIThrottlingException,max_tries=20, max_time=60)
def ias_openai_chat_completion(
    token: str, user_message: str, engine: str, temperature: str, max_tokens: int, system_message: str = None, client_id: str = None,
    x_vsl_client_id: str = None
) -> str:
    """
    Generates a chat completion response for OpenAI model
    :param token: auth token
    :param user_message: user's prompt
    :param engine: model capable for chat completion i.e. gpt*
    :param temperature: value 0-1 that tells model to be more precise or generative
    :param max_tokens: max tokens the prompt & response should be. It depends on the model's capacity
    :return: response from OpenAI model
    """
    try:
        payload = {
                "engine": engine,
                "messages": [
                    {"role": "user", "content": user_message},
                ],
                "temperature": temperature,
                "max_tokens": max_tokens,
            }

        if system_message:
            payload["messages"].insert(0, {"role": "system", "content": system_message})
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            
        }

        if x_vsl_client_id is not None:
            headers["x-vsl-client_id"] = x_vsl_client_id
        elif client_id is not None:
            headers["x-vsl-client_id"] = client_id
        
        logger.info("In open AI CHAT COMPLETION FUNCTION PHASE1")
        response = requests.post(IAS_OPENAI_CHAT_URL, headers=headers, json=payload)
        logger.info("In open AI CHAT COMPLETION FUNCTION PHASE2")
        if response.status_code !=200:
            logger.error(
                f"Error calling OpenAI chat completion  API: {response.status_code}, {response.json()}"
            )
            raise Exception(
                f"Error calling OpenAI chat completion  API: {response.status_code}, {response.json()}"
            )

        chat_completion = json.loads(response.json()["result"])["content"]

        logger.info("In open AI CHAT COMPLETION FUNCTION PHASE3")
        # chat_completion = json.loads(response.json())
        return chat_completion
    except requests.exceptions.HTTPError as e:
        print("HTTP Error:", e.response.status_code, e)
    except requests.exceptions.ConnectionError as e:
        print("Connection Error:", e.response.status_code, e)
    except requests.exceptions.Timeout as e:
        print("Timeout Error:", e.response.status_code, e)
    except requests.exceptions.RequestException as e:
        print("Other Error:", e.response.status_code, e)

@backoff.on_exception(backoff.expo, OpenAIThrottlingException, max_tries=20, max_time=60)
def ias_openai_completion(
    token: str, user_message: str, engine: str, temperature: str, max_tokens: int
) -> str:
    """
    Generates a completion response for OpenAI model
    :param token: auth token
    :param user_message: user's prompt
    :param engine: model capable for completion
    :param temperature: value 0-1 that tells model to be more precise or generative
    :param max_tokens: max tokens the prompt & response should be. It depends on the model's capacity
    :return: response from OpenAI model
    """
    try:
        payload = json.dumps(
            {
                "engine": engine,
                "prompt": user_message,
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
        )
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }

        response = requests.post(IAS_OPENAI_URL, headers=headers, data=payload)
        completion_resp = response.json()
        completion = completion_resp["result"]
        return completion
    except requests.exceptions.HTTPError as e:
        print("HTTP Error:", e.response.status_code, e)
    except requests.exceptions.ConnectionError as e:
        print("Connection Error:", e.response.status_code, e)
    except requests.exceptions.Timeout as e:
        print("Timeout Error:", e.response.status_code, e)
    except requests.exceptions.RequestException as e:
        print("Other Error:", e.response.status_code, e)


@backoff.on_exception(backoff.expo, GenericEmbeddingException, max_tries=20, max_time=60)
def ias_openai_embeddings(token: str, raw_text, engine: str):
    try:
        url = IAS_EMBEDDINGS_URL
        print("used URL for this req", url)

        payload = json.dumps({"input": raw_text, "engine": engine})
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {token}",
        }
        logger.info("In open AI EMBEDDING FUNCTION PHASE1")
        response = requests.post(url, headers=headers, data=payload)
        
        
        logger.info("In open AI EMBEDDING FUNCTION PHASE2")
        if response.status_code !=200:
            logger.error("The OpenAI Embedding errored status code is",response.status_code)
            #raising exception to capture at line 162
            raise Exception(f"OPEN AI EMBEDDING ERROR:{str(response.json())}")
        
        
        embeddings = json.loads(response.json()["result"])
        
        
        return embeddings
    except Exception as e:
        
        logger.error("Got the Exception",str(e))
        #raising backoff exception
        raise GenericEmbeddingException()


class IASOpenaiLLM(LLM):
    """Wrapper for IAS secured OpenAI completion API"""

    engine: str
    temperature: str
    max_tokens: int

    @property
    def _llm_type(self) -> str:
        return "IAS_OpenAI"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
    ) -> str:
        token = federate_auth()
        response = ias_openai_completion(
            token, prompt, self.engine, self.temperature, self.max_tokens
        )
        return response

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        """Get the identifying parameters."""
        params = {
            "engine": self.engine,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        return params


class IASOpenaiConversationalLLM(LLM):
    """Wrapper for IAS secured OpenAI chat API"""

    engine: str
    temperature: str
    max_tokens: int
    system_message: str = None
    client_id: str = None
    x_vsl_client_id: str = None

    @property
    def _llm_type(self) -> str:
        return "IAS_OpenAI"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
    ) -> str:
        token = federate_auth()
        prompt_message = prompt

        if self.system_message:
            prompt_message = prompt_message + self.system_message

        token_consumed = self.get_num_tokens(prompt_message)
        response = ias_openai_chat_completion(
            token, prompt, self.engine, self.temperature, self.max_tokens - token_consumed, self.system_message, self.client_id, self.x_vsl_client_id,
        )
        return response

    @property
    def _identifying_params(self) -> Mapping[str, Any]:
        """Get the identifying parameters."""
        params = {
            "engine": self.engine,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
        }
        return params


class IASOpenaiEmbeddings(Embeddings):
    """Wrapper for IAS secured OpenAI embedding API"""

    engine = str

    def __init__(self, engine):
        self.engine = engine

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embeddings search docs."""
        # NOTE: to keep things simple, we assume the list may contain texts longer
        #       than the maximum context and use length-safe embedding function.

        token = federate_auth()
        
        
        response = ias_openai_embeddings(token, texts, self.engine)
            

        # Extract the embeddings
        embeddings: list[list[float]] = [data["embedding"] for data in response]
        return embeddings

    def embed_query(self, text: str) -> List[float]:
        """Embeddings  query text."""
        token = federate_auth()
        response = ias_openai_embeddings(token, text, self.engine)
        # print(response)

        # Extract the embeddings and total tokens
        embeddings: list[list[float]] = [data["embedding"] for data in response]
        return embeddings[0]