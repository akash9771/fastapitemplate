from app.logs.logger_config import logger
from app.commons.load_config import config
from app.sql.controllers.DataMigrateController import DataMigrateController
from fastapi import APIRouter,HTTPException
from fastapi import Request
from validator.decorators import async_token_validation_and_metering
from app.sql.dependencies.authorization.auth_decorator import auth_token_validation
from app.commons.errors import get_err_json_response
from app.utils.api_response import generate_api_success_response_raw
import os

data_migrate_router = APIRouter(prefix=config["api_prefix"])

@data_migrate_router.post(
    "/data/migrate",
    status_code=200,
    tags=["Data migration"],
    description="Migrate content-lib data to Doc-insights"
)
@async_token_validation_and_metering()
@auth_token_validation()
async def data_migrate(request : Request):
    try:
        clientid= request.headers.get("x-agw-client_id") if request.headers.get("x-agw-client_id") is not None else None
        logger.info(f"client id - {clientid}")
        logger.info("In data migrate route..")
        if not clientid:
            message = "Client Id can not be null"
            return HTTPException(status_code=404, detail=message)
        obj = DataMigrateController().data_migrate(clientid)
        return generate_api_success_response_raw(body={
                    "status_code": 200,
                    "status": "success",
                    "message": f"Total records migrated = {obj}",
                },status_code=200)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error migrating data to doc-insights: {str(e)}")