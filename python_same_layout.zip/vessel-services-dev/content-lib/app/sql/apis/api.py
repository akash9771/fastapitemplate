from fastapi import FastAPI
from app.sql.schemas.responses import HealthCheckResponse,Status
from app.commons.load_config import config
from fastapi.openapi.utils import get_openapi
from fastapi.middleware.cors import CORSMiddleware
from app.sql.apis.routers.content_index_router import content_index_router
from app.sql.apis.routers.document_router import document_router
from app.sql.apis.routers.retrieval_router import retrieval_router
from app.sql.apis.routers.data_migrate_router import data_migrate_router

app = FastAPI(
    title="content-service",
    version="0.1",
    openapi_url=(config['api_prefix']+"/openapi.json"),
    docs_url=(config['api_prefix']+"/docs"),
    redoc_url=(config['api_prefix']+"/redoc"),
)
origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(content_index_router)
app.include_router(document_router)
app.include_router(retrieval_router)
app.include_router(data_migrate_router)

@app.get(
    f"{config['api_prefix']}/health-check",
    status_code=200,
    tags=["Health check"],
)
async def health_check():
    return HealthCheckResponse(
        status=Status.success, message="health_check completed successfully"
    )

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="content_service",
        version="0.1",
        routes=app.routes,
    )
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi