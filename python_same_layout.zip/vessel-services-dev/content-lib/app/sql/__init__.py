# Database Manager
from app.sql.database.db_manager import engine
from app.sql import orm_models
from app.sql.database.context_manager import session

orm_models.Base.metadata.create_all(bind=engine)