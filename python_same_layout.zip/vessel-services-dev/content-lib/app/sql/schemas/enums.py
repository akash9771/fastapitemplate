from enum import Enum,unique

@unique
class IndexTypeEnum(Enum):
    private="private"
    shared="shared"
    temporary="temporary"

@unique
class ContentStatus(Enum):
    updated="updated"
    outdated="outdated"

@unique
class ChunkAlgoType(Enum):
    recursive="recursive"
    text_splitter="text_splitter"

@unique
class LengthType(Enum):
    characters="characters"
    tokens="tokens"

@unique
class DocType(Enum):
    PDF="PDF"
    WORD="WORD"
    XLSX="XLSX"
    JSON="JSON"

@unique
class ChunkType(Enum):
    text="text"
    