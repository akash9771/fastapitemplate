from app.sql.orm_models.models import DocumentORM
from app.sql import session
from app.commons.errors import get_err_json_response
from app.logs.logger_config import logger

class CRUDDocument:

    def create(self, **kwargs):
        """[CRUD function to create a new document record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing create-document crud ...")
            document = DocumentORM(**kwargs)
            with session() as transaction_session:
                transaction_session.add(document)
                transaction_session.commit()
                transaction_session.refresh(document)
            return document.__dict__
        
        except Exception as e:
            logger.error("Error while adding to DocumentORM table")
            return get_err_json_response(
            "Error while adding to Document table",
            e.args,
            501,
        )


    def read_all(self):
        """[CRUD function to read_all documents record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all document records]
        """
        try:
            logger.info("executing read-all-document crud ...")
            with session() as transaction_session:
                obj: DocumentORM = transaction_session.query(DocumentORM).all()
            if obj is not None:
                return [row.__dict__ for row in obj]
            else:
                return []
            
        except Exception as e:
            logger.error("Error while reading records from document table")
            return get_err_json_response(
            "Error while reading records from document table",
            e.args,
            501,
        )


    def get_documents_by_content_index(self, context_id: int):
        """[CRUD function to read documents by context id]

        Args:
            context_id (int): [context id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [document records matching the criteria]
        """
        try:
            logger.info("executing get_documents_by_content_index crud ...")
            with session() as transaction_session:
                obj: DocumentORM = (
                        transaction_session.query(DocumentORM)
                        .filter(DocumentORM.content_index_id == context_id)
                        .all()
                    )
            if obj is not None:
                return obj
            else:
                return None
            
        except Exception as e:
            logger.error("error while filtering document by context id.")
            return get_err_json_response(
            "Error while filtering document table",
            e.args,
            501,
        )

    def get_by_id(self, id: int):
        """[CRUD function to read a document record]

        Args:
            DocumentORM_id (str): [DocumentORM id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [document record matching the criteria]
        """
        try:
            logger.info("executing get-by-id document crud ...")
            with session() as transaction_session:
                obj: DocumentORM = (
                        transaction_session.query(DocumentORM)
                        .filter(DocumentORM.document_id == id)
                        .first()
                    )
            if obj is not None:
                return obj.__dict__
            else:
                return None
            
        except Exception as e:
            logger.error("error while filtering DocumentORM by id.")
            return get_err_json_response(
            "Error while filtering DocumentORM table",
            e.args,
            501,
        )

    def update(self, **kwargs):
        """[CRUD function to update a document record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing update-document crud ...")
            with session() as transaction_session:
                obj: DocumentORM = (
                        transaction_session.query(DocumentORM)
                        .filter(DocumentORM.document_id == kwargs.get("document_id"))
                        .update(kwargs, synchronize_session=False)
                    )
                transaction_session.commit()
            return obj.__dict__
        
        except Exception as e:
            logger.error("error while updating DocumentORM.")
            return get_err_json_response(
            "Error while updating document table",
            e.args,
            501,
        )


    def delete(self, id: int):
        """[CRUD function to delete a document record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing delete-document crud ...")
            with session() as transaction_session:
                obj: DocumentORM = (
                        transaction_session.query(DocumentORM)
                        .filter(DocumentORM.document_id == id)
                        .first()
                    )
                transaction_session.delete(obj)
                transaction_session.commit()
            logger.info("Document deleted successfully!")
        
        except Exception as e:
            logger.error("error while deleting from DocumentORM.")
            return get_err_json_response(
            "Error while deleting record from document table",
            e.args,
            501,
        )
    def duplicate_check(self, md5: str, content_index_id: int):
        try:
            logger.info("executing duplicate check for md5 in doc crud..")    
            with session() as transaction_session:
                doc_obj =  (
                        transaction_session.query(DocumentORM)
                        .filter(DocumentORM.content_index_id == content_index_id)
                        .filter(DocumentORM.md5==md5)
                        .first()
                    )
                
            if doc_obj:
                return doc_obj
            else:
                return False
            
        except Exception as e:
            logger.error("error while filtering document md5 by context id.")
            return get_err_json_response(
            "Error while filtering document table",
            e.args,
            501,
        ) 