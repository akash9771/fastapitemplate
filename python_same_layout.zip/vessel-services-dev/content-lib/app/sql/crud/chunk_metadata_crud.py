from app.sql import session
from app.sql.orm_models.models import ChunkMetadataORM,ContentIndexORM,DocumentORM
from app.commons.errors import get_err_json_response
from app.logs.logger_config import logger
import ast,json
from app.commons.exceptions import BadRequestException
from app.sql.helper.functions import save_upload_file,del_file

class CRUDChunkMetadata:
    def create(self, **kwargs):
        """[CRUD function to create chunk metadata record]
        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing chunk metadata crud ...")
            chunk_metadata = ChunkMetadataORM(**kwargs)
            with session() as transaction_session:
                transaction_session.add(chunk_metadata)
                transaction_session.commit()
                transaction_session.refresh(chunk_metadata)
            return chunk_metadata.__dict__
        except Exception as e:
            logger.error("Error while adding to chunk-metadata table")
            return get_err_json_response(
            "Error while adding to chunk-metadata table",
            e.args,
            501,
        )

    def get(self, content_index_id,document_id):
        """[CRUD function to get chunk-metadata entry by name]
        Args:
            content_index_id (int): The id of the content index to retrieve.
            document_id (int): the id of document
        Returns:
            dict: A dictionary representing the chunk metadata entry.
        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing get-chunk-metadata crud ...")
            # Assuming you have an SQLAlchemy ORM model for ChunkMetadata named ChunkMetadataORM
            with session() as transaction_session:
                chunk_metadata = (transaction_session.query(ChunkMetadataORM).filter(ChunkMetadataORM.content_index_id==content_index_id).filter(ChunkMetadataORM.document_id==document_id).all())
            if chunk_metadata:
                return chunk_metadata
            else:
                logger.error("Chunk metadata not found")
                return None
        except Exception as e:
            logger.error("Error while fetching entry from content-index table")
            return get_err_json_response(
                str(e),
                e.args,
                501
            )
        
    def get_by_metadata_id(self, content_metadata_id):
        """[CRUD function to get chunk-metadata entry by name]
        Args:
            content_metadata_id (int): The id of the chunk metadata to retrieve.
        Returns:
            dict: A dictionary representing the chunk metadata entry.
        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing get-chunk-metadata crud ...")
            # Assuming you have an SQLAlchemy ORM model for ChunkMetadata named ChunkMetadataORM
            with session() as transaction_session:
                condition = (ChunkMetadataORM.content_metadata_id==content_metadata_id)
                chunk_metadata = transaction_session.query(ChunkMetadataORM).filter(condition).first()
            if chunk_metadata:
                return chunk_metadata.__dict__
            else:
                logger.error("Chunk metadata not found")
                return get_err_json_response(
                    "Chunk metadata not found",
                    None,
                    404
                )
        except Exception as e:
            logger.error("Error while fetching entry from content-index table")
            return get_err_json_response(
                str(e),
                e.args,
                501
            )
        
    def get_md5_by_doc_id(self, document_id):
        """[CRUD function to get md5 by doc id]
        Args:
            document_id (int): The id of the document .
        Returns:
            str: md5 value for the doc.
        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("executing get-md5-by-doc-id chunk-metadata crud ...")
            with session() as transaction_session:
                chunk_metadata_obj : ChunkMetadataORM = (transaction_session.query(ChunkMetadataORM)
                                                     .filter(ChunkMetadataORM.document_id == document_id)
                                                     .first())
                if chunk_metadata_obj:
                    chunk_dict = chunk_metadata_obj.__dict__
                    chunk_metadata = ast.literal_eval(chunk_dict["chunk_metadata"])
                    return (chunk_metadata['md5'],chunk_dict['content_index_id'])
                else:
                    raise BadRequestException("Chunk metadata not found for given id")
        
        except BadRequestException as e:
            logger.error("Chunk metadata not found")
            return get_err_json_response(
                str(e),
                e.args,
                404
            )
        except Exception as e:
            logger.error("Error while fetching entry from chunk metadata table")
            return get_err_json_response(
                str(e),
                e.args,
                501
            )
        
    def extract_json_data(self,md5,file):
        logger.info("saving file locally...")
        file_path = save_upload_file(file=file)

        with open(file_path,'r') as f:
            data = json.load(f)

        page_content = []
        metadata = []
        for i in data :
            i["metadata"]["md5"] = md5
            page_content.append(i["page_content"])
            metadata.append(i["metadata"])

        logger.info("deleting locally saved file ..")
        del_file(file_path=file_path)

        return page_content,metadata