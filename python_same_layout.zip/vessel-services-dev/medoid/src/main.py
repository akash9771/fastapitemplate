##################
# Import Modules #
##################

import pathlib

from fastapi.responses import RedirectResponse
from fastapi import FastAPI, status , Response
from fastapi.middleware.cors import CORSMiddleware

from app.payloads.requests import ResolveLongSentencesRequestPayload
from app.payloads.responses import LongSentencesResolvedResponsePayload

from app.settings import ApplicationSettings

from app.recipe import LongSentenceResolution
from app.recipe import ShorteningInference
from app.recipe import SplittingInference
from app.recipe import DocumentAnalysis

###################
# Paths Resolving #
###################

BASE_DIRECTORY_PATH = pathlib.Path(__file__).resolve().parent.parent

MODELS_DIRECTORY_PATH = BASE_DIRECTORY_PATH.joinpath("models")

########################
# Application Settings #
########################

app_settings = ApplicationSettings()

##########
# Recipe #
##########

long_sentence_resolution = LongSentenceResolution(
    ShorteningInference(MODELS_DIRECTORY_PATH / app_settings.RECIPE_SHORTENING_MODEL),
    SplittingInference(MODELS_DIRECTORY_PATH / app_settings.RECIPE_SPLITTING_MODEL),
    DocumentAnalysis()
)

###################
# API Application #
###################

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=app_settings.API_CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"]
)

#############
# Endpoints #
#############

@app.get("/", include_in_schema=False)
def docs_redirect():
    """
        Redirect to API documentation.
    """

    return RedirectResponse("/docs")

@app.get("/medoid/health_check",status_code=200,tags=["Health check"])
async def health_check():
    """
        Health check endpoint
    """

    return Response(content="health_check completed successfully", media_type="text/plain")

@app.post(path='/long-sentences/resolutions',
          tags=['Long Sentence Resolution'],
          status_code=status.HTTP_200_OK,
          response_model=LongSentencesResolvedResponsePayload)
def resolve_long_sentences(request_payload: ResolveLongSentencesRequestPayload):
    """
        Resolve the provided long sentences.

        - **sentences**: The sentences (mandatory field)
    """

    resolutions_df = long_sentence_resolution.resolve(
        sentences=request_payload.sentences,
        target_maximum_n_words=app_settings.RECIPE_TARGET_MAXIMUM_N_WORDS,
        n_words_threshold=app_settings.RECIPE_SHORTENING_SPLITTING_N_WORDS_THRESHOLD
    )

    return LongSentencesResolvedResponsePayload(resolutions=resolutions_df.to_dict('records'))

if __name__ == "__main__":
    import uvicorn

    uvicorn.run("main:app", host="127.0.0.1", port=8081, reload=True)
