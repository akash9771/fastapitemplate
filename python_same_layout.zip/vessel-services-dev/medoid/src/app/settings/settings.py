from typing import List

from pydantic import BaseSettings

class ApplicationSettings(BaseSettings):
    RECIPE_TARGET_MAXIMUM_N_WORDS : int
    
    RECIPE_SHORTENING_SPLITTING_N_WORDS_THRESHOLD : int
    
    RECIPE_SHORTENING_MODEL : str
    
    RECIPE_SPLITTING_MODEL : str

    API_CORS_ORIGINS: List[str]

    class Config:
        env_file = '.env'
        
        env_file_encoding = 'utf-8'
