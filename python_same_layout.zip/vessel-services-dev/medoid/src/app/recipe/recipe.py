import torch

import pandas as pd

import numpy as np

from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

from pathlib import Path

from typing import List, Union, Tuple

from spacy.lang.en import English

from spacy.tokens import Doc, Token, Span

class DocumentAnalysis:
    def __init__ (self):
        self._linguistics_model = English()

        self._linguistics_model.add_pipe("sentencizer")

    def extract_n_words_from_texts(self, texts: Union[List[str], np.ndarray, pd.Series]) -> np.ndarray:
        return np.array(list(map(self._extract_n_words_from_document_or_span, self._linguistics_model.pipe(texts, batch_size=50))))

    def extract_n_words_from_text(self, text: str) -> int:
        return self._extract_n_words_from_document_or_span(self._linguistics_model(text))

    def extract_sentence_n_words_from_text(self, text: str) -> List[int]:
        return list(map(self._extract_n_words_from_document_or_span, self._linguistics_model(text).sents))

    def extract_sentences_from_text(self, text: str) -> List[str]:
        return list(map(lambda o: o.text, self._linguistics_model(text).sents))

    def _extract_n_words_from_document_or_span(self, input: Union[Span, Doc]) -> int:
        return sum(map(self._token_is_word, input))

    def _token_is_word(self, token: Token) -> bool:
        return not any([ token.is_bracket,
                         token.is_punct,
                         token.is_currency,
                         token.is_quote,
                         token.is_space ]) # https://spacy.io/api/token#attributes

class ShorteningInference:
    def __init__ (self, checkpoint_path: Union[Path, str]):
        self._device = "cuda:0" if torch.cuda.is_available() else "cpu"

        self._model = AutoModelForSeq2SeqLM.from_pretrained(checkpoint_path).to(self._device)

        self._tokenizer = AutoTokenizer.from_pretrained(checkpoint_path)

    def generate(self, sentences: List[str], batch_size: int) -> List[str]:
        sentences = list(map(str.strip, sentences))

        shortened_sentences = []

        for i in range(0, len(sentences), batch_size):
            model_inputs = self._tokenizer(sentences[i : i + batch_size], padding=True, truncation=True, return_tensors='pt').to(self._device)

            sequences = self._model.generate(**model_inputs, max_length=1000, num_beams=2)

            outputs = self._tokenizer.batch_decode(sequences, skip_special_tokens=True)

            shortened_sentences.extend(outputs)

        return shortened_sentences

class SplittingInference:
    def __init__ (self, checkpoint_path: Union[Path, str]):
        self._device = "cuda:0" if torch.cuda.is_available() else "cpu"

        self._model = AutoModelForSeq2SeqLM.from_pretrained(checkpoint_path).to(self._device)

        self._tokenizer = AutoTokenizer.from_pretrained(checkpoint_path)

    def generate(self, sentences: List[str], batch_size: int) -> List[str]:
        sentences = list(map(str.strip, sentences))

        splitted_sentences = []

        for i in range(0, len(sentences), batch_size):
            model_inputs = self._tokenizer(sentences[i : i + batch_size], padding=True, truncation=True, return_tensors='pt').to(self._device)

            sequences = self._model.generate(**model_inputs, max_length=1000, num_beams=2)

            outputs = self._tokenizer.batch_decode(sequences, skip_special_tokens=True)

            splitted_sentences.extend(outputs)

        return splitted_sentences

class LongSentenceResolution:
    def __init__(self, shortening_inference: ShorteningInference, splitting_inference: SplittingInference, document_analysis: DocumentAnalysis):
        self._shortening_inference = shortening_inference

        self._splitting_inference = splitting_inference

        self._document_analysis = document_analysis

        self._maximum_recursion_depth = 10

    def _define_final_resolution_state(self, states: List[str]) -> str:
        if all(map(lambda o: o == 'resolved', states)):
            return 'resolved'
        elif all(map(lambda o: o == 'unresolved', states)):
            return 'unresolved'
        elif 'unresolved' in states:
            return 'partially resolved'
        else:
            return 'untouched'

    def _resolve_sentence(self, input_sentence: str, target_maximum_n_words: int, n_words_threshold: int, current_recursion_depth: int, collected_resolutions: List[Tuple[str, int, str, str]]) -> List[Tuple[str, int, str, str]]:
        input_sentence_n_words = self._document_analysis.extract_n_words_from_text(input_sentence)

        if current_recursion_depth >= self._maximum_recursion_depth:
            collected_resolutions.append((input_sentence, input_sentence_n_words, 'splitting', 'unresolved'))
        elif input_sentence_n_words <= target_maximum_n_words:
            collected_resolutions.append((input_sentence, input_sentence_n_words, 'none', 'untouched'))
        elif input_sentence_n_words <= n_words_threshold:
            shortening_result = self._shortening_inference.generate([input_sentence], batch_size=1) [0]

            shortening_result_n_words = self._document_analysis.extract_n_words_from_text(shortening_result)

            collected_resolutions.append((shortening_result, shortening_result_n_words, 'shortening', 'resolved' if shortening_result_n_words <= target_maximum_n_words else 'unresolved'))
        else:
            splitting_result = self._splitting_inference.generate([input_sentence], batch_size=1) [0]

            for sentence, n_words in zip(self._document_analysis.extract_sentences_from_text(splitting_result), self._document_analysis.extract_sentence_n_words_from_text(splitting_result)):
                if n_words > target_maximum_n_words:
                    self._resolve_sentence(sentence, target_maximum_n_words, n_words_threshold, current_recursion_depth + 1, collected_resolutions)
                else:
                    collected_resolutions.append((sentence, n_words, 'splitting', 'resolved'))

        return list(zip(*collected_resolutions))

    def resolve(self, sentences: List[str], target_maximum_n_words: int, n_words_threshold: int) -> pd.DataFrame:
        sentences = list(map(str.strip, sentences))

        sentences_df = pd.DataFrame(sentences, columns = ['input_sentence'])

        sentences_df['input_sentence_n_words'] = self._document_analysis.extract_n_words_from_texts(sentences_df['input_sentence'])

        sentences_df[['resolution', 'resolution_n_words', 'method', 'state']] = sentences_df.apply(lambda row: self._resolve_sentence(row['input_sentence'], target_maximum_n_words, n_words_threshold, current_recursion_depth=0, collected_resolutions=[]), axis=1, result_type='expand')

        sentences_df['state'] = sentences_df['state'].apply(self._define_final_resolution_state)

        sentences_df['resolution'] = sentences_df['resolution'].apply(" ".join)

        return sentences_df
