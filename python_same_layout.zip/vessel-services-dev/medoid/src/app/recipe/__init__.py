from .recipe import LongSentenceResolution
from .recipe import ShorteningInference
from .recipe import SplittingInference
from .recipe import DocumentAnalysis

__all__ = [
    "LongSentenceResolution",
    "ShorteningInference",
    "SplittingInference",
    "DocumentAnalysis"
]
