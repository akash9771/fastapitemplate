from typing import List

from pydantic import BaseModel, StrictStr, StrictInt

class LongSentenceResolvedResponsePayload(BaseModel):
    input_sentence: StrictStr

    input_sentence_n_words: StrictInt

    resolution: StrictStr

    resolution_n_words: List[StrictInt]

    method: List[StrictStr]

    state: StrictStr

class LongSentencesResolvedResponsePayload(BaseModel):
    resolutions: List[LongSentenceResolvedResponsePayload]
