from .responses import LongSentencesResolvedResponsePayload

__all__ = [
    "LongSentencesResolvedResponsePayload"
]