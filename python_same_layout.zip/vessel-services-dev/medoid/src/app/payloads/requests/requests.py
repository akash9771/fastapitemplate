from typing import List

from pydantic import BaseModel, StrictStr, validator, Field

class ResolveLongSentencesRequestPayload(BaseModel):
    sentences: List[StrictStr] = Field(..., min_items=1)

    @validator('sentences')
    def sentences_should_contain_non_empty_and_non_whitespace_strings(cls, value):
        if any(map(lambda o: not o.strip(), value)):
            raise ValueError('must contain non-empty and non-whitespace strings')

        return value

    class Config:
        schema_extra = {
            "example": {
                "sentences": [
                    "A man is facing charges after allegedly assaulting multiple people with a knife before barricading himself inside a home in Edmonton's Hazeldean neighbourhood.",
                    "Tropical storm Igor is drifting northward in the Atlantic off the coast of Africa near the Cape Verde islands.",
                    "Actor John Woodvine is reportedly in a stable condition after collapsing during a performance of Carousel on Friday.",
                    "Greece successfully launched thursday a five-billion-euro bond issue to raise desperately needed funds, but faced stiffening opposition to its plea for help and threat to go to the imf.",
                    "Singapore Airlines announced today that it has launched daily Airbus A380 service between Singapore and Hong Kong.",
                    "As events do not play in favor of Europe, governments must be realistic and practical and take the decision to develop a clear and strong union.",
                    "This album is by Academy Award Winning Hip Hop artist, Eminem, which was never officially released in the US, but circulated on the internet.",
                    "Half of UK employees are banned from using social networking site Facebook, according to a survey from HCL Technologies.",
                    "The healthcare team helped the child breathe normally, and she was back to herself quickly."
                ]
            }
        }
