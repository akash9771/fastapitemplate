from .requests import ResolveLongSentencesRequestPayload

__all__ = [
    "ResolveLongSentencesRequestPayload"
]
