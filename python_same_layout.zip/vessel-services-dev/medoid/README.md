# Pfizer - Long Sentence Resolution: API

## Table of contents
- [Pfizer - Long Sentence Resolution: API](#pfizer---long-sentence-resolution-api)
  - [Table of contents](#table-of-contents)
  - [Project Overview](#project-overview)
    - [Context](#context)
    - [Problem Statement](#problem-statement)
    - [Ambition](#ambition)
    - [Objectives](#objectives)
  - [API](#api)
  - [How to setup the development environment?](#how-to-setup-the-development-environment)
  - [How do I deploy it?](#how-do-i-deploy-it)
    - [Create the Docker image](#create-the-docker-image)
      - [Clone the project's repository](#clone-the-projects-repository)
      - [Download the ML models](#download-the-ml-models)
      - [Build the Docker image](#build-the-docker-image)
    - [Run the Docker container](#run-the-docker-container)
      - [With CPU](#with-cpu)
      - [With GPU](#with-gpu)
    - [API documentation](#api-documentation)
  - [Machine Learning](#machine-learning)

## Project Overview

### Context 

Pfizer uses a tool to check for possible **issues in English documents** produced by internal teams. For example, it checks the documents for issues related to readability, style, simplicity, **long sentences** and other. The checks are necessary before the documents are released to the public. The tool not only identifies issues in documents but is able to **propose automatic resolutions** for some of them.

### Problem Statement

Although Pfizer’s tool can identify issues of long sentences (> 16 words) it **cannot propose resolutions** for them. This leads to the problem that the internal teams have to **spend time manually** shortening and/or splitting these sentences to pass the check.

The high-level **goal** of the project is to build a **well-documented** and **production-ready** AI-based software to tackle the challenge of **long sentences automatically** without reducing the information and the fluency of the written language in text. Such a software will help to resolve the issues without the need to spend time editing the sentences.

### Ambition

Our ambition is to have a **successful cooperation** and solve the challenge at such a level that all stakeholders will be super happy with it. We want to deliver an AI system with **excellent performance** replicating and even surpassing the state-of-the-art solutions. Furthermore, we want to deliver a system that will help Pfizer’s internal teams to **improve productivity** and use it with **trust in production**.

### Objectives

The main objectives of the projects are:

* A review of state-of-the-art methods for resolving long sentences
* Software and data for computing KPIs
* ML Recipe - Pipeline for resolving long sentences
* Production - Software for resolving long sentences

## API

The final system runs as an API server application and is packaged as a dockerized container. The API is built with FastAPI, a modern, high-performance web framework for building APIs with Python. The API serves a RESTful endpoint for resolving long sentences and the data format used for the request/response is JSON. This dockerized API server container can be deployed in any cloud platform (e.g., AWS, GCP, Azure), if the minimum requirements are satisfied. The application is designed to run on GPU, but it can also support CPU if GPU is unavailable.

## How to setup the development environment?

If you already have [VS Code](https://code.visualstudio.com/) and [Docker](https://www.docker.com/) installed, you can click the badge below to get started. Clicking the badge will cause VS Code to automatically install the **Dev Containers** extension if needed, clone the source code into a container volume, and spin up a dev container for use.

[![Open in Dev Containers](https://img.shields.io/static/v1?label=Dev%20Containers&message=Open&color=blue&logo=visualstudiocode)](https://vscode.dev/redirect?url=vscode://ms-vscode-remote.remote-containers/cloneInVolume?url=https://github.com/medoidai/pfizer-long-sentence-resolution-api)

## How do I deploy it?

The API is containerized using the Docker technology and it can be deployed everywhere we want. It can run in an on-premise system, in a cloud virtual machine or even it can be deployed using a cloud-native container orchestration technology such as Kubernetes. Furthermore, it can compute predictions either with CPU or GPU. We suggest using GPU for fastest predictions.

Using GPU within a Docker container isn't straightforward. There **shouldn't be any mismatch between CUDA and CuDNN drivers on both the container and host machine** to enable seamless communication. For this reason, we use the **NVIDIA container toolkit image** that provides support to automatically recognize GPU drivers on the host machine and pass those same drivers to your Docker container when it runs.

Cloud providers provide easy ways to install **CUDA and CuDNN drivers**. For example, for virtual machines usually they provide pre-defined deep learning boot images with the drivers already pre-installed. Furthermore, managed Kubernetes clusters usually provide deployments that can install the drivers in the worker nodes.

For more information on **NVIDIA container toolkit image** as well as the minimum requirements for the container to run, please refer to the project documentation.

### Create the Docker image

Make sure you have [Docker](https://www.docker.com/), [Git LFS](https://git-lfs.github.com/) and [Git](https://git-scm.com/) installed.

#### Clone the project's repository

```sh
git clone git@github.com:medoidai/pfizer-long-sentence-resolution-api.git && cd pfizer-long-sentence-resolution-api
```

#### Download the ML models

```sh
BASH_ENV=.env ./download_models.sh
```

#### Build the Docker image

```sh
docker build --pull --rm -f "Dockerfile" -t pfizer-long-sentence-resolution-api:latest "."
```

### Run the Docker container

As Docker doesn't provide the host's machine GPUs by default in the container, we need to create containers with the **--gpus** flag for the hardware to show up. You can either specify specific devices to enable or use the all keyword.

#### With CPU

```sh
docker run --restart unless-stopped --env-file .env -p 8082:80 -d --name pfizer-long-sentence-resolution-api pfizer-long-sentence-resolution-api:latest
```

#### With GPU

```sh
docker run --gpus all --restart unless-stopped --env-file .env -p 8082:80 -d --name pfizer-long-sentence-resolution-api pfizer-long-sentence-resolution-api:latest
```

### API documentation

Swagger UI and ReDoc allow for generating the API documentation. For example, Swagger UI provides a user-friendly interface to submit requests and get responses. Both Swagger UI and ReDoc can be assessed through the following URLs locally:

* Swagger UI: http://localhost:8082/docs
* ReDoc: http://localhost:8082/redoc

## Machine Learning

* [Download Shortening Datasets](notebooks/DownloadShorteningDatasets.ipynb)
* [Download Splitting Datasets](notebooks/DownloadSplittingDatasets.ipynb)
* [Preprocess Shortening Datasets](notebooks/PreprocessShorteningDatasets.ipynb)
* [Preprocess Splitting Datasets](notebooks/PreprocessSplittingDatasets.ipynb)
* [Create Shortening Modeling Dataset](notebooks/CreateShorteningModelingDataset.ipynb)
* [Create Splitting Modeling Dataset](notebooks/CreateSplittingModelingDataset.ipynb)
* [Fine-tune Shortening Model](notebooks/FinetuneShorteningModel.ipynb)
* [Fine-tune Splitting Model](notebooks/FinetuneSplittingModel.ipynb)
* [Evaluate Shortening Model](notebooks/EvaluateShorteningModel.ipynb)
* [Evaluate Splitting Model](notebooks/EvaluateSplittingModel.ipynb)
* [Demonstrate Evaluation Metrics](notebooks/DemonstrateEvaluationMetrics.ipynb)
* [Analyze Shortening Dataset Compression Rate](notebooks/AnalyzeShorteningDatasetCompressionRate.ipynb)
* [Run Baseline Splitting Model](notebooks/RunBaselineSplittingModel.ipynb)
* [Run Solution Recipe (v1)](notebooks/RunSolutionRecipeV1.ipynb)
* [Run Solution Recipe (v2)](notebooks/RunSolutionRecipeV2.ipynb)
* [Run Solution Recipe (v3)](notebooks/RunSolutionRecipeV3.ipynb)
* [Scrape Long Sentences](notebooks/ScrapeLongSentences.ipynb)