#!/usr/bin/env bash

[ ! -n "${RECIPE_MODELS_TO_DOWNLOAD}" ] && { echo "The environment variable RECIPE_MODELS_TO_DOWNLOAD is not set."; exit 1; }

if [ ! -d models ]; then
    echo "Creating the models directory..."

    mkdir models || { echo 'Failed to create the models directory.' ; exit 1; }
fi

script_cwd="$(pwd)"

IFS=',' read -r -a models_to_download <<< "${RECIPE_MODELS_TO_DOWNLOAD}"

for model in "${models_to_download[@]}"
do
    if [ -d "models/${model}" ]; then
        echo "Skipping download of the model '${model}' as it already exists in the models directory."

        continue
    fi

    echo "Downloading the '$model' model..."

    model_repo_tmp_path="$(mktemp -d -t model-XXXXXXXX)"

    git clone --depth 1 --branch "${model}" https://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@github.com/pfizer/ias-medoidai-long-sentence-resolution-models.git "${model_repo_tmp_path}" || { echo 'Failed to clone 
the model repository.' ; exit 1; }

    cd "${model_repo_tmp_path}"

    git lfs install --local || { echo 'Failed to install Git LFS in the model repository.' ; exit 1; }

    git lfs pull

    cd "${script_cwd}"

    mv "${model_repo_tmp_path}/${model}" models || { echo 'Failed to move the model from the temporary directory in the target one.' ; exit 1; }

    rm -rf "${model_repo_tmp_path}" || { echo 'Failed to delete the temporary model repository.' ; exit 1; }
done

