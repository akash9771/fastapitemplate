# IAS-Monorepo

## Standards for Vessel Repos
1. NO SECRETS
1. {dev |  test | main} branches are protected and can only accept pull requests.
1. protected branches require Linting, PyTest, and other automated processes - any failure will fail merge
1. After automated processes, merges will need to be accepted by a colleage
1. feature branches are deleted after merges

## Standards for CI Processes
1. Dependabot implemented for dependancy scanning full-time
1. Snyk implemented for Container Scanning on build
1. Snyk implemented for dependancy scanning on build
1. Snyk implemented for IaaS Scanning on build
1. SonarQube implemented for Static Code Analysis on build
1. Naming and Tagging standards automated

## Tagging and Naming Standards for Vessel
1. **Resource Naming:** {env}-vsl-{foldername}-{use/task}
    * env = branch name
    * foldername = use-case/project/service
    * use/task = detailed purpose
1. **Stack Tags:**
    * git_commit = Git Commit Hash
    * git_branch = Git Branch Name
1. **Resource Tags:**
    * PrimaryOwner = Kenneth Jeckell
    * SecondaryOwner = Dionysis Fachilds
    * CostCenterId = 2331084
    * Platform = {Vessel | Chatterbox | TBD}
    * Usecase = *foldername* (ex. batch-translation; metering)
