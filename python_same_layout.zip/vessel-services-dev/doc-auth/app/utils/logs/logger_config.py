import logging
from config.config import config
 
# Define a list of allowed log levels
ALLOWED_LOG_LEVELS = ['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL']
 
# Validate and set a default log level if config.LOG_LEVEL is not provided or invalid
log_level = config.LOG_LEVEL.upper()  # Convert to uppercase for case-insensitivity
if log_level not in ALLOWED_LOG_LEVELS:
    log_level = 'INFO'  # Default to INFO if the specified log level is not allowed
 
logger = logging.getLogger(__name__)

logger.setLevel(log_level)

formatter = logging.Formatter("%(asctime)s [%(levelname)s] - %(message)s")

ch = logging.StreamHandler()
ch.setFormatter(formatter)

logger.addHandler(ch)