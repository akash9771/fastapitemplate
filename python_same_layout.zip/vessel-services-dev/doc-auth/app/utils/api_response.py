from fastapi import Request
import traceback
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from utils.logs.logger_config import logger
from .error_codes import get_human_status_code_msg
import json

class CustomJSONResponse(JSONResponse):
    def __init__(self,content,status_code,totaltokensllm=None,totaltokensembedding=None):
        super().__init__(status_code=status_code,content=content)
        self.totaltokensembedding = totaltokensembedding
        self.totaltokensllm=totaltokensllm
     
    def json(self):
        return self.body

def get_client_id(request):
    url_path = "" 
    client_id = None

    if request:
        url_path = request.url.path
        client_id = (
            request.headers.get("x-agw-client_id")
            if request.headers.get("x-agw-client_id") is not None
            else None
        )
    return url_path,client_id


def log_error(status_code, client_id, exc, user_message, url_path, pre_formatted_exc):
    logger.error(
        f"| status_code={status_code} | client_id={client_id} | error_type={type(exc).__name__} | msg_to_human={user_message} | url_path={url_path} | exception={pre_formatted_exc} | stack_trace={traceback.format_exc()} |"
    )


def http_exception_handler(exc,request= None):
    # Handle HTTP exceptions raised by your application
    
    url_path, client_id = get_client_id(request)

    status_code = 400

    if hasattr(exc, "status_code"):
        status_code = exc.status_code

    message = ""

    if isinstance(exc.detail, str):
        message = exc.detail
        exc.detail = {}

    elif "message" in exc.detail.keys():
            
            message = exc.detail['message']
            del exc.detail['message']
    
    elif exc.detail is None:
        exc.detail = {}

        

    status_code, user_message = get_human_status_code_msg(status_code, message=str(message))

    pre_formatted_exc = str(exc).replace("\n", "\r")

    log_error(status_code, client_id, exc, user_message, url_path, pre_formatted_exc)

    return CustomJSONResponse(
        status_code=status_code,
        content={
            "success": False,
            "message": user_message,
            "details": exc.detail,
        }
    )


def generic_exception_handler(exc, request=None):
    # Handle application-level exceptions

    # Return an appropriate response
    url_path, client_id = get_client_id(request)

    # Return an appropriate response
    status_code = 500

    status_code, user_message = get_human_status_code_msg(status_code)

    pre_formatted_exc = str(exc).replace("\n", "\r")

    log_error(status_code, client_id, exc, user_message, url_path, pre_formatted_exc)

    return CustomJSONResponse(
        status_code=status_code,
        content={
            "success": False,
            "message": user_message,
            "details": exc.args
        },
        media_type="application/json",
    )


def validation_exception_handler(exc, request=None):
    # Handle request validation errors

    url_path, client_id = get_client_id(request)
    

    status_code = 422  # fastapi throws 422 as default

    if hasattr(exc, "status_code"):
        status_code = exc.status_code

    status_code, user_message = get_human_status_code_msg(status_code)

    pre_formatted_exc = str(exc).replace("\n", "\r")

    log_error(status_code, client_id, exc, user_message, url_path, pre_formatted_exc)

    # check if the exception has an 'error()' method:
    # found some cases where it was missing.
    error_details = exc.errors() if hasattr(exc, "errors") else str(exc)
    # Return an appropriate response
    return CustomJSONResponse(
        status_code=status_code,
        content={
            "success": False,
            "message": user_message,
            "details": error_details,
        },
    )

def generate_api_success_response(status_code = 200 , message="", body={}):
    """Handles success response"""

    return CustomJSONResponse(
        status_code=status_code,
        content= {
            "success": True,
            "message": message,
            "details":jsonable_encoder((body))
        }
    )


def httpx_exception_handler(exc, request=Request):
    # Handle HTTP exceptions raised by your application

    url_path, client_id = get_client_id(request)


    status_code = exc.response.status_code

    external_api_message = ""

    try:
        external_api_message = exc.response.json()
    except Exception as e:
        external_api_message = exc.response.text
        logger.warning("External API msg is not in JSON format.")

    status_code, user_message = get_human_status_code_msg(
        status_code, upstream_msg=str(external_api_message)
    )

    pre_formatted_exc = str(exc).replace("\n", "\r")
    logger.error(
        f"| status_code={status_code} | client_id={client_id} | error_type={type(exc).__name__} | msg_to_human={user_message} | url_path={url_path} | exception={pre_formatted_exc} | upstream_api_msg={str(external_api_message)} | stack_trace={traceback.format_exc()} |"
    )

    # Return an appropriate response
    return CustomJSONResponse(
        status_code=status_code,
        content={
            "status_code": status_code,
            "success": False,
            "message": user_message,
            "upstream": {
                "message": str(external_api_message),
                "url": str(exc.request.url),
                "method": str(exc.request.method),
            },
        },
    )



def generate_api_success_response_raw(status_code = 200 , body={},totaltokensllm=None,totaltokensembedding=None):
    """Handles success response rw"""

    return CustomJSONResponse(
        status_code=status_code,
        content= jsonable_encoder((body))
        ,
        totaltokensllm=totaltokensllm,
        totaltokensembedding=totaltokensembedding
    )

