import copy


def extract_placeholders_separately(data):
    return [
        [
            {
                **placeholder.get("content", {}),
                "layout_type": child.get("metadata_info", {}).get("layout_type"),
                "slide_number": child.get("sequence_no"),
            }
            for placeholder in child.get("placeholders", [])
        ]
        for child in data.get("children", [])
    ]


def update_layouts_with_multiple_slides(data):
    layouts = [
        {
            "layout": "Layout1",
            "slide_number": "",
            "content": {"top": "", "middle": "", "bottom": ""},
        },
        {
            "layout": "Layout2",
            "slide_number": "",
            "content": {"top": "", "middle_left": "", "middle_right": "", "bottom": ""},
        },
        {
            "layout": "Layout3",
            "slide_number": "",
            "content": {
                "top": "",
                "middle_left": "",
                "middle_center": "",
                "middle_right": "",
                "bottom": "",
            },
        },
        {
            "layout": "Layout4",
            "slide_number": "",
            "content": {
                "top": "",
                "middle_top": "",
                "middle_center": "",
                "middle_bottom": "",
                "bottom": "",
            },
        },
        {
            "layout": "Layout5",
            "slide_number": "",
            "content": {"top": "", "left": "", "right": "", "bottom": ""},
        },
    ]
    updated_layouts = []
    for sublist in data:
        for item in sublist:
            # Check if the slide already exists in updated_layouts
            layout = next(
                (
                    l
                    for l in updated_layouts
                    if l["layout"] == item["layout_type"]
                    and l["slide_number"] == str(item["slide_number"])
                ),
                None,
            )
            if (
                not layout
            ):  # If not, create a new slide layout based on the original template
                original_layout = next(
                    (l for l in layouts if l["layout"] == item["layout_type"]), None
                ).copy()
                if original_layout:
                    original_layout["slide_number"] = str(item["slide_number"])
                    original_layout["content"] = {
                        k: "" for k in original_layout["content"].keys()
                    }
                    updated_layouts.append(original_layout)
                    layout = original_layout
            # Update the content of the slide
            if layout and item["name"] in layout["content"]:
                layout["content"][item["name"]] = item["text"] or ""
    return updated_layouts
