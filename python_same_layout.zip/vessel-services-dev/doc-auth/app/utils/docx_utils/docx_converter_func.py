import json
import base64
from bs4 import BeautifulSoup, NavigableString
from docx import Document
from docx.shared import Pt
from io import BytesIO
from docx.oxml.shared import OxmlElement, qn
from PIL import Image
from docx.shared import Inches
from fastapi import HTTPException
from dotenv import load_dotenv
from utils.logs.logger_config import logger
import requests
from starlette.responses import JSONResponse
from config.config import config 

load_dotenv()

def generate_mulesoft_token():
    url = f"{config.PINGFEDERATE_TOKEN_URL}?grant_type=client_credentials"
    payload = (
        f"client_id={config.MULE_CLIENT_ID}&client_secret={config.MULE_CLIENT_SECRET}"
    )
    
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    response = requests.post(url, headers=headers, data=payload)
    token = response.json()["access_token"]
    return "Bearer " + token

class DocumentCreator:
    def __init__(self, payload, user_info):
        self.payload = payload
        self.user_info =user_info
    
    @staticmethod
    def get_data_docinsights(user_info, payload):
        try:
            api_url = config.DOCINSIGHT_MULE_BASE_URL +'/fetch-doc-content'
            headers = {
                "Authorization": generate_mulesoft_token(),
                "x-auth": user_info['x-auth'],
                "Content-Type": "application/json"
            }
            response = requests.post(
                api_url,
                data=payload,
                headers=headers
            )
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as http_err:
            logger.error(
                f"Error in get data docinsights Error description \n {http_err}"
            )
            raise HTTPException(
                status_code=response.status_code, detail=response.text
            )
        except requests.exceptions.RequestException as http_err:
            logger.error(
                f"Error in get data docinsights Error description \n {http_err}"
            )
            raise HTTPException(
                status_code=response.status_code, detail= "Internal Server Error"
            )
        
    
    @staticmethod
    def apply_formatting(run, tag):
        if tag in ['strong', 'b']:
            run.bold = True
        if tag in ['em', 'i']:
            run.italic = True
        if tag == 'u':
            run.underline = True
        run.font.size = Pt(12)
        run.font.name = 'sans-serif'
 
    @staticmethod
    def add_hyperlink(paragraph, url, text, tooltip=None):
        part = paragraph.part
        r_id = part.relate_to(url, "http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink", is_external=True)
 
        hyperlink = OxmlElement('w:hyperlink')
        hyperlink.set(qn('r:id'), r_id)
        if tooltip:
            hyperlink.set(qn('w:tooltip'), tooltip)
 
        new_run = OxmlElement('w:r')
        rPr = OxmlElement('w:rPr')
 
        # Set the style to 'Hyperlink'
        style = OxmlElement('w:rStyle')
        style.set(qn('w:val'), 'Hyperlink')
        rPr.append(style)
 
        # Add underline
        u = OxmlElement('w:u')
        u.set(qn('w:val'), 'single')
        rPr.append(u)
 
        new_run.append(rPr)
        new_run.text = text
        hyperlink.append(new_run)
 
        paragraph._p.append(hyperlink)

    @staticmethod
    def add_image(document, image_data, default_dpi=96, max_width_inches=6.5, max_height_inches=9):
        # Add padding to the base64-encoded string if necessary
        padding_needed = len(image_data) % 4
        if padding_needed:
            image_data += '=' * (4 - padding_needed)
        list_image_data = image_data.split(',')
        image_data = list_image_data[1] if len(list_image_data)>1 else list_image_data[0]
        
        image_stream = BytesIO(base64.b64decode(image_data))
        image = Image.open(image_stream)
        
        try:
            dpi_x, dpi_y = image.info['dpi']
            dpi_x, dpi_y = dpi_x or 1 , dpi_y or 1
        except KeyError:
            dpi_x = dpi_y = default_dpi
        
        width_inches = image.width / dpi_x
        height_inches = image.height / dpi_y
        
        scaling_factor = 1
        if width_inches > max_width_inches or height_inches > max_height_inches:
            # Calculate the scaling factor to fit within the maximum dimensions
            scaling_factor_width = max_width_inches / width_inches
            scaling_factor_height = max_height_inches / height_inches
            scaling_factor = min(scaling_factor_width, scaling_factor_height)
        
        # Resize the image
        new_width = int(image.width * scaling_factor)
        new_height = int(image.height * scaling_factor)
        image = image.resize((new_width, new_height))
        
        document.add_picture(image_stream, width=Inches(new_width / dpi_x), height=Inches(new_height / dpi_y))

    @staticmethod
    def add_table(document, html_table):
        soup = BeautifulSoup(html_table, "html.parser")
    
        # Find header cells
        header_cells = []
        for row in soup.find_all("tr"):
            for cell in row.find_all(["th", "td"]):
                header_cells.append(cell.text)
            if header_cells:
                break

        # Add a table to the document
        table = document.add_table(rows=1, cols=len(header_cells))

        # Add header row
        for idx, header_cell in enumerate(header_cells):
            table.cell(0, idx).text = header_cell
            
        # Add data rows
        row_idx = 1  # Start from row 1 (after header row)
        for row in soup.find_all("tr")[1:]:  # Skip the first row (header row)
            cells = row.find_all(["th", "td"])
            row_cells = table.add_row().cells
            col_idx = 0
            for cell in cells:
                # Set cell value
                row_cells[col_idx].text = cell.get_text()
                # Handle attributes
                rowspan = int(cell.get("rowspan", 1))
                colspan = int(cell.get("colspan", 1))
                # Merge cells if needed
                if rowspan > 1 or colspan > 1:
                    for i in range(min(rowspan, len(table.rows) - row_idx)):
                        for j in range(min(colspan, len(header_cells) - col_idx)):
                            if i != 0 or j != 0:
                                target_cell = table.cell(row_idx + i, col_idx + j)
                                row_cells[col_idx].merge(target_cell)
                # Move to the next column index
                col_idx += colspan
            # Move to the next row index
            row_idx += rowspan

    def add_html_content_to_docx(self, document, html_content):
        soup = BeautifulSoup(html_content, "html.parser")
        current_paragraph = document.add_paragraph()
        added_texts = set()
 
        for elem in soup.descendants:
            if isinstance(elem, NavigableString):
                text = str(elem).strip()
                if text and text not in added_texts:
                    parent = elem.parent
                    if parent.name == 'a' and parent.has_attr('href'):
                        # Add a space before the hyperlink if it's not the start of the paragraph
                        if current_paragraph.text != '':
                            current_paragraph.add_run(' ')
                        self.add_hyperlink(current_paragraph, parent['href'], text)
                        # Add a space after the hyperlink
                        current_paragraph.add_run(' ')
                    else:
                        run = current_paragraph.add_run(text)
                        self.apply_formatting(run, parent.name)
                    added_texts.add(text)
            elif elem.name in ['p', 'h1', 'h2', 'h3']:
                # Start a new paragraph for these elements, if there is already text
                if current_paragraph.text:
                    current_paragraph = document.add_paragraph()
                for content in elem.contents:
                    if isinstance(content, NavigableString):
                        text = str(content).strip()
                        if text and text not in added_texts:
                            run = current_paragraph.add_run(text)
                            self.apply_formatting(run, elem.name)
                            added_texts.add(text)
                    elif content.name == 'a' and content.has_attr('href'):
                        text = content.get_text(strip=True)
                        if text not in added_texts:
                            # Add a space before the hyperlink if it's not the start of the paragraph
                            if current_paragraph.text != '':
                                current_paragraph.add_run(' ')
                            self.add_hyperlink(current_paragraph, content['href'], text)
                            # Add a space after the hyperlink
                            current_paragraph.add_run(' ')
                            added_texts.add(text)
                    else:
                        run_text = content.get_text(strip=True)
                        if run_text not in added_texts:
                            run = current_paragraph.add_run(run_text)
                            self.apply_formatting(run, content.name)
                            added_texts.add(run_text)
                if elem.name in ['h1', 'h2', 'h3']:
                    current_paragraph.style = document.styles['Heading ' + elem.name[1]]
 
    def create_document(self):
        document = Document()
        for placeholder in self.payload['placeholders']:
            if 'content' in placeholder:
                if "text" in placeholder['content'] and len(placeholder['content']['text']):
                    html_content = placeholder['content']['text']
                    self.add_html_content_to_docx(document, html_content)
                
                if 'images' in placeholder['content'] and len(placeholder['content']['images']):
                    for image_data in placeholder['content']['images']:
                        if "id" in image_data and image_data["id"]:
                            #Call docinsights api and get data
                            payload= json.dumps({
                                "content_uuid_paths":[image_data["id"]],
                                "request_id":image_data["request_id"]
                            })
                            data = self.get_data_docinsights(self.user_info,payload)
                            self.add_image(document, data[0]['content'])
                        elif "content" in image_data and image_data["content"]:
                            self.add_image(document, image_data["content"])
                        else:
                            raise HTTPException(status_code= 400,
                                detail= f"Image id or content needs to be present."
                            )
                            
                if 'tables' in placeholder['content'] and len(placeholder['content']['tables']):
                    for html_table in placeholder['content']['tables']:
                        if "id" in html_table and html_table["id"]:
                            #Call docinsights api and get data
                            payload= json.dumps({
                                "content_uuid_paths":[html_table["id"]],
                                "request_id":html_table["request_id"]
                            })
                            data = self.get_data_docinsights(self.user_info,payload)
                            self.add_table(document, data[0]['content'])
                        elif "content" in html_table and html_table["content"]: 
                            self.add_table(document, html_table["content"])
                        else:
                            raise HTTPException(status_code= 400,
                                detail= f"Table id or content needs to be present."
                            )
                            
                citations = placeholder['content'].get('citations')
                if citations:
                    citation_enhance = lambda data: json.loads(data) if isinstance(data, str) else data
                    parse_citations = citation_enhance(citations)
                    # Add the citations with a smaller font size, as plain text
                    p = document.add_paragraph("Citations:\n")
                    for citation in parse_citations:
                        source = citation['filename'] if citation['filename'].strip() else "N/A"
                        page = str(citation['page']) if str(citation['page']).strip() else "N/A"
                        section = str(citation['section']) if str(citation['section']).strip() else "N/A"
                        citation_text = f"Filename: {source}, Page: {page}, Section: {section}\n"                
                        run=p.add_run(citation_text)
                        run.font.size = Pt(8)
                        run.font.name = 'sans-serif' 
        
        # Instead of saving the file directly, return a BytesIO object
        docx_blob = BytesIO()
        document.save(docx_blob)
        docx_blob.seek(0)
        return docx_blob