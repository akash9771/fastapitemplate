import os
from fastapi import UploadFile
import boto3
from dotenv import load_dotenv
from utils.logs.logger_config import logger
from fastapi import HTTPException
from utils.date_time import get_timestamp
load_dotenv()

def upload_to_s3(
    file: UploadFile,
    tenant: str,
    file_name: str,
    user: str
):
    """Uploads file in the S3 bucket. The bucket name is configured in
    the environment variables.

    Args:
        file: actual local file
        tenant (str): group ntid or reference id
        file_name (str): file name

    Returns:
        Any: returns S3 Path.
        Otherwise returns BadRequest/InternalServerError response in case of failure
    """
    client = boto3.client("s3")
    try:
        logger.info("Inside s3 upload!")
        bucket_name: str = os.getenv("S3_BUCKET_NAME", "null")
        timestamp:str = get_timestamp()
        file_name:str = f"{file_name}_{timestamp}"
        file_path: str = f"{tenant}/{user}/documents/{file_name}.html"
        file_content = file.file.read()

        logger.info("bucket name", bucket_name)
        logger.info("filepath", file_path)

        # upload doc
        client.put_object(Body=file_content, Bucket=bucket_name, Key=file_path)
        # relative path 
        body = {"s3Path": f"{file_path}"}

        return body  # 200 success response

    except client.exceptions.NoSuchBucket as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except client.exceptions.ClientError as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code= 501,
            detail= f"Error while uploading file to s3.\n {e.args}"
        )

def delete_file_from_s3(
    file_path: str,
):
    """Deletes a file from S3.

    Args:
        file_path (str): path of file

    Returns:
        Success message.
        Otherwise returns BadRequest/InternalServerError response in case of failure
    """

    client = boto3.client("s3")

    try:
        logger.info("Inside s3 delete!")
        bucket_name: str = os.getenv("S3_BUCKET_NAME", "null")
        logger.info("bucket name", bucket_name)
        logger.info("file_path", file_path)
        client.delete_object(Bucket=bucket_name, Key=file_path)
        return True  # 200 success response
    except client.exceptions.NoSuchBucket as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except client.exceptions.ClientError as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code= 501,
            detail= f"Error while deleting file.\n {e.args}"
        )

def archive_file(document: object):
    """Moves an object from the source path to the archive path in S3.

    Args:
        document (object): document to be deleted.

    Returns:
        Success message if the move is successful.
        Otherwise returns BadRequest/InternalServerError response in case of failure.
    """
    client = boto3.client("s3")

    try:
        logger.info("Inside S3 move!")
        bucket_name: str = os.getenv("S3_BUCKET_NAME", "null")
        source_path = document["relative_url"]
        tenant = document["creator_tenant_id"]
        created_by = document["created_by"]
        document_name = document["name"]
        timestamp:str = get_timestamp()
        file_name:str = f"{document_name}_{timestamp}"
        destination_path = f"{tenant}/{created_by}/deleted/{file_name}.html"
        logger.info(f"moving file from {source_path} to {destination_path}")
        logger.info("bucket name", bucket_name)
        client.copy_object(
            Bucket=bucket_name,
            CopySource={'Bucket': bucket_name, 'Key': source_path},
            Key=destination_path
        )
        client.delete_object(Bucket=bucket_name, Key=source_path)
        return {"message": "Object successfully moved to archive folder!"}
    except client.exceptions.NoSuchBucket as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except client.exceptions.ClientError as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code= 501,
            detail= f"Error while archive file.\n {e.args}"
        )
        
def download_file(file_path: str):
    """Downloads the file mentioned in the path from an AWS S3 bucket

    Args:
        file_path: bucket path

    Returns:
        Dict[str, Any]: JSON like Python Dict object
    """
    client = boto3.client("s3")
    try:
        logger.info("Inside s3_v2 downlaod!")
        bucket_name: str = os.getenv("S3_BUCKET_NAME", "null")
        logger.info("bucket name inside read file from s3_v2 function", bucket_name)
        logger.info("filename inside read file from s3_v2 function", file_path)
        response = client.get_object(Bucket=bucket_name, Key=file_path)
        return response["Body"].read()

    except client.exceptions.NoSuchBucket as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except client.exceptions.ClientError as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code= 501,
            detail= f"Error while downloading file.\n {e.args}"
        )

def read_a_file(file_path: str):
    """Reads a file from S3 in HTML.

    Args:
        file_path (str): file path

    Returns:
        Success message.
        Otherwise returns BadRequest/InternalServerError response in case of failure
    """
    client = boto3.client("s3")
    html_content = """
            <!doctype html>
            <html>
                <head>
                    <title>Content Error</title>
                    <meta charset="utf-8"/>
                    <meta http-equiv="Content-type" content="text/html; charset=utf-8"/>
                    <meta name="viewport" content="width=device-width, initial-scale=1"/>
                <style type="text/css">* {font-family: Inter;} body {padding: 2em;}</style>
                </head>
                <body>
                    <div>
                        <h1>Content Error</h1>
                        <p>Corresponding content corrupted or not found</p>
                    </div>
                </body>
            </html>
        """
    try:
        logger.info("Inside s3_v2 read file!")
        logger.info("file_path",file_path)
        bucket_name: str = os.getenv("S3_BUCKET_NAME", "null")
        logger.info("bucket name inside read file from s3_v2 function", bucket_name)
        logger.info("filename inside read file from s3_v2 function", file_path)
        response = client.get_object(Bucket=bucket_name, Key=file_path)
        html_content = response["Body"].read().decode("utf-8")
        return html_content
    except client.exceptions.NoSuchBucket as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except client.exceptions.NoSuchKey as err:
        logger.error(err)
        return html_content
    except client.exceptions.ClientError as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except Exception as e:
        logger.error(e)
        return html_content

def copy_file(tenant,file_name, user, existing_url:str):
    """Copy an object in S3.

    Args:
        document (object): document to be copied.

    Returns:
        Success message if the move is successful.
        Otherwise returns BadRequest/InternalServerError response in case of failure.
    """
    client = boto3.client("s3")

    try:
        logger.info("Inside s3 upload!")
        bucket_name: str = os.getenv("S3_BUCKET_NAME", "null")
        timestamp:str = get_timestamp()
        file_name:str = f"{file_name}_{timestamp}"
        file_path: str = f"{tenant}/{user}/documents/{file_name}.html"

        logger.info("bucket name", bucket_name)
        logger.info("filepath", file_path)
        client.copy_object(
            Bucket=bucket_name,
            CopySource={'Bucket': bucket_name, 'Key': existing_url},
            Key=file_path
        )
        body = {"s3Path": f"{file_path}"}

        return body
    except client.exceptions.NoSuchBucket as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except client.exceptions.ClientError as err:
        logger.error(err)
        raise HTTPException(status_code= 400, detail= f"{err.args[0]}")
    except Exception as e:
        logger.error(e)
        raise HTTPException(status_code= 501,
            detail= f"Error while archive file.\n {e.args}"
        )