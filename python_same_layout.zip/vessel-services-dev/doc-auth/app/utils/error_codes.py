status_codes_msg = {
    400: "The server didn't understand your request. Please check the provided information and try again.",
    401: "You are not authorized to access this resource. Please make sure you have the necessary permissions.",
    402: "Payment is required to proceed. Please make the necessary payment and try again.",
    403: "Looks like you're not able to access this feature right now. Make sure you've joined the right group to use this service.",
    404: "The requested resource was not found. Please make sure you entered the correct URL.",
    405: "The server doesn't allow the requested method for this resource. Please try a different method.",
    406: "The server cannot provide the content in the requested format. Please try a different format.",
    407: "Authentication is required to access this resource via a proxy. Please provide valid credentials.",
    408: "The server didn't receive a timely response. Please check your internet connection and try again.",
    409: "There is a conflict with the current state of the resource. Please resolve the conflict and try again.",
    410: "The requested resource is no longer available. It may have been removed or relocated.",
    411: "The 'Content-Length' header is required for this request. Please provide the necessary length.",
    412: "The server didn't meet the preconditions specified in your request. Please check the requirements.",
    413: "The request payload is too large for the server to handle. Please reduce the payload size.",
    414: "The requested URL is too long for the server to process. Please shorten the URL and try again.",
    415: "The server doesn't support the provided media type. Please try a different media type.",
    416: "The requested range is not satisfiable for the resource. Please request a valid range.",
    417: "The server couldn't meet the expectations specified in the 'Expect' header. Please adjust your expectations.",
    418: "I'm a teapot. The server is a teapot, not capable of fulfilling this request.",
    421: "The server cannot process the request due to a misdirected server resource.",
    422: "The server cannot process the request due to semantic errors. Please check your request.",
    423: "The requested resource is locked and currently unavailable. Please try again later.",
    424: "The request failed due to a dependency on another resource. Please resolve the dependency and try again.",
    425: "The server is not willing to process the request at this time. Please try again later.",
    426: "Switch to a different protocol version to proceed with the request.",
    428: "The server requires certain preconditions to be met for this request. Please fulfill the preconditions.",
    429: "You have exceeded the rate limit for this resource. Please wait for a while and try again.",
    431: "The server refused the request due to excessive header size. Please reduce the header size.",
    451: "The requested resource is unavailable due to legal restrictions.",
    500: "Something went wrong on the server. Please try again later.",
    501: "The server doesn't support the requested feature. Please try a different feature.",
    502: "Bad Gateway. There was an issue with the upstream server. Please try again later.",
    503: "Service Unavailable. The server is temporarily unable to handle the request. Please try again later.",
    504: "Gateway Timeout. The server didn't receive a timely response from an upstream server.",
    505: "The server doesn't support the HTTP protocol version used in the request.",
    506: "The server has an internal configuration error. Please contact the server administrator.",
    507: "The server has insufficient storage to fulfill the request. Please free up some storage and try again.",
    508: "The server detected an infinite loop while processing the request.",
    510: "The server requires further extensions to fulfill the request. Please contact the server administrator.",
    511: "The client needs to authenticate to gain network access. Please provide valid credentials.",
}

def get_human_status_code_msg(status_code, message=None):
    conditions_to_avoid = [None, "", " ", "Forbidden"]
    if message not in conditions_to_avoid:
        return status_code, str(message)

    if status_code in status_codes_msg:
        return (
            status_code, status_codes_msg[status_code],
        )
    else:
        return status_code, "Unknown Error!"