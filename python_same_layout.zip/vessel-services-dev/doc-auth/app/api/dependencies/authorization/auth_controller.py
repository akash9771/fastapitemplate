import logging, requests
from config.config import config 
from fastapi import Request
from fastapi import HTTPException
from starlette.responses import Response, JSONResponse
from fastapi import status
import json

class ExceptionCustom(HTTPException):
    pass

class AuthController:
    logger = logging.getLogger(__name__)

    @staticmethod 
    async def verify_token(request: Request) -> Response:
        logging.info(f"Request: {request.headers.__dict__}")
        authorization = request.headers["x-auth"]
        
        if authorization is None:
            return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "X-auth header is missing"})
        if not authorization.startswith("Bearer "):
            return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "Invalid Bearer token format"})
        bearer_token = authorization[7:]
        if not bearer_token:
            return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "Token not found"})
        
        payload = {
            "token": {bearer_token},
            "client_id": {config.PINGFEDERATE_CLIENT_ID},
            "client_secret": {config.PINGFEDERATE_CLIENT_SECRET}
          }
        if "x-server-token" in request.headers:
            payload["grant_type"]={config.GRANT_TYPE}
            if "x-username" in request.headers:
                username = request.headers["x-username"]
                if username is None or username == "":
                    return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "Username header not found"})
            if "x-usergroups" in request.headers:
                usergroups = request.headers["x-usergroups"].split(",")

        try:
            response = requests.post(url=config.PINGFEDERATE_TOKEN_VALIDATION_URL, data=payload, headers=config.FORM_DATA_HEADER)
            responseDict = json.loads(response.text)            
            
            if("active" in responseDict.keys()):
                if(responseDict["active"] == False):
                    return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "Token expired"})

            if 'error_description' in responseDict.keys():
                return JSONResponse(status_code=status.HTTP_403_FORBIDDEN, content={"detail": responseDict["error_description"]})
            
            user_groups = []
            groups = responseDict.get("group", None)
            if isinstance(groups, list):
                groups_cleaned = [group.split("CN=")[1].split(",")[0] for group in groups]
            elif isinstance(groups, str) and "CN=" in groups:
                groups_cleaned = [groups.split("CN=")[1].split(",")[0]]
            else:
                groups_cleaned = []
            
            if groups is None and "x-server-token" in request.headers:
                groups_cleaned = usergroups
            
            if (config.ALLOWED_GROUPS != ""):
                allowed_groups = config.ALLOWED_GROUPS.split("|")
                for group in groups_cleaned:               
                    for allowed_group in allowed_groups:
                        if (group == allowed_group):
                            user_groups.append(group)
                if (len(user_groups) == 0):
                    return JSONResponse(status_code=status.HTTP_403_FORBIDDEN, content={"detail": "User does not belong to any known groups"})
                responseDict["user_groups"] = user_groups  
            else:
                responseDict["user_groups"] = groups_cleaned
            
            mule_client_id = ''
            
            if "x-agw-client_id" not in request.headers:
                raise HTTPException(status_code=403, detail="Mule Client id is not present in the header")
            elif "x-agw-client_id" in request.headers and request.headers.get("x-agw-client_id") is None:
                logging.info("Mule client id is not present")
                raise HTTPException(status_code=403, detail="Mule Client id is not present in the header")
            else:
                mule_client_id = request.headers.get("x-agw-client_id")

            responseDict["mule_client_id"] = mule_client_id
            if "x-server-token" in request.headers:
                responseDict["Username"] = username.upper()
            else: 
                responseDict["Username"] = responseDict["Username"].upper()

            request.state.userInfo = responseDict
            return JSONResponse(status_code=status.HTTP_200_OK, content=responseDict)
        
        except requests.HTTPError as http_err:
            return JSONResponse(status_code=status.HTTP_401_UNAUTHORIZED, content={"detail": "Token invalid"})
        except requests.RequestException as err:
            return JSONResponse(status_code=status.HTTP_400_BAD_REQUEST, content={"detail": "Bad request"})
        except Exception as e:
            return JSONResponse(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, content={"detail": "Internal server error."})
