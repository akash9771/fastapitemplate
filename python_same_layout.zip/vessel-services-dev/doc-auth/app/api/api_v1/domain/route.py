from fastapi import APIRouter, Request
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation
from config.load_config import config
from api.api_v1.domain.controller import DomainController
from utils.api_response import generate_api_success_response_raw



domain_router = APIRouter()


@domain_router.get("/domains")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_all_domains(request : Request):
    """[Get List of all domains]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of domains]
    """
    list_of_domains = DomainController().get_all_domains_controller()
    return generate_api_success_response_raw(body=list_of_domains)


@domain_router.get("/sub-domains")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_all_subdomains(request : Request, domain_id: int):
    """[Get List of all subdomains]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of subdomains]
    """
    list_of_sub_domains = DomainController().get_all_subdomains(domain_id)
    return generate_api_success_response_raw(body=list_of_sub_domains)
