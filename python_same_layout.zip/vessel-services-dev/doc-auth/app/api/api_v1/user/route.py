from fastapi import APIRouter, Request
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation
from config.load_config import config
from api.api_v1.user.controller import UserController
from schemas.v1.requests.UserRequest import UserDetails
from utils.api_response import generate_api_success_response_raw


user_detail_router = APIRouter()


@user_detail_router.post("/user/register")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_user(request : Request, create_user_request: UserDetails):
    """[API router to create new user into the system]

    Args:
        create_user_request (create): [New user details]

    Raises:
        HTTPException: [Unauthorized exception when invalid token is passed]
        error: [Exception in underlying controller]

    Returns:
        [createResponse]: [create new user response]
    """
    user_obj = UserController().create_user_controller(create_user_request)
    return generate_api_success_response_raw(body=user_obj)


@user_detail_router.get("/get-all-user")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_all_users(request : Request):
    """[Get List of all users]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of users]
    """
    list_of_users = UserController().get_all_user()
    return generate_api_success_response_raw(body=list_of_users)
