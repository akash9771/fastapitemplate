from typing import Optional
from fastapi import APIRouter, Request
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

from config.load_config import config
from api.api_v1.admin_config.controller import AdminConfigController
from schemas.v1.requests.AdminConfigRequest import AdminConfigRequest
from utils.api_response import generate_api_success_response_raw


admin_config_router = APIRouter()


@admin_config_router.get("/admin-config")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_all_admin_configs(request : Request, domain: Optional[str] = None, subdomain: Optional[str] = None):
    """[Get List of all admin_configs]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of AdminConfigs]
    """
    list_of_admin_configs = AdminConfigController().get_all_admin_config(domain, subdomain)
    return generate_api_success_response_raw(body=list_of_admin_configs)
