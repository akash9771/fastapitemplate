from fastapi import APIRouter, Request
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

from config.load_config import config
from api.api_v1.dashboard.controller import MetricController
from api.api_v1.document.controller import DocumentController
from utils.api_response import generate_api_success_response_raw


dashboard_router = APIRouter()

@dashboard_router.get("/dashboard/count")
@async_token_validation_and_metering()
@auth_token_validation()
async def fetch_metric(request : Request):
    """[Get List of all project]

    Raises:
        error: [Error details]

    Returns:
        [str]: [Success response]
    """
    metric_obj = MetricController().fetch_metric()
    return generate_api_success_response_raw(body=metric_obj)


@dashboard_router.get("/dashboard/stats")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_dashboard_stats(request : Request, project_id: int):
    """[Get dashboard stats by project id]

    Raises:
        error: [Error details]

    Returns:
        dict: dashboard stats
    """
    stats = DocumentController().get_dashboard_stats(project_id)
    return generate_api_success_response_raw(body=stats)
