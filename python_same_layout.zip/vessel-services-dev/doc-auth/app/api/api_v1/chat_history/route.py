import json
from fastapi import APIRouter, Request
from config.load_config import config
from api.api_v1.chat_history.controller import ChatHistoryController
from schemas.v1.requests.ChatHistoryRequest import ChatHistoryRequest

from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation
from utils.api_response import generate_api_success_response_raw


chat_history_router = APIRouter()


@chat_history_router.get("/chat-history/{id}")
@async_token_validation_and_metering()
@auth_token_validation()
async def fetch_chat_history(request : Request , id: int):
    """[API router to fetch chat history by id]

    Args:
        id: chat id

    Raises:
        HTTPException: [Unauthorized exception when invalid token is passed]
        error: [Exception in underlying controller]

    Returns:
        [chat history][List]: [chat history response]
    """
    chat_history = ChatHistoryController().fetch_chat_history(id)

    return generate_api_success_response_raw(body=chat_history)


@chat_history_router.post("/chat-history")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def update_chat_history(request : Request , id: int, chat_history_req: ChatHistoryRequest):
    """[API router to update chat history by id]

    Args:
        id: chat id
        chat_history_req (create): [prompt and content details]

    Raises:
        HTTPException: [Unauthorized exception when invalid token is passed]
        error: [Exception in underlying controller]

    Returns:
        [chat history][List]: [chat history response]
    """
    chat_history = ChatHistoryController().update_chat_history(id, chat_history_req)
    return generate_api_success_response_raw(body=chat_history)
