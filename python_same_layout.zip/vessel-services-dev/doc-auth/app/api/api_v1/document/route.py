import json
from fastapi import APIRouter, Request, File, UploadFile, Form
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation
from config.load_config import config
from api.api_v1.document.controller import DocumentController
from schemas.v1.requests.DocumentCreateRequest import DocumentRequest
from utils.api_response import generate_api_success_response_raw




document_router = APIRouter()


@document_router.get("/document/all")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_all_documents(request : Request):
    """[Get List of all documents]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of documents]
    """
    list_of_documents = DocumentController().get_all_documents()
    return generate_api_success_response_raw(body=list_of_documents)


@document_router.get("/document/mine")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_documents_by_ntid(request : Request, nt_id: str):
    """[Get List of all documents by nt_id]

    Raises:
        error: [Error details]

    Returns:
        [list]: [List of documents]
    """
    list_of_documents = DocumentController().get_documents_by_ntid(nt_id)
    return generate_api_success_response_raw(body=list_of_documents)


@document_router.post("/document")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_document(request : Request, create_document_request: DocumentRequest):
    """[API router to create new document into the system]

    Args:
        create_document_request (create): [New document details]

    Raises:
        HTTPException: [Unauthorized exception when invalid token is passed]
        error: [Exception in underlying controller]

    Returns:
        [createResponse]: [create new document response]
    """
    document_obj = DocumentController().create_document(
        create_document_request
    )
    return generate_api_success_response_raw(body=document_obj)


@document_router.get("/document/{document_id}")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_by_document_id(request : Request, document_id: int):
    """[Get document by id]

    Raises:
        error: [Error details]

    Returns:
        dict: document record
    """
    document = DocumentController().read_by_id(document_id)
    return generate_api_success_response_raw(body=document)


@document_router.put("/document/{document_id}")
@async_token_validation_and_metering(uom=3)
@auth_token_validation()
async def update_document(
    request : Request,
    document_id: int,
    update_document_request: str = Form(...),
    html_file: UploadFile = File(),
):
    """[Update document by document name]

    Raises:
        error: [Error details]

    Returns:
        [str]: [Success response]
    """
    update_document_request = json.loads(update_document_request)
    document_obj = DocumentController().update_document(
        document_id, update_document_request, html_file
    )
    return generate_api_success_response_raw(body=document_obj)


@document_router.delete("/document/{document_id}", include_in_schema=False)
@async_token_validation_and_metering()
@auth_token_validation()
async def delete_document(request : Request, document_id: int):
    """[Get List of all document]

    Raises:
        error: [Error details]

    Returns:
        [str]: [Success response]
    """
    document_obj = DocumentController().delete_Document(document_id)
    return generate_api_success_response_raw(body=document_obj)


@document_router.get("/document/{document_name}", include_in_schema=False)
@async_token_validation_and_metering()
@auth_token_validation()
async def get_document_by_name(request : Request, document_name: str):
    """[Get document by name]

    Raises:
        error: [Error details]

    Returns:
        dict: document record
    """
    document = DocumentController().read_by_name(document_name)
    return generate_api_success_response_raw(body=document)


@document_router.get("/document")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_document_by_project_id(request : Request, project_id: int):
    """[Get document by project id]

    Raises:
        error: [Error details]

    Returns:
        dict: document record
    """
    document = DocumentController().read_by_project_id(project_id)
    return generate_api_success_response_raw(body=document)


@document_router.get("/download", include_in_schema=False)
@async_token_validation_and_metering()
@auth_token_validation()
async def download_file(request : Request, id: int):
    """[API router to download document by id]

    Args:
        id: chat id

    Raises:
        HTTPException: [Unauthorized exception when invalid token is passed]
        error: [Exception in underlying controller]

    Returns:
        [File]: [downloaded file]
    """
    file = DocumentController().download_file(id)
    return file
