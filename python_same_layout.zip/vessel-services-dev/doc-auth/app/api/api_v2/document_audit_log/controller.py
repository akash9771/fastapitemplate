from utils.logs.logger_config import logger
from crud.v2.document_crud import CRUDDocument
from crud.v2.document_audit_log_crud import CRUDDocumentsAuditLog
from fastapi import HTTPException

class DocumentAuditLogController:
    def __init__(self):
        self.CRUDDocument = CRUDDocument()
        self.CRUDDocumentsAuditLog = CRUDDocumentsAuditLog()


    def create_audit_log(self, document_id: str, action: str, detail: str, created_by: str) -> None:
        """Controller to create a audit log record

        Args:
            document_id (str): id of the document
            action (str): type of logs to fetch. Defaults to none.
            detail (str): description
            created_by (str): username
        """
        logger.info("calling create doc audit log crud ....")
        audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=document_id, 
                                                    action=action,
                                                    detail= detail,
                                                    created_by=created_by
                                                    )


    def get_audit_log_by_document_id(self, user_info, document_id, action, page_limit, page_number):
        """[Controller to get audit log by document id]
            
        Args:
            user_info(required): info of the user
            document_id (str, required): id of document to fetch its audit logs.
            action(enum, optional): type of logs to fetch. Defaults to none.
            page_limit (int, optional): max number of documents on a page. Defaults to 10.
            page_number (int, optional): page number. Defaults to 1.

        Raises:
            Exception: Exception in underlying controller

        Returns:
            dict:  detail of a document-audit-log with given document id
        """
        logger.info("executing get-audit-log controller ...")
        logger.info("calling check user access to doc function .. ")
        has_access = self.CRUDDocument.check_user_access_to_document(user_info=user_info, doc_id=document_id)
        if has_access == False:
            logger.error("No access to document.")
            raise HTTPException(status_code= 400, detail=
                                 f'''You dont have access to the document with id={document_id}.\n Hence, you cant access its audit logs!''')
        
        logger.info("calling read by doc id audit logs crud ...")
        return self.CRUDDocumentsAuditLog.read_by_document_id( 
            document_id, 
            action, 
            page_limit, 
            page_number
        )