from fastapi import APIRouter, Request, HTTPException
from api.api_v2.document_audit_log.controller import DocumentAuditLogController
from db.orm_models.v2.enums import ACTION
from utils.logs.logger_config import logger
from utils.api_response import *
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

document_audit_router = APIRouter()

@document_audit_router.get("/documents/{document_id}/logs")
@async_token_validation_and_metering() 
@auth_token_validation() 
async def get_audit_logs_by_document_id(
    request:Request, 
    document_id: str,
    action: ACTION = None,
    page_limit: int = 10,
    page_number: int = 1):
    """
    API to get audit logs of a document by document id
    ```
    Args:
        document_id (str, required): id of document to fetch its audit logs.
        action(enum, optional): type of logs to fetch. Defaults to none.
        page_limit (int, optional): max number of documents on a page. Defaults to 10.
        page_number (int, optional): page number. Defaults to 1.

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [dict:  detail of a document-audit-log with given document id]: {
                    "success": true,
                    "message": "",
                    "details": {
                        "audit_logs": [
                            {
                                "detail": "string.",
                                "id": "string",
                                "created_at": "datetime",
                                "document_id": "string",
                                "action": "string",
                                "created_by": "string"
                            }
                        ],
                        "page_number":int,
                        "page_limit": int,
                        "total_count":int
                    }
                }
    ```
    """
    user_info =  request.state.userInfo
    logger.info("executing get_audit_log_by_document_id router ...")

    if page_number >= 1:
        if page_number > 1 and page_limit is None:
            logger.error("Page limit is also required with page number.")
            raise HTTPException(
                status_code=400, detail="Page limit is also required with page number."
            )
        elif page_limit is not None and page_limit <=0 and page_limit != -1:
            logger.error("Page limit cannot be 0 or less than -1.")
            raise HTTPException(
                status_code=400, detail="Page limit cannot be 0 or less than -1."
            )
        
    elif page_number < 1:
            logger.error("Page number cannot be less than 1.")
            raise HTTPException(
                status_code=400, detail="Page number cannot be less than 1."
            )

    logger.info("calling document audit controller ...")
    audit_logs_response = DocumentAuditLogController().get_audit_log_by_document_id(
        user_info,
        document_id,
        action,
        page_limit,
        page_number)
    return generate_api_success_response(body = audit_logs_response)