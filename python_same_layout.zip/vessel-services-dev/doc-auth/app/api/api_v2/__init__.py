from fastapi import APIRouter
from api.api_v2.document.route import document_router
from api.api_v2.stats.route import stats_router
from api.api_v2.placeholders.route import placeholder_router
from api.api_v2.document_share.route import document_sharing_router
from api.api_v2.document_audit_log.route import document_audit_router
from api.api_v2.data_migrate.route import data_migrate

api_router_v2 = APIRouter()
api_router_v2.include_router(document_router, tags=["document"])
api_router_v2.include_router(placeholder_router, tags=["placeholders"])
api_router_v2.include_router(document_sharing_router, tags=["document sharing"])
api_router_v2.include_router(document_audit_router, tags= ["audit logs"])
api_router_v2.include_router(stats_router, tags=["stats"])
api_router_v2.include_router(data_migrate,tags=["data migrate"])