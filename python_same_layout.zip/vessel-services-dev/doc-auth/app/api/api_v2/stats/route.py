from api.api_v2.stats.controller import StatsController
from fastapi import APIRouter,Request
from utils.api_response import generate_api_success_response
from utils.logs.logger_config import logger
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

stats_router = APIRouter()


@stats_router.get("/stats")
@async_token_validation_and_metering()
@auth_token_validation() 
async def get_stats(
    request:Request
):
    """[API to get count of private and shared documents]
    ```
    Args:
        No params needed

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [dict]: {
            "success": true,
            "message": "",
            "details": {
                "private_documents_count": int,
                "shared_documents_count": int
            }
        }
    ```
    """
    try:
        logger.info("In get stats route..")
        user_info =  request.state.userInfo

        count = StatsController().get_stats(
            user_info
        )
        return generate_api_success_response(body=count)
    except Exception as e:
        raise e

