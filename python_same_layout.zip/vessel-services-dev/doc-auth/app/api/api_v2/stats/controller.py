from crud.v2.stats_crud import CRUDStats
from utils.logs.logger_config import logger


class StatsController:
    def __init__(self):
        self.CRUDStats = CRUDStats()


    def get_stats(self, user_info):
        """[Gets doc counts from doc table]"""
        logger.info("executing get-doc-stats controller ...")
        return self.CRUDStats.get_stats(user_info)
    
