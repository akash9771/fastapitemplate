from crud.v2.stats_crud import CRUDStats
from utils.logs.logger_config import logger
from io import StringIO
from uuid import UUID
from api.api_v2.document.controller import DocumentController
import json
import pandas as pd
import boto3
import os
import numpy as np

S3_BUCKET_NAME_BIOPHARMA=os.getenv("S3_BUCKET_NAME_BIOPHARMA")

def download_s3_file_to_df(bucket_name, file_name):
    """Converts a CSV file from S3 bucket to a pandas DataFrame

    :param bucket_name: Bucket to get CSV from
    :param file_name: File to convert to DF
    :return: A dataframe version of the selected CSV
    """
    # Initialize the S3 client
    s3_client = boto3.client('s3')
    # Read the CSV file from S3 into a Pandas DataFrame
    obj = s3_client.get_object(Bucket=bucket_name, Key=file_name)
    s3_data = obj['Body'].read()
    try:
        decoded_data = s3_data.decode('utf-8')
        df = pd.read_csv(StringIO(decoded_data))
        return df
    except UnicodeDecodeError:
        decoded_data = s3_data.decode('latin1')
        df = pd.read_csv(StringIO(decoded_data))
        return df

def transform_docs(df,client_id):
    # Apply your transformation logic here
    df = df.dropna(subset=['name'])
    transformed_df = pd.DataFrame()
    transformed_df["name"] = df["name"]
    transformed_df['type'] = "DOC"
    transformed_df['is_template'] = False
    transformed_df['content'] = None
    transformed_df["metadata_info"] = df.apply(lambda row: {"readability_score": row["readability_score"],
                                                                        "perception_score": row['perception_score'],
                                                                        "words": row["words"],
                                                                        "characters": row["characters"],
                                                                        "old_session_id":row["session_id"]}, 
                                                                        axis = 1)
    transformed_df['creator_tenant_id'] = client_id
    transformed_df['is_deleted'] = False
    transformed_df['is_locked_by'] = df["locked_by"]
    transformed_df['is_private'] = False
    transformed_df['parent_id'] = None
    transformed_df['created_at'] = df["creation_date"]
    transformed_df["created_by"] = df['ntid']
    transformed_df['modified_at'] = df['modification_date']
    transformed_df["modified_by"] = df['ntid']
    transformed_df['session_id'] = df["session_id"]
    transformed_df = transformed_df.where(pd.notna(transformed_df), None)
        
    return transformed_df.to_dict(orient="records")
 
def load_data(transformed_df,user_info,client_id):
    try:
        total_records_migrated=0
        for doc in transformed_df:
            placeholders=doc['placeholders']
            temp=[]
            for placeholder_id in placeholders:
                try:
                    uuid_obj=UUID(placeholder_id['id'],version=4)
                    temp.append(placeholder_id)
                except ValueError:
                    continue
            doc['placeholders']=temp
            doc['sharing_details']=[{
                "shared_with_type":"GROUP",
                "shared_with_id":"VOX_BIOPHARMA_MSC_Users"
            }]
            user_info={
                "Username":doc['created_by'],
                "user_groups":["VOX_BIOPHARMA_MSC_Users"],
                'mule_client_id':client_id
            }
            result=DocumentController().create_document(doc,file = None, isFilePresent= False,user_info=user_info)
            total_records_migrated+=1
        return total_records_migrated

    except Exception as e:
        print(f"Error: Unable to load data into the v2 schema\n{e}")
 
def migrate_data(user_info,client_id):
    
    session=download_s3_file_to_df(bucket_name=S3_BUCKET_NAME_BIOPHARMA, file_name="database csv/Session.csv")
    session = session.where(pd.notna(session), None)

    placeholder=download_s3_file_to_df(bucket_name=S3_BUCKET_NAME_BIOPHARMA, file_name="database csv/Placeholder.csv")
    placeholder = placeholder.where(pd.notna(placeholder), None)

    section=download_s3_file_to_df(bucket_name=S3_BUCKET_NAME_BIOPHARMA, file_name="database csv/Section.csv")
    section = section.where(pd.notna(section), None)

    records = transform_docs(session,client_id)
    placeholder = placeholder.merge(session[['session_id',"ntid"]], on= "session_id")

    section["metadata_info"] = section.apply(lambda row: {"name": row["name"], "words": row["words"], "characters": row["characters"]}, axis =1)

    for i, section_row in section.iterrows():
        index = placeholder.index[placeholder["section_id"] == section_row["section_id"]].tolist()
        if len(index) ==0:
            continue
        index = index[0]
        placeholder.loc[index, 'section_name'] = section_row['name']

    placeholder = placeholder.where(pd.notna(placeholder), None)
    placeholder.section_name.fillna('',inplace=True)
    placeholder.content.fillna('',inplace=True)
    transformed_df = pd.DataFrame()
    transformed_df["id"] = placeholder.placeholder_id
    transformed_df["section_id"] = placeholder.section_id
    transformed_df["content"] = placeholder.apply(lambda row:{"citations": row["citations"],"text": row['section_name']+"\n"+row["content"]}, axis = 1)  

    transformed_df = transformed_df.merge(section[['metadata_info',"section_id"]], on= "section_id",how="left")
    transformed_df=transformed_df.replace(np.nan,None)
    transformed_df.drop('section_id',axis = 1, inplace= True)
    transformed_df["created_at"] = placeholder['creation_date']
    transformed_df["created_by"] = placeholder["ntid"]
    transformed_df["modified_at"] = placeholder["modification_date"]
    transformed_df["modified_by"] = placeholder["ntid"]

    transformed_df["to_dict"] = transformed_df.apply(lambda row: row.to_dict(), axis =1)

    transformed_df["session_id"] = placeholder.session_id
    transformed_df = transformed_df.where(pd.notna(transformed_df), None)

    placeholder_list = transformed_df.to_dict(orient="records")

    for doc in records:
        doc['placeholders'] = []
        for placeholder in placeholder_list:
            if doc['session_id'] == placeholder['session_id']:
                doc['placeholders'].append(placeholder['to_dict'])
    
    for doc in records:
        del doc['session_id']
        
    return load_data(records,user_info,client_id)

class DataMigration:

    def data_migration(self, user_info,client_id):
        """[Migrate data from biopharma to doc-auth]"""
        logger.info("inside data migration controller...")
        total_records_migrated=migrate_data(user_info,client_id)
        return {"total_records_migrated":total_records_migrated}