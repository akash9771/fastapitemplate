import psycopg2
from fastapi import HTTPException
from utils.logs.logger_config import logger
from crud.v2.document_crud import CRUDDocument
from crud.v2.placeholder_crud import CRUDPlaceholder
from utils.aws.s3_v2 import read_a_file
import uuid
import os

VOX_DBNAME = os.getenv("VOX_DBNAME")
VOX_DBUSER = os.getenv("VOX_DBUSER")
VOX_DBPASSWORD = os.getenv("VOX_DBPASSWORD")
VOX_DBENDPOINT = os.getenv("VOX_DBENDPOINT")


class VOXDataMigration:
    def __init__(self):
        self.CRUDDocument = CRUDDocument()
        self.CRUDPlaceholder = CRUDPlaceholder()


    def get_html_from_s3(self, file_path):
        """[Get s3 HTML content]

        Args:
            file_path (str): relative url

        Returns:
            str: html content
        """
        html_content = read_a_file(file_path)
        return html_content

    def generate_uuid(self):
        """
        Generate a UUID (Universally Unique Identifier).
        
        Returns:
            str: UUID in string format.
        """
        return str(uuid.uuid4())
        
    def create_placeholders(self, user_info):
        """[create placeholders for all free flow documents]

        Args:
            user_info (dict): user information

        Returns:
            count(int) : document updated count
        """
        all_docs = self.CRUDDocument.get_all_documents(user_info)
        doc_count= 0
        for doc in all_docs:
            document_id = doc[0]
            type = doc[1].value
            relative_url = doc[2]
            metadata_info = doc[3]
            
            if relative_url != "" and type == 'DOC':
                placeholder_id = self.generate_uuid()
                html_content = self.get_html_from_s3(relative_url)
                placeholder = [{
                    "id": placeholder_id,
                    "document_id": document_id,
                    "sequence_no": 1,
                    "metadata_info":metadata_info,
                    "content": {"text":html_content},
                    "created_by": doc[4],
                    "modified_by": doc[5],
                }]

                self.CRUDPlaceholder.create(placeholder)
                doc_count+=1
            
        return doc_count


    def connect_to_target_database(self, dbname, user, password, host, port):
        try:
            connection = psycopg2.connect(dbname=dbname, user=user, password=password, host=host, port=port)
            logger.info("Connections established!")
            return connection
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Error: Unable to connect to the database\n{e}")


    def read_vox_chat_session_table(self, conn):

        if conn is not None:
            try:
                cursor = conn.cursor()

                cursor.execute("select id, placeholder_id from document_authoring_session where is_active = True")
                records = cursor.fetchall()
                logger.info("Records fetched!")
                return records
            except psycopg2.Error as e:
                logger.error(e)
                raise HTTPException(status_code= 501,
                    detail= f"error reading records: \n {e}")

    
    def update_vox_chat_session_table(self, conn, records, user_info):
        try:
            cursor = conn.cursor()
            count =0
            for record in records:

                record_id = record[0]
                doc_id = record[1]
                placeholders = self.CRUDPlaceholder.read_by_document_id(doc_id)

                if len(placeholders) >=2:
                    raise HTTPException(status_code= 501, detail=f"There are more than 1 placeholders present for doc_id: {doc_id}")
                elif len(placeholders) ==0:
                    continue
                placeholder = placeholders[0]
                
                #update chat_history_id in placeholder metadata
                placeholder["metadata_info"].update({"chat_history_id": record_id})
                placeholder_details_obj = {
                    "placeholder_id" : placeholder["id"],
                    "metadata_info" : placeholder["metadata_info"]
                    }
                logger.info("calling update placeholder crud ...")
                self.CRUDPlaceholder.update(user_info,**placeholder_details_obj)
                
                #replace doc id with placeholder id in chat history session
                cursor.execute("update document_authoring_session SET placeholder_id = %s where id = %s", (placeholder["id"], record_id))
                count+=1

            conn.commit()
            print("Records updated successfully.")
            return count
        except psycopg2.Error as e:
            logger.error(e)
            conn.rollback()
            raise HTTPException(status_code= 501,
                detail= f"error updating records: \n {e}")

    
    def data_migration(self, user_info):
        """[Entry point for data migration]

        Args:
            user_info (dict): user details
            client_id (str): mule client id

        Returns:
            dict: Count of total_records_updated
        """
        logger.info("inside data migration controller...")
        total_records_updated= self.create_placeholders(user_info)
        conn = self.connect_to_target_database(dbname=VOX_DBNAME, user=VOX_DBUSER, password=VOX_DBPASSWORD, host=VOX_DBENDPOINT, port=5432)
        records = self.read_vox_chat_session_table(conn)
        session_count = self.update_vox_chat_session_table(conn,records,user_info)
        return {
            "total_records_updated":total_records_updated,
            "sessions_updated": session_count
            }