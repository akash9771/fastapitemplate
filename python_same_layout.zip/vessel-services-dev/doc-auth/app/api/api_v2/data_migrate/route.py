from api.api_v2.data_migrate.vox_migrate_controller import VOXDataMigration
from fastapi import APIRouter,Request,HTTPException
from utils.api_response import generate_api_success_response
from utils.logs.logger_config import logger
from api.dependencies.authorization.auth_decorator import auth_token_validation
from validator.decorators import async_token_validation_and_metering
from config.config import config 
 
data_migrate = APIRouter()
 
 
@data_migrate.get("/data/migrate",include_in_schema=False)
@async_token_validation_and_metering()
@auth_token_validation()
async def data_migration(
    request:Request
):
    try:
        logger.info("In data migrate route..")
        if not config.IS_MIGRATION:
            raise HTTPException(status_code= 401, detail="Unauthorized access")
        user_info =  request.state.userInfo
        count = VOXDataMigration().data_migration(
            user_info
        )
        return generate_api_success_response(body=count)
    except Exception as e:
        raise e