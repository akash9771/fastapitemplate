from typing import List, Union
from fastapi import APIRouter, Request
from api.api_v2.placeholders.controller import PlaceholderController
from utils.logs.logger_config import logger
from utils.api_response import generate_api_success_response
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation
from api.api_v2.document_audit_log.controller import DocumentAuditLogController
from db.orm_models.v2.enums import ACTION
from schemas.v2.requests.PlaceholderRequest import UpdatePlaceholder, CreatePlaceholderWithId,UpdatePlaceholderById

placeholder_router = APIRouter()


@placeholder_router.post("/document/{document_id}/placeholders/count/{number}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_document_placeholders_from_count(
    request: Request, document_id: str, number:int
) -> dict:
    """API to create placeholders for a document
    ```
    Args:
        document_id (str): document id.
        count (int): placeholder count to be created.
    
    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [dict: placeholders created]: {
                        "success": true,
                        "message": "",
                        "details": [
                            "string"
                        ]
                    }
    ```
    """

    logger.info("calling create_document_placeholders_from_count router ...")

    user_info =  request.state.userInfo

    try:
        response = PlaceholderController().create_placeholders_with_count(
            user_info, document_id, number
        )
    except Exception as e:
        logger.info("calling create doc audit log crud ....")
        DocumentAuditLogController().create_audit_log(document_id=document_id, 
                                                    action=ACTION.UPDATED.value,
                                                    detail= "Error occurred while creating placeholders",
                                                    created_by=user_info["Username"])
        raise e

    
    return generate_api_success_response(body=response)


@placeholder_router.post("/document/{document_id}/placeholders")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_document_placeholders(request: Request, document_id: str, placeholders: List[Union[CreatePlaceholderWithId, UpdatePlaceholder]]) -> dict:
    """API to create placeholders for a document
    ```
    Args:
        document_id (str): document id.
    
    Payload:
        placeholders (list): requires a list of placeholder entries along with their sequence_no, metadata_info and content (all individually optional)
    
    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [dict: placeholders created, returns a list of all placeholder ids that were generated]: 
        {
            "success": true,
            "message": "",
            "details": [
                "string"
            ]
        }
    ```
    """

    logger.info("calling create_document_placeholders router ...")
    user_info =  request.state.userInfo
    try:
        response = PlaceholderController().create_placeholder(
            user_info, document_id, placeholders
        )
    except Exception as e:
        logger.info("calling create doc audit log crud ....")
        DocumentAuditLogController().create_audit_log(document_id=document_id, 
                                                    action=ACTION.UPDATED.value,
                                                    detail= "Error occurred while creating placeholders",
                                                    created_by=user_info["Username"])
        raise e

    
    return generate_api_success_response(body=response)


@placeholder_router.put("/document/{document_id}/placeholder/{placeholder_id}")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def update_placeholder_by_id(request : Request,
                           document_id:str,
                           placeholder_id:str,
                           placeholder_details:UpdatePlaceholderById):
    """[API router to update placeholder by id]

    ```
    Args:
        document_id (str): document_id
        placeholder_id (str): placeholder_id

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [updated placeholder]: {
                "success": true,
                "message": "Placeholder {id} updated successfully!",
                "details": {
                    "placeholder_id": "string"
                }
            }
    ```
    """
    user_info =  request.state.userInfo
    logger.info("executing update_placeholder router ...")
    logger.info("calling update_placeholder controller ...")
    response = PlaceholderController().update_placeholder_by_id(user_info,document_id,placeholder_id, placeholder_details)
    message= f'Placeholder {response} updated successfully!'
    return generate_api_success_response(message=message, body={"placeholder_id":response})

@placeholder_router.patch("/document/{document_id}/placeholder/{placeholder_id}/metadata")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def update_metadata_info(request : Request, document_id: str, placeholder_id: str, metadata_info: dict):
    """[API router to update metadata info for a placeholder]
    ```
    Args:
        document_id (str): path param : [document id ]
        placeholder_id (str): path param : [placeholder id ]
        metadata_info(dict): body : [metadata info for a placeholder]

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [dict : details of placeholder with given id] : {
                "success": true,
                "message": "",
                "details": {
                    "metadata_info": {},
                    "id":  "string",
                    "is_deleted": boolean,
                    "modified_by":  "string",
                    "created_at":"datetime",
                    "document_id":  "string",
                    "sequence_no": int,
                    "content": {},
                    "created_by":  "string",
                    "modified_at": "datetime""
                }
            }
    ```
    """
    user_info =  request.state.userInfo

    logger.info("executing update_metadata router ...")
    
    logger.info("calling update_metadata in placeholder controller ...")
    response = PlaceholderController().update_metadata(user_info,document_id, placeholder_id, metadata_info)
    message= f'Metadata Info for placeholder {response["id"]} is updated successfully!'
    return generate_api_success_response(message=message, body=response)


@placeholder_router.delete("/document/{document_id}/placeholder/{placeholder_id}")
@async_token_validation_and_metering() 
@auth_token_validation() 
async def delete_placeholder_by_id(
    request:Request, 
    document_id: str,
    placeholder_id:str):
    """[API router to delete the placeholder]
    ```
    Args:
        request (Request): _description_
        document_id (str): document_id
        placeholder_id (str): placeholder_id
    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }
    Returns:
        [dict: deleted placeholder id]:{
            "success": true,
            "message": "",
            "details": {
                "document_id": "string",
                "deleted_placeholder_ids": [
                    "string"
                ]
            }
        }
    ```
    """
    
    user_info =  request.state.userInfo
    logger.info("executing get_placeholder_by_id router ...")
    logger.info("calling placeholder controller ...")
    placeholders = PlaceholderController().delete_placeholders(
        user_info,
        document_id,
        placeholder_id)
    return generate_api_success_response(body = placeholders)

@placeholder_router.delete("/document/{document_id}/placeholder")
@async_token_validation_and_metering() 
@auth_token_validation() 
async def delete_placeholder_by_doc_id(
    request:Request, 
    document_id: str):
    """[API router to delete all placeholders for a document]
    ```
    Args:
        request (Request): _description_
        document_id (str): document_id
    
    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }
    Returns:
        [dict: deleted placeholders ids]:{
            "success": true,
            "message": "",
            "details": {
                "document_id": "string",
                "deleted_placeholder_ids": [
                    "string"
                ]
            }
        }
    ```
    """
    
    user_info =  request.state.userInfo
    logger.info("executing get_placeholder_by_id router ...")
    logger.info("calling placeholder controller ...")
    placeholders = PlaceholderController().delete_placeholders(
        user_info,
        document_id)
    return generate_api_success_response(body = placeholders)


@placeholder_router.get("/document/{document_id}/placeholder/{placeholder_id}")
@async_token_validation_and_metering() 
@auth_token_validation() 
async def get_placeholder_by_id(
    request:Request, 
    document_id: str,
    placeholder_id:str):

    """[Api router to get placeholders details]
    ```
    Args:
        document_id (str): document id
        placeholder_id(str): placeholder_id
    
    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [dict : placeholder details]: {
            "success": true,
            "message": "",
            "details": {
                "placeholder": {
                    "metadata_info": {},
                    "id":  "string",
                    "is_deleted": boolean,
                    "modified_by":  "string",
                    "created_at":"datetime",
                    "document_id":  "string",
                    "sequence_no": int,
                    "content": {},
                    "created_by":  "string",
                    "modified_at": "datetime""
                }
            }
        }
    ```
    """
    
    user_info =  request.state.userInfo
    logger.info("executing get_placeholder_by_id router ...")
    logger.info("calling placeholder controller ...")
    placeholders = PlaceholderController().get_placeholder_by_id(
        user_info,
        document_id,
        placeholder_id)
    return generate_api_success_response(body = placeholders)


@placeholder_router.get("/document/{document_id}/placeholders")
@async_token_validation_and_metering() 
@auth_token_validation() 
async def get_placeholder_by_doc_id(
    request:Request, 
    document_id: str):
    """[Api router to get placeholders list for a document]
    ```
    Args:
        document_id (str): document id
    
    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [dict: placeholder details]: {
            "success": true,
            "message": "",
            "details": [
                {
                    "metadata_info": {},
                    "id":  "string",
                    "is_deleted": boolean,
                    "modified_by":  "string",
                    "created_at":"datetime",
                    "document_id":  "string",
                    "sequence_no": int,
                    "content": {},
                    "created_by":  "string",
                    "modified_at": "datetime""
                }
            ]
        }
    ```
    """
    
    user_info =  request.state.userInfo
    logger.info("executing get_placeholder_by_doc_id router ...")
    logger.info("calling placeholder controller ...")
    placeholders = PlaceholderController().get_placeholder_by_doc_id(
        user_info,
        document_id)
    return generate_api_success_response(body = placeholders)