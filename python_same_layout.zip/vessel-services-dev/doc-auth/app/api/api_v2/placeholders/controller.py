from utils.logs.logger_config import logger
from crud.v2.document_crud import CRUDDocument
from crud.v2.placeholder_crud import CRUDPlaceholder
from crud.v2.document_audit_log_crud import CRUDDocumentsAuditLog
from db.orm_models.v2.enums import ACTION
from fastapi import HTTPException
from utils.exceptions import ResourceNotFound, BadRequestResult
from uuid import UUID
from schemas.v2.requests.PlaceholderRequest import UpdatePlaceholder


class PlaceholderController:
    def __init__(self):
        self.CRUDDocument = CRUDDocument()
        self.CRUDPlaceholder = CRUDPlaceholder()
        self.CRUDDocumentsAuditLog = CRUDDocumentsAuditLog()
    
    def create_placeholder(self, user_info, document_id, placeholders):
        """[Controller to create new placeholder]

        Args:
            document_id (str): document_id
            placeholders (str): placeholders

        Raises:
            HTTPException: error

        Returns:
            List: placeholders
        """
        logger.info("executing create-placeholder controller ...")

        document = self.CRUDDocument.get_by_id(document_id, user_info)
        placeholders_list= []
        if document is None:
            raise HTTPException(
                status_code=404, detail="The given document id doesn't exist."
            )
        doc_placeholders=[]

        for placeholder in placeholders:
            if not isinstance(placeholder, dict):
                placeholder = placeholder.dict()
            db_object = {
                "document_id": document_id,
                "metadata_info": placeholder.get("metadata_info", None),
                "created_by": user_info["Username"],
                "modified_by": user_info["Username"],
                "content": placeholder.get("content", None)
            }
            
            if "sequence_no" in placeholder and placeholder["sequence_no"] :
                db_object["sequence_no"] = placeholder["sequence_no"]
            
            if "id" in placeholder:
                placeholder_id = placeholder["id"].strip()          
                db_object["id"] = placeholder_id

            if "_sa_instance_state" in placeholder:
                    placeholder.pop("_sa_instance_state")

            doc_placeholders.append(db_object)

        objs = self.CRUDPlaceholder.create(doc_placeholders)
        for obj in objs:
            placeholders_list.append(str(obj["id"]))

        logger.info("calling create doc audit log crud ....")
        audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=document_id, 
                                                    action=ACTION.UPDATED.value,
                                                    detail= "Created placeholders",
                                                    created_by=user_info["Username"])
        return placeholders_list

    def create_placeholders_with_count(self, user_info, document_id,count):
        """[Controller to create placeholder with count]

        Args:
            user_info (dict): user_info
            document_id (str): document_id
            count (int): count
        """
        logger.info("executing create_placeholders_with_count controller ...")

        document = self.CRUDDocument.get_by_id(document_id, user_info)
        
        if document is None:
            raise HTTPException(
                status_code=404, detail="The given document id doesn't exist."
            )
        placeholders_list= []
        
        doc_placeholders=[{"document_id": document_id, "created_by": user_info["Username"], "modified_by": user_info["Username"]} for _ in range(count)]

        objs = self.CRUDPlaceholder.create(doc_placeholders)
        for obj in objs:
            placeholders_list.append(str(obj["id"]))

        logger.info("calling create doc audit log crud ....")
        audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=document_id, 
                                                    action=ACTION.UPDATED.value,
                                                    detail= "Created placeholders",
                                                    created_by=user_info["Username"])
        return placeholders_list

    def get_placeholder_by_id(self, user_info, document_id, placeholder_id):
        """[Controller to read placeholder]

        Args:
            document_id (str): document_id
            placeholder_id (str): placeholder_id

        Raises:
            HTTPException: Error

        Returns:
            Dict: Placeholder details
        """
        try:
            logger.info("executing placeholder controller ...")
            logger.info("calling check user access to doc function .. ")
            has_access = self.CRUDDocument.check_user_access_to_document(user_info=user_info, doc_id=document_id)
            if has_access == False:
                logger.error("No access to document.")
                raise HTTPException(status_code= 400, detail=
                                    f'''You dont have access to the document with id={document_id}.\n Hence, you cant access its placeholders!''')
            
            logger.info("calling read by placeholder id placeholder crud ...")
            response = self.CRUDPlaceholder.read_by_placeholder_id( 
                document_id, 
                placeholder_id
            )
            if "placeholder" in response and not response["placeholder"]:
                raise ResourceNotFound(f"Placeholder with id- {placeholder_id} does not exists")
            return response
    
        except ResourceNotFound as e:
            logger.error(e)
            raise HTTPException(status_code= 404, detail= str(e.args[0]))
        except Exception as e:
            logger.error(e)
            raise HTTPException(status_code= 501,
                detail= f"Error while getting a document in controller.\n {e.args}"
            )

    def get_placeholder_by_doc_id(self, user_info, document_id):
        """[Controller to read placeholders for a doc]

        Args:
            document_id (str): document_id

        Raises:
            HTTPException: Error

        Returns:
            List: placeholders
        """
        logger.info("executing placeholder controller ...")
        logger.info("calling check user access to doc function .. ")
        has_access = self.CRUDDocument.check_user_access_to_document(user_info=user_info, doc_id=document_id)
        if has_access == False:
            logger.error("No access to document.")
            raise HTTPException(status_code= 400, detail=
                                 f'''You dont have access to the document with id={document_id}.\n Hence, you cant access its placeholders!''')
        
        logger.info("calling read by doc id placeholder crud ...")
        return self.CRUDPlaceholder.read_by_document_id(document_id)
    
    def update_placeholders(self, user_info, doc_id, placeholders):
        existing_placeholders = self.CRUDPlaceholder.read_by_document_id(doc_id)
    
        doc_placeholders=[]
        for placeholder in placeholders:  
            placeholder_id = placeholder["id"].strip()          
            db_object = {
                "id" :placeholder_id,
                "document_id": doc_id,
                "modified_by": user_info["Username"],
                "created_by" : user_info["Username"]  
            }
            
            if "sequence_no" in placeholder and placeholder["sequence_no"] :
                db_object["sequence_no"] = placeholder["sequence_no"]
            if "metadata_info" in placeholder:
                if placeholder["metadata_info"] is None:
                    del placeholder["metadata_info"]
                else:
                    db_object["metadata_info"] = placeholder["metadata_info"]
            if "content" in placeholder:
                if placeholder["content"] is None:
                    del placeholder["content"]
                else:
                    db_object["content"] = placeholder["content"]
            if "created_by" in placeholder and placeholder["created_by"] :
                db_object["created_by"] = placeholder["created_by"]
            
            doc_placeholders.append(db_object)

        new_placeholders = self.CRUDPlaceholder.upsert(doc_placeholders)
        
        #delete the placeholders not in new payload
        existing_ids = {str(item['id']) for item in existing_placeholders}
        new_ids = {str(item['id']) for item in new_placeholders}
        deleted_ids = existing_ids - new_ids
        deleted_list = [item for item in existing_placeholders if str(item['id']) in deleted_ids]
        if len(deleted_list):
            self.CRUDPlaceholder.delete(user_info,deleted_list)

        placeholders_list=[]
        objs =self.CRUDPlaceholder.read_by_document_id(doc_id)
        for obj in objs:
            placeholders_list.append(str(obj["id"]))
        
        return placeholders_list
    
    def update_placeholder_by_id(self,user_info,document_id,placeholder_id,placeholder_details):
        try:
            logger.info("calling get by id crud doc ...")
            document = self.CRUDDocument.get_by_id(id=document_id,user_info=user_info)
            placeholder = self.CRUDPlaceholder.read_by_placeholder_id(document_id,placeholder_id)

            if document is not None and placeholder['placeholder'] is not None:
                
                logger.info("calling crud update placeholder...") 
                placeholder_details = placeholder_details.__dict__  
                db_object = {
                    "modified_by": user_info["Username"]
                }
                if "sequence_no" in placeholder_details and placeholder_details["sequence_no"] :
                    db_object["sequence_no"] = placeholder_details["sequence_no"]
                if "metadata_info" in placeholder_details:
                    if placeholder_details["metadata_info"] is None:
                        del placeholder_details["metadata_info"]
                    else:
                        db_object["metadata_info"] = placeholder_details["metadata_info"]
                if "content" in placeholder_details:
                    if placeholder_details["content"] is None:
                        del placeholder_details["content"]
                    else:
                        db_object["content"] = placeholder_details["content"]
    
                
                self.CRUDPlaceholder.update(user_info,placeholder_id,**db_object)
                logger.info("calling create doc audit log crud ....")
                audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=document_id, 
                                                        action=ACTION.UPDATED.value,
                                                        detail= "Placeholder updated",
                                                        created_by=user_info["Username"])
                return placeholder_id
            else:
                raise ResourceNotFound(f"Document-Id : {document_id} or Placeholder-Id : {placeholder_id} does not exists.")
        except ResourceNotFound as e:
            logger.error(e)
            raise HTTPException(status_code= 404, detail= str(e.args[0]))
        except Exception as e:
            logger.error(e)
            raise HTTPException(status_code= 501,
                detail= f"Error while updating placeholder in controller.\n {e.args}"
            )
        
    def update_metadata(self, user_info, document_id, placeholder_id, metadata_info):
        try:
            logger.info("calling get by id crud doc ...")
            document = self.CRUDDocument.get_by_id(id=document_id,user_info=user_info)
            if document is not None:
                placeholder = self.CRUDPlaceholder.read_by_placeholder_id(document_id, placeholder_id)
                if placeholder["placeholder"] is not None:
                    placeholder_details_obj = {
                        "placeholder_id" : placeholder_id,
                        "modified_by" : user_info["Username"],
                        "metadata_info" : metadata_info
                        }
                    logger.info("calling update placeholder crud ...")
                    document = self.CRUDPlaceholder.update(user_info,**placeholder_details_obj)

                    updated_placeholder = self.CRUDPlaceholder.read_by_placeholder_id(document_id, placeholder_id)
                    updated_placeholder = updated_placeholder['placeholder'].__dict__

                    logger.info("calling create doc audit log crud ....")
                    audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=document_id, 
                                                                action=ACTION.UPDATED.value,
                                                                detail= f"placeholder:{placeholder_id}'s metadata updated.",
                                                                created_by=user_info["Username"])
                    
                    return updated_placeholder

                else:
                    raise ResourceNotFound(f"Placeholder-Id : {placeholder_id} does not exist.")
            else:
                    raise ResourceNotFound(f"Document-Id : {document_id} does not exist.")
        except ResourceNotFound as e:
            logger.error(e)
            raise HTTPException(status_code= 404, detail= str(e.args[0]))
        except Exception as e:
            logger.error(e)
            raise HTTPException(status_code= 501,
                detail= f"Error while updating placeholder metadata in controller.\n {e.args}"
            )


    def delete_placeholders(self, user_info, document_id, placeholder_id=None):
        try:
            logger.info("calling get by id crud doc ...")
            document = self.CRUDDocument.get_by_id(id=document_id,user_info=user_info)
            if document is not None:
                if not placeholder_id:
                    placeholders = self.CRUDPlaceholder.read_by_document_id(document_id)
                    placeholder_ids = [str(item['id']) for item in placeholders]
                elif placeholder_id:
                    placeholders = self.CRUDPlaceholder.read_by_placeholder_id(document_id,placeholder_id)
                    placeholders = [placeholders['placeholder'].__dict__]
                    placeholder_ids=  [placeholder_id]

                logger.info("calling crud delete placeholder...")
                self.CRUDPlaceholder.delete(user_info,placeholders)
                logger.info("calling create doc audit log crud ....")
                audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=document_id, 
                                                        action=ACTION.DELETED.value,
                                                        detail= "Placeholders deleted",
                                                        created_by=user_info["Username"])
                return {"document_id":document_id, "deleted_placeholder_ids": placeholder_ids}
            else:
                raise ResourceNotFound(f"Document-Id : {document_id}")
        except ResourceNotFound as e:
            logger.error(e)
            raise HTTPException(status_code= 404, detail= str(e.args[0]))
        except Exception as e:
            logger.error(e)
            raise HTTPException(status_code= 501,
                detail= f"Error while getting a deleting placeholder in controller.\n {e.args}"
            )
