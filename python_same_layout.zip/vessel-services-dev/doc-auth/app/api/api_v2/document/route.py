from fastapi import APIRouter, HTTPException, UploadFile, File, Form, Request
from fastapi.responses import StreamingResponse
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation
from api.api_v2.document.controller import DocumentController
from db.orm_models.v2.enums import OrderBy, SortBy, DocType, DocFormat
import json
from utils.api_response import generate_api_success_response
from utils.logs.logger_config import logger
from config.config import config 
from crud.v2.document_crud import CRUDDocument
from fastapi import HTTPException
from typing import Optional,List
from schemas.v2.response.LockedResponse import LockedResponse
from schemas.v2.requests.DocumentSharingRequests import CopyDocumentShareMap


document_router = APIRouter()

@document_router.post("/document")
@async_token_validation_and_metering()
@auth_token_validation()
async def create_document(request : Request, document_details: str = Form(...), file:  Optional[UploadFile] = None):
    """[API router to create new document into the system]
    ```
    shared_with_type (ENUM) : USER | GROUP | TENANT
    
    Args:   
        file: File
        document_details (create): {
                    "type":"string",
                    "sequence_no": integer,
                    "is_template":boolean,
                    "metadata_info": {},
                    "name": "string",
                    "content": {},
                    "sharing_details":[{
                        "shared_with_type":"ENUM",
                        "shared_with_id":"string"
                    }],
                    "placeholders":[{}],
                    "children": [
                        {
                            "sequence_no": integer,
                            "metadata_info":{},
                            "content": {},
                            "placeholders": [
                                {
                                    "id": "string",
                                    "sequence_no": integer,
                                    "metadata_info": {},
                                    "content": {}
                                }
                            ]
                        }
                    ]
                }

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}

        }

    Returns:
        [createResponse: dict]: {
                    "success": true,
                    "message": "Document group created successfully!",
                    "details": {
                        "id":"string",
                        "type":"string",
                        "content": {},
                        "is_template": boolean,
                        "creator_tenant_id": "string",
                        "is_locked_by":  "string",
                        "created_by": "string",
                        "modified_by": "string",
                        "modified_at": "datetime",
                        "parent_id": "string",
                        "relative_url":"string",
                        "name":"string",
                        "sequence_no": integer,
                        "metadata_info": {},
                        "is_deleted": boolean,
                        "is_private": boolean,
                        "created_at": "string",
                        "placeholder_ids": [
                            "string"
                        ],
                        "children": [
                            {
                                "id": "string",
                                "placeholder_ids": [
                                    "string"
                                ]
                            }
                        ]
                    }
                }
    ```
    """
    user_info =  request.state.userInfo

    logger.info("executing doc router ...checking filetype ...")
    document_details = json.loads(document_details)

    isFilePresent = True if file else False

    if isFilePresent and file.content_type!='text/html':
        raise HTTPException(status_code= 400, detail="Incorrect file type.")
     
    # if not isFilePresent and not isContentPresent:
    #     raise HTTPException(status_code= 400, detail="Document or Document data not present.")

    document_details = {key: value.strip() if isinstance(value, str) else value for key,value in document_details.items()}
    document_details["created_by"] = user_info["Username"]
    document_details["modified_by"] = user_info["Username"]
    document_details["creator_tenant_id"] = user_info["mule_client_id"]

    isParent = True if "children" in document_details and len(document_details["children"])>0 else False

    # logger.info("calling check duplicate doc ...")
    # document = CRUDDocument().check_duplicate_document(document_details["name"],document_details["creator_tenant_id"],document_details["created_by"])
    # if document:
    #     logger.error("Duplicate document found.")
    #     raise HTTPException(status_code=400, detail="Document with given name already exists!")
    
    if isParent:
        logger.info("calling doc controller for ppt...")
        document = DocumentController().create_group_doc(document_details, file, isFilePresent, user_info)
        return generate_api_success_response(message="Document group created successfully!",body=document)

    logger.info("calling doc controller for document...")
    document_details.pop("children", None)
    document = DocumentController().create_document(document_details, file, isFilePresent, user_info)

    return generate_api_success_response(message="Document created successfully!",body=document)
    
@document_router.post("/document/{id}/template/copy")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_template_copy(request : Request, id:str, doc_name:str = None, sharing_details: Optional[CopyDocumentShareMap] = None):
    """[API router to create new template from existing into the system]
    ```
    shared_with_type (ENUM) : USER | GROUP | TENANT
    
    Args:
        id (str): existing document id 
        doc_name(str): document name
        Request Body : [sharing_details]

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [createResponse: dict]:  {
                    "success": true,
                    "message": "Document group created successfully!",
                    "details": {
                        "id":"string",
                        "type":"string",
                        "content": {},
                        "is_template": boolean,
                        "creator_tenant_id": "string",
                        "is_locked_by":  "string",
                        "created_by": "string",
                        "modified_by": "string",
                        "modified_at": "datetime",
                        "parent_id": "string",
                        "relative_url":"string",
                        "name":"string",
                        "sequence_no": integer,
                        "metadata_info": {},
                        "is_deleted": boolean,
                        "is_private": boolean,
                        "created_at": "string",
                        "placeholder_ids": [
                            "string"
                        ],
                        "children": [
                            {
                                "id": "string",
                                "placeholder_ids": [
                                    "string"
                                ]
                            }
                        ]
                    }
                }
    ```
    """
    user_info =  request.state.userInfo

    logger.info("calling doc controller for template copy...")
    template = DocumentController().create_template_copy(user_info, id, doc_name, sharing_details)

    return generate_api_success_response(message="Template copy created successfully!",body=template)
    

@document_router.put("/document/{id}")
@async_token_validation_and_metering()
@auth_token_validation()
async def update_document(request : Request, id:str,
                           document_details: str = Form(...),
                           file: Optional[UploadFile] = None):
    """[API router to update document by id . Only the fields requiring updates need to be included in the request. Furthermore, an upsert mechanism is implemented specifically for placeholders, ensuring that new placeholders are created if they do not exist, or existing ones are updated, and the ones not present in the payload are deleted. ]

    ```
    
    Args:   
        file: File
        id (str): document id 
        document_details (JSON): {
                    "sequence_no": integer,
                    "metadata_info": {},
                    "name": "string",
                    "content": {},
                    "placeholders":[{}],
                    "children": [
                        {
                            "sequence_no": integer,
                            "metadata_info":{},
                            "content": {},
                            "placeholders": [
                                {
                                    "id": "string",
                                    "sequence_no": integer,
                                    "metadata_info": {},
                                    "content": {}
                                }
                            ]
                        }
                    ]
                }

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}

        }

    Returns:
        [updateResponse:dict]: {
                    "success": true,
                    "message": "Document group created successfully!",
                    "details": {
                        "id":"string",
                        "type":"string",
                        "content": {},
                        "is_template": boolean,
                        "creator_tenant_id": "string",
                        "is_locked_by":  "string",
                        "created_by": "string",
                        "modified_by": "string",
                        "modified_at": "datetime",
                        "parent_id": "string",
                        "relative_url":"string",
                        "name":"string",
                        "sequence_no": integer,
                        "metadata_info": {},
                        "is_deleted": boolean,
                        "is_private": boolean,
                        "created_at": "string"
                    }
                }
    ```
    """
    user_info =  request.state.userInfo

    logger.info("executing update_document_by_id router ...")
    
    document_details_obj = json.loads(document_details)
    document_details_obj = {key: value.strip() if isinstance(value, str) else value for key,value in document_details_obj.items()}

    isFilePresent = True if file else False

    if isFilePresent and file.content_type!='text/html':
        raise HTTPException(status_code= 400, detail="Incorrect file type.")
         
    logger.info("calling update_document controller ...")
    response = DocumentController().update_group_doc(id, document_details_obj,user_info, file)
    message= f'Update successfully!'
    return generate_api_success_response(message=message, body=response)

@document_router.patch("/document/{id}/template")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def mark_document_as_template(request : Request, id:str):
    """[API router to mark an existing document as a template based on id.]
    ```
    Args:
        id (str): path param : [document id ]

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [details of document with given id] : {
                    "success": true,
                    "message": "Document {name} is marked as template successfully!",
                    "details": {
                        "metadata_info": {},
                        "id": "string",
                        "name": "string",
                        "is_deleted": boolean,
                        "is_private": boolean,
                        "modified_by": "string",
                        "modified_at": "datetime",
                        "is_template": boolean,
                        "creator_tenant_id":"string",
                        "is_locked_by":  "string",
                        "created_by": "string",
                        "created_at": "datetime",
                    }
                }
    ```
    """
    user_info =  request.state.userInfo

    logger.info("executing mark_document_as_template router ...")
    
    logger.info("calling update_document controller ...")
    response = DocumentController().mark_document_as_template(id,user_info)
    message= f'Document {response["name"]} is marked as template successfully!'
    return generate_api_success_response(message=message, body=response)

@document_router.get("/document/{id}")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_document(request : Request, id: str):
    """[API router to get the document by id ]
    ```
    Args:
        id (str): document id

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [get document response]: {
                    "success": true,
                    "message": "Document fetched successfully!",
                    "details": {
                        "id": "string",
                        "type": "string",
                        "content": {},
                        "is_template": boolean,
                        "creator_tenant_id":  "string",
                        "is_locked_by":  "string",
                        "created_by":  "string",
                        "modified_by":  "string",
                        "modified_at":"datetime",
                        "parent_id":  "string",
                        "relative_url":  "string",
                        "name":  "string",
                        "sequence_no": integer,
                        "metadata_info": { },
                        "is_deleted": boolean,
                        "is_private": boolean,
                        "created_at":  "string",
                        "placeholders": [
                            {
                                "metadata_info": {},
                                "id":  "string",
                                "is_deleted": boolean,
                                "modified_by":  "string",
                                "created_at":  "string",
                                "document_id": "string",
                                "sequence_no": integer,
                                "content": { },
                                "created_by":  "string",
                                "modified_at": "datetime"
                            }
                        ],
                        "children": [
                            {
                                "id":  "string",
                                "type":  "string",
                                "content": {},
                                "is_template": boolean,
                                "creator_tenant_id":  "string",
                                "is_locked_by":  "string",
                                "created_by":  "string",
                                "modified_by":  "string",
                                "modified_at":"datetime",
                                "parent_id": "string",
                                "relative_url": "string",
                                "name":  "string",
                                "sequence_no": integer,
                                "metadata_info": {  },
                                "is_deleted": boolean,
                                "is_private": boolean,
                                "created_at":"datetime",
                                "placeholders": [
                                    {
                                        "metadata_info": {},
                                        "id":  "string",
                                        "is_deleted": boolean,
                                        "modified_by":  "string",
                                        "created_at": "datetime",
                                        "document_id":  "string",
                                        "sequence_no": integer,
                                        "content": { },
                                        "created_by":  "string",
                                        "modified_at":"datetime"
                                    }
                                ]
                            }
                        ]
                    }
                }

    ```
    """
    user_info = request.state.userInfo

    logger.info("calling doc controller ...")
    response = DocumentController().get_document(
        id,user_info
    )
    return generate_api_success_response(message="Document fetched successfully!",body=response)

@document_router.get("/document/{id}/download")
@async_token_validation_and_metering()
@auth_token_validation()
async def download_document(request : Request, id: str,type:DocFormat=DocFormat.html):
    """[API router to download the document]
    ```
    Args:
        id (str): document id
        type (str): ENUM ( 'html' | 'json')

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [download document response] : [blob streaming object]
        OR
        [download document response] : {
                "success": true,
                "message": "Document downloaded successfully!",
                "details": {
                    "html_text":  "string",
                    "name":  "string",
                    "id": "string",
                }
            }
    ```
    """
    user_info = request.state.userInfo
    user_info['authorization'] = request.headers['authorization']
    user_info['x-auth'] = request.headers['x-auth']
    logger.info("calling doc controller ...")
    response = DocumentController().download_document(
        id,user_info,type.value
    )
    if isinstance(response, StreamingResponse):
        return response
    else:
        return generate_api_success_response(
            message="Document downloaded successfully!", body=response
        )

@document_router.delete("/document/{id}")
@async_token_validation_and_metering()
@auth_token_validation()
async def delete_document(request : Request, id: str):
    """[API router to delete the document]

    ```
    Args:
        id (str): document id

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [delete document response] :    {
                "success": true,
                "message": "Document {name} deleted successfully!",
                "details": {
                    "id": "string"
                }
            }
    ```
    """
    user_info = request.state.userInfo

    logger.info("calling doc controller ...")
    response = DocumentController().delete_group_docs(id,user_info)
    return generate_api_success_response(message=f"Document deleted successfully!",body=response)

@document_router.get("/documents")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_multiple_documents(
    request: Request,
    search_by_name:str= None,
    type: DocType = None,
    show_children: bool = False,
    with_content: bool = False,
    is_private: bool = None,
    is_template: bool = None,
    created_by: str = None,
    page_limit: int = None,
    page_number: int = 1,
    order_by: OrderBy = OrderBy.DESC,
    sort_by: SortBy = SortBy.Modified_at,
    # show_deleted: bool = None
) -> dict:
    """API router to fetch multiple document records with filters

    ```
    Args: 
        search_by_name (str, optional): name of documents to fetch. Defaults to None. 
        type: (DocType, optional): type of Doc to be filtered for 
        show_children: (bool, optional): whether should show child documents. Defaults to False
        with_content: (bool, optional): whether should fetch document content JSON. Defaults to False. 
        is_private (bool, optional): type of document to fetch. Defaults to None.
        is_template (bool, optional): type of documents to fetch. Defaults to None.
        created_by (str, optional): NTID of a user. Defaults to None.
        page_limit (int, optional): max number of documents on a page. Defaults to None.
        page_number (int, optional): page number. Defaults to 1.
        order_by (OrderBy, optional): ascending or descending. Defaults to "DESC".
        sort_by (SortBy, optional): sort the documents by. Defaults to "Modified_at".

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [list of documents]: {
                "success": true,
                "message": "",
                "details": {
                    "documents": [
                        {
                            "metadata_info": {},
                            "id":  "string",
                            "name":  "string",
                            "is_deleted": boolean,
                            "is_private": boolean,
                            "modified_by":  "string",
                            "modified_at": "datetime",
                            "relative_url":  "string",
                            "is_template": boolean,
                            "creator_tenant_id":  "string",
                            "is_locked_by": "string",
                            "created_by":  "string",
                            "created_at": "datetime"
                        }
                    ],
                    "page_number": integer,
                    "page_limit": integer,
                    "total_docs": integer
                }
            }
    ```
    """

    user_info =  request.state.userInfo

    logger.info("calling get_multiple_documents router ...")

    
    if page_number >= 1:
        if page_number > 1 and page_limit is None:
            message = "Page limit is also required with page number."
            logger.error(message)
            raise HTTPException(
                status_code=400, detail= message
            )
        elif page_limit is not None and page_limit < 1:
            message = "Page limit cannot be less than 1."
            logger.error(message)
            raise HTTPException(
                status_code=400, detail= message
            )
    elif page_number < 1:
        message = "Page number cannot be less than 1"
        logger.error(message)
        raise HTTPException(
            status_code=400, detail= message
        )
    
    if search_by_name:
        search_by_name=search_by_name.strip()
    if created_by:
        created_by = created_by.strip()
        
    response = DocumentController().get_documents(
        user_info,
        search_by_name,
        type,
        show_children,
        with_content,
        is_private,
        is_template,
        created_by,
        page_limit,
        page_number,
        order_by.value,
        sort_by.value,
        # show_deleted,
    )
    return generate_api_success_response(body=response)

@document_router.patch("/document/{id}/metadata")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def update_metadata_info(request : Request, id: str, metadata_info: dict):
    """[API router to update metadata info for a document]

    ```
    Args:
        id (str): path param : [document id ]
        metadata_info(dict) : [metadata info for a document]

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [dict : details of document with given id] : {
                "success": true,
                "message": "Metadata Info for document {name} is updated successfully!",
                "details": {
                    "metadata_info": {},
                    "id": "string",
                    "name": "string",
                    "is_deleted": boolean,
                    "is_private": boolean,
                    "modified_by": "string",
                    "modified_at": "datetime",
                    "is_template": boolean,
                    "creator_tenant_id":"string",
                    "is_locked_by": "",
                    "created_by": "string",
                    "created_at": "datetime"
                }
            }
    ```
    """
    user_info =  request.state.userInfo

    logger.info("executing update_metadata router ...")
    
    logger.info("calling update_metadata in document controller ...")
    response = DocumentController().update_metadata(id, user_info, metadata_info)
    message= f'Metadata Info for document {response["name"]} is updated successfully!'
    return generate_api_success_response(message=message, body=response)

@document_router.patch("/document/{id}/locked", response_model=LockedResponse)
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def toggle_document_as_lock(request : Request, id:str):
    """[API router to lock document by id]
    ```
    Args:
        id (str): path param : [document id ]

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [dict : details of document with given id]
    ```
    """
    user_info =  request.state.userInfo

    logger.info("executing mark_document_as_locked router ...")
    response = DocumentController().toggle_document_as_lock(id,user_info)
    message= f'Document {response["name"]} locked status changed successfully!'
    return generate_api_success_response(message=message, body=response)


@document_router.get("/document/tenant/id", include_in_schema = False)
@async_token_validation_and_metering()
@auth_token_validation()
async def get_document_by_tenant_id(request : Request , get_all:bool=False, type: DocType = None):
    """[API router to get all documents by tenant id]

    Args:
        get_document_request (create): [GET Documents]

    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }

    Returns:
        [createResponse]: [get document response]
    """
    user_info = request.state.userInfo

    if not config.IS_MIGRATION:
        raise HTTPException(status_code= 401, detail="Unauthorized access")
    
    logger.info("calling doc controller ...")
    response = DocumentController().get_document_by_tenant_id(user_info, get_all, type)
    return generate_api_success_response(message="Document fetched successfully!",body=response)
