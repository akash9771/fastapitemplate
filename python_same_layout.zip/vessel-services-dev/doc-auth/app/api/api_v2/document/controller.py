import json

from fastapi.encoders import jsonable_encoder
from crud.v2.document_crud import CRUDDocument
from api.api_v2.document_share.controller import DocumentShareController
from api.api_v2.placeholders.controller import PlaceholderController
from utils.aws.s3_v2 import upload_to_s3, delete_file_from_s3,archive_file, read_a_file, copy_file
from utils.ppt_utils.pptfunc import extract_placeholders_separately,update_layouts_with_multiple_slides
from utils.docx_utils.docx_converter_func import DocumentCreator
from utils.logs.logger_config import logger
from fastapi import HTTPException
from utils.exceptions import ResourceNotFound, BadRequestResult
from fastapi.responses import Response, StreamingResponse
from db.orm_models.v2.enums import ACTION, DocType
from crud.v2.document_audit_log_crud import CRUDDocumentsAuditLog
from crud.v2.placeholder_crud import CRUDPlaceholder
from utils.ppt_utils.pptbase import CustomPPTGenerator

class DocumentController:
    def __init__(self):
        self.CRUDDocument = CRUDDocument()
        self.CRUDDocumentsAuditLog = CRUDDocumentsAuditLog()
        self.CRUDPlaceholder = CRUDPlaceholder()

    def create_group_doc(self, request, file, isFilePresent, user_info):
        """[Controller to register new ppt]

        Args:
            request (object): _description_
            file (file): _description_
            isFilePresent (bool): _description_
            isParent (bool): _description_

        Raises:
            HTTPException: _description_
            HTTPException: _description_

        Returns:
            _type_: _description_
        """
        children = request["children"]
        del request["children"]

        #create parent docs
        logger.info("calling doc controller for parent document...")
        document = self.create_document(request, file, isFilePresent, user_info)
        parent_type = document["type"].value
        parent_id = document["id"]
        parent_name = request["name"]
        document["children"] = []
        is_template = True if "is_template" in request and request["is_template"] else False 

        #create child docs
        try:
            for child in children:
                child_obj= {}
                child = {key: value.strip() if isinstance(value, str) else value for key,value in child.items()}
                child["created_by"] = user_info["Username"]
                child["modified_by"] = user_info["Username"]
                child["creator_tenant_id"] = user_info["mule_client_id"]
                child["is_template"] = is_template
                child["type"] = parent_type
                child["name"] =  parent_name
                
                isFilePresent =  False

                logger.info("creating child document...")
                child["parent_id"] = parent_id

                doc_obj = self.create_document(child, file, isFilePresent, user_info) 
                child_obj = {
                    "id": doc_obj["id"]
                } 
                if "placeholder_ids" in doc_obj:
                    child_obj["placeholder_ids"]= doc_obj["placeholder_ids"]

                document["children"].append(child_obj)          
                    
        except HTTPException as e:   
            logger.info("calling create doc audit log crud ....")
            audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=parent_id, 
                                                    action=ACTION.UPDATED.value,
                                                    detail= "Error occurred while creating documents for ppt",
                                                    created_by=user_info["Username"])
            raise HTTPException(e.status_code, f"Parent Document is created with id={parent_id}. There is an error while creating the child document. Error Details:{e.detail}")    
        
        return document

    def create_document(self, request, file, isFilePresent, user_info):
        """[Controller to create a new document]

        Args:
            request ([dict]): [create new document]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [document]
        """

        is_private = True
        
        
        request["is_private"] = is_private
        if "relative_url" not in request:
            request["relative_url"]=""

        if isFilePresent:
            relative_url = upload_to_s3(
                file=file,
                tenant=request["creator_tenant_id"],
                file_name=request["name"],
                user=request["created_by"])
            request["relative_url"] = relative_url["s3Path"]

        sharing_details = None
        if "sharing_details" in request :
            if len(request["sharing_details"]) > 0:
                sharing_details = request["sharing_details"]
            del request["sharing_details"]
    
        placeholders= None
        if "placeholders" in request:
            if len(request["placeholders"])>0:
                placeholders = request["placeholders"]
                for placeholder in placeholders:

                    if not isinstance(placeholder, dict):
                        placeholder = placeholder.dict()
                        
                    # if "id" not in placeholder or placeholder["id"].strip() in ['', None]:
                    #     raise HTTPException(
                    #         status_code=400, detail="Placeholder id cannot be empty."
                    #     ) 
            del request["placeholders"]
        
        if "_sa_instance_state" in request:
            request.pop("_sa_instance_state")

        document = self.CRUDDocument.create(**request)
        
        logger.info("calling create doc audit log crud ....")
        audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=document['id'], 
                                                      action=ACTION.UPLOADED.value,
                                                      detail="",
                                                      created_by=user_info["Username"])
        

        try:
            if sharing_details is not None and document.get("parent_id", None) is None:
                logger.info("calling create document share map...")
                mapping_ids = DocumentShareController().create_document_share_map(user_info, document["id"], sharing_details)               
                 
        except HTTPException as e:   
            doc_id = document["id"]
            logger.info("calling create doc audit log crud ....")
            audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=doc_id, 
                                                      action=ACTION.CREATED_SHARING.value,
                                                      detail= "Error occurred while creating mappings",
                                                      created_by=user_info["Username"])
            raise HTTPException(e.status_code, f"Document is created with id={doc_id}. There is an error while sharing the document . Error Details:{e.detail}")

        try:
            if placeholders is not None:
                logger.info("calling create document placeholders...")
                if "_sa_instance_state" in placeholders:
                    placeholders.pop("_sa_instance_state")
                placeholder_ids = PlaceholderController().create_placeholder(user_info, document["id"], placeholders)
                document["placeholder_ids"] = placeholder_ids          
                 
        except HTTPException as e:   
            doc_id = document["id"]
            logger.info("calling create doc audit log crud ....")
            audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=doc_id, 
                                                      action=ACTION.UPDATED.value,
                                                      detail= "Error occurred while creating placeholders",
                                                      created_by=user_info["Username"])
            raise HTTPException(e.status_code, f"Document is created with id={doc_id}. There is an error while cerating the placeholders for the document . Error Details:{e.detail}")
        
        if sharing_details:
            logger.info("calling get_by_id CRUD....")
            document = self.CRUDDocument.get_by_id(id= document["id"], user_info= user_info)
            
        return document 

    def update_group_doc(self,parent_id,doc_details,user_info,file):
        """[Controller to update one document or a grouped document]

        Args:
            doc_id (str): _description_
            doc_details (dict): _description_
            user_info (dicgt): _description_
            file (file): _description_
        """
        logger.info("calling get by id crud doc ...")
        children = None
        if "children" in doc_details:
            children = doc_details["children"] if len(doc_details["children"])>0 else None
            del doc_details["children"]

        updated_parent = DocumentController().update_document(parent_id,doc_details,user_info,file)
        
        if children:
            temp_child=[]
            for child in children:
                response = DocumentController().update_document(child["id"],child,user_info,file)
                temp_child.append(response)
            updated_parent["children"] = temp_child
        return updated_parent
       

    def update_document(self, id, document_details_obj, user_info, file):
        """[Controller to update a document]

        Args:
            document_details_obj ([dict]): [update new document request]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [document]
        """
        logger.info("calling get by id document crud ...")
        doc_by_id  = self.CRUDDocument.get_by_id(id,user_info)

        if doc_by_id is None:
            logger.error("Document with given id does not exist.")
            raise HTTPException(status_code= 404, detail=f"Document with given id - {id} does not exist.")
        if "name" in document_details_obj and doc_by_id["name"] != document_details_obj["name"]:
            # doc_duplicate_check  = self.CRUDDocument.check_duplicate_document(document_details_obj["name"],doc_by_id["creator_tenant_id"],doc_by_id["created_by"])
            # if doc_duplicate_check:
                # raise HTTPException(400, "Document name already exists!")
            doc_name = document_details_obj["name"]
        else :
            doc_name = doc_by_id["name"]
        
        logger.info("calling upload to s3 function ...")
        if file and not doc_by_id['parent_id']:
            relative_url = upload_to_s3(file,doc_by_id["creator_tenant_id"],doc_name,doc_by_id["created_by"])
            document_details_obj["relative_url"] = relative_url["s3Path"]
       
        document_details_obj["id"] = id
        document_details_obj["modified_by"] = user_info["Username"]
        document_details_obj["is_private"] = doc_by_id["is_private"]

        if "name" in document_details_obj and file and doc_by_id["relative_url"] not in ['',None]:
            if (doc_by_id["name"] != document_details_obj["name"]):
                logger.info("calling delete document function ...")
                deletion_status = delete_file_from_s3(doc_by_id["relative_url"])

        #Updating placholders 
        logger.info("Updating placholders ...")
        placeholders= None
        if "placeholders" in document_details_obj:
            if len(document_details_obj["placeholders"])>0:
                placeholders = document_details_obj["placeholders"]
                for placeholder in placeholders:

                    if not isinstance(placeholder, dict):
                        placeholder = placeholder.dict()

                    if "id" not in placeholder or placeholder["id"].strip() in ['', None]:
                        raise HTTPException(
                            status_code=400, detail="Placeholder id cannot be empty."
                        ) 
            del document_details_obj["placeholders"]
        
        logger.info("calling update document crud ...")
        self.CRUDDocument.update(user_info,**document_details_obj)

        updated_document= self.CRUDDocument.get_by_id(id, user_info)
        del updated_document["relative_url"]

        try:
            if placeholders is not None:
                logger.info("calling update document placeholders...")
                placeholder_ids = PlaceholderController().update_placeholders(user_info, id, placeholders)    
                updated_document["placeholder_ids"] = placeholder_ids          
                 
        except HTTPException as e:   
            doc_id = id
            logger.info("calling update doc audit log crud ....")
            audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=doc_id, 
                                                      action=ACTION.UPDATED.value,
                                                      detail= "Error occurred while Updating placeholders",
                                                      created_by=user_info["Username"])
            raise HTTPException(e.status_code, f"Document is updated with id={doc_id}. There is an error while updating the placeholders for the document . Error Details:{e.detail}")


        logger.info("calling create doc audit log crud ....")
        audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=id, 
                                                      action=ACTION.UPDATED.value,
                                                      detail="Document updated.",
                                                      created_by=user_info["Username"])
        return updated_document 
    
    def mark_document_as_template(self, id, user_info):
        """[Controller to mark a document as template]

        Args:
            id (str): [doc id]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [document]
        """
        logger.info("calling get by id document crud ...")
        doc_by_id  = self.CRUDDocument.get_by_id(id,user_info)

        if doc_by_id is None:
            logger.error("Document with given id does not exist.")
            raise HTTPException(status_code= 404, detail="Document with given id does not exist.")
        
        if doc_by_id['parent_id']:
            logger.error("Document is a child doc, cannot update to a template.")
            raise HTTPException(status_code= 404, detail="Document is a child doc, cannot update to a template.")
        
        document_details_obj = {
            "id" : id,
            "modified_by" : user_info["Username"],
            "is_template" : True
        }

        logger.info("calling update document crud ...")
        self.CRUDDocument.update(user_info,**document_details_obj)

        children = self.CRUDDocument.read_documents_by_parent_id(user_info,id)
        if len(children):
            child_obj = {
                "parent_id" : id,
                "modified_by" : user_info["Username"],
                "is_template" : True
            }
            self.CRUDDocument.update_child(user_info,**child_obj)

        updated_document= self.CRUDDocument.get_by_id(id, user_info)
        del updated_document["relative_url"]

        logger.info("calling create doc audit log crud ....")
        audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=id, 
                                                      action=ACTION.MARKED_AS_TEMPLATE.value,
                                                      detail="",
                                                      created_by=user_info["Username"])
        return updated_document 
    
    def get_document(self, document_id, user_info):
        """[Controller to get document]

        Args:
            document_id (id: str): id of document

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [document]
        """
        try:
            document = self.CRUDDocument.get_by_id(id=document_id,user_info=user_info)
            if document is not None:
                placeholders = self.CRUDPlaceholder.read_by_document_id(document_id)
                for i, placeholder in enumerate(placeholders):
                    placeholder["sequence_no"] = i + 1 if placeholder["sequence_no"] else 0
                document['placeholders'] = placeholders

                if not document["parent_id"] :
                    children = self.CRUDDocument.read_documents_by_parent_id(user_info,document["id"])
                    for child in children:
                        placeholders = self.CRUDPlaceholder.read_by_document_id(child["id"])
                        for i, placeholder in enumerate(placeholders):
                            placeholder["sequence_no"] = i + 1 if placeholder["sequence_no"] else 0
                        child['placeholders'] = placeholders
                    document["children"] = children

                return document 
            else:
                raise ResourceNotFound(f"Document-Id : {document_id} does not exist!")
        except ResourceNotFound as e:
            logger.error(e)
            raise HTTPException(status_code= 404, detail= str(e.args[0]))
        except Exception as e:
            logger.error(e)
            raise HTTPException(status_code= 501,
                detail= f"Error while getting a document in controller.\n {e.args}"
            )

    def download_document(self, document_id, user_info,type):
        
        """[Controller to delete document]

        Args:
            document_id (id: str): id of document
            

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [document]
        """
        try:
            logger.info("Inside document download!")
            doc_obj = self.get_document(document_id, user_info)
            doc_obj_updated=jsonable_encoder(doc_obj)

            if doc_obj is None:
                message = f"Document with id : {document_id} does not exist!"
                raise ResourceNotFound(message)
                
            if doc_obj_updated["type"]=='DOC' and type in ['json','html']:
                
                get_doc=self.get_document(document_id, user_info)
                docx_name=doc_obj['name']
                
                response_dict=jsonable_encoder(get_doc)
                
                doc_creator = DocumentCreator(response_dict, user_info)
                docx_blob = doc_creator.create_document()
                
                headers = {"Content-Disposition": f"attachment; filename={docx_name}.docx"}
                response_obj=StreamingResponse(docx_blob, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document", headers=headers)
                
                return response_obj

            elif doc_obj_updated["type"]=='PPT' and type=='json':
                ppt_name=doc_obj['name']
                get_doc=self.get_document(document_id, user_info)
                 
                response_dict=jsonable_encoder(get_doc)
                
                contents=extract_placeholders_separately(response_dict)
                
                json_to_use=update_layouts_with_multiple_slides(contents)
                
                updated_json_string = json.dumps(json_to_use, indent=4)
                
                ppt_obj_create=CustomPPTGenerator()
                
                ppt_blob = ppt_obj_create.generate_presentation(updated_json_string)
                headers = {
                "Content-Disposition": f"attachment; filename={ppt_name}.pptx"
                        }
                response_obj=StreamingResponse(ppt_blob, media_type="application/vnd.openxmlformats-officedocument.presentationml.presentation",headers=headers)

                return response_obj
            else:
                raise BadRequestResult("Error while downloading file!")

        except ResourceNotFound as e:
            logger.error(e)
            raise HTTPException(status_code= 404, detail= str(e.args[0]))
        except Exception as e:
            logger.error(e)
            raise HTTPException(status_code= 501,
                detail= f"Error while getting a document in controller.\n {e.args}"
            )
       
    def delete_group_docs(self, parent_id,user_info):
        """[Controller to delete ppt]

        Args:
            parent_id (id: str): id of document

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [document]
        """

        try:
            logger.info("calling get by id crud doc ...")
            response = DocumentController().delete_document(parent_id,user_info)
            deleted_items=[response]
            children = self.CRUDDocument.read_documents_by_parent_id(user_info,parent_id)
            for child in children:
                response = DocumentController().delete_document(child["id"],user_info)
                deleted_items.append(response)
            return deleted_items
           
        except ResourceNotFound as e:
            logger.error(e)
            raise HTTPException(status_code= 404, detail= str(e.args[0]))
        except Exception as e:
            logger.error(e)
            raise HTTPException(status_code= 501,
                detail= f"Error while getting a document in controller.\n {e.args}"
            )
        
    def delete_document(self, document_id,user_info):
        """[Controller to delete document]

        Args:
            document_id (id: str): id of document

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [document]
        """

        try:
            logger.info("calling get by id crud doc ...")
            document = self.CRUDDocument.get_by_id(id=document_id,user_info=user_info)
            if document is not None:
                logger.info("calling archieve function...")
                if document["relative_url"]:
                    s3_delete = archive_file(document)
                
                
                if document["is_private"] == False:
                    logger.info("calling delete share mappings...")
                    DocumentShareController().delete_sharing_details(user_info, document_id)

                logger.info("calling crud delete doc...")
                template_deleted = self.CRUDDocument.delete(document_id=document_id, user_info=user_info)
                logger.info("calling create doc audit log crud ....")
                audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=document_id, 
                                                        action=ACTION.DELETED.value,
                                                        detail= "",
                                                        created_by=user_info["Username"])
                template_deleted["name"] = document["name"]
                return template_deleted
            else:
                raise ResourceNotFound(f"Document-Id : {document_id}")
        except ResourceNotFound as e:
            logger.error(e)
            raise HTTPException(status_code= 404, detail= str(e.args[0]))
        except Exception as e:
            logger.error(e)
            raise HTTPException(status_code= 501,
                detail= f"Error while getting a document in controller.\n {e.args}"
            )
        
    def get_documents(
        self,
        user_info: dict,
        search_by_name:str=None,
        type: DocType.DOC = None,
        show_children: bool = False,
        with_content: bool = False,
        is_private:bool =None,
        is_template:bool = None,
        created_by: str = None,
        page_limit: int = None,
        page_number: int = 1,
        order_by: str = "DESC",
        sort_by: str = "modified_at",
        # show_deleted: bool = None
    ) -> dict:
        """Controller to fetch list of documents

        Args:
            user_info (dict): information about the user. 
            search_by_name (str, optional): name of documents to fetch. Defaults to None.
            type: (DocType, optional): type of Doc to be filtered for 
            show_children: (bool, optional): whether should show child documents. Defaults to False.
            with_content: (bool, optional): whether should fetch document content JSON. Defaults to False. 
            is_private (bool, optional): type of documents to fetch. Defaults to None.
            is_template (bool, optional): type of documents to fetch. Defaults to None.
            created_by (str, optional): NTID of a user. Defaults to None.
            page_limit (int, optional): max number of documents on a page. Defaults to None.
            page_number (int, optional): page number. Defaults to 1.
            order_by (str, optional): ascending or descending. Defaults to "DESC".
            sort_by (str, optional): sort the documents by. Defaults to "modified_at".

        Returns:
            dict: documents
        """        

        all_docs = []
        doc_count = 0
        all_docs, doc_count = self.CRUDDocument.read_documents(
            user_info, 
            search_by_name,
            type,
            show_children,
            with_content,
            is_private, 
            is_template,
            created_by,
            page_limit, 
            page_number, 
            order_by, 
            sort_by,
            # show_deleted,
        )
        
        return {
            "documents": all_docs,
            "page_number": page_number,
            "page_limit": page_limit if page_limit is not None else doc_count,
            "total_docs": doc_count,
        }
    
    def update_metadata(self, id, user_info, metadata_info):
        """[Controller to update metadata info for a doc]

        Args:
            id (str): [doc id]
            metadata_info (dict) : [metadata_info]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [document]
        """
        logger.info("calling get by id document crud ...")
        doc_by_id  = self.CRUDDocument.get_by_id(id,user_info)

        if doc_by_id is None:
            logger.error("Document with given id does not exist.")
            raise HTTPException(status_code= 404, detail="Document with given id does not exist.")
        
        document_details_obj = {
            "id" : id,
            "modified_by" : user_info["Username"],
            "metadata_info" : metadata_info
        }

        logger.info("calling update document crud ...")
        document = self.CRUDDocument.update(user_info,**document_details_obj)

        updated_document= self.CRUDDocument.get_by_id(id, user_info)
        del updated_document["relative_url"]

        logger.info("calling create doc audit log crud ....")
        audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=id, 
                                                    action=ACTION.UPDATED.value,
                                                    detail= "metadata updated.",
                                                    created_by=user_info["Username"])
        return updated_document 

    def toggle_document_as_lock(self, id, user_info):
        """[Controller to mark a document as locked]

        Args:
            id (str): [doc id]

        Raises:
            error: [Error raised from controller layer]

        Returns:
            [dict]: [document]
        """
        logger.info("calling get by id document crud ...")
        doc_by_id  = self.CRUDDocument.get_by_id(id,user_info)

        if doc_by_id is None:
            logger.error("Document with given id does not exist.")
            raise HTTPException(status_code= 404, detail="Document with given id does not exist.")

        document_details_obj = {
            "id" : id,
            "modified_by" : user_info["Username"]
        }

        if doc_by_id["is_locked_by"]:
            document_details_obj["is_locked_by"] = None
        else: 
            document_details_obj["is_locked_by"] = user_info["Username"]        

        logger.info("calling update document crud ...")
        self.CRUDDocument.update(user_info,**document_details_obj)

        updated_document= self.CRUDDocument.get_by_id(id, user_info)
        response = {
            "name": updated_document["name"],
            "is_locked_by" : user_info["Username"] if updated_document["is_locked_by"] else '',
            "is_locked" : True if updated_document["is_locked_by"] else False
        }

        logger.info("calling create doc audit log crud ....")
        audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=id, 
                                                      action=ACTION.UPDATED.value,
                                                      detail="Updated is_locked_by info",
                                                      created_by=user_info["Username"])
        return response 

    def remove_keys(self,template_obj, keys_to_remove):
        if isinstance(template_obj, dict):
            # Remove keys at root level
            for key in keys_to_remove:
                if key in template_obj:
                    template_obj.pop(key, None)
                    if key == "name":
                        keys_to_remove.remove(key)
            # Recursively remove keys for values of type dict
            for key, value in template_obj.items():
                if key in ["content","metadata_info"] and isinstance(value, dict):
                    continue  # Skip any key removal inside content or metadata_info
                self.remove_keys(value, keys_to_remove)        
        
        elif isinstance(template_obj, list):
            # Recursively remove keys for elements of type list
            for item in template_obj:
                self.remove_keys(item, keys_to_remove)

    def create_template_copy(self,user_info,template_id, doc_name,sharing_details):
        """[Controller to create a copy of template]

        Args:
            template_id (str): template id
        """
        template_obj = self.get_document(template_id,user_info)
        relative_url = template_obj["relative_url"]  if "relative_url" in template_obj and template_obj["relative_url"] not in ['',None] else None

        keys_to_remove = ["id" ,
                        "is_locked_by",
                        "parent_id",
                        "relative_url",
                        "is_deleted",
                        "is_private",
                        "document_id"]
        
        if doc_name:
            keys_to_remove.append("name")
        
        self.remove_keys(template_obj, keys_to_remove)

        template_obj["created_by"] = user_info["Username"]
        template_obj["modified_by"] = user_info["Username"]
        template_obj["creator_tenant_id"] = user_info["mule_client_id"]
        template_obj['is_template'] = False

        if doc_name:
            template_obj["name"] = doc_name

        if sharing_details:
            if not isinstance(sharing_details, dict):
                sharing_details = sharing_details.dict()
            if len(sharing_details["sharing_details"]) > 0:
                template_obj["sharing_details"]= sharing_details["sharing_details"]

        if relative_url:
            new_url = copy_file(
                tenant=template_obj["creator_tenant_id"],
                file_name=template_obj["name"],
                user=template_obj["created_by"],
                existing_url=relative_url)
            template_obj["relative_url"] = new_url["s3Path"] if relative_url else None
        
        template = self.create_group_doc(template_obj, file=None, isFilePresent=False, user_info=user_info)      

        return template
    
    def get_document_by_tenant_id(self, user_info, get_all, type):
        try:
            documents, doc_count = self.CRUDDocument.get_document_by_tenant_id(user_info=user_info, get_all=get_all, type=type)
            for document in documents:
                if document is not None:
                    placeholders = self.CRUDPlaceholder.read_by_document_id(document['id'])
                    document['placeholders'] = placeholders
            return {
                "documents": documents,
                "total_docs": doc_count
            }
        except ResourceNotFound as e:
            logger.error(e)
            raise HTTPException(status_code= 404, detail= str(e.args[0]))
        except Exception as e:
            logger.error(e)
            raise HTTPException(status_code= 501,
                detail= f"Error while getting a document in controller.\n {e.args}"
            )
