from utils.logs.logger_config import logger
from crud.v2.document_share_crud import CRUDDocumentShareMap
from crud.v2.document_crud import CRUDDocument
from crud.v2.document_audit_log_crud import CRUDDocumentsAuditLog
from db.orm_models.v2.enums import SharedwithType, ACTION
import json
from fastapi import HTTPException


class DocumentShareController:
    def __init__(self):
        self.CRUDDocumentShareMap = CRUDDocumentShareMap()
        self.CRUDDocument = CRUDDocument()
        self.CRUDDocumentsAuditLog = CRUDDocumentsAuditLog()

    def create_document_share_map(
        self, user_info: dict, id: str, sharing_details: list
    ) -> list:
        """Creates a document share mapping

        Args:
            user_info (dict): infor about the user.
            id (str): document id.
            sharing_details (list): sharing ids and types of the entities.

        Raises:
            HTTPException: given id doesn't exist

        Returns:
            list: ids of mapped records
        """

        logger.info("executing create-document-share-map controller ...")

        document = self.CRUDDocument.get_by_id(id, user_info)

        if document is None:
            raise HTTPException(
                status_code=404, detail="The given document id doesn't exist."
            )

        if document['parent_id']:
            logger.error("Document is a child doc, cannot update sharing details.")
            raise HTTPException(status_code= 404, detail="Document is a child doc, cannot update sharing details.")
        
        mappings = self.CRUDDocumentShareMap.read_by_shared_with_type(id)
        
        flag = 0
        if mappings:
            flag = 1
        else:
            document["is_private"] = False
        
        document["modified_by"] = user_info["Username"]

        mapping_id_list = []
        audit_details =[]


        for sharing_detail in sharing_details:
            if not isinstance(sharing_detail, dict):
                sharing_detail = sharing_detail.dict()
            
            if "shared_with_id" in sharing_detail and sharing_detail['shared_with_id']:
                sharing_detail['shared_with_id'] = sharing_detail["shared_with_id"].strip()
                
            if not isinstance(sharing_detail['shared_with_type'], SharedwithType):
                sharing_detail["shared_with_type"] = SharedwithType(sharing_detail["shared_with_type"])
            
            if sharing_detail["shared_with_type"] not in SharedwithType:
                raise HTTPException(
                    status_code=422,
                    detail={
                        "type": "enum",
                        "loc": ["body", "shared_with_type"],
                        "msg": "Input should be 'USER','GROUP' or 'TENANT'",
                        "input": sharing_detail["shared_with_type"]
                    },
                )

            
            # check for default tenant id
            if sharing_detail["shared_with_type"] == SharedwithType.TENANT:
                if "shared_with_id" not in sharing_detail or sharing_detail["shared_with_id"] in [None,'']:
                    sharing_detail["shared_with_id"] = user_info["mule_client_id"]

            if sharing_detail["shared_with_id"] in [None,'']:
                raise HTTPException(400,"shared with id should not be None or empty!")
            
            #group access check
            if sharing_detail["shared_with_type"] == SharedwithType.GROUP and sharing_detail["shared_with_id"] not in user_info["user_groups"]:
                raise HTTPException(400,"User is not part of the given group.")
            
            if sharing_detail["shared_with_type"] == SharedwithType.USER:
                sharing_detail["shared_with_id"] =  sharing_detail["shared_with_id"].upper()

            duplicate_check = self.CRUDDocumentShareMap.duplicate_check(
                document_id=id,
                shared_with_type=sharing_detail["shared_with_type"],
                shared_with_id=sharing_detail["shared_with_id"],
            )

            if duplicate_check:
                mapping_id_list.append(str(duplicate_check["id"]))
                continue
            
            db_document = {
                "document_id": id,
                "shared_with_type": sharing_detail["shared_with_type"],
                "shared_with_id": sharing_detail["shared_with_id"],
                "is_deleted": False,
                "created_by": user_info["Username"],
                "modified_by": user_info["Username"],
            }

            obj = self.CRUDDocumentShareMap.create(**db_document)
            #update is_private for all the versions.
            if flag == 0 :
                self.CRUDDocument.update(
                    user_info =  user_info,
                    id=document["id"],
                    is_private=document["is_private"],
                    modified_by=document["modified_by"]
                )
                logger.info("calling create doc audit log crud ....")
                audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=id, 
                                                        action=ACTION.UPDATED.value,
                                                        detail="Privacy updated to False",
                                                        created_by=user_info["Username"])
                flag = flag+1 
            audit_details.append(str(obj['id']))
            mapping_id_list.append(str(obj["id"]))

        if audit_details:
            audit_details = json.dumps(audit_details)
        
        else:
            audit_details = "Duplicate entries"
        logger.info("calling create doc audit log crud ....")
        audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=id, 
                                                    action=ACTION.CREATED_SHARING.value,
                                                    detail= audit_details,
                                                    created_by=user_info["Username"])
        return mapping_id_list

    def get_sharing_details(
        self, user_info: dict, document_id: str, shared_with_type: str = None
    ) -> list:
        """Gets document share mapping by id and shared_with_type

        Args:
            user_info (dict): information about the user.
            document_id (str): document id.
            shared_with_type (str, optional): type of the shared entity. Defaults to None.

        Raises:
            HTTPException: document id doesn't exist.

        Returns:
            list: all records matching the criteria
        """

        logger.info("executing get-sharing-details controller ...")

        check = self.CRUDDocument.check_user_access_to_document(user_info, document_id)
        if check == False:
            raise HTTPException(
                status_code=404, detail="Given document id doesn't exist."
            )

        response = self.CRUDDocumentShareMap.read_by_shared_with_type(
            document_id, shared_with_type
        )

        return response

    def delete_sharing_details(
        self,
        user_info: dict,
        document_id: str,
        shared_with_type: SharedwithType = None,
        shared_with_id: str = None,
    ) -> int:
        """Deletes document share mapping by id and shared_with_type/share_with_id

        Args:
            user_info (dict): information about the user.
            document_id (str): document id.
            shared_with_type (SharedwithType, optional): type of the shared entity. Defaults to None.
            shared_with_id (str, optional): id of the shared entity. Defaults to None.

        Raises:
            HTTPException: Shared_with_type must be passed along with shared_with_id.
            HTTPException: There are no records present with the specified parameters.

        Returns:
            int: no. of mappings deleted
        """

        logger.info("executing delete-sharing-details controller ...")

        if shared_with_type is None and shared_with_id is not None:
            raise HTTPException(
                status_code=400,
                detail="Shared_with_type must be passed along with shared_with_id",
            )

        mappings = self.get_sharing_details(user_info, document_id, shared_with_type)

        if shared_with_id is not None and shared_with_type == SharedwithType.USER:
            shared_with_id = shared_with_id.upper()

        if len(mappings) != 0:
            no_of_maps = self.CRUDDocumentShareMap.update_delete_status(
                user_info, document_id, shared_with_type, shared_with_id
            )
            if no_of_maps >0:
                if shared_with_type is not None:
                    detail = f"Shared with type: {shared_with_type.value}"
                    if shared_with_id is not None:
                        detail += f", Shared with id: {shared_with_id}"
                else:
                    detail = f"Removed all mappings for the document."

                logger.info("calling create doc audit log crud ....")
                audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=document_id, 
                                                        action=ACTION.REMOVED_SHARING.value,
                                                        detail= detail,
                                                        created_by=user_info["Username"])

        else:
            raise HTTPException(
                status_code=400,
                detail="There are no records present with the specified parameters.",
            )
        
        response = self.CRUDDocumentShareMap.read_by_shared_with_type(document_id)
        if len(response) == 0:
            logger.info("calling update crud for document ..")
            update_obj = self.CRUDDocument.update(
                user_info = user_info, id = document_id, is_private = True
            )
            logger.info("calling create doc audit log crud ....")
            audit_obj = self.CRUDDocumentsAuditLog.create(doc_id=document_id, 
                                                      action=ACTION.UPDATED.value,
                                                      detail="Privacy updated to True",
                                                      created_by=user_info["Username"])

        return no_of_maps
