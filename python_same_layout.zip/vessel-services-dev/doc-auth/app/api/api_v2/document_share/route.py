from fastapi import APIRouter, Request
from schemas.v2.requests.DocumentSharingRequests import BasicDocumentSharingDetails
from db.orm_models.v2.enums import SharedwithType, ACTION
from api.api_v2.document_share.controller import DocumentShareController
from api.api_v2.document_audit_log.controller import DocumentAuditLogController

from utils.logs.logger_config import logger
from utils.api_response import *
from typing import List
from validator.decorators import async_token_validation_and_metering
from api.dependencies.authorization.auth_decorator import auth_token_validation

document_sharing_router = APIRouter()


@document_sharing_router.post("/document/{id}/share")
@async_token_validation_and_metering(uom=4)
@auth_token_validation()
async def create_document_share_map(
    request: Request, id: str, sharing_details: List[BasicDocumentSharingDetails]
) -> dict:
    """API to create sharing details for a document

    ```
    shared_with_type (ENUM) : USER | GROUP | TENANT
    Args:
        id (str): document id.
        sharing_details (List[BasicDocumentSharingDetails]): sharing details.
    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }
    Returns:
        [dict: mapping ids of the records created]: {
                "success": true,
                "message": "",
                "details": {
                    "id": [
                        "string"
                    ]
                }
            }
    ```
    """

    logger.info("calling create-document-share-mapping router ...")

    user_info =  request.state.userInfo

    try:
        response = DocumentShareController().create_document_share_map(
            user_info, id, sharing_details
        )
    except Exception as e:
        logger.info("calling create doc audit log crud ....")
        DocumentAuditLogController().create_audit_log(document_id=id, 
                                                    action=ACTION.CREATED_SHARING.value,
                                                    detail= "Error occurred while creating mappings",
                                                    created_by=user_info["Username"])
        raise e

    
    return generate_api_success_response(body={"id": response})


@document_sharing_router.get("/document/{id}/share")
@async_token_validation_and_metering()
@auth_token_validation()
async def get_document_by_id(
    request: Request, id: str, shared_with_type: SharedwithType = None
) -> dict:
    """API to get sharing details for a document
    ```
    shared_with_type (ENUM) : USER | GROUP | TENANT
    Args:
        id (str): document id.
        shared_with_type (SharedwithType, optional): type of the shared entity. Defaults to None.
    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }
    Returns:
        [dict: sharing details of a document with given id]:{
                "success": true,
                "message": "",
                "details": [
                    {
                        "id": "string",
                        "document_id": "string",
                        "shared_with_id":"string",
                        "modified_by": "string",
                        "modified_at": "datetime",
                        "shared_with_type": "string",
                        "created_by": "string",
                        "created_at": "datetime",
                        "is_deleted": boolean
                    }
                ]
            }

    ```
    """

    logger.info("calling get-document-sharing-details router ...")

    user_info =  request.state.userInfo

    response = DocumentShareController().get_sharing_details(
        user_info, id, shared_with_type
    )

    return generate_api_success_response(body=response)


@document_sharing_router.delete("/document/{id}/share")
@async_token_validation_and_metering()
@auth_token_validation()
async def delete_document_by_id(
    request: Request,
    id: str,
    shared_with_type: SharedwithType = None,
    shared_with_id: str = None,
) -> str:
    """API to delete document share mapping
    ```
    shared_with_type (ENUM) : USER | GROUP | TENANT
    Args:
        id (str): document id.
        shared_with_type (SharedwithType, optional): type of the shared entity. Defaults to None.
        shared_with_id (str, optional): id of the shared entity. Defaults to None.
    Raises:
        HTTPException: [Exception in underlying controller]
        error: {
            "success": false,
            "message": "string",
            "details": {}
        }
    Returns:
        [dict: number of mappings deleted]: {
            "success": true,
            "message": "{count} mappings deleted.",
            "details": {}
        }
    ```
    """
    logger.info("calling delete-document-share-mapping router ...")
    user_info = request.state.userInfo
    
    if shared_with_id:
        shared_with_id = shared_with_id.strip()

    response = DocumentShareController().delete_sharing_details(
        user_info, id, shared_with_type, shared_with_id
    )

    return generate_api_success_response(message=f"{response} mappings deleted.")
