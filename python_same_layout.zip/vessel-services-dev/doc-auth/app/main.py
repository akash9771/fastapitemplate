import uvicorn
from fastapi import FastAPI
from config.load_config import config
from starlette.middleware.cors import CORSMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException
from fastapi.exceptions import RequestValidationError
from api.api_v1 import api_router
from api.api_v2 import api_router_v2
from fastapi.openapi.utils import get_openapi
from schemas.v1.requests.HealthCheckRequest import HealthCheckResponse, Status
from utils.api_response import generic_exception_handler, http_exception_handler, validation_exception_handler
# import configparser, os


app = FastAPI(
    title="Doc Authoring Service",
    # version="0.1",
    # openapi_url=(config["api_prefix"] + "/openapi.json"),
    # docs_url=(config["api_prefix"] + "/docs"),
    # redoc_url=(config["api_prefix"] + "/redoc"),
)
origins = ["*"]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app_v1 = FastAPI(version="1.0") # Older doc auth app - v1

app_v1.include_router(api_router)

app_v2 = FastAPI(version="2.0") # V2 of doc auth - major changes

app_v2.include_router(api_router_v2)

app.mount((config["api_prefix"] + "/v2"), app_v2)
app.mount(config["api_prefix"], app_v1)


@app_v1.get(
    "/health_check",
    status_code=200,
    tags=["Health check"],
)
async def health_check():
    return HealthCheckResponse(
        status=Status.success, message="health_check completed successfully"
    )


@app_v2.exception_handler(RequestValidationError)
async def new_validation_exception_handler(request, exc):
    return validation_exception_handler(exc, request)


@app_v2.exception_handler(StarletteHTTPException)
async def new_http_exception_handler(request, exc):
    return http_exception_handler(exc, request)


@app_v2.exception_handler(Exception)
async def new_generic_exception_handler(request, exc):
    return generic_exception_handler(exc, request)


def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Doc Authoring Service",
        version="0.1",
        routes=app.routes,
    )
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi

# cfg = configparser.ConfigParser()
# cfg.read('alembic.ini')


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
