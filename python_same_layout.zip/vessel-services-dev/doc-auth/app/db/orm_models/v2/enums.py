import enum

class SortBy(enum.Enum):
    Id = "id"
    Name = "name"
    Modified_at = "modified_at"
    Created_at = "created_at"
    Is_template = "is_template"

class OrderBy(enum.Enum):
    ASC = "ASC"
    DESC = "DESC"

class DocType(enum.Enum):
    all = "all"
    shared = "shared"
    private = "private"
    
class MetaEnum(enum.EnumMeta):
    def __contains__(cls, item):
        try:
            cls(item)
        except ValueError:
            return False
        return True

class SharedwithType(enum.Enum, metaclass=MetaEnum):
    USER = "USER"
    GROUP = "GROUP"
    TENANT = "TENANT"


class DocType(enum.Enum, metaclass=MetaEnum):
    DOC = "DOC" 
    PDF = "PDF"
    PPT = "PPT"

class ACTION(enum.Enum):
    DELETED  = "DELETED"
    UPLOADED = "UPLOADED"
    UPDATED = "UPDATED"
    CREATED_SHARING = "CREATED_SHARING"
    REMOVED_SHARING = "REMOVED_SHARING"
    MARKED_AS_TEMPLATE = "MARKED_AS_TEMPLATE"
    

class DocFormat(enum.Enum):
    html = "html"
    json = "json"