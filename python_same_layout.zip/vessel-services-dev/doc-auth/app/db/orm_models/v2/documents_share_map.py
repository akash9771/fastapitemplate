import uuid

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKeyConstraint,
    String,
    func,
    text,
    Enum
)
from sqlalchemy.dialects.postgresql import UUID

from ...base_class import Base

from .documents import Documents
from .enums import SharedwithType


class DocumentsShareMap(Base):
    __tablename__ = "documents_share_map"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text('gen_random_uuid()'))
    document_id = Column(UUID(as_uuid=True), index=True, nullable=False)
    shared_with_type = Column(Enum(SharedwithType, name="shared_with_type", schema="v2"), index=True, nullable=False)
    shared_with_id = Column(String, index=True, nullable=False)
    created_by = Column(String, nullable=False)
    modified_by = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now(), server_default=func.now(), nullable=False)
    modified_at = Column(
        DateTime, default=func.now(), onupdate=func.now(), server_default=func.now(), server_onupdate=func.now(), nullable=False, index=True
    )
    is_deleted = Column(Boolean, default=False, server_default=text('false'), nullable=False)

    __table_args__ = (ForeignKeyConstraint([document_id],[Documents.id]),
                       {"extend_existing": True, "schema": "v2"})
