import uuid
from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    ForeignKeyConstraint,
    String,
    Integer,
    func,
    text
)
from sqlalchemy.dialects.postgresql import (UUID , JSONB)
from ...base_class import Base
from .documents import Documents

class Placeholders(Base):
    __tablename__ = "placeholders"
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, server_default=text('gen_random_uuid()'))
    document_id = Column(UUID(as_uuid=True), index=True, nullable=False)
    sequence_no = Column(Integer, nullable=False, default=0, server_default=text('0'))
    metadata_info = Column(JSONB)
    content = Column(JSONB)
    is_deleted = Column(Boolean,default=False,server_default=text('false'),nullable=False)
    created_by = Column(String, nullable=False)
    modified_by = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now(), server_default=func.now(), nullable=False,index=True)
    modified_at = Column(
        DateTime, default=func.now(), onupdate=func.now(), server_default=func.now(), server_onupdate=func.now(), nullable=False
    )

    __table_args__ = (ForeignKeyConstraint([document_id],[Documents.id]),
                       {"extend_existing": True, "schema": "v2"})
