import uuid

from sqlalchemy import (
    Boolean,
    Column,
    DateTime,
    Enum,
    ForeignKeyConstraint,
    String,
    Integer,
    func,
    text
)
from sqlalchemy.dialects.postgresql import (UUID , JSONB)
from ...base_class import Base
from .enums import DocType
class Documents(Base):
    __tablename__ = "documents"
    id = Column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4,  server_default=text('gen_random_uuid()'), nullable=False
    )
    relative_url  = Column(String, nullable=False)
    name = Column(String, nullable=False, index=True)
    type = Column(Enum(DocType, name="doc_types", schema="v2"), nullable=False, default=DocType.DOC.value, server_default=text('DOC'))
    parent_id = Column(UUID(as_uuid=True), index=True, nullable=True)
    content = Column(JSONB)
    sequence_no=Column(Integer, nullable=False, default=0, server_default=text('0'))
    is_template = Column(Boolean, nullable=False, default=False, server_default=text('false'))
    metadata_info = Column(JSONB)
    creator_tenant_id = Column(String, nullable=False)
    is_deleted = Column(Boolean,default=False,server_default=text('false'),nullable=False)
    is_locked_by = Column(String)
    is_private = Column(Boolean,default=False, server_default=text('false'),nullable=False)
    created_by = Column(String, nullable=False)
    modified_by = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now(), server_default=func.now(), nullable=False)
    modified_at = Column(
        DateTime, default=func.now(), onupdate=func.now(), server_default=func.now(), server_onupdate=func.now(), nullable=False, index=True
    )

    __table_args__ = (ForeignKeyConstraint([parent_id],[id]),
                       {"extend_existing": True, "schema": "v2"})