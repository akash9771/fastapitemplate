import uuid
 
from sqlalchemy import (
    Column,
    DateTime,
    Enum,
    ForeignKeyConstraint,
    Integer,
    String,
    func,
    text
)
from sqlalchemy.dialects.postgresql import UUID
 
from ...base_class import Base
from .enums import ACTION
from .documents import Documents
 
 
class DocumentsAuditLog(Base):
    __tablename__ = "documents_audit_log"
 
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, 
                server_default=text('gen_random_uuid()'))
    document_id = Column(UUID(as_uuid=True), index=True, nullable=False)
    action = Column(Enum(ACTION, schema="v2"), nullable=False)
    detail = Column(String)
    created_by = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now(), server_default=func.now(), nullable=False)
    
 
    __table_args__ = (ForeignKeyConstraint([document_id],[Documents.id]),
                       {"extend_existing": True, "schema": "v2"})