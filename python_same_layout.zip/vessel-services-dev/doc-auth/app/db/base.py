# Import all the models, so that Base has them before being
# imported by Alembic

# from db.base_class import Base  # noqa
from db.orm_models.v1.domain_config_model import *
from db.orm_models.v1.admin_config_model import *
from db.orm_models.v1.project_model import *
from db.orm_models.v1.template_model import *
from db.orm_models.v1.document_model import *