from typing import Optional
from pydantic import BaseModel


class LockedResponse(BaseModel):
    name: str
    is_locked_by: str
    is_locked: bool
