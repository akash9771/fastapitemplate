from typing import Optional
from pydantic import BaseModel


class UpdatePlaceholder(BaseModel):
    sequence_no: Optional[int]
    metadata_info: Optional[dict]
    content: Optional[dict]

class CreatePlaceholderWithId(BaseModel):
    id: str
    sequence_no: Optional[int] = 0
    metadata_info: Optional[dict] = None
    content: Optional[dict] = None

class UpdatePlaceholderById(BaseModel):
    sequence_no: Optional[int] = 0
    metadata_info: Optional[dict] = None
    content: Optional[dict] = None
    class Config:
        extra = "forbid"