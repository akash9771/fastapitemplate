from pydantic import BaseModel
from typing import Optional, List
from db.orm_models.v2.enums import SharedwithType

class BasicDocumentSharingDetails(BaseModel):
    shared_with_type: SharedwithType
    shared_with_id: str = None

class DocumentShareMap(BaseModel):
    id: str
    basic_prompt_sharing_details: BasicDocumentSharingDetails

class CopyDocumentShareMap(BaseModel):
    sharing_details: List[BasicDocumentSharingDetails]