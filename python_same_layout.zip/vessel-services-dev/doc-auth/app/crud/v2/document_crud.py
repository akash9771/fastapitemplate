from typing import Tuple

from sqlalchemy import and_, exists, func, or_, select
from db.orm_models.v2.documents import Documents
from db.orm_models.v2.documents_share_map import DocumentsShareMap
from utils.logs.logger_config import logger
from config.errors import get_err_json_response
from db.session import acquire_db_session as session
from utils.exceptions import BadRequestResult
from db.orm_models.v2.enums import DocType
from sqlalchemy.orm import defer


class CRUDDocument:

    @staticmethod
    def get_user_access_check_query(user_info):
        shared_with_ids = []
        shared_with_ids.extend(user_info['user_groups'])
        shared_with_ids.extend([user_info["Username"], user_info["mule_client_id"]])

        return or_(
                and_(
                    Documents.created_by == user_info["Username"],
                    Documents.creator_tenant_id == user_info["mule_client_id"],
                ),
                and_(
                    Documents.creator_tenant_id == user_info["mule_client_id"],
                    exists(select(1)).where(
                        ((DocumentsShareMap.document_id == Documents.id) | (DocumentsShareMap.document_id == Documents.parent_id)) &
                        (DocumentsShareMap.shared_with_id.in_(shared_with_ids)) &
                        (DocumentsShareMap.is_deleted == False)
                    ),
                )
            )

    def check_user_access_to_document(self, user_info, doc_id):
        try:
            logger.info("Checking if the user has access to the document...")
            with session() as transaction_session:
                has_access: Documents = (
                    transaction_session.query(exists().where(
                         Documents.id == doc_id,
                        self.get_user_access_check_query(user_info)
                    )).scalar()
                )
            if has_access:
                return True
            else:
                return False
        except Exception as e:
            logger.error("Error while reading records by id from document table")
            raise e
        
    def create(self, **request):
        """[CRUD function to create a new Document record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("Inside CRUD Document - create !")
            obj: Documents = Documents(**request)
            with session() as transaction_session:
                transaction_session.add(obj)
                transaction_session.commit()
                transaction_session.refresh(obj)
            logger.info("Created a new Document record")
            return obj.__dict__
        except Exception as e:
            logger.error(f"error in doc crud : {e}")
            raise e
        
    def get_by_id(self, id, user_info):
        """[CRUD function to read a Documents record]

        Args:
            Document_id (str): [Document id to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [Document record matching the criteria]
        """
        try:
            logger.info("Inside CRUD Documents - get by id !")
            with session() as transaction_session:
                obj: Documents = (
                    transaction_session.query(Documents)
                    .filter(Documents.id == id)
                    .filter(Documents.is_deleted == False)
                    .filter(self.get_user_access_check_query(user_info=user_info))
                    .first()
                )
            
            if obj is not None:
                return obj.__dict__
            else:
                return None
        except Exception as e:
            logger.error(f"error in doc crud : {e}")
            raise e

    def update(self,user_info, **kwargs):
        """[CRUD function to update a User record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [Document record matching the criteria]
        
        """
        try:
            logger.info("Inside CRUD Documents - update !")
            with session() as transaction_session:
                obj: Documents = (
                    transaction_session.query(Documents)
                    .filter(Documents.id == kwargs.get("id"))
                    .update(kwargs, synchronize_session=False)
                )
                transaction_session.commit()

                if obj > 0:
                    logger.info("Updation successful, fetching record..")
                    return obj 
                else: 
                    raise BadRequestResult("Update not successful.")
        except Exception as e:
            logger.error(f"error in doc crud : {e}")
            raise e
    
    def update_child(self,user_info, **kwargs):
        """[CRUD function to update child a User record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [Document record matching the criteria]
        
        """
        try:
            logger.info("Inside CRUD Documents - update !")
            with session() as transaction_session:

                query = transaction_session.query(Documents).filter(self.get_user_access_check_query(user_info),Documents.is_deleted == False)
                query = query.filter(Documents.parent_id == kwargs.get("parent_id"))
                obj = query.update(kwargs, synchronize_session=False)
                transaction_session.commit()

                if obj > 0:
                    logger.info("Updation successful, fetching record..")
                    return obj 
                else: 
                    raise BadRequestResult("Update not successful.")
        except Exception as e:
            logger.error(f"error in doc crud : {e}")
            raise e
        
    def check_duplicate_document(self, document_name: str,creator_tenant_id: str,created_by: str):
        """[CRUD function toh check document by name already exist or not]

        Args:
            document_name: name of document
            creator_tenant_id
            created_by

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [boolean]: true if already exist 
        """
        try:
            logger.info("Inside CRUD Document - check for duplicate document!")
            with session() as transaction_session:
                obj: Documents = (
                    transaction_session.query(Documents)
                    .filter(Documents.name == document_name)
                    .filter(Documents.creator_tenant_id==creator_tenant_id)
                    .filter(Documents.created_by==created_by)
                    .filter(Documents.is_deleted==False)
                    .first()
                )
            if obj is not None:
                return obj.__dict__
            else:
                return False
        except Exception as e:
            logger.error(f"error in doc crud : {e}")
            raise e

    def delete(self, document_id, user_info):
        """[CRUD function to delete a Document record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("Inside CRUD Document - delete !")
            with session() as transaction_session:
                obj: Documents = (
                    transaction_session.query(Documents)
                    .filter(Documents.id == document_id)
                    .update(dict(is_deleted = True , modified_by = user_info["Username"]), synchronize_session=False)
                )
                transaction_session.commit()
            logger.info(f"deleted a document record for document id {document_id}.")
            if obj:
                return {"id": document_id}
            else:
                raise BadRequestResult("Error while deleteing file!")
        except Exception as e:
            logger.error(f"error in doc crud : {e}")
            logger.error(e)
            return get_err_json_response(
                "Error while updating to Documents table",
                e.args,
                501,
            )
            
    def read_documents(
        self, 
        user_info: dict, 
        search_by_name:str = None,
        type: DocType.DOC = None,
        show_children: bool = False,
        with_content: bool = False,
        is_private:bool = None,
        is_template:bool =None, 
        created_by: str = None,
        limit: int = None, 
        offset: int = None, 
        order_by: str = "DESC", 
        sort_by: str = "modified_at",
        # show_deleted: bool = None  
    ) -> Tuple[list, int]:
        """CRUD function to return multiple documents

        Args:
            user_info (dict): information about the user
            search_by_name (str, optional): name of documents to fetch. Defaults to None.
            type: (DocType, optional): type of Doc to be filtered for 
            show_children: (bool, optional): whether should show child documents. Defaults to False
            with_content: (bool, optional): whether should fetch document content JSON. Defaults to False. 
            is_private (bool, optional): type of documents to fetch. Defaults to None.
            is_template (bool, optional): type of documents to fetch. Defaults to None.
            created_by (str, optional): id of a user. Defaults to None.
            limit (int, optional): max number of documents to return. Defaults to None.
            offset (int, optional): number of documents to skip from start. Defaults to None.
            order_by (str, optional): ascending or descending. Defaults to "DESC".
            sort_by (str, optional): sort the documents by. Defaults to "modified_at".

        Raises:
            e: Error returned from the DB layer

        Returns:
            Tuple[list,int]: List of documents and total count
        """

        try:
            logger.info("executing read-document crud ...")
            with session() as transaction_session:
                # Build the query
                if with_content:
                    query = transaction_session.query(Documents)
                else:
                    query = transaction_session.query(Documents).options(defer(Documents.content))
                query = query.filter(self.get_user_access_check_query(user_info),Documents.is_deleted == False)

                # if show_deleted is not None: 
                #     query = query.filter(Documents.is_deleted == show_deleted)

                if search_by_name is not None: 
                    query = query.filter(Documents.name.ilike(f"%{search_by_name}%"))
                
                if is_private is not None:
                    query = query.filter(Documents.is_private == is_private)

                if is_template is not None:
                    query = query.filter(Documents.is_template == is_template)

                if created_by:
                    query = query.filter(Documents.created_by == created_by.upper())

                if type is not None:
                    query = query.filter(Documents.type == type)
                
                if show_children == False:
                    query = query.filter(Documents.parent_id == None)


                #sort records
                if sort_by is not None:
                    sort_column = getattr(Documents, sort_by)
    
                    if order_by == "DESC":
                        query = query.order_by(sort_column.desc())
                    else:
                        query = query.order_by(sort_column.asc())

                total_count = query.count()

                # Apply pagination
                if limit is not None:
                    start_index = (offset - 1) * limit
                    end_index = start_index + limit
                    query = query.offset(start_index).limit(limit)

                # Execute the query
                docs = query.all()
                if docs == []:
                    logger.info(
                        "There are no documents in table with matching criteria"
                    )
                    return [], total_count
                else:
                    return [doc.__dict__ for doc in docs], total_count

        except Exception as e:
            logger.error("Error while reading records from document table")
            raise e
              
    def read_documents_by_parent_id(
        self, 
        user_info: dict, 
        parent_id:str
    ) -> Tuple[list, int]:
        """CRUD function to return multiple documents

        Args:
            user_info (dict): information about the user
            parent_id(str): partent id

        Raises:
            e: Error returned from the DB layer

        Returns:
            Tuple[list,int]: List of documents and total count
        """

        try:
            logger.info("executing read-document crud ...")
            with session() as transaction_session:
                # Build the query
                query = transaction_session.query(Documents).filter(self.get_user_access_check_query(user_info),Documents.is_deleted == False, Documents.parent_id == parent_id).order_by(Documents.sequence_no.asc())

                # Execute the query
                docs = query.all()
                if docs == []:
                    logger.info(
                        "There are no documents in table with matching criteria"
                    )
                    return []
                else:
                    return [doc.__dict__ for doc in docs]

        except Exception as e:
            logger.error("Error while reading records from document table")
            raise e
        
    def get_document_by_tenant_id(self, user_info: dict, get_all:bool, type: DocType)-> Tuple[list, int]:
        """CRUD function to return multiple documents

        Args:
            user_info (dict): information about the user

        Raises:
            e: Error returned from the DB layer
        """

        try:
            logger.info("executing get-document by tenant crud ...")
            with session() as transaction_session:
                query = transaction_session.query(Documents).filter(Documents.creator_tenant_id == user_info["mule_client_id"], Documents.is_deleted == False)

                if type is not None:
                    query = query.filter(Documents.type == type)
                
                if not get_all:
                    query = query.limit(10)

                docs = query.all()
                total_count = query.count()
                if docs == []:
                    logger.info(
                        "There are no documents in table with matching criteria"
                    )
                    return []
                else:
                    return [doc.__dict__ for doc in docs], total_count

        except Exception as e:
            logger.error("Error while reading records from document table")
            raise e
    
    
    def get_all_documents(
        self,
        user_info
    ) ->list:
        """CRUD function to return multiple documents

        Args:
            user_info (dict): information about the user
        Raises:
            e: Error returned from the DB layer

        Returns:
            list: List of documents
        """

        try:
            logger.info("executing read-document crud ...")
            with session() as transaction_session:
                # Build the query
                query = transaction_session.query(Documents).with_entities(Documents.id ,Documents.type, Documents.relative_url, Documents.metadata_info, Documents.created_by , Documents.modified_by).filter( Documents.creator_tenant_id == user_info['mule_client_id'], Documents.is_deleted == False)
                return query.all()

        except Exception as e:
            logger.error("Error while reading records from document table")
            raise e