from db.session import acquire_db_session as session
from db.orm_models.v2.placeholders import Placeholders
from config.errors import get_err_json_response
from utils.logs.logger_config import logger
from sqlalchemy import asc, and_
from fastapi import HTTPException

from utils.exceptions import BadRequestResult


class CRUDPlaceholder:

    def duplicate_check(
        self, document_id: str, placeholder_id: str
    ) -> str:
        """CRUD function to check for duplicate entry

        Args:
            document_id (str): document id.
            placeholder_id (str): placeholder

        Raises:
            e: Error returned from the DB layer

        Returns:
            str: id of the record if it exists
        """
        try:
            logger.info("executing duplicated-check crud ...")
            with session() as transaction_session:
                obj: Placeholders = (
                    transaction_session.query(Placeholders)
                    .filter(
                        Placeholders.document_id == document_id,
                        Placeholders.id == placeholder_id,
                    )
                    .first()
                )
                transaction_session.commit()

            if obj is not None:
                return obj.__dict__
            else:
                return None

        except Exception as e:
            logger.error("Error while reading records from placeholder table")
            raise e

    def create(self, doc_placeholders):
        """[CRUD function to create a new doc placeholder record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("Inside CRUD Doc Placeholder - create !")
            with session() as transaction_session:
                placeholders=[]
                for doc_data in doc_placeholders:
                    doc_placeholder = Placeholders(**doc_data)
                    placeholders.append(doc_placeholder)
                transaction_session.add_all(placeholders)
                transaction_session.commit()

            return [doc_placeholder.__dict__ for doc_placeholder in placeholders]
        except Exception as e:
            logger.error("Error while creating placeholder in table")
            raise e
    
    def read_by_placeholder_id(self, 
                            document_id,
                            placeholder_id):
        """[CRUD function to read a placeholder record]

        Args:
            document_id (str): document_id
            placeholder_id (str): placeholder_id

        Raises:
            e: _description_
        """
       
        try:
            logger.info("executing read_by_placeholder_id crud ...")
            with session() as transaction_session:
                response = (transaction_session.query(Placeholders)
                         .filter(and_(Placeholders.document_id == document_id , Placeholders.id == placeholder_id, Placeholders.is_deleted == False))).order_by(asc(Placeholders.sequence_no)).first()
                return {"placeholder": response }                            
        except Exception as e:
            logger.error("Error while reading placeholder by id in placeholder table")
            raise e
    
    def read_by_document_id(self, 
                            document_id):
        """[CRUD function to read a placeholder record]

        Args:
            document_id (str): document_id

        Raises:
            e: _description_
        """
       
        try:
            logger.info("executing read-by-document-id crud ...")
            with session() as transaction_session:
                query = (transaction_session.query(Placeholders)
                         .filter(Placeholders.document_id == document_id)
                         .filter(Placeholders.is_deleted == False))
                query = (query.order_by(asc(Placeholders.sequence_no)))
                placeholders= query.all()
                return [placeholder.__dict__ for placeholder in placeholders]
                                            
        except Exception as e:
            logger.error("Error while reading placeholder by document id in placeholder table")
            raise e

    def update(self,user_info,placeholder_id, **kwargs):
        """[CRUD function to update a Placeholders record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [Placeholders record matching the criteria]
        
        """
        try:
            logger.info("Inside CRUD Placeholders - update !")
            with session() as transaction_session:
                obj: Placeholders = (
                    transaction_session.query(Placeholders)
                    .filter(Placeholders.id == placeholder_id)
                    .update(kwargs, synchronize_session=False)
                )
                transaction_session.commit()

                if obj > 0:
                    logger.info("Updation successful, fetching record..")
                    return obj 
                else: 
                    raise BadRequestResult("Update not successful.")
        except Exception as e:
            logger.error(f"error in Placeholders crud : {e}")
            raise e
        
    def upsert(self, doc_placeholders):
        """[CRUD function to create a new doc placeholder record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("Inside CRUD Doc Placeholder - create !")
            with session() as transaction_session:
                placeholders=[]
                for doc_data in doc_placeholders:
                    doc_placeholder = Placeholders(**doc_data)
                    placeholders.append(doc_placeholder)
                for placeholder in placeholders:
                     transaction_session.merge(placeholder)
                transaction_session.commit()

            return [doc_placeholder.__dict__ for doc_placeholder in placeholders]
        except Exception as e:
            logger.error("Error while creating placeholder in table")
            raise e
    
    def delete(self, user_info,placeholders ):
        """[CRUD function to delete a Placeholder record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("Inside CRUD Placeholder - delete !")
            obj = 0
            with session() as transaction_session:
                for placeholder_data in placeholders:
                    placeholder_id = placeholder_data["id"]
                    # Update the object in the database
                    obj = transaction_session.query(Placeholders).filter(Placeholders.id == placeholder_id).update(
                        {
                            Placeholders.is_deleted: True,
                            Placeholders.modified_by: user_info["Username"]
                        },
                        synchronize_session=False
                    )
                transaction_session.commit()
            logger.info(f"deleted placeholder records.")
            if obj:
                return True
            else:
                raise BadRequestResult("Error while deleting placeholder!")
        except Exception as e:
            logger.error(f"error in placeholder crud : {e}")
            logger.error(e)
            return get_err_json_response(
                "Error while deleteing to placeholder table",
                e.args,
                501,
            )