from db.orm_models.v2.documents_share_map import DocumentsShareMap
from db.session import acquire_db_session as session
from utils.logs.logger_config import logger


class CRUDDocumentShareMap:
    def create(self, **request) -> dict:
        """CRUD function to create a new Document share map

        Raises:
            e: Error returned from the DB layer

        Returns:
            dict: created record
        """
        try:
            logger.info("Inside CRUD Document - create !")
            obj = DocumentsShareMap(**request)
            with session() as transaction_session:
                transaction_session.add(obj)
                transaction_session.commit()
                transaction_session.refresh(obj)
            logger.info("Created a new Document record")
            return obj.__dict__
        except Exception as e:
            logger.error("Error while adding to documents share map table")
            raise e

    def duplicate_check(
        self, document_id: str, shared_with_type: str, shared_with_id: str
    ) -> str:
        """CRUD function to check for duplicate entry

        Args:
            document_id (str): document id.
            shared_with_type (str): type of the entity document is shared with
            shared_with_id (str): id of the entity document is shared with

        Raises:
            e: Error returned from the DB layer

        Returns:
            str: id of the record if it exists
        """
        try:
            logger.info("executing duplicated-check crud ...")
            with session() as transaction_session:
                obj: DocumentsShareMap = (
                    transaction_session.query(DocumentsShareMap)
                    .filter(
                        DocumentsShareMap.document_id == document_id,
                        DocumentsShareMap.shared_with_type == shared_with_type,
                        DocumentsShareMap.shared_with_id == shared_with_id,
                        DocumentsShareMap.is_deleted == False,
                    )
                    .first()
                )
                transaction_session.commit()

            if obj is not None:
                return obj.__dict__
            else:
                return None

        except Exception as e:
            logger.error("Error while reading records from documents_share table")
            raise e

    def read_all(self) -> list:
        """CRUD function to read_all documents_share records

        Raises:
            e: Error returned from the DB layer

        Returns:
            list: all documents_share records
        """
        try:
            logger.info("executing read-all-documents_share crud ...")
            with session() as transaction_session:
                obj: DocumentsShareMap = transaction_session.query(
                    DocumentsShareMap
                ).all()

            if len(obj) != 0:
                return [row.__dict__ for row in obj]
            else:
                return []

        except Exception as e:
            logger.error("Error while reading records from documents_share table")
            raise e

    def read_by_shared_with_type(
        self, document_id: str, shared_with_type: str = None
    ) -> list:
        """CRUD function to read documents_share records

        Args:
            document_id (str): document id.
            shared_with_type (str, optional): type of the shared entity. Defaults to None.

        Raises:
            e: Error returned from the DB layer.

        Returns:
            list: all the records matching the criteria.
        """
        try:
            logger.info("executing read-documents_share crud ...")
            with session() as transaction_session:
                # Build the query
                query = transaction_session.query(DocumentsShareMap).filter(
                    DocumentsShareMap.document_id == document_id,
                    DocumentsShareMap.is_deleted == False
                )

                if shared_with_type is not None:
                    query = query.filter(DocumentsShareMap.shared_with_type == shared_with_type)

                # Execute the query
                docs = query.all()
                if docs == []:
                    logger.info(
                        "There are no documents in table with matching criteria"
                    )
                    return []
                else:
                    return [doc.__dict__ for doc in docs]

        except Exception as e:
            logger.error("Error while reading records from documents_share table")
            raise e

    def update_delete_status(
        self,
        user_info: dict,
        document_id: str,
        shared_with_type: str = None,
        shared_with_id: str = None,
    ) -> int:
        """CRUD function to delete a record by id

        Args:
            user_info (dict): information about the user.
            document_id (str): document id.
            shared_with_type (str, optional): type of the shared entity. Defaults to None.
            shared_with_id (str, optional): id of the shared entity. Defaults to None.

        Raises:
            e: Error returned from the DB layer.

        Returns:
            int: no. of mappings deleted
        """
        try:
            logger.info("executing delete-promptShareMap crud ...")
            with session() as transaction_session:
                obj: DocumentsShareMap = transaction_session.query(
                    DocumentsShareMap
                ).filter(
                    DocumentsShareMap.document_id == document_id,
                    DocumentsShareMap.is_deleted == False,
                )

                if shared_with_type is not None:
                    obj = obj.filter(
                        DocumentsShareMap.shared_with_type == shared_with_type
                    )

                if shared_with_id is not None:
                    obj = obj.filter(DocumentsShareMap.shared_with_id == shared_with_id)

                obj = obj.update(
                    dict(is_deleted=True, modified_by=user_info["Username"]),
                    synchronize_session=False,
                )

                transaction_session.commit()

            if obj is not None:
                return obj
            else:
                return 0

        except Exception as e:
            logger.error("Error while deleting record in PromptShareMap table...")
            raise e
