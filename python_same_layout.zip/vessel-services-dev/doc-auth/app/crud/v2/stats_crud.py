
from crud.v2.document_crud import CRUDDocument
from db.orm_models.v2.documents import Documents
from db.session import acquire_db_session as session
from utils.logs.logger_config import logger
from sqlalchemy import func, distinct



class CRUDStats:
    def __init__(self) -> None:
        self.CRUDDocument = CRUDDocument()
        
    def get_stats(self, user_info):
        try:
            logger.info("Inside CRUD stats - get stats !")
            with session() as transaction_session:
                query= (transaction_session.query(func.count(distinct(Documents.id)))
                                                 .filter(self.CRUDDocument.get_user_access_check_query(user_info) , Documents.is_deleted == False, Documents.parent_id == None))
                private_count = query.filter(Documents.is_private == True).scalar()
                shared_count = query.filter(Documents.is_private == False).scalar()
                return {
                    "private_documents_count": private_count,
                    "shared_documents_count": shared_count
                }
        except Exception as e:
            raise e