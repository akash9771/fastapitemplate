from db.session import acquire_db_session as session
from db.orm_models.v2.documents_audit_log import DocumentsAuditLog
from config.errors import get_err_json_response
from utils.logs.logger_config import logger
from sqlalchemy import desc


class CRUDDocumentsAuditLog:
    def create(self, doc_id, action, detail, created_by):
        """[CRUD function to create a new document audit log]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("creating audit log object ....")
            audit_log_obj = {
                "document_id" : doc_id,
                "action" : action,
                "detail" : detail if detail else "",
                "created_by" : created_by
            }
            logger.info("executing create-Documents Audit crud ...")
            obj = DocumentsAuditLog(**audit_log_obj)
            with session() as transaction_session:
                transaction_session.add(obj)
                transaction_session.commit()
                transaction_session.refresh(obj)
            return obj.__dict__

        except Exception as e:
            logger.error("Error while adding to Documents Audit Log table ")
            raise e

    def read_all(self):
        """[CRUD function to read_all document audit logs]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all document audit logs]
        """
        try:
            logger.info("executing read-all-Documents Audit crud ...")
            with session() as transaction_session:
                obj: DocumentsAuditLog = transaction_session.query(DocumentsAuditLog).all()
            if obj is not None:
                return [row.__dict__ for row in obj]
            else:
                return []

        except Exception as e:
            logger.error("Error while getting data from Documents Audit Log table ")
            raise e


    def get_by_id(self, id: int):
        """[CRUD function to read a Documents Audit log]

        Args:
            Documentsaudit_id (str): [Documents Audit id to filter the log]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [Documents Audit log matching the criteria]
        """
        try:
            logger.info("executing get-Documents Audit-by-id crud ...")
            with session() as transaction_session:
                obj: DocumentsAuditLog = (
                    transaction_session.query(DocumentsAuditLog)
                    .filter(DocumentsAuditLog.id == id)
                    .first()
                )
            if obj is not None:
                return obj.__dict__
            else:
                return None

        except Exception as e:
            logger.error("Error while filtering Documents Audit Log table  by id")
            raise e


    def read_by_document_id(self, 
                            document_id,
                            action,
                            page_limit,
                            page_number):
        """[CRUD function to read a audit log record]

        Args:
            document id (str): [document id to filter the log]
            action (str, optional): type of document audit log to fetch. Defaults to None.
            page_limit (int, optional): max number of documents to return. Defaults to None.
            page_offset (int, optional): number of documents to skip from start. Defaults to None.

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [document audit log matching the criteria]
        """
        try:
            logger.info("executing read-by-document-id crud ...")
            with session() as transaction_session:
                query = (transaction_session.query(DocumentsAuditLog).filter(DocumentsAuditLog.document_id == document_id))
                
                if action is not None:
                    query = query.filter(DocumentsAuditLog.action == action)

                query = (query.order_by(desc(DocumentsAuditLog.created_at)))
                total_count = query.count()

                # pagination section
                if page_limit > -1:
                    start_index = (page_number - 1) * page_limit
                    end_index = start_index + page_limit
                    query = query.offset(start_index).limit(page_limit)

                # Execute the query 
                return {
                    "audit_logs": query.all(),
                    "page_number": page_number,
                    "page_limit": page_limit,
                    "total_count": total_count,
                }
                                            
        except Exception as e:
            logger.error("Error while reading logs by doc id from document audit log table")
            raise e