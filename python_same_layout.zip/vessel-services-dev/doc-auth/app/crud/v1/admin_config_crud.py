from db.session import acquire_db_session as session
from db.orm_models.v1.admin_config_model import AdminConfig
from utils.logs.logger_config import logger
from config.errors import get_err_json_response
from crud.v1.domain_crud import CRUDDomain
from crud.v1.subdomain_crud import CRUDSubDomain


class CRUDAdminConfig:
    def __init__(self):
        self.CRUDDomain = CRUDDomain()
        self.CRUDSubDomain = CRUDSubDomain()        

    def create(self, **kwargs):
        """[CRUD function to create a new admin_config record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("Inside CRUD Admin - create !")
            admin_config = AdminConfig(**kwargs)
            with session() as transaction_session:
                transaction_session.add(admin_config)
                transaction_session.commit()
                transaction_session.refresh(admin_config)
            return admin_config.__dict__
        except Exception as e:
            logger.error(e)
            return get_err_json_response(
                "Error while adding to admin config table",
                e.args,
                501,
            )

    def read_all(self, domain = None, subdomain = None):
        """[CRUD function to read_all admin_configs record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [list]: [all admin_config records]
        """
        try:
            logger.info("Inside CRUD Admin - read !")
            with session() as transaction_session:
                admin_config_obj: AdminConfig = transaction_session.query(AdminConfig).all()
                admin_config_data = []
                for admin_config in admin_config_obj:
                    admin_config_dict = admin_config.__dict__
                    admin_config_dict["domain_name"] = self.CRUDDomain.get_by_id(admin_config.domain_id)["name"]
                    subdomain_data = self.CRUDSubDomain.get_by_id(admin_config.domain_id, admin_config.sub_domain_id)
                    if subdomain_data:
                        admin_config_dict["subdomain_name"] = subdomain_data["name"]
                    else:
                        admin_config_dict["subdomain_name"] = None
                    if domain and subdomain:
                        if admin_config_dict["domain_name"] != domain or admin_config_dict["subdomain_name"] != subdomain:
                            continue
                    admin_config_data.append(admin_config_dict)
            return admin_config_data
        except Exception as e:
            logger.error(e)
            return get_err_json_response(
                "Error while reading from admin config table",
                e.args,
                501,
            )

    def get_by_id(self, **kwargs):
        """[CRUD function to read a admin_config record by display]

        Args:
            admin_config_name (str): [admin_config name to filter the record]

        Raises:
            error: [Error returned from the DB layer]

        Returns:
            [dict]: [admin_config record matching the criteria]
        """
        try:
            logger.info("Inside CRUD Admin - get by id !")
            with session() as transaction_session:
                obj: AdminConfig = (
                    transaction_session.query(AdminConfig)
                    .filter(AdminConfig.id == kwargs.get("id"))
                    .first()
                )
                if obj is not None:
                    return obj.__dict__
                else:
                    return None
        except Exception as e:
            logger.error(e)
            return get_err_json_response(
                "Error while getting data from admin config table",
                e.args,
                501,
            )

    def update(self, admin_config_id, request):
        """[CRUD function to update a AdminConfig record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("Inside CRUD Admin - update !")
            with session() as transaction_session:
                obj: AdminConfig = (
                    transaction_session.query(AdminConfig)
                    .filter(AdminConfig.id == admin_config_id)
                    .update(request, synchronize_session=False)
                )
                transaction_session.commit()
            return {"message": "AdminConfig table updated"}
        except Exception as e:
            logger.error(e)
            return get_err_json_response(
                "Error while updating to AdminConfig table",
                e.args,
                501,
            )

    def delete(self, id: int):
        """[CRUD function to delete a admin_config record]

        Raises:
            error: [Error returned from the DB layer]
        """
        try:
            logger.info("Inside CRUD Admin - delete !")
            with session() as transaction_session:
                obj: AdminConfig = (
                    transaction_session.query(AdminConfig)
                    .filter(AdminConfig.id == id)
                    .first()
                )
                transaction_session.delete(obj)
                transaction_session.commit()
                return {"Message": "Config deleted successfully!"}
        except Exception as e:
            logger.error(e)
            return get_err_json_response(
                "Error while deleting from admin config table",
                e.args,
                501,
            )
