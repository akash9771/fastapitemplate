import boto3
import json
import logging
import os
import redis
import httpx
from dotenv import load_dotenv
from redis.cluster import RedisCluster
from redis.exceptions import RedisClusterException

load_dotenv()

http_client = httpx.Client(timeout=360)

ALL_BEDROCK_REGIONS = os.getenv(
    "ALL_BEDROCK_REGIONS"
)  # us-east-1, eu-central-1, us-west-2
REDIS_HOST_PORT = os.getenv("REDIS_HOST_PORT")
REDIS_PASSWORD = os.getenv("REDIS_PASSWORD")
SERVICE_ATTRIBUTES = os.getenv("SERVICE_ATTRIBUTES")  # bedrock_regions, openai_regions
CONTRACT_TABLE = os.getenv("CONTRACT_TABLE")
ENV = os.getenv("ENV", "dev")

# FOR AZURE OPENAI
AZURE_TENANT_ID = os.getenv("AZURE_TENANT_ID")
AZURE_CLIENT_ID = os.getenv("AZURE_CLIENT_ID")
AZURE_CLIENT_SECRET = os.getenv("AZURE_CLIENT_SECRET")
AZURE_OPENAI_SUBSCRIPTIONS = os.getenv("AZURE_OPENAI_SUBSCRIPTIONS")

logger = logging.getLogger()
logger.setLevel(logging.INFO)


class RedisClient:
    def __init__(
        self,
        host_port=REDIS_HOST_PORT,
        password=REDIS_PASSWORD,
        encoding="utf8",
        decode_responses=True,
    ):
        self.host_port = host_port
        self.password = password
        self.encoding = encoding
        self.decode_responses = decode_responses
        self.redis = None

    def connect(self):
        try:
            self.redis = RedisCluster.from_url(
                f"{self.host_port}",
                password=self.password,
                encoding=self.encoding,
                decode_responses=self.decode_responses,
            )
            pong = self.redis.ping()
            logger.info(f"Connected to Redis: {pong}")
        except RedisClusterException as e:
            logger.error(
                "Cluster mode is not enabled on this redis - trying standard mode"
            )
            self.redis = redis.from_url(
                f"{self.host_port}",
                password=self.password,
                encoding=self.encoding,
                decode_responses=self.decode_responses,
            )
            pong = self.redis.ping()
            logger.info(f"Connected to Redis: {pong}")
        except Exception as e:
            logger.error(f"Failed connecting to Redis: {str(e)}")
            raise

    def close(self):
        if self.redis:
            self.redis.close()
            self.redis = None


def get_contracts_from_dynamo_db() -> list:
    try:
        dynamodb = boto3.resource("dynamodb")
        table = dynamodb.Table(CONTRACT_TABLE)

        # split SERVICE_ATTRIBUTES into a list and strip whitespace
        service_attributes = [
            attribute.strip() for attribute in SERVICE_ATTRIBUTES.split(",")
        ]

        # concatenate attributes from SERVICE_ATTRIBUTES to structure the ProjectionExpression
        projection_expression = ",".join(service_attributes)

        # structure FilterExpression to get contracts that have either of the attributes in SERVICE_ATTRIBUTES
        filter_expression = " OR ".join(
            [f"attribute_exists({attribute})" for attribute in service_attributes]
        )
        # Scan the table to get all contracts
        response = table.scan(
            ProjectionExpression=f"client_id, {projection_expression}",
            FilterExpression=filter_expression,
        )
        contracts = response["Items"]

        # If there are more contracts then paginate through the table
        while response.get("LastEvaluatedKey"):
            response = table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
            contracts.extend(response["Items"])

        # Convert string of regions to list and strip whitespace
        for contract in contracts:
            for service in service_attributes:
                if service in contract:
                    contract[service] = [
                        region.strip() for region in contract[service].split(",")
                    ]

        # Combine contracts with same client_id into one contract with all necessary attributes
        contracts = sorted(contracts, key=lambda k: k["client_id"])
        merged_contracts = []
        current_contract = None

        for contract in contracts:
            if (
                not current_contract
                or contract["client_id"] != current_contract["client_id"]
            ):
                current_contract = contract
                merged_contracts.append(current_contract)
            else:
                current_contract.update(contract)
        logger.info(f"Structured {len(merged_contracts)} contracts")
        logger.info(f"Contracts: {merged_contracts}")
        return merged_contracts
    except Exception as e:
        logger.error(f"Exception in get_contracts_from_dynamo_db  {str(e)}")
        return []


def get_provisioned_models_from_bedrock(region: str = "us-east-1") -> list:
    try:
        models = []
        bedrock = boto3.client(service_name="bedrock", region_name=region)
        response = bedrock.list_provisioned_model_throughputs()
        provisioned_models = response.get("provisionedModelSummaries")
        for model in provisioned_models:
            models.append(model.get("provisionedModelName"))
        logger.info(
            f"Got {len(models)} provisioned models from bedrock in region {region}"
        )
        logger.info(f"Provisioned models: {models}")
        return models
    except Exception as e:
        logger.error(
            f"ERROR: Could not get provisioned models from bedrock in region {region}. Error: {e}"
        )
        return []


def get_models(region: str = "us-east-1") -> list:
    try:
        bedrock = boto3.client(service_name="bedrock", region_name=region)
        response = bedrock.list_foundation_models(byInferenceType="ON_DEMAND")
        model_summaries = response.get("modelSummaries")
        models = [model.get("modelId") for model in model_summaries]
        logger.info(f"Got {len(models)} models from bedrock in region {region}")
        logger.info(f"Models: {models}")
        return models
    except Exception as e:
        logger.error(
            f"ERROR: Could not get models from bedrock in region {region}. Error: {e}"
        )
        return []


def get_all_models() -> tuple:
    region_provisioned_models = {}
    region_models = {}

    # split ALL_BEDROCK_REGIONS into a list and strip whitespace
    all_bedrock_regions = [region.strip() for region in ALL_BEDROCK_REGIONS.split(",")]

    for region in all_bedrock_regions:
        logger.info(f"calling region {region}")
        # Step 2a: Get all provisioned models from bedrock
        provisioned_models = get_provisioned_models_from_bedrock(region)
        region_provisioned_models[region] = provisioned_models
        # Step 2b: Get all models from bedrock
        models = get_models(region)
        region_models[region] = models
        # print(models)
    return region_provisioned_models, region_models


def structure_bedrock_contract_cache(
    contracts: list, region_provisioned_models: dict, region_models: dict
) -> dict:
    contract_cache = {"default": {}}
    contract_cache["default"]["bedrock"] = {}
    contract_cache["default"]["bedrock"]["provisioned"] = {}
    contract_cache["default"]["bedrock"]["models"] = {}
    # Default configuration for all clients
    for region in region_provisioned_models:
        available_models = region_provisioned_models[region]
        for model in available_models:
            if model not in contract_cache["default"]["bedrock"]["provisioned"]:
                contract_cache["default"]["bedrock"]["provisioned"][model] = [region]
    for region in region_models:
        available_models = region_models[region]
        for model in available_models:
            if model not in contract_cache["default"]["bedrock"]["models"]:
                contract_cache["default"]["bedrock"]["models"][model] = [region]
            else:
                contract_cache["default"]["bedrock"]["models"][model].append(region)
    for contract in contracts:
        contract["bedrock"] = {"provisioned": {}, "models": {}}
        for region in region_provisioned_models:
            # get provisioned models for each region
            available_models = region_provisioned_models[region]
            for model in available_models:
                # if there is a provisioned model then add it to the client for use to prioritize it
                if model not in contract["bedrock"]["provisioned"]:
                    contract["bedrock"]["provisioned"][model] = [region]
        for region in region_models:
            # get all models for each region
            available_models = region_models[region]
            if region in contract["bedrock_regions"]:
                for model in available_models:
                    # if there is a model then add it to the client for use to prioritize it
                    if model not in contract["bedrock"]["models"]:
                        contract["bedrock"]["models"][model] = [region]
                    else:
                        contract["bedrock"]["models"][model].append(region)
        contract_cache[contract["client_id"]] = {}
        contract_cache[contract["client_id"]]["bedrock"] = contract["bedrock"]
    return contract_cache


def azure_authenticate(credentials):
    auth_endpoint = (
        f"https://login.microsoftonline.com/{credentials['tenant_id']}/oauth2/token"
    )
    auth_data = {
        "grant_type": "client_credentials",
        "client_id": credentials["client_id"],
        "client_secret": credentials["client_secret"],
        "resource": credentials["resource"],
    }
    auth_response = http_client.post(auth_endpoint, data=auth_data)
    return auth_response.json()["access_token"]


def list_azure_cognitive_services_accounts(subscription_id, access_token):
    accounts_endpoint = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.CognitiveServices/accounts?api-version=2021-10-01"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }
    accounts_response = http_client.get(accounts_endpoint, headers=headers)
    return accounts_response.json()["value"]


def get_azure_openai_account_keys(
    subscription_id, resource_group_name, resource_name, access_token
):
    keys_endpoint = f"https://management.azure.com/subscriptions/{subscription_id}/resourceGroups/{resource_group_name}/providers/Microsoft.CognitiveServices/accounts/{resource_name}/listKeys?api-version=2021-10-01"
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json",
    }
    keys_response = http_client.post(keys_endpoint, headers=headers)
    return keys_response.json()


def list_openai_models(resource_name, openai_api_key):
    openai_models_endpoint = (
        f"https://{resource_name}.openai.azure.com/openai/models?api-version=2022-12-01"
    )
    openai_headers = {"api-key": openai_api_key}
    models_response = http_client.get(openai_models_endpoint, headers=openai_headers)
    return models_response.json()["data"]


def list_openai_deployments(resource_endpoint, openai_api_key):
    try:
        logger.info(f"\n GET list of deployments: {resource_endpoint}")
        openai_deployments_endpoint = (
            f"{resource_endpoint}openai/deployments?api-version=2022-12-01"
        )
        logger.info(f"{openai_deployments_endpoint}")
        openai_headers = {"api-key": openai_api_key}
        deployments_response = http_client.get(
            openai_deployments_endpoint, headers=openai_headers
        )
        return deployments_response.json()["data"]
    except Exception as e:
        logger.error(f"error in function list_openai_deployments::::: {str(e)}")
        return []


def get_azure_openai_deployments_models(credentials, subscription_id):
    access_token = azure_authenticate(credentials)
    result = []
    for sub_id in subscription_id:
        logger.info(f"::::::::::::::::::::: SUBSCRIPTION: {sub_id}")
        accounts = list_azure_cognitive_services_accounts(sub_id, access_token)

        for account in accounts:
            if account["kind"] == "OpenAI":
                resource_group_name = account["id"].split("/")[4]
                resource_name = account["name"]
                resource_location = account["location"]
                resource_properties = account["properties"]
                resource_endpoint = resource_properties["endpoint"]
                print(resource_endpoint)
                logger.info(
                    f"resource_name: {resource_name}, resource_location: {resource_location}, resource_endpoint: {resource_endpoint}"
                )

                keys = get_azure_openai_account_keys(
                    sub_id, resource_group_name, resource_name, access_token
                )
                # print(keys)

                openai_api_key = keys["key2"]
                # models = list_openai_models(resource_name, openai_api_key)
                deployments = list_openai_deployments(resource_endpoint, openai_api_key)

                for deployment in deployments:
                    logger.info(f"{resource_name} deployment_id: {deployment['id']}")
                    deployment_name = deployment["id"]
                    model_id = deployment["model"]
                    status = deployment["status"]
                    # model_id = models.get(model_id, {})
                    # deprecation_info = models.get("deprecation", {})
                    # lifecycle_status = models.get("lifecycle_status", None)
                    # capabilities = models.get("capabilities", {})

                    result.append(
                        {
                            # "resource_name": resource_name,
                            "resource_endpoint": resource_endpoint,
                            "resource_location": resource_location,
                            "deployment_name": deployment_name,
                            "model_id": model_id,
                            "api-keys": keys,
                            # "deprecation_date": deprecation_info,
                            # "lifecycle_status": lifecycle_status,
                            # "capabilities": capabilities,
                            "deployment_status": status,
                        }
                    )

    return result


def structure_openai_contract_cache(deployment_data):
    contract_cache = {"default": {}}
    contract_cache["default"]["openai"] = {}
    deployment_with_regions = {}

    for deployment in deployment_data:
        deployment_name = deployment["deployment_name"]
        resource_endpoint = deployment["resource_endpoint"]
        api_keys = deployment["api-keys"]
        deployment_with_regions.setdefault(deployment_name, []).append(
            {"resource_endpoint": resource_endpoint, "api-keys": api_keys}
        )
    contract_cache["default"]["openai"] = deployment_with_regions
    return contract_cache


def lambda_handler(event, context):
    try:
        # Step 1: Get all contracts from DynamoDB
        contracts = get_contracts_from_dynamo_db()
        print(f"{len(contracts)} contracts found in DynamoDB")
    except Exception as e:
        logger.error(
            f"Exception in failover-lb - faile to fetch info from dynamodb: {str(e)}"
        )
        return {
            "status": "error",
            "data": e,
            "message": e.orig.args if hasattr(e, "orig") else f"{e}",
        }

    try:
        # Step 2: Get all provisioned and foundation models from bedrock
        region_provisioned_models, region_models = get_all_models()

        # Step 3: Structure the contracts cache with bedrock models data
        contracts = structure_bedrock_contract_cache(
            contracts, region_provisioned_models, region_models
        )
        print(f"Contracts: {contracts}")
        # Step 4: Connect to Redis
        redis_client = RedisClient()
        redis_client.connect()

        # Step 5: Set the contracts cache in Redis
        for client_id, config in contracts.items():
            cache_key = f"{ENV}-vsl-failover-lb:{client_id}"
            print(f"cache_key: {cache_key} | config: {str(config)}")
            redis_client.redis.set(cache_key, json.dumps(config))

    except Exception as e:
        logger.error(f"Exception in failover-lb caching lambda: {str(e)}")
        return {
            "status": "error",
            "data": e,
            "message": e.orig.args if hasattr(e, "orig") else f"{e}",
        }

    ###########################
    # RUN FOR AZURE OPENAI!!! #
    ###########################
    try:
        print(
            "---------------------------++++++++++++++ OPENAI +++++++++++++---------------------------"
        )
        credentials = {
            "tenant_id": AZURE_TENANT_ID,
            "client_id": AZURE_CLIENT_ID,
            "client_secret": AZURE_CLIENT_SECRET,
            "resource": "https://management.azure.com/",
        }
        subscription_id = AZURE_OPENAI_SUBSCRIPTIONS
        subscription_id = subscription_id.split(",")
        subscription_id = [sub_id.strip() for sub_id in subscription_id]
        print(subscription_id)

        deployment_data = get_azure_openai_deployments_models(
            credentials, subscription_id
        )
        # # Step 3: Structure the contracts cache with OpenAIs deployment data
        contracts = structure_openai_contract_cache(deployment_data)
        # print(contracts)
        # print(f"Contracts: {contracts}")

        # Step 4: Connect to Redis
        redis_client = RedisClient()
        redis_client.connect()

        # Step 5: Set the contracts cache in Redis
        # for client_id, config in contracts.items():
        cache_key = f"{ENV}-vsl-failover-lb:openai:default"
        # print(f"cache_key: {cache_key} | config: {str(contracts)}")
        redis_client.redis.set(cache_key, json.dumps(contracts))

    except Exception as e:
        logger.error(f"Exception in failover-lb caching lambda: {str(e)}")
        return {
            "status": "error",
            "data": e,
            "message": e.orig.args if hasattr(e, "orig") else f"{e}",
        }
