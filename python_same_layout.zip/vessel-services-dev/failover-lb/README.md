lambda function that runs periodically to fetch contracts from DynamoDB, get available models and cache for use from GenAI microservices

For local run

```
pip install -r requirements-dev.txt
```
Also have a empty event.json file
```
python-lambda-local .\app.py event.json -f lambda_handler -t 100
```
