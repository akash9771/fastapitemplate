# Vessel AE API

## Prerequisites
* git
* Python3
* JSL license env vars
  * AWS_ACCESS_KEY_ID
  * AWS_SECRET_ACCESS_KEY
  * JSL_VERSION
  * PUBLIC_VERSION
  * SECRET
  * SPARK_NLP_LICENSE
* JSL spark-nlp-jsl python package
    ```shell script
    pip install --upgrade -q spark-nlp-jsl==$JSL_VERSION  --extra-index-url https://pypi.johnsnowlabs.com/$SECRET
    ```

## Getting Started
See prerequisites. To run this code locally, clone the repository and execute the following:

```shell script
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## API Documentation
When running this code locally, navigate to http://localhost:8000/docs

## Testing
To run the unit tests and get a code coverage report, follow these steps:

```shell script
pip install -r requirements.txt
pip install -r requirements_test.txt
nosetests -c tests/nose.cfg
```

To view the coverage report, open htmlcov/index.html in any browser.
