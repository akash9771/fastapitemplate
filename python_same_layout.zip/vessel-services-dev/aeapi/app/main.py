from fastapi import FastAPI

from app.adverse_event.v1.api import router as ae_v1
from app.adverse_event.v1.pipeline import Pipeline

from contextlib import asynccontextmanager
PREFIX_V1 = "/aeapi"
TAGS_METADATA = [
    {
        "name": "Detect Adverse Events",
        "description": """Detects adverse events in an array of text entries. 
            If 'detailed' is set to true in the request, probability of
            returned entities are returned.""",
    },
]

app = FastAPI(
    title="Vessel AE Services",
    openapi_tags=TAGS_METADATA,
    swagger_ui_parameters={"defaultModelsExpandDepth": -1},
)




@asynccontextmanager
async def lifespan(app: FastAPI):
    # Initialize pipeline at startup
    print("loading pipeline")
    Pipeline()
    print("loaded pipeline")
    yield

app.include_router(ae_v1, prefix=PREFIX_V1)