import logging
from typing import List


from fastapi import Request as Request1

from fastapi import APIRouter, HTTPException

from app.adverse_event.v1.config import settings
from app.adverse_event.v1.models import (
    AdverseEvent,
    Entity,
    EntityType,
    Relationship,
    Request,
    Response,
    Result,
    Status,
    HealthCheckResponse
)
from app.adverse_event.v1.pipeline import Pipeline

from validator.decorators import async_token_validation_and_metering


router = APIRouter()
logger = logging.getLogger()
logger.setLevel(settings.log_level)



@router.get(
    "/health_check",
    status_code=200,
    tags=["Adverse Events"],
)
async def health_check():
    return HealthCheckResponse(
            status=Status.success,
            message="health_check completed successfully"
        )



@router.post(
    "/detect_adverse_events",
    status_code=200,
    tags=["Adverse Events"],
)
@async_token_validation_and_metering(uom=2)
async def detect_adverse_events(request: Request1,req: Request):
    try:
        print("entering inside function")
        print(req)
        results: List[Result] = []

        for text in req.text:
            #prepare spacy doc objects of text
            ner_doc = Pipeline().ner_method(text) #named entitiy recognition method
            sc_doc = Pipeline().sc_method(text) #span categorizer method

            #pull entities/spans from doc objects
            ner_ents = ner_doc.ents #entities are identified in ents
            sc_spans = sc_doc.spans["sc"] #spans are identified in spans under "sc"
            sc_scores = sc_doc.spans["sc"].attrs["scores"] #span scores for condfidence


            ae_found = False
            ae_confidence = 0
            details = []

            if len(ner_ents) or len(sc_spans) != 0: #
                ae_found = True

                #detect AE's with NER method
                for ent in ner_ents:
                    if ae_confidence == 0: #check if event has been found yet
                        ae_confidence = 0.91 #recall rate for NER method as NER does not produce scores
                    else:
                        pass

                    entity = Entity(type = EntityType.adverse_event,
                                    text = ent.text)
                    
                    #add entity details if required
                    if req.detailed: 
                        details.append(
                            Relationship(
                                related = True,
                                confidence = 0.91, #hard coded to result from NER recall metric
                                entity_1 = entity
                            )
                        )
                    else:
                        pass
                
                #detect AE's with spancat model
                for span, score in zip(sc_spans, sc_scores):
                    #check score to return highest probability 
                    if ae_confidence == 0:
                        ae_confidence = score
                    elif score > ae_confidence:
                        ae_confidence = score
                    else:
                        pass
                    
                    entity = Entity(type = EntityType.adverse_event,
                                    text = span.text)
                    
                    #store entity details if required
                    if req.detailed: 
                        details.append(
                            Relationship(
                                related = True,
                                confidence = score, #confidence from spancat model
                                entity_1 = entity
                            )
                        )
                    else:
                        pass

                    
            #prepare json payload depending on detailed flag
            if req.detailed:
                results.append(
                    Result(
                        adverse_event = AdverseEvent(
                            found = ae_found,
                            confidence = ae_confidence
                        ),
                        details = details,
                        text = text
                    )

                )
            else:
                results.append(
                    Result(
                        adverse_event = AdverseEvent(
                            found = ae_found,
                            confidence = ae_confidence
                        ),
                        text = text
                    )
                )

        return Response(
            status=Status.success,
            message="Adverse event detection completed successfully",
            results=results,
        )

    except Exception as e:
        print(str(e))
        raise HTTPException(status_code=400, detail=f"Error: {str(e)}")