import spacy
import boto3
import zipfile

from pathlib import Path

#try clearing env variables and force use of IAM execution role
import os
for env_var in ["AWS_ACCESS_KEY_ID", "AWS_SECRET_ACCESS_KEY", "AWS_SESSION_TOKEN"]:
    try:
        os.environ.pop(env_var)
    except Exception as e:
            print(f"Error clearing AWS_Secret_Key {e}")


class Pipeline(object):
    """Singleton that initializes the Pipeline only once"""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Pipeline, cls).__new__(cls)

            
            #download model resources
            print("loading models from S3")
            s3 = boto3.client('s3')

            #list objects for error troubleshooting
            objects = s3.list_objects(Bucket='dev-vsl-aedetects-models')
            for obj in objects['Contents']:
                print(obj['Key'])


            s3.download_file("dev-vsl-aedetects-models", "ner_model.zip", "ner_model.zip")
            with zipfile.ZipFile("ner_model.zip", 'r') as zip_ref:
                zip_ref.extractall("./ner_model")
            print("Successfully downloaded ner_model from S3")

            s3.download_file("dev-vsl-aedetects-models", "sc_model.zip", "sc_model.zip")
            with zipfile.ZipFile("sc_model.zip", 'r') as zip_ref:
                zip_ref.extractall("./sc_model")
            print("Successfully downloaded ner_model from S3")

            #load model resources

            cls.sc_method = spacy.load("./sc_model/model-best") #Spancat method for identifying AEs NEED TO SWAP FOR 
            cls.ner_method = spacy.load("./ner_model/model-best") #ner method for identifying AEs
            print('successfully loaded models into pipeline')

            

        return cls._instance
