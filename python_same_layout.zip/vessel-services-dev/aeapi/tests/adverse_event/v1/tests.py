import json
from unittest import mock

from fastapi.testclient import TestClient

from app.main import app
from app.adverse_event.v1.models import Status


client = TestClient(app)
ROUTE = "/ias/v1/detect_adverse_events"


class TestAnnotate:
    def fullAnnotate(self, _text: str):
        return [{"class": [TestResult()], "jsl_ner_chunk": []}]


class ADEAnnotate:
    def fullAnnotate(self, _text: str):
        return [{"class": [TestResult()], "ner_chunk": []}]


class TestPipeline:
    def __init__(self):
        self.jsl_light_model = TestAnnotate()
        self.ade_ner_clf_pipeline = ADEAnnotate()


class TestResult:
    def __init__(self):
        self.result = True
        self.metadata = {"True": "0.9", "False": "0.1"}


def test_root():
    """Nothing should exist at the root"""
    response = client.get("/")
    assert response.status_code == 404
    assert response.json() == {"detail": "Not Found"}


def test_docs():
    """Documentation endpoint should return successfully"""
    response = client.get("/docs")
    assert response.status_code == 200


def test_missing_payload():
    """Requests missing a payload should be rejected"""
    response = client.post(ROUTE)
    assert response.status_code == 422


def test_missing_params():
    """Requests missing required parameters should be rejected"""
    response = client.post(ROUTE, data=json.dumps({"detailed": False}))
    assert response.status_code == 422
    assert response.json() == {
        "detail": [
            {
                "loc": ["body", "text"],
                "msg": "field required",
                "type": "value_error.missing",
            }
        ]
    }


@mock.patch(
    "app.adverse_event.v1.pipeline.Pipeline.__new__", return_value=TestPipeline()
)
def test_valid_request(_mock_pipeline):
    """Valid requests should return a 200 response"""
    response = client.post(
        ROUTE,
        data=json.dumps({"detailed": True, "text": ["The drug gave me a headache"]}),
    )
    assert response.status_code == 200
    assert response.json()["status"] == Status.success
