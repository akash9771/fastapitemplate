import pytest
import unittest
# from app.adverse_event.v1.api import *
from fastapi.testclient import TestClient
from app.main import app
import fastapi
import httpx
from fastapi import APIRouter, HTTPException
from unittest.mock import patch
from unittest import mock
import asyncio
import logging
from httpx import AsyncClient
from app.adverse_event.v1.models import (
    Response,
    Request,
    Status,
)

# class TestHealtCheck(unittest.TestCase):
loop = asyncio.get_event_loop()

logging.error(loop)

client = TestClient(app)
ROUTE = "/ias/v1/detect_adverse_events"



class Testing(unittest.IsolatedAsyncioTestCase):
    pass

    # test for health check

    def test_health_check(self):
        # client = TestClient(app)

        res = client.get('aeapi/health_check')

        data = res.json()

    def test_missing_payload(self):
        """Requests missing a payload should be rejected"""
        json = {}
        response = client.post("/aeapi/detect_adverse_events", json=json)

        # logging.info("Response from  Missing_payload function", response)

        assert response.status_code == 422
    
    @patch(
        "app.adverse_event.v1.api.httpx.AsyncClient.post",
        return_value=httpx.Response(
            200,
            json={
                "adverse_event": {
                    "found": False,
                    "confidence": 1.0
                },
                "details": None,
                "text": "test ae for prod v2 service 3"
            },
        ),
    )
    @mock.patch('utils.libzip.validator.decorators.async_token_validation_and_metering')    
    async def test_adverse_events(self, mock_valid ,mock_meter):
        mock_meter = Response(status="success",
                    message= "Adverse event detection completed successfully",
                    results=[
                        {
                                    "adverse_event": {
                                        "found": False,
                                        "confidence": 0
                                    },
                                    "details": None,
                                    "text": "test ae for prod v2 service 3"
                                }
                    ]
                    )
        json = {
            "detailed": True,
            "text": [
                "antacid"
            ]
        }
        
        header = {
            'Content-Type': 'application/json', 
            'Accept': 'application/json',
            'authorization': 'Bearer 00019zOiOl5T3BgXCmZoBa0L1hIP'
        }
        
        async with AsyncClient(app=app, base_url="http://test") as ac:
            response = await ac.post(
                "/aeapi/detect_adverse_events", headers=header, json=json
            )
        print(response.json)
        assert response.status_code == 200

    
        result = client.post('/aeapi/detect_adverse_events',json=json)
        print(result)