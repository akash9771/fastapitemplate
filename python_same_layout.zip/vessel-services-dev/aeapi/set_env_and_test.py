import json
import os
import subprocess
import sys
from base64 import b64decode


if __name__ == "__main__":
    # Determine which branch's secrets to set
    branch_name = os.environ["BRANCH"].upper()

    # GitHub secret data is made available as an environment variable
    github_secrets = json.loads(os.environ["SECRETS"])
    secret_name = f"{os.environ['SECRET_NAME']}_{branch_name}"

    # Set env for testing
    os.environ["SECRET_NAME"] = secret_name
    os.environ[secret_name] = github_secrets[secret_name]

    # Run tests
    sys.exit(subprocess.call(["nosetests", "-c", "tests/nose.cfg"], env=os.environ))
