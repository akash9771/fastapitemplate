# token_validator

token_validator is a Python package that contains handy functions. 
It's main goal, however, is to validate the token.  


## Installation and updating
Use the package manager [pip](https://pip.pypa.io/en/stable/) to install Validator like below. 
Rerun this command to check for and install  updates .
```bash
pip install git+https://github.com/Pfizer/Validator
```

## Usage
Features:
* decorators.token_validation  --> used for validate the token.

#### Demo of some of the features:
```python
from validator.decorators import token_validation


```


