import datetime
import json
import logging
import os

import boto3

logger = logging.getLogger()
logger.setLevel(logging.WARNING)


def datetime_handler(dt: datetime.datetime):
    """Make Python datetime objects JSON serializable"""

    if isinstance(dt, datetime.datetime):
        return dt.isoformat()
    raise TypeError("Failed to parse datetime to iso format")


def remove_task_def_warnings(task_def: dict):
    """Remove fields that are not used by the ECS task definition"""
    task_def.pop("compatibilities")
    task_def.pop("taskDefinitionArn")
    task_def.pop("requiresAttributes")
    task_def.pop("revision")
    task_def.pop("status")
    task_def.pop("registeredAt")
    task_def.pop("registeredBy")


def run() -> str:
    """Securely store GitHub secrets in AWS Secrets Manager"""

    # Determine which branch's secrets to set
    branch_name = os.environ["BRANCH"].upper()

    # GitHub secret data is made available as an environment variable
    github_secrets = json.loads(os.environ["SECRETS"])
    secret_name = f"{os.environ['SECRET_NAME']}_{branch_name}"

    # Search for the secret in AWS Secrets Manager
    client_sm = boto3.client("secretsmanager", region_name=os.environ["AWS_REGION"])
    aws_secret = client_sm.list_secrets(
        Filters=[{"Key": "name", "Values": [secret_name]}]
    )

    # Update or create a new secret in AWS Secrets Manager accordingly
    if aws_secret["SecretList"]:
        logger.warning(f"Updating AWS secret named: {secret_name}")
        client_sm.update_secret(
            SecretId=secret_name, SecretString=github_secrets[secret_name]
        )
    else:
        logger.warning(f"Adding new AWS secret named: {secret_name}")
        client_sm.create_secret(
            Name=secret_name, SecretString=github_secrets[secret_name]
        )

    # Store the ECS task definition
    client_ecs = boto3.client("ecs", region_name=os.environ["AWS_REGION"])
    task_def = client_ecs.describe_task_definition(
        taskDefinition=f"{os.environ['ECS_TASK_FAMILY']}-{branch_name}"
    )["taskDefinition"]
    remove_task_def_warnings(task_def)
    with open("task_definition.json", "w") as file:
        json.dump(
            task_def,
            file,
            default=datetime_handler,
            indent=4,
            sort_keys=True,
        )

    # Return the branch name so it can be reused in the GitHub workflow
    return branch_name


if __name__ == "__main__":
    print(run())
