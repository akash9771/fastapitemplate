import asyncio
from contextlib import asynccontextmanager
import time
from app.bedrock.v1.utils.exception_handler import http_exception_handler
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from app.bedrock.v1.api import router as bedrock_v1
import os
import json
import logging
from fastapi.openapi.utils import get_openapi
from app.bedrock.v1.config import settings

from app.bedrock.v1.utils.env_vars import ENV, REQUEST_TIMEOUT_SECONDS
from app.bedrock.v1.utils.cache_config import redis_client

# OpenTelemetry Configuration
# Basic packages for your application
# Add imports for OTel components into the application
from opentelemetry import trace
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource, get_aggregated_resources
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.sdk.extension.aws.resource import AwsEcsResourceDetector

from opentelemetry.semconv.resource import ResourceAttributes


# Import the AWS X-Ray for OTel Python IDs Generator into the application.
from opentelemetry.sdk.extension.aws.trace import AwsXRayIdGenerator


# Import the AWS X-Ray for OTel Python IDs Generator into the application.
from opentelemetry.sdk.extension.aws.trace import AwsXRayIdGenerator

# Import the httx, requests, boto3 instrumentors
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from opentelemetry.instrumentation.requests import RequestsInstrumentor


# Import the AWS X-Ray propagator into the application
from opentelemetry.propagate import set_global_textmap
from opentelemetry.propagators.aws.aws_xray_propagator import AwsXRayPropagator


logger = logging.getLogger()
logger.setLevel(settings.log_level)

SERVER_ENV = os.environ.get("SERVER_ENV", "dev")
SERVER_REGION = os.environ.get("SERVER_REGION", "us-east-1")

PREFIX_V1 = "/bedrock"
TAGS_METADATA = [
    {
        "name": "Models",
        "description": """Get details of each model - their modality.""",
    },
    {
        "name": "Featured Endpoints",
        "description": """list of services actively supported by vessel.""",
    },
    # {
    #     "name": "Preview",
    #     "description": """List of services in active deployment from vsl or openai""",
    # },
    {
        "name": "Health Check",
        "description": """Use this to know the availability of the vessel's openai service availablity.""",
    },
]

if not os.environ.get("LOCAL_MODE", "False"):
    # Sends generated traces in the OTLP format to an ADOT Collector running on port 4317
    otlp_exporter = OTLPSpanExporter(endpoint="127.0.0.1:4317", insecure=True)
    # Processes traces in batches as opposed to immediately one after the other
    span_processor = BatchSpanProcessor(otlp_exporter)
    # Configures the Global Tracer Provider
    trace.set_tracer_provider(
        TracerProvider(
            active_span_processor=span_processor,
            id_generator=AwsXRayIdGenerator(),
            resource=get_aggregated_resources(
                initial_resource=Resource(
                    attributes={"service.name": f"{ENV}-vsl-bedrock"}
                ),
                detectors=[AwsEcsResourceDetector()],
            ),
        )
    )

    # Set the global propagator to AwsXRayPropagator
    set_global_textmap(AwsXRayPropagator())

    # Instrument httpx
    HTTPXClientInstrumentor().instrument()

    # Instrument requests
    RequestsInstrumentor().instrument()


@asynccontextmanager
async def lifespan(app: FastAPI):
    # start the connection with redis cache
    await redis_client.connect()
    with open("mule_openapi.json", "w") as f:
        openapi_data = get_openapi(
            title=app.title,
            version=app.version,
            openapi_version=app.openapi_version,
            description=app.description,
            routes=app.routes,
            tags=app.openapi_tags,
            contact=app.contact,
            summary=app.summary,
        )

        openapi_data_str = json.dumps(openapi_data)
        openapi_data_str = openapi_data_str.replace(
            "/bedrock/", "/vessel-bedrock-api-v1/"
        )

        # Save the modified data to the file
        f.write(openapi_data_str)
    yield
    # close the connection with redis cache
    await redis_client.close()
    os.remove("mule_openapi.json")


app = FastAPI(
    lifespan=lifespan,
    title=f"Vessel | AWS Bedrock Services | {SERVER_ENV} | {SERVER_REGION}",
    openapi_tags=TAGS_METADATA,
    swagger_ui_parameters={
        "defaultModelsExpandDepth": -1,
        "syntaxHighlight.theme": "tomorrow-night",
        "persistAuthorization": True,
    },
    version="1.1",
    contact={
        "name": "VOX Team",
        "email": "DL-IAS-Platform-Operations@pfizer.com; dl-vox-dev@pfizer.com",
    },
    summary="Access to the AWS Bedrock endpoints.",
    openapi_url=PREFIX_V1 + "/openapi.json",
    docs_url=PREFIX_V1 + "/vsl-docs",
)

if not os.environ.get("LOCAL_MODE", "False"):
    FastAPIInstrumentor.instrument_app(app)

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def timeout_middleware(request: Request, call_next):
    if "/health" not in request.url.path:
        logger.info(f"{request.method}: {request.url.path}")

    url_path = request.url.path
    try:
        start_time = time.time()
        response = await asyncio.wait_for(
            call_next(request), timeout=REQUEST_TIMEOUT_SECONDS
        )

    except asyncio.TimeoutError as exc:
        process_time = time.time() - start_time
        logger.error(f"Human Request Timeout: {process_time} seconds - {url_path}")
        exc.status_code = 408
        return http_exception_handler(exc, request)

    except RuntimeError as exc:
        if await request.is_disconnected() and str(exc) == "No response returned.":
            logger.warning(
                "Error `No response returned` detected. "
                "At the same time we know that the client is disconnected "
                "and not waiting for a response."
                f"Human Request Timeout: {process_time} seconds - {url_path}"
            )
        return http_exception_handler(exc, request)

    except Exception as exc:
        process_time = time.time() - start_time
        logger.error(
            f"Main Exception - Human Request Error: {process_time} seconds - {url_path}"
        )
        exc.status_code = 500
        return http_exception_handler(exc, request)

    else:
        process_time = time.time() - start_time
        if "/health" not in request.url.path:
            logger.info(f"Human Request Complete: {process_time} seconds - {url_path}")
        else:
            logger.info(
                f"Health Check Request Complete: {process_time} seconds - {url_path}"
            )

        return response


app.include_router(bedrock_v1, prefix=PREFIX_V1)
