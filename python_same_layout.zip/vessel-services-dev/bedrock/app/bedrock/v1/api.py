import json
from collections import defaultdict
from typing import List, Literal, Union, Optional
import os
import boto3
from botocore.config import Config
import logging
import random
from itertools import cycle
from fastapi import Request as fastapi_request, Depends, Body
from fastapi import APIRouter, HTTPException
from starlette.responses import JSONResponse
from typing import Union
from app.bedrock.v1.config import settings
from app.bedrock.v1.models import (
    HealthCheckResponse,
    Status,
    Models,
    CompletionRequest1,
    CompletionRequest2,
    CompletionResponse,
    EmbeddingsResponse,
    EmbeddingsRequest,
    ImageRequest,
    ImageResponse,
    ImageRequest,
    ImageResponse,
)
from app.bedrock.v1.utils.env_vars import ENV, MODELS_METADATA
from app.bedrock.v1.utils.audit import audit

from app.bedrock.v1.utils.helper_functions import (
    enabled_model,
    log_error_with_client_id,
    merge_models_metadata,
    actual_model_id,
    valid_model,
    define_model_body,
    define_completion_model_response,
    define_embedding_model_response,
)
from app.bedrock.v1.utils.cache_config import redis_client

from validator.decorators import async_token_validation_and_metering

from fastapi.openapi.docs import get_swagger_ui_html
from fastapi.security.api_key import APIKeyHeader
from app.bedrock.v1.examples import (
    ImageRequestExample,
    completionRequestExample,
    embeddingsRequestExample,
)

access_token_header = APIKeyHeader(
    name="Authorization",
    description="access_token generated from your client-id and client secret. Prefix 'Bearer ' before the token eg: Bearer 123567",
)

router = APIRouter()
logger = logging.getLogger()
logger.setLevel(settings.log_level)

# TODO: Put region in env variable and in secret manager for multi region
aws_region = os.environ.get("AWS_REGION", "")  # picks region from config file (secret)
print("Region name -- ", aws_region)


def bedrock_client(aws_region: str = "us-east-1"):
    # Create connection with bedrock
    try:
        boto3_config = Config(connect_timeout=120, read_timeout=120)
        bedrock = boto3.client(
            service_name="bedrock", region_name=aws_region, config=boto3_config
        )
        logger.info(f"Connected to bedrock in region {aws_region}")
        return bedrock
    except Exception as e:
        logger.error(f"Error in bedrock client in region {aws_region}")
        logger.error(e)
        raise HTTPException(status_code=500, detail="Error in AWS bedrock")


def bedrock_runtime_client(aws_region: str = "us-east-1"):
    # Create connection with bedrock runtime
    try:
        boto3_config = Config(connect_timeout=120, read_timeout=120)
        bedrock_runtime = boto3.client(
            service_name="bedrock-runtime", region_name=aws_region, config=boto3_config
        )
        logger.info(f"Connected to bedrock runtime in region {aws_region}")
        return bedrock_runtime
    except Exception as e:
        logger.error(f"Error in bedrock-runtime client in region {aws_region}")
        logger.error(e)
        raise HTTPException(status_code=500, detail="Error in AWS bedrock")


def get_round_robin_list(client_config, model_id):
    # Define round robin list based on the client config
    try:
        client_config = json.loads(client_config).get("bedrock")
        robin_list = []
        provisioned_list = []
        models_list = []
        for k, v in client_config.get("provisioned").items():
            if model_id in k:
                for region in v:
                    provisioned_list.append({k: region})
        for k, v in client_config.get("models").items():
            if model_id == k:
                for region in v:
                    models_list.append({k: region})
        robin_list.extend(provisioned_list)
        random.shuffle(models_list)
        robin_list.extend(models_list)
        return robin_list
    except Exception as e:
        logger.error(f"Error in defining round robin list for model {model_id}")
        logger.error(e)
        return []


def load_balance_from_cache_config(body, round_robin_list):
    # Failover and load balance between bedrock runtime regions using round robin and max tries of 6
    max_tries = 6
    try_count = 0
    # Load balance bedrock runtime
    while try_count < max_tries:
        region = next(round_robin_list)
        try:
            region_model = list(region.keys())[0]
            region_name = list(region.values())[0]
            bedrock_runtime_region = bedrock_runtime_client(region_name)
            logger.warning(f"Invoking bedrock runtime in region {region_name}")
            response = bedrock_runtime_region.invoke_model(
                body=body, modelId=region_model
            )
            return response
        except Exception as e:
            logger.error(f"Error in bedrock-runtime client in region {region_name}")
            logger.error(e)
        try_count += 1
    logger.error("No response from all bedrock runtimes")
    raise Exception("Error in AWS bedrock")


async def read_cache_configuration_for_client(request):
    client_id = request.headers.get("x-agw-client_id", None)
    # Read cache configuration for client id
    client_config = await redis_client.redis.get(f"{ENV}-vsl-failover-lb:{client_id}")

    if not client_config:
        logger.warning(
            f"Client: {client_id} | Endpoint: {request.url.path} | Warning: No client config found in cache. Reading default config for all clients"
        )
        # Read default cache configuration for all clients
        default_config = await redis_client.redis.get(f"{ENV}-vsl-failover-lb:default")
        if default_config:
            return default_config
        else:
            logger.warning(
                f"Client: {client_id} | Endpoint: {request.url.path} | Warning: No default config found in cache. Continuing without load balancing"
            )
            return None
    return client_config


# Health check
@router.get(
    "/health",
    status_code=200,
    tags=["Health Check"],
)
async def health_check():
    return HealthCheckResponse(status=Status.success, message="Healthy")


@router.get("/mule_openapi.json", include_in_schema=False)
async def openapijson():
    with open("mule_openapi.json", "r") as openapifile:
        data = json.loads(openapifile.read())
    return data


@router.get("/docs", include_in_schema=False)
async def documentation():
    SERVER_ENV = os.environ.get("SERVER_ENV", "dev")
    SERVER_REGION = os.environ.get("SERVER_REGION", "us-east-1")

    region_mapping = {
        "eu-central-1": "emea",
        "us-east-1": "amer",
    }

    env_mapping = {
        "test": "-stg",
        "prod": "",
    }

    SERVER_REGION = region_mapping.get(SERVER_REGION, "amer")
    SERVER_ENV = env_mapping.get(SERVER_ENV, "-dev")

    openapi_url = f"https://mule4api-comm-{SERVER_REGION}{SERVER_ENV}.pfizer.com/vessel-bedrock-api-v1/mule_openapi.json"

    return get_swagger_ui_html(
        # openapi_url="http://localhost:8000/bedrock/mule_openapi.json",
        openapi_url=openapi_url,
        title=f"{SERVER_ENV} - IAS - Vessel",
    )


@router.get(
    "/models",
    status_code=200,
    tags=["Models"],
    summary="Lists all the available bedrock models",
    response_model=List[Models],
)
@router.get(
    "/models/{modality}",
    status_code=200,
    tags=["Models"],
    summary="Lists all the available bedrock models based on the modality",
    response_model=List[Models],
)
@async_token_validation_and_metering()
async def models(
    request: fastapi_request,
    modality: Optional[
        Union[Literal["chat", "completion", "embeddings", "image"], None]
    ] = None,
    access_key=Depends(access_token_header),
):
    try:
        # Get all foundation models
        response = bedrock_client(aws_region).list_foundation_models()

        # Structure response
        foundation_models = response.get("modelSummaries")
        models = map(
            lambda d: dict(
                {
                    "id": d.get("modelId"),
                    "model": d.get("modelName"),
                    "provider": d.get("providerName"),
                    "input_modalities": d.get("inputModalities"),
                    "output_modalities": d.get("outputModalities"),
                    "response_streaming_support": d.get(
                        "responseStreamingSupported", False
                    ),
                }
            ),
            foundation_models,
        )

        # Get models metadata
        metadata = MODELS_METADATA

        models_w_metadata = merge_models_metadata(list(models), metadata)

        # Allow all models in dev environment, only models with enabled flag in test and prod
        if ENV in ["test", "prod"]:
            models_w_metadata = [
                model for model in models_w_metadata if model.get("enabled")
            ]

        if modality:
            models_modality = [
                model for model in models_w_metadata if model.get(modality)
            ]
            return models_modality

        return models_w_metadata
    except Exception as e:
        status_code = e.http_status if hasattr(e, "http_status") else 500
        error_text = str(e)
        # Log error with client id if exists
        logger.error(
            log_error_with_client_id(
                request.headers.get("x-agw-client_id", None),
                request.url.path,
                error_text,
            )
        )
        raise HTTPException(
            status_code=status_code, detail=f"Models Error: {error_text}"
        )


@router.post(
    "/completion",
    status_code=200,
    tags=["Featured Endpoints"],
    summary="Completion inference using bedrock foundation models",
    response_model=CompletionResponse,
)
@audit()
@async_token_validation_and_metering(uom=6)
async def completion(
    request: fastapi_request,
    req: Union[CompletionRequest1, CompletionRequest2] = Body(
        openapi_examples=completionRequestExample
    ),
    access_key=Depends(access_token_header),
):
    try:
        model_id = req.model
        if not valid_model(model_id, MODELS_METADATA, "completion") and not valid_model(
            model_id, MODELS_METADATA, "chat"
        ):
            error_message = (
                f"Model {model_id} is not supported for completion operation"
            )
            # Log error with client id if exists
            logger.error(
                log_error_with_client_id(
                    request.headers.get("x-agw-client_id", None),
                    request.url.path,
                    error_message,
                )
            )
            return JSONResponse(
                status_code=400,
                content={"status": Status.failure, "detail": error_message},
            )
        # Allow all models in dev environment, only models with enabled flag in test and prod
        if ENV in ["test", "prod"]:
            if not enabled_model(model_id, MODELS_METADATA):
                error_message = f"Model {model_id} is not enabled yet"
                # Log error with client id if exists
                logger.error(
                    log_error_with_client_id(
                        request.headers.get("x-agw-client_id", None),
                        request.url.path,
                        error_message,
                    )
                )
                return JSONResponse(
                    status_code=400,
                    content={"status": Status.failure, "detail": error_message},
                )
        # now since all validations are done get the actual model name if there is any alteration done
        model_id = actual_model_id(req.model)

        body = await define_model_body(model_id, req)
        if not body:
            error_message = (
                f"Model {model_id} is not supported for completion operation"
            )
            # Log error with client id if exists
            logger.error(
                log_error_with_client_id(
                    request.headers.get("x-agw-client_id", None),
                    request.url.path,
                    error_message,
                )
            )
            return JSONResponse(
                status_code=400,
                content={"status": Status.failure, "detail": error_message},
            )
        # Read cache configuration for client id
        client_config = await read_cache_configuration_for_client(request)

        # Define round robin list based on the client config if exists
        robin_list = (
            get_round_robin_list(client_config, model_id) if client_config else []
        )

        # Load balance if round robin list exists. Otherwise, invoke bedrock runtime with the region defined in env variable
        load_balance = True if len(robin_list) > 0 else False
        response = (
            load_balance_from_cache_config(
                body=body, round_robin_list=cycle(robin_list)
            )
            if load_balance
            else bedrock_runtime_client(aws_region).invoke_model(
                body=body, modelId=model_id
            )
        )
        (
            completion_tokens,
            prompt_tokens,
            text_completion,
            total_tokens,
        ) = await define_completion_model_response(model_id, body, response)

        return CompletionResponse(
            status=Status.success,
            result=text_completion,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
        )
    except Exception as e:
        status_code = e.http_status if hasattr(e, "http_status") else 500
        error_text = str(e)
        # Log error with client id if exists
        logger.error(
            log_error_with_client_id(
                request.headers.get("x-agw-client_id", None),
                request.url.path,
                error_text,
            )
        )
        raise HTTPException(
            status_code=status_code, detail=f"Completion Error: {error_text}"
        )


@router.post(
    "/embeddings",
    status_code=200,
    tags=["Featured Endpoints"],
    summary="Embeddings creation using bedrock foundation models",
    response_model=EmbeddingsResponse,
)
@audit()
@async_token_validation_and_metering(uom=6)
async def embeddings(
    request: fastapi_request,
    req: EmbeddingsRequest = Body(openapi_examples=embeddingsRequestExample),
    access_key=Depends(access_token_header),
):
    try:
        model_id = req.model
        if not valid_model(model_id, MODELS_METADATA, "embeddings"):
            error_message = (
                f"Model {model_id} is not supported for embeddings operation"
            )
            # Log error with client id if exists
            logger.error(
                log_error_with_client_id(
                    request.headers.get("x-agw-client_id", None),
                    request.url.path,
                    error_message,
                )
            )
            return JSONResponse(
                status_code=400,
                content={"status": Status.failure, "detail": error_message},
            )
        # Allow all models in dev environment, only models with enabled flag in test and prod
        if ENV in ["test", "prod"]:
            if not enabled_model(model_id, MODELS_METADATA):
                error_message = f"Model {model_id} is not enabled yet"
                # Log error with client id if exists
                logger.error(
                    log_error_with_client_id(
                        request.headers.get("x-agw-client_id", None),
                        request.url.path,
                        error_message,
                    )
                )
                return JSONResponse(
                    status_code=400,
                    content={"status": Status.failure, "detail": error_message},
                )
        body = json.dumps({"inputText": req.prompt})
        # Read cache configuration for client id
        client_config = await read_cache_configuration_for_client(request)

        # Define round robin list based on the client config if exists
        robin_list = (
            get_round_robin_list(client_config, model_id) if client_config else []
        )

        # Load balance if round robin list exists. Otherwise, invoke bedrock runtime with the region defined in env variable
        load_balance = True if len(robin_list) > 0 else False
        response = (
            load_balance_from_cache_config(
                body=body, round_robin_list=cycle(robin_list)
            )
            if load_balance
            else bedrock_runtime_client(aws_region).invoke_model(
                body=body, modelId=model_id
            )
        )
        embedding, prompt_tokens, total_tokens = await define_embedding_model_response(
            response
        )
        return EmbeddingsResponse(
            status=Status.success,
            embedding=embedding,
            prompt_tokens=prompt_tokens,
            total_tokens=total_tokens,
        )
    except Exception as e:
        status_code = e.http_status if hasattr(e, "http_status") else 500
        error_text = str(e)
        # Log error with client id if exists
        logger.error(
            log_error_with_client_id(
                request.headers.get("x-agw-client_id", None),
                request.url.path,
                error_text,
            )
        )
        raise HTTPException(
            status_code=status_code, detail=f"Embeddings Error: {error_text}"
        )


@router.post(
    "/image",
    status_code=200,
    tags=["Featured Endpoints"],
    summary="Image creation using bedrock foundation models",
    response_model=ImageResponse,
)
@async_token_validation_and_metering()
async def image(
    request: fastapi_request,
    req: ImageRequest = Body(openapi_examples=ImageRequestExample),
    access_key=Depends(access_token_header),
):
    try:
        model_id = req.model
        if not valid_model(model_id, MODELS_METADATA, "image"):
            error_message = f"Model {model_id} is not supported for image generation"
            # Log error with client id if exists
            logger.error(
                log_error_with_client_id(
                    request.headers.get("x-agw-client_id", None),
                    request.url.path,
                    error_message,
                )
            )
            return JSONResponse(
                status_code=400,
                content={"status": Status.failure, "detail": error_message},
            )
        # Allow all models in dev environment, only models with enabled flag in test and prod
        if ENV in ["test", "prod"]:
            if not enabled_model(model_id, MODELS_METADATA):
                error_message = f"Model {model_id} is not enabled yet"
                # Log error with client id if exists
                logger.error(
                    log_error_with_client_id(
                        request.headers.get("x-agw-client_id", None),
                        request.url.path,
                        error_message,
                    )
                )
                return JSONResponse(
                    status_code=400,
                    content={"status": Status.failure, "detail": error_message},
                )
        body = json.dumps(
            {
                "text_prompts": [{"text": req.prompt}],
                "cfg_scale": req.cfg_scale,
                "seed": req.seed,
                "steps": req.generation_steps,
                "style_preset": req.style_preset,
            }
        )

        response = bedrock_runtime_client(aws_region).invoke_model(
            body=body, modelId=model_id
        )
        response_body = json.loads(response.get("body").read())
        base_64_img_str = response_body["artifacts"][0].get("base64")
        return ImageResponse(status=Status.success, image=base_64_img_str)
    except Exception as e:
        status_code = e.http_status if hasattr(e, "http_status") else 500
        error_text = str(e)
        # Log error with client id if exists
        logger.error(
            log_error_with_client_id(
                request.headers.get("x-agw-client_id", None),
                request.url.path,
                error_text,
            )
        )
        raise HTTPException(
            status_code=status_code, detail=f"Image Error: {error_text}"
        )
