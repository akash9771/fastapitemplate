import logging
import os

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    log_level: int = logging.WARNING


settings = Settings()
