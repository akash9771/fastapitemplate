import json
import os
from anthropic import Anthropic
import logging

logger = logging.getLogger()
# Antropic official client which is used for counting tokens
anthropic_client = Anthropic()

# Based on Anthropic documentation this is how they handle context
ANTHROPIC_HUMAN = "\n\nHuman:"
ANTHROPIC_ASSISTANT = "\n\nAssistant:"


def get_model_id_mapping(reverse=False):
    model_name_mappings_data = {
        "anthropic.claude-3-haiku-v1:0": "anthropic.claude-3-haiku-20240307-v1:0",
        "anthropic.claude-3-sonnet-v1:0": "anthropic.claude-3-sonnet-20240229-v1:0",
        # Add more mappings here
    }
    model_name_mappings_str = os.getenv(
        "BEDROCK_MODEL_NAME_MAPPINGS", json.dumps(model_name_mappings_data)
    )
    model_name_mappings = json.loads(model_name_mappings_str)

    if reverse:
        model_name_mappings = {v: k for k, v in model_name_mappings.items()}

    return model_name_mappings


def actual_model_id(model_id, reverse=False):

    model_name_mappings = get_model_id_mapping(reverse)

    if model_id in model_name_mappings:
        return model_name_mappings[model_id]

    return model_id  # return original if no mapping found


def merge_models_metadata(models, metadata):
    # Helper function. Gets 2 lists of deployed models and metadata and merges their data

    # Here the reverse operation is done in order to map the bedrock id vs the vsl used id.
    vessel_models_dict = {}
    models_dict = {
        actual_model_id(model["id"], reverse=True): model for model in models
    }
    for data in metadata:
        if data["id"] in models_dict:
            vessel_models_dict[data["id"]] = models_dict[data["id"]]
            vessel_models_dict[data["id"]].update(data)

    return list(vessel_models_dict.values())


async def define_completion_model_response(model_id, body, response):
    response_body = json.loads(response.get("body").read())

    ### FOR CLAUDE-v3
    if model_id.startswith("anthropic.claude-3"):
        text_completion = response_body["content"][0]["text"]
        prompt_tokens = response_body["usage"]["input_tokens"]
        logger.error(prompt_tokens)
        completion_tokens = response_body["usage"]["output_tokens"]
        logger.error(completion_tokens)

    elif model_id.startswith("amazon"):
        text_completion = response_body.get("results")[0].get("outputText")
        prompt_tokens = response_body["inputTextTokenCount"]
        completion_tokens = response_body["results"][0]["tokenCount"]
    elif model_id.startswith("anthropic"):
        text_completion = response_body.get("completion")
        prompt_tokens = anthropic_client.count_tokens(json.loads(body).get("prompt"))
        completion_tokens = anthropic_client.count_tokens(
            response_body.get("completion")
        )
    elif model_id.startswith("ai21"):
        text_completion = response_body.get("completions")[0].get("data").get("text")
        prompt_tokens = len(
            response_body["prompt"]["tokens"]
        )  # TODO: find out how tokens are counted for ai21
        completion_tokens = len(
            response_body["completions"][0]["data"]["tokens"]
        )  # TODO: find out how tokens are counted for ai21
    elif model_id.startswith("cohere"):
        text_completion = response_body.get("generations")[0].get("text")
        prompt_tokens = (
            0  # TODO: find out how we can distinguish prompt and completion tokens
        )
        completion_tokens = len(
            response_body.get("generations")[0].get("token_likelihoods")
        )
    elif model_id.startswith("meta"):
        text_completion = response_body.get("generation")
        prompt_tokens = response_body.get("prompt_token_count")
        completion_tokens = response_body.get("generation_token_count")
    total_tokens = int(prompt_tokens) + int(completion_tokens)

    return completion_tokens, prompt_tokens, text_completion, total_tokens


async def define_embedding_model_response(response):
    response_body = json.loads(response.get("body").read())
    embedding = response_body.get("embedding")
    prompt_tokens = response_body["inputTextTokenCount"]
    total_tokens = prompt_tokens
    return embedding, prompt_tokens, total_tokens


async def anthropic_completion_body(request, model_id=None):
    # # Append necessary prefix if missing
    if model_id.startswith("anthropic.claude-3"):
        keys_to_include = [
            "anthropic_version",
            "max_tokens",
            "messages",
            "stop_sequences",
            "temperature",
            "top_p",
            "top_k",
        ]
        data = {
            key: getattr(request, key)
            for key in keys_to_include
            if getattr(request, key) is not None
        }
        # Find system message and remove it
        system_msg = next(
            (msg for msg in data["messages"] if msg["role"] == "system"), None
        )
        if system_msg:
            data["messages"].remove(system_msg)
            data["system"] = system_msg["content"]
        return json.dumps(data)

    # if not request.prompt.startswith(ANTHROPIC_HUMAN):
    #     request.prompt = f"{ANTHROPIC_HUMAN}{request.prompt}"
    # Append necessary suffix if missing
    if not request.prompt.endswith(ANTHROPIC_ASSISTANT):
        request.prompt = f"{request.prompt}{ANTHROPIC_ASSISTANT}"
    # Structure anthropic body
    body = json.dumps(
        {
            "prompt": request.prompt,
            "max_tokens_to_sample": request.max_tokens,
            "temperature": request.temperature,
        }
    )

    return body


async def define_model_body(model_id, request):
    # Define the necessary payload per provider
    if model_id.startswith("amazon"):
        body = json.dumps(
            {
                "inputText": request.prompt,
                "textGenerationConfig": {
                    "maxTokenCount": request.max_tokens,
                    "stopSequences": ["User:"],
                    "temperature": request.temperature,
                },
            }
        )
    elif model_id.startswith("anthropic"):
        body = await anthropic_completion_body(request, model_id=model_id)
    elif model_id.startswith("ai21"):
        body = json.dumps(
            {
                "prompt": request.prompt,
                "maxTokens": request.max_tokens,
                "temperature": request.temperature,
            }
        )
    elif model_id.startswith("cohere"):
        body = json.dumps(
            {
                "prompt": request.prompt,
                "max_tokens": request.max_tokens,
                "temperature": request.temperature,
                "return_likelihoods": "ALL",
            }
        )
    elif model_id.startswith("meta"):
        body = json.dumps(
            {
                "prompt": request.prompt,
                "max_gen_len": request.max_tokens,
                "temperature": request.temperature,
                # "top_p"
            }
        )
    else:
        return None
    return body


def valid_model(model_id, metadata, modality):
    # Checks if given model id exists and is allowed for use for a specific operation
    if not any(model["id"] == model_id and model.get(modality) for model in metadata):
        return False
    return True


def enabled_model(model_id, metadata):
    # Checks if given model id exists and is enabled
    if not any(model["id"] == model_id and model.get("enabled") for model in metadata):
        return False
    return True


def log_error_with_client_id(client_id, endpoint, error_message):
    # Helper function to log errors with client id
    return f"Client: {client_id} | Endpoint: {endpoint} | Error: {error_message}"
