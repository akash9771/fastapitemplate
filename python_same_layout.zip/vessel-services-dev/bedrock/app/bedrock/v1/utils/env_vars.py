import json
import os

MODELS_METADATA = json.load(open("app/bedrock/v1/utils/models-metadata.json"))
REQUEST_TIMEOUT_SECONDS = 220

ENV = os.environ.get("ENV", "dev")
REDIS_HOST_PORT = os.environ.get("REDIS_HOST_PORT")
REDIS_PASSWORD = os.environ.get("REDIS_PASSWORD")
