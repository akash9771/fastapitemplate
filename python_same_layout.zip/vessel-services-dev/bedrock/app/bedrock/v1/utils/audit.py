import datetime
from functools import wraps
import json
import boto3
import os
import logging
import uuid

from app.bedrock.v1.config import settings

logger = logging.getLogger()
logger.setLevel(settings.log_level)
AUDIT_SNS = os.getenv("AUDIT_SNS", "")
AUDIT_EXCLUSION = os.getenv("AUDIT_EXCLUSION_LIST", "")


async def send_to_sns(message):
    """
    Send message to SNS.
    """
    # Try to publish message to the SNS queue
    try:
        # serialize the msg dict to json string
        message_string = json.dumps(message)

        sns_client = boto3.client("sns", region_name="us-east-1")
        # publish the message
        response = sns_client.publish(
            TopicArn=AUDIT_SNS,
            Message=message_string,
            MessageStructure="string",
            MessageDeduplicationId=message["request_id"],
            MessageGroupId="bedrock",
        )
        print("Response is: ", response)
    # Log any errors that occur while trying to send the message
    except Exception as e:
        logger.error(f"Error while sending message to SNS {AUDIT_SNS}: {str(e)}")


async def prepare_payload(request, response, headers, url):
    # try:
    # checking if api call is for embedding then exclude the response from payload
    print("Splittttt : ", url.path.split("/")[-1])
    if url.path.split("/")[-1] == "embeddings":
        final_payload = {
            "request_id": str(uuid.uuid4()),
            "api_id": headers.get("x_agw_api_id"),
            "client_id": headers.get("x-agw-client_id"),
            "request_time": headers.get("x_agw_request_time"),
            "correlation - id": headers.get("x-correlation-id"),
            "endpoint": url.path.split("/")[-1],
            "request": request,
        }
        print("FInal payload from Util---- ", final_payload)
        return final_payload
    else:
        final_payload = {
            "request_id": str(uuid.uuid4()),
            "api_id": headers.get("x_agw_api_id"),
            "client_id": headers.get("x-agw-client_id"),
            "request_time": headers.get("x_agw_request_time"),
            "correlation - id": headers.get("x-correlation-id"),
            "endpoint": url.path.split("/")[-1],
            "request": request,
            "response": response.json(),
        }
        print("FInal payload from Audit---- ", final_payload)
        return final_payload
    # except Exception as e:
    #     logger.error(f"Error preparing final payload: {str(e)}")

    # return final_payload


def audit():
    def decorator(func):
        @wraps(func)
        async def wrapper(request=None, *args, **kwargs):
            header = request.headers
            if request:
                res = await func(request, *args, **kwargs)

            else:
                res = await func(*args, **kwargs)

            # skip audit if status_code is not 200 i.e if the LLM hasnt responded successfully
            if hasattr(res, "status_code") and res.status_code != 200:
                return res

            json_body = await request.json()
            AUDIT_EXCLUSION_LIST = AUDIT_EXCLUSION.strip("[]")
            AUDIT_EXCLUSION_LIST = AUDIT_EXCLUSION_LIST.split(", ")

            # Here checking client id is present in AUDIT_EXCLUSION_LIST or not
            if header.get("x-agw-client_id") in AUDIT_EXCLUSION_LIST:
                pass
            elif (
                "x_agw_api_id" not in header
                or "x-agw-client_id" not in header
                or "x-correlation-id" not in header
            ):
                pass
            else:
                # Prepare the payload for the SNS message
                final_payload = await prepare_payload(
                    json_body, res, request.headers, request.url
                )

                # Send prepared payload to SNS
                await send_to_sns(final_payload)

            return res

        return wrapper

    return decorator
