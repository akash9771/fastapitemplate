import logging
import traceback
from app.bedrock.v1.config import settings
from fastapi import Request
from fastapi.responses import JSONResponse

logger = logging.getLogger()
logger.setLevel(settings.log_level)


def get_client_id(request):
    client_id = (
        request.headers.get("x-agw-client_id")
        if request.headers.get("x-agw-client_id") is not None
        else None
    )
    return client_id


def http_exception_handler(exc, request=None):
    # Handle HTTP exceptions raised by your application
    # Log or handle the exception as required

    url_path = ""
    client_id = None

    if request:
        url_path = request.url.path
        client_id = get_client_id(request)

    status_code = (
        exc.response.status_code
        if hasattr(exc, "response") and hasattr(exc.response, "status_code")
        else 500
    )
    error_text = (
        str(exc.response.text)
        if hasattr(exc, "response") and hasattr(exc.response, "text")
        else str(exc)
    )

    logger.error(
        f"| Client: {client_id} | Endpoint: {url_path} | error_type={type(exc).__name__} | status_code={status_code} | error_text={error_text} | stack_trace={traceback.format_exc()} |"
    )

    # Return an appropriate response
    return JSONResponse(
        status_code=status_code,
        content={
            "status_code": status_code,
            "status": "failure",
            "message": f"Error: {error_text} | Error Code: {status_code}",
        },
    )
