import logging
from redis import asyncio as aioredis
from redis.asyncio.cluster import RedisCluster
from redis.exceptions import RedisClusterException
import asyncio

from app.bedrock.v1.utils.env_vars import REDIS_HOST_PORT, REDIS_PASSWORD


logger = logging.getLogger()
logger.setLevel(logging.INFO)


class RedisClient:
    def __init__(
        self,
        host_port=REDIS_HOST_PORT,
        password=REDIS_PASSWORD,
        encoding="utf8",
        decode_responses=True,
    ):
        self.host_port = host_port
        self.password = password
        self.encoding = encoding
        self.decode_responses = decode_responses
        self.redis = None

    async def connect(self):
        try:
            self.redis = await RedisCluster.from_url(
                f"{self.host_port}",
                password=self.password,
                encoding=self.encoding,
                decode_responses=self.decode_responses,
            )
            pong = await asyncio.wait_for(self.redis.ping(), timeout=5)
            logger.info(f"Connected to Redis: {pong}")
        except RedisClusterException as e:
            logger.warning(
                "Cluster mode is not enabled on this redis - trying standard mode"
            )
            self.redis = await aioredis.from_url(
                f"{self.host_port}",
                password=self.password,
                encoding=self.encoding,
                decode_responses=self.decode_responses,
            )
            pong = await asyncio.wait_for(self.redis.ping(), timeout=5)
            logger.info(f"Connected to Redis: {pong}")
        except asyncio.TimeoutError:
            logger.error("Connection to Redis timed out")
            raise
        except Exception as e:
            logger.error(f"Failed connecting to Redis: {str(e)}")
            raise

    async def close(self):
        if self.redis:
            await self.redis.close()
            self.redis = None


redis_client = RedisClient()
